import express, { Application, Request, Response } from "express";
import { connect, set, connection } from 'mongoose';
import router from './routes/index';
import dotenv from 'dotenv';
import cors from 'cors';
import http from 'http';
import path from "path";
import { SetSessionService } from "./utils/set-sessions";
import morgan from 'morgan';
import {createStream} from "rotating-file-stream";
import CRONJob from "./utils/job";
import UserService from "./services/user-service";
import BookService from "./services/book-service";
import SubBookService from "./services/sub-book-service";
import AccessModuleService from "./services/access-module-service";
import AccessOptionService from "./services/access-option-service";
import AccessMenuService from "./services/access-menu-service";
import AccountsGroupService from "./services/accounts-group-service";
dotenv.config();

process.env.TZ = 'Asia/Kolkata';
const port = process.env.PORT;
const app: Application = express();
connect(`mongodb://localhost:27017`, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
  dbName: process.env.DB
});
set('useNewUrlParser', true);
set('useFindAndModify', false);
set('useCreateIndex', true);
app.use(cors());
app.use(express.json())
app.use(express.urlencoded({ extended: true }))
app.use(SetSessionService);


async function init(){
  let bookservice=new BookService();
  let userservice=new UserService();
  let subbookservice = new SubBookService();
  let accessmodule = new AccessModuleService();
  let accessoption = new AccessOptionService();
  let accessmenu = new AccessMenuService();
  let accounts = new AccountsGroupService();

  await accessmodule.init();
  await accessoption.init();
  await accessmenu.init();
  await accounts.init();

  await bookservice.init();
  await subbookservice.init();
  await userservice.insertData();
}
init();


var accessLogStream = createStream('access.log', {
  interval: '1d', // rotate daily
  path: path.join(`${__dirname}/../`, 'log')
})

CRONJob();
app.use(morgan('combined', { stream: accessLogStream }))
connection.on('error', console.error.bind(console, 'connection error:'));
connection.once('open', function () {
  console.log("connected to db"+port);
});
app.use(router)
http.createServer(app).listen(port);