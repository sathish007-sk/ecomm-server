import { Request, Response} from "express";
import StockService from "../services/stock-service";
export default async (req:Request,res:Response)=>{
    try {     
        let service=new StockService();
        res.json(await service.getData()); 
        
    } catch (error:any) {
        res.json({success:false,message:error.message});
    }

}
