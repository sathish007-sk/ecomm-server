import { Router} from "express";
import TdsSlabService from "../services/tds-slab-service";
import { CommonRoutes } from "../utils/common-route";
let routes=new CommonRoutes();
routes.service=TdsSlabService;
const tdsController = Router();
tdsController.get('/', routes.list)
.get('/:id', routes.retrieve)
.post('/', routes.add)
.put('/:id', routes.update) 
.delete('/:id', routes.delete);
export default tdsController;