import { Router,Request,Response} from "express";
import TcsSlabService from "../services/tcs-slab-service";
import TdsSlabService from "../services/tds-slab-service";
const SlabController = Router();
SlabController.get('/tds',async (req:Request,res:Response)=>{
    try {
        let service =  new TdsSlabService();
        res.json(await service.getSlab())
    } catch (error:any) {
        res.json({success:false,message:error.message})
    }
})
.get('/tcs',async (req:Request,res:Response)=>{
    try {
        let service =  new TcsSlabService();
        res.json(await service.getSlab())
    } catch (error:any) {
        res.json({success:false,message:error.message})
    }
})
export default SlabController;