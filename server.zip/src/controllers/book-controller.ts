import { Router,Request, Response } from "express";
import bookModel from '../models/book-model';
const  app = Router(); 
app.get('/', async (req:Request, res:Response) => {
    try {
        let data=await bookModel.findOne();
        res.json(data);
    } catch (error:any) {
        res.json({success:false,message:error.message});
    }
}).post('/',async (req:Request, res:Response) => {
    try {
        let check=await bookModel.findOne();
        if(check){
            await bookModel.findByIdAndUpdate(check._id,{
                code: req.body.code?.trim(),
                name: req.body.name?.trim(),
            })
        }
        else{
            await bookModel.create({
                code: req.body.code?.trim(),
                name: req.body.name?.trim(),
            })
        }
        res.json({ success: true, message: 'Saved successfully' });
    } catch (error:any) {
        res.json({success:false,message:error.message});
    }
});
export default app;