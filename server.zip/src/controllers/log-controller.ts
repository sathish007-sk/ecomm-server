import { Router,Request,Response} from "express";
import LogService from "../logging";


const logController = Router();
logController.get('/file-list', async(req:Request,res:Response)=>{
    try {
       let service=new LogService();
       res.json(service.listFile());
    } catch (error:any) {
        res.json({success:false,message:error.message})
    }
}).get('/read-file/:file', async(req:Request,res:Response)=>{
    try {
       let service=new LogService();
       res.json(service.readFile(req.params.file));
    } catch (error:any) {
        res.json({success:false,message:error.message})
    }
});
export default logController;
