import { Request, Response, Router } from "express";
import PartyService from "../services/party-service";
import PrintService from "../services/print-service";
import { PurchaseService } from "../services/purchase-service";
import { salesService } from "../services/sales-service";
import  VoucherService  from "../services/voucher-service";
import ejs from "ejs";
import path from "path";
import html_to_pdf, { CreateOptions } from "html-pdf";
import MetalOutstandingService from "../services/metal-outstanding-service";
import LedgerService from "../services/ledger-service";
import { MaterialTransferService } from "../services/material-transfer-service";
import { MetalReturnService } from "../services/metal-return-service";



const printController = Router();
printController.get('/amount', async (req: Request, res: Response) => {
    try {
        let party_id: string = String(req.query.party_id);
        let date = new Date();
        if (req.query.date) date = new Date(String(req.query.date));
        
        let partyservice = new PartyService();
        let party = await partyservice.retrieveById(party_id)
        let service = new PrintService();
        let data = await service.print(party_id, date);
        
        let resultP = await ejs.renderFile(path.join(__dirname, '/../', 'views', 'print-outstanding.ejs'), {
            party: party,
            date: date?.toLocaleString('en-IN',{dateStyle:'medium'}),
            data: data,
        }, {});
        
        

        let options: CreateOptions = { format:'A5' };

        html_to_pdf.create(resultP, options).toBuffer((err, pdfBuffer) => {
            if (!err) {
                res.header('content-type', 'application/pdf');
                res.send(pdfBuffer);
            }
            else {
                console.log(err);
                
                res.send({ success: false, message: err.message });
            }
        });
    } catch (error: any) {   
        res.send({ success: false, message: error.message });
    }
}).get('/metal', async (req: Request, res: Response) => {
    try {
        let service=new MetalOutstandingService();
        let party_id: string = String(req.query.party_id);
        let date = new Date();
        if (req.query.date) date = new Date(String(req.query.date));
      
        let data=await service.getOutStandingList(party_id,date);
        let partyservice = new PartyService();
        let party = await partyservice.retrieveById(party_id)
       
        let resultP = await ejs.renderFile(path.join(__dirname, '/../', 'views', 'print-metal-outstanding.ejs'), {
            party_name: party.print_name,
            date: date?.toLocaleString('en-IN',{dateStyle:'medium'}),
            data: data,
            
        }, {});
        let options: CreateOptions = { format:'A5' };
        html_to_pdf.create(resultP, options).toBuffer((err, pdfBuffer) => {
            if (!err) {
                res.header('content-type', 'application/pdf');
                res.send(pdfBuffer);
            }
            else {
                res.send({ success: false, message: err.message });
            }
        });
    } catch (error: any) {       
        res.send({ success: false, message: error.message });
    }
}).get('/sales/:id', async (req: Request, res: Response) => {
    try {
        let service=new salesService(); 
        let partyservice = new PartyService();
        let voucherservice = new VoucherService();
        let ledgerservice=new LedgerService();

        let data=await service.retrieveById(req.params.id);        
        let ledger=await ledgerservice.getPartyLedger(data.party_id);
        let ob=await voucherservice.closingBalance(data.invoice_date,ledger._id);
        let party = await partyservice.retrieveById(data.party_id)       
        let date=new Date(data.invoice_date);
        
        let resultP = await ejs.renderFile(path.join(__dirname, '/../', 'views', 'sales.ejs'), {
            party: party,
            date: date?.toLocaleString('en-IN',{dateStyle:'medium'}),
            data: data,
            ob:ob.length>0?ob[0].closing:0,
            
        }, {});

        let options: CreateOptions = { format:'A5' };
        html_to_pdf.create(resultP, options).toBuffer((err, pdfBuffer) => {
            if (!err) {
                res.header('content-type', 'application/pdf');
                res.send(pdfBuffer);
            }
            else {
                res.send({ success: false, message: err.message });
            }
        });


    } catch (error: any) {
        res.send({ success: false, message: error.message }); 
    }
    
}).get('/purchase/:id', async (req: Request, res: Response) => {
    try {
        let service=new PurchaseService(); 
        let partyservice = new PartyService();
        let voucherservice = new VoucherService();
        let ledgerservice=new LedgerService();

        let data=await service.retrieveById(req.params.id);
        
        let ledger=await ledgerservice.getPartyLedger(data.party_id);
        let ob=await voucherservice.closingBalance(data.invoice_date,ledger._id);
        let party = await partyservice.retrieveById(data.party_id)
        let date=new Date(data.invoice_date);
        
        let resultP = await ejs.renderFile(path.join(__dirname, '/../', 'views', 'purchase.ejs'), {
            party: party,
            date: date.toLocaleString('en-IN',{dateStyle:'medium'}),
            data: data,
            ob:ob.length>0?ob[0].closing:0,
            
        }, {});

        let options: CreateOptions = { format:'A5' };
        html_to_pdf.create(resultP, options).toBuffer((err, pdfBuffer) => {
            if (!err) {
                res.header('content-type', 'application/pdf');
                res.send(pdfBuffer);
            }
            else {
                res.send({ success: false, message: err.message });
            }
        });


    } catch (error: any) {
        res.send({ success: false, message: error.message }); 
    }
    
}).get('/metal-transfer/:id', async (req: Request, res: Response) => {
    try {
        let service=new MaterialTransferService(); 
        let partyservice = new PartyService();
        let metalservice = new MetalOutstandingService();
        let ledgerservice=new LedgerService();
        let voucherservice = new VoucherService();

        let data=await service.retrieveById(req.params.id);
        let ob=await metalservice.outStanding(data.party_id,new Date(data.invoice_date));
        let party = await partyservice.retrieveById(data.party_id)
        let ledger=await ledgerservice.getPartyLedger(data.party_id);
        let oba=await voucherservice.closingBalance(new Date(data.invoice_date),ledger._id);

        let date=new Date(data.invoice_date);
        
        let resultP = await ejs.renderFile(path.join(__dirname, '/../', 'views', 'metal-transfer.ejs'), {
            party: party,
            date: date?.toLocaleString('en-IN',{dateStyle:'medium'}),
            data: data,
            ob:ob.length>0?ob[0].outstanding:0,
            oba:oba.length>0?oba[0].closing:0,
        }, {});
        

        let options: CreateOptions = { format:'A5' };
        html_to_pdf.create(resultP, options).toBuffer((err, pdfBuffer) => {
            if (!err) {
                res.header('content-type', 'application/pdf');
                res.send(pdfBuffer);
            }
            else {
                res.send({ success: false, message: err.message });
            }
        });


    } catch (error: any) {
        res.send({ success: false, message: error.message }); 
    }
    
}).get('/metal-return/:id', async (req: Request, res: Response) => {
    try {
        let service=new MetalReturnService(); 
        let partyservice = new PartyService();
        let metalservice = new MetalOutstandingService();
        let voucherservice = new VoucherService();
        let ledgerservice=new LedgerService();

        let data=await service.retrieveById(req.params.id);
        
    
        let ob=await metalservice.outStanding(data.party_id,new Date(data.invoice_date));
        let party = await partyservice.retrieveById(data.party_id)
        let ledger=await ledgerservice.getPartyLedger(data.party_id);
        let oba=await voucherservice.closingBalance(data.invoice_date,ledger._id);
        let date=new Date(data.invoice_date);
        
        let resultP = await ejs.renderFile(path.join(__dirname, '/../', 'views', 'metal-return.ejs'), {
            party: party,
            date: date.toLocaleString('en-IN',{dateStyle:'medium'}),
            data: data,
            ob:ob.length>0?ob[0].outstanding:0,
            oba:oba.length>0?oba[0].closing:0,
        }, {});
        

        let options: CreateOptions = { format:'A5' };
        html_to_pdf.create(resultP, options).toBuffer((err, pdfBuffer) => {
            if (!err) {
                res.header('content-type', 'application/pdf');
                res.send(pdfBuffer);
            }
            else {
                res.send({ success: false, message: err.message });
            }
        });


    } catch (error: any) {
        res.send({ success: false, message: error.message }); 
    }
    
});
export default printController;