import { Router} from "express";
import UserService from "../services/user-service";
import { CommonRoutes } from "../utils/common-route";
let routes=new CommonRoutes();
routes.service=UserService;
const app = Router();
app.get('/', routes.list)
.get('/:id', routes.retrieve)
.post('/', routes.add)
.put('/:id', routes.update) 
.delete('/:id', routes.delete);
export default app;