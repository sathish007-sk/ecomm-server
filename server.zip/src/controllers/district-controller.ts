import { Router} from "express";
import DistrictService from "../services/district-service";
import { CommonRoutes } from "../utils/common-route";
let routes=new CommonRoutes();
routes.service=DistrictService;
const districtController = Router();
districtController.get('/', routes.list)
.get('/:id', routes.retrieve)
.post('/', routes.add)
.put('/:id', routes.update) 
.delete('/:id', routes.delete);
export default districtController;