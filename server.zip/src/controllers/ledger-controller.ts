import { Router,Request,Response} from "express";
import LedgerService from "../services/ledger-service";
import { CommonRoutes } from "../utils/common-route";
let routes=new CommonRoutes();
routes.service=LedgerService;
const app = Router();
app.get('/', routes.list)
.get('/:id', routes.retrieve)
.post('/', routes.add)
.put('/:id', routes.update) 
.delete('/:id', routes.delete);
export default app;
export const cashBankLedger=async (req: Request, res: Response)=>{
    try {
        let service=new routes.service()
        res.json(await service.getBankAndCashLedger());
    } catch (error:any) {
        console.log(error);
        
        res.json({ success: false, message: error.message });
    }
    
}