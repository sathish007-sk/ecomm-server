import { Router} from "express";
import ProductService from "../services/product-service";
import { CommonRoutes } from "../utils/common-route";
let routes=new CommonRoutes();
routes.service=ProductService;
const productController = Router();
productController.get('/', routes.list)
.get('/:id', routes.retrieve)
.post('/', routes.add)
.put('/:id', routes.update) 
.delete('/:id', routes.delete);
export default productController;