import { Request, Response, Router } from "express";
import AccountsGroupService from "../services/accounts-group-service";
import BankService from "../services/bank-service";
import DashboardCalculationService from "../services/dashboard-calculation-service";
import DashboardMappingService from "../services/dashboard-mapping-service";
import DashboardService from "../services/dashboard-service";
import LedgerService from "../services/ledger-service";
import MetalOutstandingService from "../services/metal-outstanding-service";
import PartyService from "../services/party-service";
import ReportService from "../services/report-service";
import { user } from "../services/session-service";
import StockService from "../services/stock-service";
import UserService from "../services/user-service";
import VoucherService from "../services/voucher-service";
const dashboardController = Router();
dashboardController
  .get("/", async (req: Request, res: Response) => {
    try {
      let userservice = new UserService();
      let userData = await userservice.retrieveById(user(req.headers));
      if (userData.role?.toLowerCase() == "super admin") {
        let service = new DashboardService();

        let bankbalance = await service.bankBalance();
        let closingstock = await service.closingStock();
        let partyclosing = await service.partyClosing();

        let dailySales = await service.dailySales();
        let dailyPurchase = await service.dailyPurchase();
        let dailyMetalTransfer = await service.dailyMetalTransfer();

        let activeUser = await service.users();
        let activeProduct = await service.products();

        let charts = [
          bankbalance,
          closingstock,
          dailySales,
          dailyPurchase,
          dailyMetalTransfer,
        ];

        let card: any = [
          {
            title: "Party Balances",
            value: Math.round(partyclosing.party_balance)?.toLocaleString(
              "en-IN"
            ),
            class: "red",
            icon: "profile",
          },
          {
            title: "Party Advance",
            value: Math.round(partyclosing.party_advance)?.toLocaleString(
              "en-IN"
            ),
            class: "green",
            icon: "credit-card",
          },
          {
            title: "Product",
            value: `${String(activeProduct.active)} / ${String(
              activeProduct.total
            )}`,
            class: "orange",
            icon: "shopping",
          },
          {
            title: "Active Users",
            value: `${String(activeUser.active)} / ${String(activeUser.total)}`,
            class: "blue",
            icon: "user",
          },
        ];

        res.json({ charts: charts, card: card });
      } else res.json({ success: false, message: "Permission Denied" });
    } catch (error: any) {
      res.json({ success: false, message: error.message });
    }
  })
  .get("/bank-balance", async (req: Request, res: Response) => {
    try {
      let service = new DashboardService();
      let result = await service.bankBalance();
      let data: any = [];
      result.series?.forEach((e: number, i: number) => {
        data.push({
          amount: e,
          bank: result.labels[i],
        });
      });
      res.json(data);
    } catch (error: any) {
      res.json({ success: false, message: error.message });
    }
  })
  .get("/db1", async (req: Request, res: Response) => {
    try {
      let serviceDashboard = new DashboardService();
      let stockService = new StockService();
      let ledgerService = new LedgerService();
      let voucherService = new VoucherService();
      let bankService = new BankService();
      let metalservice=new MetalOutstandingService();
      let accservice = new AccountsGroupService();
      let partyservice=new PartyService();
      let bankList = await bankService.list({ is_display_dashboard: true });
      let partyclosing = await serviceDashboard.partyClosing();
      partyclosing.party_advance = 0 - partyclosing.party_advance;
      let tdsReceivable = await ledgerService.tdsReceivable();
      let tdsPayable = await ledgerService.tdsPayable();
      let tcsReceivable = await ledgerService.tcsReceivable();
      let tcsPayable = await ledgerService.tcsPayable();
      let closing = await voucherService.closingBalance(new Date());
      let stock = await stockService.getData();
      let metal=await metalservice.outStanding();

      // let party=await partyservice.list({ account_type: "Customer" });
      let groupList = await accservice.getPartyGroup();
      let groupClosing=[];
      for(let x of groupList){
          let groups  = await accservice.getPartyGroup(String(x._id));
          let groupIds=groups?.map((e:any)=>e._id);
          
           
          let partyLedger=await ledgerService.list({group:{'$in':groupIds}});
          let cbAmt=0; let cbm=0;
          for(let y of partyLedger){
            let c=closing.find((el:any)=> String(el.ledger_id)==String(y._id));
            if(c) cbAmt+=c.closing;
            let m=metal.find((el:any)=>String(el._id)==String(y.reference.ref_id));
            if(m) cbm+=m.outstanding;
          }
          groupClosing.push({
            _id:x._id,
            group_name:x.group_name,
            closing:cbAmt,
            metal:Number(Number(cbm).toFixed(3))
          })

           
      }
     
      let metalOutstanding = metal.reduce((c:number,e:any)=>{
        return c+=e.outstanding
      },0);
      
      let cb: any = {};
      closing?.forEach((e: any) => {
        cb[String(e.ledger_id)] = e;
      });
      

      let bankBalance=await Promise.all(bankList.map(async (e: any, i: number) => {
        let ledger = await ledgerService.getBankLedger(e._id);
        let c = cb[String(ledger._id)];
        return {
          amount: c ? Math.round(c.closing) : 0,
          bank: ledger.ledger_name,
        };
      }));      
      res.json({
        bankBalance: bankBalance,
        tdsReceivable: Math.round(cb[String(tdsReceivable._id)]?.closing ?? 0),
        tdsPayable: Math.round(cb[String(tdsPayable._id)]?.closing ?? 0),
        tcsReceivable: Math.round(cb[String(tcsReceivable._id)]?.closing ?? 0),
        tcsPayable: Math.round(cb[String(tcsPayable._id)]?.closing ?? 0),
        stock: Math.round(stock.reduce((c:number,e:any)=>c+=Number(e.stock.toFixed()),0)),
        metalOutstanding:Math.round(metalOutstanding),
        groupClosing:groupClosing,
        ...partyclosing,
      });
    } catch (error: any) {
      res.json({ success: false, message: error.message });
    }
  })
  .post("/db1", async (req: Request, res: Response) => {
    try {
      let service = new DashboardCalculationService();
      res.json(await service.add(req.body));
    } catch (error: any) {
      res.json({ success: false, message: error.message });
    }
  })
  .get("/dashboard-type", async (req: Request, res: Response) => {
    try {
      let service = new DashboardMappingService();
      res.json(await service.retrieve({ user_id: req.body.done_by }));
    } catch (error: any) {
      res.json({ success: false, message: error.message });
    }
  });
export default dashboardController;
