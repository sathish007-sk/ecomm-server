import {Router, Request, Response} from "express";
import VoucherService from "../services/voucher-service";
import AccountsGroupService from "../services/accounts-group-service";
import LedgerService from "../services/ledger-service";
import {CommonRoutes} from "../utils/common-route";
let routes = new CommonRoutes();
routes.service = AccountsGroupService;
const app = Router();
app.get('/', routes.list).get('/:id', routes.retrieve).get('/tree/party', async (req : Request, res : Response) => {
    try {
        let service = new AccountsGroupService();
        return res.json(await service.getPartyGroup())
    } catch (error : any) {
        return res.json({success: false, message: error.message})
    }
}).post('/', routes.add).put('/:id', routes.update).delete('/:id', routes.delete)

.get('/expenses/:id',async (req : Request, res : Response) => {
    try {
        let service = new AccountsGroupService();
        let ledgerservice = new LedgerService();
        let voucherservice = new VoucherService();
        let result: []  = await ledgerservice.list({'group': req.params.id})
        let fromDate: Date | undefined,toDate: Date | undefined;
        
        if(req.query.from_date) fromDate=new Date(String(req.query.from_date));
        if(req.query.to_date) toDate=new Date(String(req.query.to_date));
        const result1 = await Promise.all(result.map( async  (e:any ) => {
            let data = await voucherservice.ledgerExp(e._id,toDate)  
            var arr = [];
            for(let x of data){
                arr.push(x)
            // if(e._id == x.ledger_id){
            //     console.log("x");
                
            //     arr.push(x)
            //     console.log(arr);
                
            // }
        }
        return data
       }))
       return res.json(result1)
    } catch (error : any) {
        return res.json({success: false, message: error.message})
    } });
export default app;