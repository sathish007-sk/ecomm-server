import { Router,Request,Response} from "express";
import AccessSettingService from "../services/access-setting-service";
import { book, sub_book, user } from "../services/session-service";
import { CommonRoutes } from "../utils/common-route";
let routes=new CommonRoutes();
routes.service=AccessSettingService;
const accessSettingController = Router();
accessSettingController.get('/', routes.list)
.get('/:id', routes.retrieve)
.post('/', async (req:Request,res:Response)=>{
    try {
        let service=new routes.service();
        let data=await service.save( book(req.headers),sub_book(req.headers),user(req.headers),req.body.menu,req.body.user_id)
        res.json(data);
    } catch (error:any) {
        res.json({success:false,message:error.message});
    }
});
export default accessSettingController;