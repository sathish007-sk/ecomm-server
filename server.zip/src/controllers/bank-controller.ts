import { Router} from "express";
import BankService from "../services/bank-service";

import { CommonRoutes } from "../utils/common-route";
let routes=new CommonRoutes();
routes.service=BankService;
const bankController = Router();
bankController.get('/', routes.list)
.get('/:id', routes.retrieve)
.post('/', routes.add)
.put('/:id', routes.update) 
.delete('/:id', routes.delete);
export default bankController;