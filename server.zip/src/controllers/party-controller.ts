import { Request, Response, Router} from "express";
import LedgerService from "../services/ledger-service";
import MetalOutstandingService from "../services/metal-outstanding-service";
import PartyService from "../services/party-service";
import VoucherService from "../services/voucher-service";
import { CommonRoutes } from "../utils/common-route";
let routes=new CommonRoutes();
routes.service=PartyService;
const PartyController = Router();
PartyController.get('/', routes.list)
.get('/:id', routes.retrieve)
.post('/', routes.add)
.put('/:id', routes.update) 
.delete('/:id', routes.delete)
.get('/metal-outstanding/:party_id',async (req:Request,res:Response)=>{
    try {
        let service=new MetalOutstandingService();
        let data=await service.outStanding(req.params.party_id);     
        res.json({success:true,outstanding:data[0]?.outstanding ?? 0});
    } catch (error:any) {
        res.json({success:false,error:error.message});
    }
}).get('/outstanding/:party_id',async (req:Request,res:Response)=>{
    try {
        let ledgerservice=new LedgerService();   
        let ledger=await ledgerservice.getPartyLedger(req.params.party_id)
       
        let service=new VoucherService();
        if(ledger){
            let outstanding=await service.closingBalance(new Date(),ledger?._id);  
            res.json({success:true,outstanding:outstanding[0]?.closing.toFixed(2)});
        }
        else{
            res.json({success:true,outstanding:0});  
        }
      
    } catch (error:any) {
        res.json({success:false,error:error.message});
    }
});
export default PartyController;