import { Router} from "express";
import CountryService from "../services/country-service";
import { CommonRoutes } from "../utils/common-route";
let routes=new CommonRoutes();
routes.service=CountryService;
const countryController = Router();
countryController.get('/', routes.list)
.get('/:id', routes.retrieve)
.post('/', routes.add)
.put('/:id', routes.update) 
.delete('/:id', routes.delete);
export default countryController;