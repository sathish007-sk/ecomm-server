import dtdSalesModel from "../models/dtd-sales-model";
import { Router, Request, Response } from "express";
import { user, book, sub_book } from "../services/session-service";
const app = Router();
app.get('/', async (req: Request, res: Response) => {
    try {
        let filter:any={ book_id: book(req.headers), sub_book_id: sub_book(req.headers) }
        if(req.query.product) filter.product=req.query.product;
        if(req.query.date) filter.date=req.query.date;

        let data = await dtdSalesModel.find(filter);
        res.json(data);
    } catch (error:any) {
        res.json({ success: false, message: error.message });
    }
}).get('/:id', async (req: Request, res: Response) => {
    try {
        let data = await dtdSalesModel.findOne({ book_id: book(req.headers), sub_book_id: sub_book(req.headers), _id: req.params.id });
        res.json(data);
    } catch (error:any) {
        res.json({ success: false, message: error.message });
    }
}).post('/', async (req: Request, res: Response) => {
    try {
        let save=await dtdSalesModel.create({
            book_id: book(req.headers),
            sub_book_id: sub_book(req.headers),
            party_id: req.body.party_id,
            party_name:req.body.party_name,
            product: req.body.product,
            quantity: req.body.quantity,
            rate: req.body.rate,
            total: req.body.total,
            weight:req.body.weight,
            done_by: user(req.headers),
        });
       
        res.json({ success: true, message: 'Saved successfully' });
    } catch (error:any) {
        res.json({ success: false, message: error.message });
    }
}).put('/:id', async (req: Request, res: Response) => {
    try {
        let save=await dtdSalesModel.findOneAndUpdate({ book_id: book(req.headers), sub_book_id: sub_book(req.headers), _id: req.params.id }, {
           
            party_id: req.body.party_id,
            party_name:req.body.party_name,
            product: req.body.product,
            quantity: req.body.quantity,
            weight:req.body.weight,
            rate: req.body.rate,
            total: req.body.total,
        })
       
        res.json({ success: true, message: 'Saved successfully' });
    } catch (error:any) {
        res.json({ success: false, message: error.message });
    }
}).delete('/:id', async (req: Request, res: Response) => {
    try {
        let data = await dtdSalesModel.findOne({ book_id: book(req.headers), sub_book_id: sub_book(req.headers), _id: req.params.id });
        if (data) {
            await data.deleteOne();
           
        }
        res.json({ success: true, message: 'Deleted successfully' });
    } catch (error:any) {
        res.json({ success: false, message: error.message });
    }
});
export default app;