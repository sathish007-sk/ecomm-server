import { Request, Response, Router} from "express";
import { date } from "../services/date-service";
const dateController = Router();
dateController.get('/', (req:Request,res:Response)=>{
    res.json({success:true,date:date()});
});
export default dateController;