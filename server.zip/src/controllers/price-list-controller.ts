import { Router, Request, Response } from "express";
import priceListModel from '../models/price-list-model';
import { user, book, sub_book } from "../services/session-service";
const app = Router();
app.get('/', async (req: Request, res: Response) => {
    try {
        let data = await priceListModel.find({ book_id: book(req.headers), sub_book_id: sub_book(req.headers) }).populate('product');
        res.json(data);
    } catch (error:any) {
        res.json({ success: false, message: error.message });
    }
}).get('/:id', async (req: Request, res: Response) => {
    try {
        let data = await priceListModel.findOne({ book_id: book(req.headers), sub_book_id: sub_book(req.headers), _id: req.params.id });
        res.json(data);
    } catch (error:any) {
        res.json({ success: false, message: error.message });
    }
}).post('/', async (req: Request, res: Response) => {
    try {
        let check = await priceListModel.findOne({ book_id: book(req.headers), sub_book_id: sub_book(req.headers), code: { $regex: new RegExp("^" + req.body.code?.toLowerCase() + "$", "i") } });
        if (check) {
            res.json({ success: false, message: 'Already exists' });
        }
        await priceListModel.create({
            book_id: book(req.headers),
            sub_book_id: sub_book(req.headers),
            product: req.body.product,
            price_list_name: req.body.price_list_name,
            print_name: req.body.print_name,
            alias: req.body.alias,
            type: req.body.type,
            touch: req.body.touch,
            tax: req.body.tax,
            hsn_code: req.body.hsn_code,
            making_cost_per_qty: req.body.making_cost_per_qty,
            making_cost_per_piece: req.body.making_cost_per_piece,
            status: req.body.status,
            done_by: user(req.headers),
        })
        res.json({ success: true, message: 'Saved successfully' });
    } catch (error:any) {
        res.json({ success: false, message: error.message });
    }
}).put('/:id', async (req: Request, res: Response) => {
    try {
        let check = await priceListModel.findOne({ book_id: book(req.headers), sub_book_id: sub_book(req.headers), code: { $regex: new RegExp("^" + req.body.code?.toLowerCase() + "$", "i") }, _id: { $ne: req.params.id } });
        if (check) {
            res.json({ success: false, message: 'Already exists' });
        }
        await priceListModel.findOneAndUpdate({ book_id: book(req.headers), sub_book_id: sub_book(req.headers), _id: req.params.id }, {
            product: req.body.product,
            price_list_name: req.body.price_list_name,
            print_name: req.body.print_name,
            alias: req.body.alias,
            type: req.body.type,
            touch: req.body.touch,
            tax: req.body.tax,
            hsn_code: req.body.hsn_code,
            making_cost_per_qty: req.body.making_cost_per_qty,
            making_cost_per_piece: req.body.making_cost_per_piece,
            status: req.body.status,
        })
        res.json({ success: true, message: 'Saved successfully' });
    } catch (error:any) {
        res.json({ success: false, message: error.message });
    }
}).delete('/:id', async (req: Request, res: Response) => {
    try {
        let data = await priceListModel.findOne({ book_id: book(req.headers), sub_book_id: sub_book(req.headers), _id: req.params.id });
        if (data) {
            await data.deleteOne();
        }
        res.json({ success: true, message: 'Deleted successfully' });
    } catch (error:any) {
        res.json({ success: false, message: error.message });
    }
});
export default app;