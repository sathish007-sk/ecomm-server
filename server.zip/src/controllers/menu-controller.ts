import { Request,Response,Router} from "express";
import AccessMenuService from "../services/access-menu-service";
import AccessModuleService from "../services/access-module-service";
import MenuService from "../services/menu-service";
import { user } from "../services/session-service";
const menuController = Router();
menuController.get('/', async (req: Request, res: Response) => {
    try {       
        let service=new MenuService()
        let result = await service.getMenus(user(req.headers));
        res.json(result);
    } catch (error:any) {
        res.json({ success: false, message: error.message });
    }
}).get('/module', async (req: Request, res: Response) => {
    try {
        let service=new AccessModuleService()
        let result = await service.getModule();
        res.json(result);
    } catch (error:any) {
        res.json({ success: false, message: error.message });
    }
}).get('/module/:id', async (req: Request, res: Response) => {
    try {
        let service=new AccessMenuService()
        let result = await service.menu({module:req.params.id});
        res.json(result);
    } catch (error:any) {
        res.json({ success: false, message: error.message });
    }
});
export default  menuController;