import { Router} from "express";
import TcsSlabService from "../services/tcs-slab-service";
import { CommonRoutes } from "../utils/common-route";
let routes=new CommonRoutes();
routes.service=TcsSlabService;
const tcsController = Router();
tcsController.get('/', routes.list)
.get('/:id', routes.retrieve)
.post('/', routes.add)
.put('/:id', routes.update) 
.delete('/:id', routes.delete);
export default tcsController;