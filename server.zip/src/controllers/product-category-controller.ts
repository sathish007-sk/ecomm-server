import { Router, Request, Response } from "express";
import { productCategoryModel } from '../models/product-model';
import { user, book, sub_book } from "../services/session-service";
const app = Router();
app.get('/', async (req: Request, res: Response) => {
    try {
        let data = await productCategoryModel.find({ book_id: book(req.headers), sub_book_id: sub_book(req.headers) }).populate('parent');
        res.json(data);
    } catch (error:any) {
        res.json({ success: false, message: error.message });
    }
}).get('/:id', async (req: Request, res: Response) => {
    try {
        let data = await productCategoryModel.findOne({ book_id: book(req.headers), sub_book_id: sub_book(req.headers), _id: req.params.id });
        res.json(data);
    } catch (error:any) {
        res.json({ success: false, message: error.message });
    }
}).post('/', async (req: Request, res: Response) => {
    try {
        let check = await productCategoryModel.findOne({ book_id: book(req.headers), sub_book_id: sub_book(req.headers), code: { $regex: new RegExp("^" + req.body.code?.toLowerCase() + "$", "i") } });
        if (check) {
            res.json({ success: false, message: 'Already exists' });
        }
        await productCategoryModel.create({
            book_id: book(req.headers),
            sub_book_id: sub_book(req.headers),
            name: req.body.name,
            parent: req.body.parent,
            status: req.body.status,
            done_by: user(req.headers),
        })
        res.json({ success: true, message: 'Saved successfully' });
    } catch (error:any) {
        res.json({ success: false, message: error.message });
    }
}).put('/:id', async (req: Request, res: Response) => {
    try {
        let check = await productCategoryModel.findOne({ book_id: book(req.headers), sub_book_id: sub_book(req.headers), code: { $regex: new RegExp("^" + req.body.code?.toLowerCase() + "$", "i") }, _id: { $ne: req.params.id } });
        if (check) {
            res.json({ success: false, message: 'Already exists' });
        }
        await productCategoryModel.findOneAndUpdate({book_id: book(req.headers), sub_book_id: sub_book(req.headers), _id: req.params.id }, {
            name: req.body.name,
            parent: req.body.parent,
            status: req.body.status,
        })
        res.json({ success: true, message: 'Saved successfully' });
    } catch (error:any) {
        res.json({ success: false, message: error.message });
    }
}).delete('/:id', async (req: Request, res: Response) => {
    try {
        let data = await productCategoryModel.findOne({ book_id: book(req.headers), sub_book_id: sub_book(req.headers), _id: req.params.id });
        if (data) {
            await data.deleteOne();
        }
        res.json({ success: true, message: 'Deleted successfully' });
    } catch (error:any) {
        res.json({ success: false, message: error.message });
    }
});
export default app;