import { Router} from "express";
import StateService from "../services/state-service";
import { CommonRoutes } from "../utils/common-route";
let routes=new CommonRoutes();
routes.service=StateService;
const stateController = Router();
stateController.get('/', routes.list)
.get('/:id', routes.retrieve)
.post('/', routes.add)
.put('/:id', routes.update) 
.delete('/:id', routes.delete);
export default stateController;