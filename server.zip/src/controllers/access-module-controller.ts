import { Router} from "express";
import Service from "../services/access-module-service";
import { CommonRoutes } from "../utils/common-route";
let routes=new CommonRoutes();
routes.service=Service;
const app = Router();
app.get('/', routes.list)
.get('/:id', routes.retrieve)
.post('/', routes.add)
.put('/:id', routes.update) 
.delete('/:id', routes.delete);
export default app;