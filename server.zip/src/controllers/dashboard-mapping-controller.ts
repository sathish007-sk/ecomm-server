import { Request, Response, Router} from "express";
import DashboardMappingService from "../services/dashboard-mapping-service";
import { CommonRoutes } from "../utils/common-route";
let routes=new CommonRoutes();
routes.service=DashboardMappingService;
const DashboardMappingController = Router();
DashboardMappingController.get('/', routes.list)
.get('/:id', routes.retrieve)
.post('/', async(req:Request,res:Response)=>{
    try {
        let service=new DashboardMappingService();
        return res.json(await service.save(req.body));
    } catch (error:any) {
        return res.json({success:false,message:error.message});
    }
})
.put('/:id', routes.update) 
.delete('/:id', routes.delete);
export default DashboardMappingController;