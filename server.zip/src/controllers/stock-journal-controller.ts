import { Request, Response, Router } from "express";
import { book, sub_book } from "../services/session-service";
import StockJournalService from "../services/stock-journal-service";
import { CommonRoutes } from "../utils/common-route";
let routes=new CommonRoutes();
routes.service=StockJournalService;
const stockJournalController = Router();
stockJournalController.get('/', async (req:Request,res:Response)=>{
    try {     
        let service=new routes.service()   
        let result=await service.list({book_id:book(req.headers),sub_book_id:sub_book(req.headers),...req.query});
        res.json(result);
    } catch (error:any) {
        res.json({ success: false, message: error.message });
    }
})
.get('/:id', async (req:Request,res:Response)=>{
    try {     
        let service=new routes.service()   
        let result=await service.retrieve({_id:req.params.id,book_id:book(req.headers),sub_book_id:sub_book(req.headers)});
        res.json(result);
    } catch (error:any) {
        res.json({ success: false, message: error.message });
    }
})
.post('/', routes.add)
.put('/:id', async (req:Request,res:Response)=>{
    try {     
        let service=new routes.service()   
        let result=await service.update(req.body,{_id:req.params.id,book_id:book(req.headers),sub_book_id:sub_book(req.headers)});
        res.json(result);
    } catch (error:any) {
        res.json({ success: false, message: error.message });
    }
}) 
.delete('/:id', async (req:Request,res:Response)=>{
    try {     
        let service=new routes.service()   
        let result=await service.delete({_id:req.params.id,book_id:book(req.headers),sub_book_id:sub_book(req.headers)});
        res.json(result);
    } catch (error:any) {
        res.json({ success: false, message: error.message });
    }
})
/* .post('/get-invoice-no',async (req,res)=>{
    try {     
        let service=new routes.service()   
        let result=await service.getBillNo(await book(req.headers),await sub_book(req.headers),req.body.date);
        res.json(result);
    } catch (error:any) {
        res.json({ success: false, message: error.message });
    }
})
.post('/check-invoice-no',async (req,res)=>{
    try {
        let service=new routes.service()
        let result=await service.checkExists(await book(req.headers),await sub_book(req.headers),req.body.invoice_no,req.body.financial_year,req.body._id);
        res.json(result);
    } catch (error:any) {
        res.json({ success: false, message: error.message });
    }
}) */;
export default stockJournalController;