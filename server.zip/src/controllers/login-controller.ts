import { Router,Request,Response} from "express";
import UserService from "../services/user-service";

const loginController = Router();
loginController.post('/', async(req:Request,res:Response)=>{
    try {
        let user=new UserService();
        res.json(await user.login(req.body.code,req.body.password))
    } catch (error:any) {
        res.json({success:false,message:error.message})
    }
});
export default loginController;
