import { Router,Request,Response} from "express";
import AccountsGroupService from "../services/accounts-group-service";
import { date } from "../services/date-service";
import LedgerService from "../services/ledger-service";
import MetalOutstandingService from "../services/metal-outstanding-service";
import PartyService from "../services/party-service";
import { PurchaseService } from "../services/purchase-service";
import ReportService from "../services/report-service";
import { salesService } from "../services/sales-service";
import StockService from "../services/stock-service";
import VoucherService from "../services/voucher-service";
const ReportController = Router();
ReportController.get('/ledger',async (req:Request,res:Response)=>{
    try {
        let fromDate,toDate;
        if(req.query.from_date) fromDate=new Date(String(req.query.from_date));
        if(req.query.to_date) toDate=new Date(String(req.query.to_date));       
        let service=new VoucherService();
        res.json(await service.ledgerReport(String(req.query.ledger),fromDate,toDate));
    } catch (error:any) {
        res.json({success:false,message:error.message});
    }
}).get('/ledger/brief',async (req:Request,res:Response)=>{
    try {
        let service=new VoucherService();
        let fromDate,toDate;
        if(req.query.from_date) fromDate=new Date(String(req.query.from_date));
        if(req.query.to_date) toDate=new Date(String(req.query.to_date));

        


        res.json(await service.ledgerBrief(String(req.query.ledger),fromDate,toDate));
    } catch (error:any) {
        res.json({success:false,message:error.message});
    }
}).get('/day-book',async (req:Request,res:Response)=>{
    try {
        let service=new VoucherService();
        res.json(await service.dayBook(req.query));
    } catch (error:any) {
        res.json({success:false,message:error.message});
    }
}).get('/trial-balance',async (req:Request,res:Response)=>{
    try {
        let service=new VoucherService();
        res.json(await service.trialBalance(req.query));
    } catch (error:any) {
        res.json({success:false,message:error.message});
    }
}).get('/outstanding',async (req:Request,res:Response)=>{
    try {
        let service=new ReportService();
        res.json(await service.getOutStanding(req.query));
    } catch (error:any) {
        res.json({success:false,message:error.message});
    }
}).get('/outstanding-party-wise',async (req:Request,res:Response)=>{
    try {
        
        
        let groupservice=new AccountsGroupService();
        let ledgerservice=new LedgerService();
        let partyservice=new PartyService();
        let metalservice=new MetalOutstandingService();
        let voucherservice=new VoucherService();
       
      
        let metal=await metalservice.outStanding();
        let closing=await voucherservice.closingBalance();
        let partyFilter:any={'reference.ref_from':'party'}
        if(req.query.group){
            let groups  = await groupservice.getPartyGroup(String(req.query.group));
            let groupIds=groups?.map((e:any)=>e._id);
            if(groupIds.length>0) partyFilter.group={'$in':groupIds}

        }
        let partyLedger=await ledgerservice.list(partyFilter);
        let party=await partyservice.list();
        let partyName:any={};
        for(let x of party){
            partyName[x._id]=x.account_name;
        }
       /*  let result= party.map(e=>{
            let closing_balance_metal=0,closing_balance_amount=0;
            let m=metal.find((el:any)=>String(el._id)==String(e._id));
            if(m) closing_balance_metal=m.outstanding;

            let party_ledger=partyLedger.find((el:any)=>String(el.reference.ref_id)==String(e._id))

            let c=closing.find((el:any)=> String(el.ledger_id)==String(party_ledger._id));
            if(c) closing_balance_amount=c.closing;
           
            
            return{
                party_id:e._id,
                party_name:e.account_name,
                closing_balance_metal:closing_balance_metal,
                closing_balance_amount:closing_balance_amount
            }
            
        }); */

        let result= partyLedger.map((e:any)=>{
            let closing_balance_metal=0,closing_balance_amount=0;
            let m=metal.find((el:any)=>String(el._id)==String(e.reference.ref_id));
            if(m) closing_balance_metal=m.outstanding;
            // let party_ledger=partyLedger.find((el:any)=>String(el.reference.ref_id)==String(e._id))

            let c=closing.find((el:any)=> String(el.ledger_id)==String(e._id));
            if(c) closing_balance_amount=c.closing;
           
            
            return{
                party_id:e.reference.ref_id,
                party_name:partyName[e.reference.ref_id],
                closing_balance_metal:closing_balance_metal,
                closing_balance_amount:Number(closing_balance_amount.toFixed()),
                date:m?.date
            }
            
        });

        res.json(result);


    } catch (error:any) {
        res.json({success:false,message:error.message});
    }
}).get('/total-sales',async(req:Request,res:Response)=>{
    try {
        let service=new salesService();
        let id;
        if(req.query.id) id=String(req.query.id);
        let total=await service.totalSales(String(req.query.party_id),String(req.query.financial_year),id);
        res.json({success:true,total:total})
    } catch (error:any) {
        res.json({success:false,message:error.message});
    }
}).get('/total-purchase',async(req:Request,res:Response)=>{
    try {
        let service=new PurchaseService();
        let id;
        if(req.query.id) id=String(req.query.id);
        let total=await service.totalPurchase(String(req.query.party_id),new Date(String(req.query.date)),id);
        res.json({success:true,total:total})
    } catch (error:any) {
        res.json({success:false,message:error.message});
    }
}).get('/stock',async(req:Request,res:Response)=>{
    try {
        let service=new StockService();
        let result=await service.getData();
        res.json(result);
    } catch (error:any) {
        res.json({success:false,message:error.message});
    }
}).get('/stock/:id',async(req:Request,res:Response)=>{
    try {
        let service=new StockService();
        let result=await service.getStockDetail(req.params.id);
        res.json(result);
    } catch (error:any) {
        res.json({success:false,message:error.message});
    }
}).get('/day-stock',async(req:Request,res:Response)=>{
    try {
        let service=new StockService();
        if(req.query.from_date && req.query.to_date){
            let fromDate=new Date(String(req.query.from_date));
            let toDate=new Date(String(req.query.to_date));
            let result=await service.dayStock(fromDate,toDate);
            res.json(result);
        }
        else res.json({success:false,message:"Date mandatory"});
        
    } catch (error:any) {
        res.json({success:false,message:error.message});
    }
});
export default ReportController;