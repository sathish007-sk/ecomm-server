export default function (date: Date = new Date()) {
    let fy;
    let d = new Date(date);
    d.setHours(0,0,0,0);
    let year = d.getFullYear().toString();
    let month = d.getMonth();
    let ys = parseInt(year.substr(2, 2));
    if (month > 2) fy = ys + "-" + (ys + 1);
    else fy = (ys - 1) + "-" + ys;
    return fy;
}
export function financialYearReverse(fy:string):{min:Date,max:Date}{
    try {
        let f = fy.split('-');
        let minYear = Number(f[0]) + 2000;
        let maxYear = Number(f[1]) + 2000;
        let min = new Date(minYear, 3, 1, 0, 0, 0, 0);
        let max = new Date(maxYear, 2, 31, 0, 0, 0, 0);
        return { min: min, max: max };
    }
    catch (error) {
        throw error;
    }
}