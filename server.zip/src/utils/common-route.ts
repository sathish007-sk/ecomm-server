import { Request, Response } from "express";
export class CommonRoutes {
  public service: any;
  constructor() {}
  list = async (req: Request, res: Response) => {
    try {
      let service = new this.service();
      res.json(await service.list(req.query));
    } catch (error: any) {
      res.json({ success: false, message: error.message });
    }
  };
  retrieve = async (req: Request, res: Response) => {
    try {
      let service = new this.service();
      res.json(await service.retrieveById(req.params.id));
    } catch (error: any) {
      res.json({ success: false, message: error.message });
    }
  };
  add = async (req: Request, res: Response) => {
    try {
      let service = new this.service();
      res.json(await service.add(req.body));
    } catch (error: any) {
      res.json({ success: false, message: error.message });
    }
  };
  update = async (req: Request, res: Response) => {
    try {
      let service = new this.service();
      res.json(await service.updateById(req.body, req.params.id));
    } catch (error: any) {
      res.json({ success: false, message: error.message });
    }
  };
  delete = async (req: Request, res: Response) => {
    try {
      let service = new this.service();
      res.json(await service.deleteById(req.params.id));
    } catch (error: any) {
      res.json({ success: false, message: error.message });
    }
  };
}
