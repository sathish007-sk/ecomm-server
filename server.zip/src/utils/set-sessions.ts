import express, { Response, Request, NextFunction, Router, Application } from "express";
import BookService from "../services/book-service";
import UserService from "../services/user-service";
import * as sessionService from "../services/session-service";
import SubBookService from "../services/sub-book-service";

const app: Application = express();
var sessions = require("express-session");
const oneDay = 1000 * 60 * 60 * 24;
app.use(sessions({
    secret: "thisismysecrctekeyfhrgfgrfrty84fwir767",
    saveUninitialized:true,
    cookie: { maxAge: oneDay },
    resave: false 
}));


export const SetSessionService = async (req: Request, res: Response, next: NextFunction) => {
  if (req.path != "/login") {
    let userId: string = sessionService.user(req.headers);
    if (!userId) {
      res.status(401).send();
      return false;
    }
    let userService = new UserService();
    let user = await userService.retrieveById(userId);
    if (!user?.status) {
      res.status(401).send("User deactivated. Contact office");
      return false;
    }
    req.body.done_by = userId;

    let bookId = sessionService.book(req.headers)
    let bookservice = new BookService();
    let book = await bookservice.retrieveById(bookId);
    if (!book?.status) {
      res.status(401).send("Book deactivated. Contact office");
      return false;
    }
    req.body.book_id = bookId;

    let subbookId = sessionService.sub_book(req.headers)
    let subbookservice = new SubBookService();
    let subbook = await subbookservice.retrieveById(subbookId);    
    if (!subbook?.status) {
      res.status(401).send("Sub Book deactivated. Contact office");
      return false;
    }
    req.body.sub_book_id = subbookId;
    
  }
  next();
}