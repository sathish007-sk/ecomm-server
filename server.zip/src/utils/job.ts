import { schedule } from "node-cron";
import BackupDb from "../services/backup-service";
export default function CRONJob(){
    schedule('0 3 * * *', () => {
        let dbBackup=new BackupDb();
        dbBackup.daily();
    });
    schedule('0 3 * * 0', () => {
        let dbBackup=new BackupDb();
        dbBackup.weekly();
    });
    schedule('0 3 1 * *', () => {
        let dbBackup=new BackupDb();
        dbBackup.monthly();
    });
}
