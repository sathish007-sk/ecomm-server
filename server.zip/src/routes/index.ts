import { Router,Request,Response,NextFunction } from "express";
import StockController from "../controllers/stock-controller";
import master from "./master-routing";
import access from "./access-routing";
import process from "./process-routing";
import accounts from "./accounts-routing";
import loginController from "../controllers/login-controller";
import ReportController from "../controllers/report-controller";
import menuController from "../controllers/menu-controller";
import printController from "../controllers/print-controller";
import SlabController from "../controllers/slab-controller";
import dashboardController from "../controllers/dashboard-controller";
import dateController from "../controllers/date-controller";
import logController from "../controllers/log-controller";
const app = Router();

app
.use('/access', access)
.use('/accounts', accounts)
.use('/master', master)
.use('/process', process)
.use('/stock', StockController)
.use('/slab', SlabController)
.use('/login',loginController)
.use('/report',ReportController)
.use('/menu',menuController)
.use('/print',printController)
.use('/dashboard',dashboardController)
.use('/date',dateController)
.use('/log',logController)
.get('/', (req:Request, res:Response) => {
    res.send("Auriferous");
})
export default app;