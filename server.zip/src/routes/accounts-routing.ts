import { Router } from "express";
import ReceiptController from "../controllers/receipt-controller";
import PaymentController from "../controllers/payment-controller";
import AccountsGroupController from "../controllers/accounts-group-controller"
import LedgerController, { cashBankLedger } from "../controllers/ledger-controller"
import ContraController from "../controllers/contra-controller";
import JournalController from "../controllers/journal-controller";
const accounts = Router(); 
accounts.use('/receipt',ReceiptController)
.use('/payment',PaymentController)
.use('/contra',ContraController)
.use('/journal',JournalController)
.use('/group',AccountsGroupController)
.use('/ledger',LedgerController)
.get('/bank-cash-ledgers',cashBankLedger)

export default accounts;