import { Router } from "express";
import salesController from "../controllers/sales-controller";
import purchaseController from "../controllers/purchase-controller";
import dtdSalesController from "../controllers/dtd-sales-controller";
import dtdPurchaseController from "../controllers/dtd-purchase-controller";
import MaterialTransferController from "../controllers/material-transfer-controller";
import MetalReturnController from "../controllers/metal-return-controller";
import stockJournalController from "../controllers/stock-journal-controller";

const app = Router();
app.use('/sales', salesController)
.use('/purchase', purchaseController)
.use('/material-transfer', MaterialTransferController)
.use('/metal-return', MetalReturnController)
.use('/dtd-sales', dtdSalesController)
.use('/dtd-purchase', dtdPurchaseController)
.use('/stock-journal', stockJournalController)
export default app;