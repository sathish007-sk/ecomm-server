import { Router } from "express";
import userController from "../controllers/user-controller";
import bookController from "../controllers/book-controller";
import subBookController from "../controllers/sub-book-controller";
import partyController from "../controllers/party-controller";
import productCategoryController from "../controllers/product-category-controller";
import productGroupController from "../controllers/product-group-controller";
import productBrandController from "../controllers/product-brand-controller";
import productController from "../controllers/product-controller";
import priceListController from "../controllers/price-list-controller";
import bankController from "../controllers/bank-controller";
import taxController from "../controllers/tax-controller";
import tcsController from "../controllers/tcs-controller";
import tdsController from "../controllers/tds-controller";
import countryController from "../controllers/country-controller";
import stateController from "../controllers/state-controller";
import districtController from "../controllers/district-controller";
import accessSettingController from "../controllers/access-setting-controller";
import DashboardMappingController from "../controllers/dashboard-mapping-controller";
const app = Router(); 
app
.use('/country',countryController)
.use('/state',stateController)
.use('/district',districtController)
.use('/user',userController)
.use('/book',bookController)
.use('/sub-book',subBookController)
.use('/party',partyController)
.use('/product-brand',productBrandController)
.use('/product-group',productGroupController)
.use('/product-category',productCategoryController)
.use('/product',productController)
.use('/price-list',priceListController)
.use('/bank',bankController)
.use('/tax',taxController)
.use('/tcs',tcsController)
.use('/tds',tdsController)
.use('/access-setting',accessSettingController)
.use('/dashboard-mapping',DashboardMappingController)
export default app;