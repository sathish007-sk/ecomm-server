import { Router } from "express";
import AccessOptionController from "../controllers/access-option-controller";
import AccessMenuController from "../controllers/access-menu-controller";
import AccessModuleController from "../controllers/access-module-controller";

const access = Router(); 
access.use('/module',AccessModuleController)
access.use('/menu',AccessMenuController)
access.use('/option',AccessOptionController)
export default access;