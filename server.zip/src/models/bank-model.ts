import { Schema, model } from 'mongoose';
export interface Bank {
    _id?:string;
    book_id:string;
    sub_book_id:string;
    account_holder_name: string;
    account_no: string;
    bank_name: string;
    branch_name: string;
    ifsc: string;
    is_display_dashboard:boolean;
    default_bank: boolean,
    status: boolean,
    opening_balance_date?:Date,
    opening_balance?: number;
    posting?: 'Cr' | 'Dr';
}
export default model('bank', new Schema<Bank>({
    book_id: { type: Schema.Types.ObjectId, ref: 'book' },
    sub_book_id: { type: Schema.Types.ObjectId, ref: 'sub_book' },
    account_holder_name:{type:String,trim:true},
    account_no: {type:String,trim:true},
    bank_name: {type:String,trim:true},
    branch_name: {type:String,trim:true},
    ifsc: {type:String,trim:true},
    is_display_dashboard:{ type: Boolean, default: false },
    default_bank: { type: Boolean, default: false },
    opening_balance_date:Date,
    opening_balance: Number,
    posting:  { type: String, enum: ['Dr', 'Cr'] },
    status: { type: Boolean, default: true },
}, {
  timestamps: true,
}));