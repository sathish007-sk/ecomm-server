import { Schema, model } from 'mongoose';
interface Address{
    line1:string,
    line2?:string,
    country:string,
    state: string,
    district:string,
    pincode:number,
    is_primary:boolean,
    status: boolean,
}
export interface SubBook{
    _id?:string;
    name:string;
    code:string;
    pan_no?:string;
    gst_no?:string;
    state?:string;
    billing_address:Address[];
    communication_address:Address[];
    done_by:string;
    date_time?:Date;
    status:boolean;
}
export default model('sub_book', new Schema<SubBook>({
    book_id: { type: Schema.Types.ObjectId, ref: 'book' },
    name: { type: String, trim: true, uppercase: true },
    code: { type: String, trim: true, uppercase: true, unique:true },
    pan_no: {type:String ,trim:true,uppercase:true,maxLength:10},
    gst_no: {type:String ,trim:true,uppercase:true,maxLength:15},
    state: { type: Schema.Types.ObjectId, ref: 'state' },
    billing_address:[{
        line1:String,
        line2:String,
        country:{ type: Schema.Types.ObjectId, ref: 'country' },
        state: { type: Schema.Types.ObjectId, ref: 'state' },
        district:{ type: Schema.Types.ObjectId, ref: 'district' },
        pincode:Number,
        is_primary:{type:Boolean,default:false},
        status: { type: Boolean, default: true },
    }],
    communication_address:[{
        line1:String,
        line2:String,
        country:{ type: Schema.Types.ObjectId, ref: 'country' },
        state: { type: Schema.Types.ObjectId, ref: 'state' },
        district:{ type: Schema.Types.ObjectId, ref: 'district' },
        pincode:Number,
        is_primary:{type:Boolean,default:false},
        status: { type: Boolean, default: true },
    }],
    done_by: { type: Schema.Types.ObjectId, ref: 'user' },
    date_time: { type: Date, default: Date.now},
    status: { type: Boolean, default: true },
}, {
    timestamps: true,
    toObject : {getters: true},
    toJSON : {getters: true}
}));