import { Schema, model } from 'mongoose';
export interface DashboardMapping{
    _id?:string;
    book_id: string;
    sub_book_id: string;
    user_id:string;
    dashboard_id:string;
    done_by:string;
}
const dashboardMappingModel= model('dashboard_mapping', new Schema<DashboardMapping>({
    book_id: { type: Schema.Types.ObjectId, ref: 'book' },
    sub_book_id: { type: Schema.Types.ObjectId, ref: 'sub_book' },
    user_id:{ type: Schema.Types.ObjectId, ref: 'user' },
    dashboard_id:String,
    done_by: { type: Schema.Types.ObjectId, ref: 'user' },
    
}, {
    timestamps: true,
}));

export default dashboardMappingModel;