import { Schema, model } from 'mongoose';
export interface Country{
    _id?:string;
    name:string;
    description?:string;
    latitude?:string,
	longitude?:string,
    status:boolean;
}
export const countryModel= model('country', new Schema<Country>({
    name: { type: String, required: true ,trim:true,uppercase:true},
    description:String,
    latitude:String,
	longitude:String,
    status: { type: Boolean, default: true },
}, {
    timestamps: true,
}));
export interface State{
    _id?:string;
    name:string;
    code:string;
    country:string | Country;
    description?:string;
    latitude?:string,
	longitude?:string,
    status:boolean;
}
export const stateModel= model('state', new Schema<State>({
    name:{type:String,required:true,trim:true,uppercase:true},
	code:Number,
	country:{type:Schema.Types.ObjectId,ref:'country'},
	description:String,
	latitude:String,
	longitude:String,
	status:{type:Boolean,default:true},
}, {
    timestamps: true,
}));

export interface District{
    _id?:string;
    name:string;
    state:string | State;
    description?:string;
    latitude?:string,
	longitude?:string,
    status:boolean;
}
export const districtModel= model('district', new Schema<District>({
    name:{type:String,required:true,trim:true,uppercase:true},
  	state:{type:Schema.Types.ObjectId,ref:'state'},
	description:String,
	latitude:String,
	longitude:String,
	status:{type:Boolean,default:true},
}, {
    timestamps: true,
}));
