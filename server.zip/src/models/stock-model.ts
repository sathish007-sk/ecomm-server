import { Schema, model } from 'mongoose';
export interface StockDetail {
    product: string | null;
    quantity: number;
    gross_weight: number;
    stone?: number;
    waste?: number;
    touch?: number;
    touch_difference?: number;
    net_weight: Number,
    rate: number;
    total: number;
    is_discount?:boolean;
    status: 'in' | 'out';
}

export interface Stock {
    book_id: string | null;
    sub_book_id?: string | null;
    date: Date;
    module: string;
    ref_id?: string | null;
    ref_no?: number | string | null;
    party_name?: string;
    party_id?: string | null;
    item_details: StockDetail[];
    date_time?: Date;
    done_by?: string | null;
}

export default model('stock', new Schema<Stock>({
    book_id: { type: Schema.Types.ObjectId, ref: 'book' },
    sub_book_id: { type: Schema.Types.ObjectId, ref: 'sub_book' },
    date: { type: Date, default: Date.now },
    module: String,
    ref_id: { type: Schema.Types.ObjectId },
    ref_no: String,
    party_name: String,
    party_id: { type: Schema.Types.ObjectId, ref: 'party' },
    item_details: [
        {
            product: { type: Schema.Types.ObjectId, ref: 'product' },
            quantity: Number,
            gross_weight: Number,
            stone: Number,
            waste: Number,
            touch: Number,
            touch_difference: Number,
            net_weight: Number,
            rate: Number,
            total: Number,
            is_discount:{type:Boolean,default:false},
            status: { type: String, enum: ['in', 'out'] },
        }
    ],
    date_time: { type: Date, default: Date.now },
    done_by: { type: Schema.Types.ObjectId, ref: 'user' }
}, {
    timestamps: true,
    toObject : {getters: true},
    toJSON : {getters: true}
}));

