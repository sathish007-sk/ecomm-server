import { Schema } from 'mongoose';
export const address = new Schema({
    state: { type: Schema.Types.ObjectId, ref: 'state' },
    district: { type: Schema.Types.ObjectId, ref: 'district' },
    area: String,
    pincode: Number,
    address_line1: {type:String,trim:true},
    address_line2: {type:String,trim:true},
});