import { Schema, model } from 'mongoose';
export default model('access_permission', new Schema({
    book_id: { type: Schema.Types.ObjectId, ref: 'book' },
    sub_book_id: { type: Schema.Types.ObjectId, ref: 'sub_book' },
    user_id: { type: Schema.Types.ObjectId, ref: 'user' },
    done_by: { type: Schema.Types.ObjectId, ref: 'user' },
    status: { type: Boolean, default: true },
}, {
    timestamps: true,
}));