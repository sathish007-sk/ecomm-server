import { Schema, model } from 'mongoose';
interface UserDefined{
    description:string; 
    rate:number;
}
export interface DashboardCalculation{
    rate:number;
    date:Date;
    bank_balance:number;
    balances:number;
    advances:number;
    user_defined:UserDefined[],
    total:number;
    gold_convert:number;
    stock:number;
    metal_balance:number;
    net_stock:number;
    remark:string;
    done_by: string;    
}


export default model('dashboard_calculation', new Schema<DashboardCalculation>({
    rate:Number,
    date:{type:Date,default:Date.now},
    bank_balance:Number,
    balances:Number,
    advances:Number,
    user_defined:[{
        description:String,
        rate:Number
    }],
    total:Number,
    gold_convert:Number,
    stock:Number,
    metal_balance:Number,
    net_stock:Number,
    remark:String,
    done_by: { type: Schema.Types.ObjectId, ref: 'user' },
}, {
    timestamps: true,
}));

