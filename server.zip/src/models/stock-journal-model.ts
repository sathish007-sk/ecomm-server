import { model, Schema } from 'mongoose';
interface ItemDetail{
    product:string;
    net_weight:number;
    rate:number;
    total:number;
}
export interface StockJournal{
    _id?:string;
    date:Date;
    book_id: string | null;
    sub_book_id: string | null;
  	ref_no:string;
    narration:string;
    consumption:ItemDetail[],
    production:ItemDetail[],
    done_by: string;
}




const itemDetailSchema=new Schema<ItemDetail>({
    product:{type:Schema.Types.ObjectId,ref:'product',required:true},
    net_weight:Number,
    rate:Number,
    total:Number,
});
const stockJournalSchema = new Schema<StockJournal>({
    date:{type:Date,default:Date.now,required:true},
    book_id: { type: Schema.Types.ObjectId, ref: 'book' },
    sub_book_id: { type: Schema.Types.ObjectId, ref: 'sub_book' },
  	ref_no:String,
    narration:String,
    consumption:[itemDetailSchema],
    production:[itemDetailSchema],
    done_by:{type:Schema.Types.ObjectId,ref:'user'},
},{
    timestamps:true,
});
const stockJournalModel= model('stock_journal', stockJournalSchema);
export default stockJournalModel;