import { Schema, model } from 'mongoose';
export interface User{
    _id?:string;
    code: string;
    user_name: string;
    password: string;
    done_by: string;
    sub_book_id:string[];
    role:string;
    status: boolean;
}
export default model('user', new Schema<User>({
    code:{type: String,unique:true},
    user_name: String,
    password: String,
    sub_book_id:[{ type: Schema.Types.ObjectId, ref: 'sub_book' }],
    role:{type:String,enum:['Super Admin','Admin','Staff']},
    done_by: { type: Schema.Types.ObjectId, ref: 'user' },
    status: { type: Boolean, default: true },
}, {
    timestamps: true,
}));