import { Schema, model } from 'mongoose';
import { AccessModule } from './access-module-model';
import { AccessOption } from './access-option-model';
export interface AccessMenu{
    _id?:string;
    menu_name:string;
    route:string;
    module:string | null | AccessModule;
    options:string[] | AccessOption[];
    order_no:number;
    status:boolean;
}
export default model('access_menu', new Schema<AccessMenu>({
    menu_name:{type:String,required:true,trim:true,unique:false},
    route:String,
    module:{type:Schema.Types.ObjectId,ref:'access_module'},
    options:[{type:Schema.Types.ObjectId,ref:'access_option'}],
    order_no:Number,
	status:{type:Boolean,default:true},
}, {
    timestamps: true,
}));