import { Schema, model } from 'mongoose';
interface BankDetails {
    account_number: string;
    account_holder_name: string;
    bank_name: string;
    branch_name: string;
    ifsc_code: string;
    micr_code: string;
    is_primary: boolean;
    is_active: boolean;
}

interface OtherDetails {
    referred_by:string;
    credit_days: number;
    credit_limit: number;
    cash_discount: number;
    credit_discount: number;
    special_discount: number;
    grade: string;
    price_list: string;
    sales_person: string;
    commission: number;
    terms: string;
}
interface Address {
    address_line1: string;
    address_line2: string;
    country: string;
    state: string;
    district: string;
    area: string;
    pincode: number;
    type: 'Billing' | 'Shipping' | 'Communication';
    is_primary: boolean;
    is_active: boolean;
    contact_name: string;
    mobile_no: string;
    phone_no: string;
    email: string;
    website: string;
    transport: string;
    transport_mode: string;
    latitude: string;
    longitude: string;
    distance: String

}
interface KeyContacts {
    contact_name: string;
    designation: string;
    department: string;
    mobile_no: string;
    phone: string;
    email: string;
}
export interface Party {
    _id: string;
    book_id: string;
    sub_book_id: string;
    account_name: string;
    account_group?: string;
    alias: string;
    print_name: string;
    account_type: 'Vendor' | 'Customer';
    pan_no: string;
    gst_no: string;
    user_name: string;
    password: string;
    opening_balance_date:Date,
    opening_balance: number;
    posting: 'Cr' | 'Dr';
    metal_balance: number;
    transaction_amount: number;
    tds_applicable: boolean;
    tcs_applicable: boolean;
    address: Address[];
    key_contacts: KeyContacts[];
    bank_details: BankDetails[];
    other_details: OtherDetails;
    done_by: string;
    status: boolean;
}

export const partyModel = model('party', new Schema<Party>({
    book_id: { type: Schema.Types.ObjectId, ref: 'book' },
    sub_book_id: { type: Schema.Types.ObjectId, ref: 'sub_book' },
    account_name: { type: String, trim: true, uppercase: true },
    account_group: { type: Schema.Types.ObjectId, ref: 'account_group' },
    alias: String,
    print_name: String,
    account_type: { type: String, enum: ['Vendor', 'Customer'] },
    remarks: String,
    pan_no: { type: String, trim: true, uppercase: true, maxLength: 10 },
    gst_no: { type: String, trim: true, uppercase: true, maxLength: 15 },
    user_name: { type: String, trim: true },
    password: { type: String, trim: true },
    opening_balance_date:Date,
    opening_balance: Number,
    posting:  { type: String, enum: ['Dr', 'Cr'] },
    metal_balance: Number,
    transaction_amount: Number,
    tds_applicable: Boolean,
    tcs_applicable: Boolean,
    address: [
        {
            address_line1: String,
            address_line2: String,
            country: { type: Schema.Types.ObjectId, ref: 'country' },
            state: { type: Schema.Types.ObjectId, ref: 'state' },
            district: { type: Schema.Types.ObjectId, ref: 'district' },
            area: String,
            pincode: Number,
            type: { type: String, enum: ['Billing', 'Shipping', 'Communication'] },
            is_primary: { type: Boolean, default: false },
            is_active: { type: Boolean, default: true },
            contact_name: String,
            mobile_no: String,
            phone_no: String,
            email: String,
            website: String,
            transport: String,
            transport_mode: String,
            latitude: String,
            longitude: String,
            distance: String
        }
    ],
    key_contacts: [
        {
            contact_name: String,
            designation: String,
            department: String,
            mobile_no: String,
            phone: String,
            email: String,
        }
    ],
    bank_details: [
        {
            account_number: String,
            account_holder_name: String,
            bank_name: String,
            branch_name: String,
            ifsc_code: String,
            micr_code: String,
            is_primary: { type: Boolean, default: false },
            is_active: { type: Boolean, default: true },
        }
    ],
    other_details: {
        referred_by: String,
        credit_days: Number,
        credit_limit: Number,
        cash_discount: Number,
        credit_discount: Number,
        special_discount: Number,
        grade: { type: Schema.Types.ObjectId, ref: 'grade' },
        price_list: { type: Schema.Types.ObjectId, ref: 'price_list' },
        sales_person: { type: Schema.Types.ObjectId, ref: 'user' },
        commission: Number,
        terms: String,
    },
    done_by: { type: Schema.Types.ObjectId, ref: 'user' },
    status: { type: Boolean, default: true },
}, {
    timestamps: true,
}));
// export const openingBalanceModel=model('party_opening_balance', new Schema({
//     party_id: { type: Schema.Types.ObjectId, ref: 'party' },
//     date:{ type: Date, default: Date.now,set: LocalDate ,get:getLocalDate },
//     amount:Number,
//     posting:{type:String,enum:['Dr','Cr']},
//     metal_in_hand:Number,
//     done_by: { type: Schema.Types.ObjectId, ref: 'user' },
// }, {
//     timestamps: true,
//     toObject : {getters: true},
//     toJSON : {getters: true},
// }));