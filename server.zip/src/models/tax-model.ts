import { Schema, model } from 'mongoose';
export interface Tax {
    _id?:string;
    book_id:string;
    tax_name: string;
    tax_percentage: number;
    description:string;
    status: boolean;
}
export default model('tax', new Schema<Tax>({
    book_id: { type: Schema.Types.ObjectId, ref: 'book' },
    tax_name:{type:String,trim:true,uppercase:true, required: true,unique:true},
    tax_percentage:{type:Number, required:true},
    description:String,
	status:{type:Boolean,default:true},
}, {
    timestamps: true,
}));
