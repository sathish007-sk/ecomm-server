import { Schema, model } from 'mongoose';
export interface AccessSetting {
    id?: string;
    book_id: string | null;
    sub_book_id: string | null;
    user_id: string;
    done_by: string;
    menu_id: string;
    options: string[]
}
export default model('access_setting', new Schema<AccessSetting>({
    book_id: { type: Schema.Types.ObjectId, ref: 'book' },
    sub_book_id: { type: Schema.Types.ObjectId, ref: 'sub_book' },
    user_id: { type: Schema.Types.ObjectId, ref: 'user' },
    done_by: { type: Schema.Types.ObjectId, ref: 'user' },
    menu_id: { type: Schema.Types.ObjectId, ref: 'access_menu' },
    options: [{ type: Schema.Types.ObjectId, ref: 'access_option' }],

}, {
    timestamps: true,
}));