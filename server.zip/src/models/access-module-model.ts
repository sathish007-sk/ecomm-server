import { Schema, model } from 'mongoose';
export interface AccessModule {
    _id: string;
    module_name: string;
    icon: string | null;
    parent: string | AccessModule | null;
    order_no:number;
    status: boolean;
}
export default model('access_module', new Schema<AccessModule>({
    module_name: { type: String, required: true, trim: true },
    icon: String,
    parent: { type: Schema.Types.ObjectId, ref: 'access_module' },
    order_no:Number,
    status: { type: Boolean, default: true },
}, {
    timestamps: true,
}));