import { Schema, model } from 'mongoose';
export default model('book', new Schema({
    code: {type:String,trim:true,uppercase:true},
    name: {type:String,trim:true},
    database_name: String,
    status: { type: Boolean, default: true },
}, {
    timestamps: true,
}));