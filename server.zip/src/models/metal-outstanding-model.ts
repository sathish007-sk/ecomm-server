import { Schema, model } from 'mongoose';
export default model('metal_outstanding', new Schema({
    book_id: { type: Schema.Types.ObjectId, ref: 'book' },
    sub_book_id: { type: Schema.Types.ObjectId, ref: 'sub_book' },
    date:{ type: Date, default: Date.now },
    module: String,
    ref_id: { type: Schema.Types.ObjectId },
    ref_no: String,
    party_name: String,
    party_id: { type: Schema.Types.ObjectId,ref:'party' },
    item_details:[
        {
            product: { type: Schema.Types.ObjectId, ref: 'product' },
            quantity: Number,
            weight: Number,
            rate: Number,
            total: Number,
            status: { type: String, enum: ['in', 'out'] },
        }
    ],
    date_time:{ type: Date, default: Date.now},
    done_by:{type: Schema.Types.ObjectId,ref:'user' }
}, {
    timestamps: true,
    toObject : {getters: true},
    toJSON : {getters: true}
}));

