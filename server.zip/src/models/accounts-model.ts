import { model, Schema } from 'mongoose';
export interface Group {
    _id: string;
    group_name: string;
    parent: string | Group | null;
    status: boolean;
}
export const groupModel = model('account_group', new Schema<Group>({
    group_name: { type: String, required: true, unique: true, trim: true, uppercase: true },
    parent: { type: Schema.Types.ObjectId, ref: 'account_group' },
    status: { type: Boolean, default: true },
}, {
    timestamps: true,
}));
export interface Ledger {
    _id?: string;
    opening_balance_date?:Date,
    opening_balance?: number;
    posting?: 'Cr' | 'Dr';
    ledger_name: string;
    group: string | Group;
    status?: boolean;
    operation?: string;
    reference?: {
        ref_from?: string;
        ref_id?: string;
    };
}
export const ledgerModel = model('ledger', new Schema<Ledger>({
    ledger_name: { type: String, unique: true, required: true, trim: true, uppercase: true },
    group: { type: Schema.Types.ObjectId, ref: 'account_group' },
    status: { type: Boolean, default: true },
    opening_balance_date:Date,
    opening_balance: Number,
    posting:  { type: String, enum: ['Dr', 'Cr'] },
    operation: String,
    reference: {
        ref_from: String,
        ref_id: { type: Schema.Types.ObjectId },
    },
}, {
    timestamps: true,
}));
export interface VoucherDetail {
    ledger: string | Ledger;
    posting: string;
    amount: number;
    narration?: string;
}
export interface Voucher {
    _id?: string;
    book_id: string | null;
    sub_book_id: string | null;
    date: Date;
    voucher_no?: number;
    financial_year: string;
    voucher_type: string;
    voucher_for?: string;
    ref_id?: string | null;
    ref_no?: string;
    detail: VoucherDetail[];
    date_time?: Date;
    done_by: string;
}
export const voucherModel = model('voucher', new Schema<Voucher>({
    book_id: { type: Schema.Types.ObjectId, ref: 'book' },
    sub_book_id: { type: Schema.Types.ObjectId, ref: 'sub_book' },
    date: { type: Date, required: true },
    voucher_no: Number,
    financial_year: { type: String, required: true },
    voucher_type: { type: String, required: true },
    voucher_for: String,
    ref_id: { type: Schema.Types.ObjectId },
    ref_no: String,
    detail: [
        {
            ledger: { type: Schema.Types.ObjectId, ref: 'ledger' },
            posting: { type: String },
            amount: { type: Number, required: true },
            narration: String,
        }
    ],
    date_time: { type: Date, default: Date.now },
    done_by: { type: Schema.Types.ObjectId, ref: 'user' },
}, {
    timestamps: true,
    toObject : {getters: true},
    toJSON : {getters: true}
}));
