import { Schema, model } from 'mongoose';
export interface AccessOption{
    _id?:string;
    option_name:string;
    status:boolean;
}
export default model('access_option', new Schema<AccessOption>({
    option_name:{type:String,required:true,unique:true,trim:true},
	status:{type:Boolean,default:true},
}, {
    timestamps: true,
}));