import { Schema, model } from 'mongoose';
export default model('price_list', new Schema({
    book_id: { type: Schema.Types.ObjectId, ref: 'book' },
    sub_book_id: { type: Schema.Types.ObjectId, ref: 'sub_book' },
    product: { type: Schema.Types.ObjectId, ref: 'product' },
    price_list_name: String,
    print_name: String,
    alias: String,
    type: { type: String, enum: ['Purchase', 'Sales'] },
    touch: Number,
    tax: Number,
    hsn_code: String,
    making_cost_per_qty: Number,
    making_cost_per_piece: Number,
    done_by: { type: Schema.Types.ObjectId, ref: 'user' },
    status: { type: Boolean, default: true },
}, {
    timestamps: true,
    toObject : {getters: true},
    toJSON : {getters: true}
}));