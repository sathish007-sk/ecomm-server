import { model, Schema } from 'mongoose';
export interface ItemDetail {
    product: string;
    description: string;
    quantity: number;
    gross_weight: number;
    stone?: number;
    waste?: number;
    touch: number;
    touch_difference?: number;
    net_weight: number;
    rate_per_gram: number;
    tax_id: string,
    tax_percentage: number,
    tax_amount: number,
    discount?:number,
    special_discount?:number,
    total_discount?:number,
    total_discount_amount?:number,
    amount: number;
    mc_per_gram?: number;
    mc_per_piece?: number;
    mc_amount?: number;
    cost_rate?: number;
    tds_amount?: number;
    tcs_amount?: number;
    balance?: number;
}
export interface Sales {
    _id?: string;
    book_id: string | null;
    sub_book_id: string | null;
    reference_no?: string;
    material_transfer_id?: string;
    is_igst: boolean;
    party_id: string;
    party_name: string;
    financial_year: string;
    invoice_no: number;
    invoice_date: Date;
    invoice_amount: number;
    invoice_type: 'Cash' | 'Credit';
    price_list: string;
    remark: string;
    old_balance_amount: number;
    old_balance_metal: number;
    done_by: string;
    date_time: Date;
    item_details: ItemDetail[];
    round_off: number;
    metal_discount: number;
}

export const salesModel = model('sales', new Schema<Sales>({
    book_id: { type: Schema.Types.ObjectId, ref: 'book' },
    sub_book_id: { type: Schema.Types.ObjectId, ref: 'sub_book' },
    reference_no: String,
    material_transfer_id: { type: Schema.Types.ObjectId, ref: ' material_transfer' },
    is_igst: { type: Boolean, default: false },
    party_id: { type: Schema.Types.ObjectId, ref: 'party' },
    party_name: String,
    financial_year: String,
    invoice_no: Number,
    invoice_date: { type: Date},
    invoice_amount: Number,
    invoice_type: { type: String, enum: ['Cash', 'Credit'] },
    price_list: { type: Schema.Types.ObjectId, ref: 'price_list' },
    item_details: [{
        product: { type: Schema.Types.ObjectId, ref: 'product',required:true },
        description: String,
        quantity: Number,
        gross_weight: Number,
        stone: Number,
        waste: Number,
        touch: Number,
        touch_difference: Number,
        net_weight: Number,
        rate_per_gram: Number,
        tax_id: { type: Schema.Types.ObjectId, ref: 'tax',required:true },
        tax_percentage: Number,
        tax_amount: Number,
        amount: Number,
        mc_per_gram: Number,
        mc_per_piece: Number,
        mc_amount: Number,
        cost_rate: Number,
        discount:Number,
        special_discount:Number,
        total_discount:Number,
        total_discount_amount:Number,
        tds_amount:Number,
        tcs_amount:Number,
        balance:Number,
    }],
    remark: String,
    old_balance_amount: Number,
    old_balance_metal: Number,
    round_off: Number,
    metal_discount: Number,
    date_time: { type: Date, default: Date.now},
    done_by: { type: Schema.Types.ObjectId, ref: 'user' },
}, {
    timestamps: true,
    toObject : {getters: true},
    toJSON : {getters: true}
}));

export const salesLogModel = model('sales_log', new Schema({
    sales_id: { type: Schema.Types.ObjectId, ref: ' sales' },
    done_by: { type: Schema.Types.ObjectId, ref: 'user' },
    date_time: { type: Date, default: Date.now },
    action: { type: String, enum: ['Add', 'Edit', 'Delete', 'Print'] },
}, {
    timestamps: true,
    toObject : {getters: true},
    toJSON : {getters: true}
}));

export const conversionLogModel = model('conversion_transfer_log', new Schema({
    conversion_id: { type: Schema.Types.ObjectId, ref: ' conversion' },
    done_by: { type: Schema.Types.ObjectId, ref: 'user' },
    date_time: { type: Date, default: Date.now},
    action: { type: String, enum: ['Add', 'Edit', 'Delete', 'Print'] },
}, {
    timestamps: true,
    toObject : {getters: true},
    toJSON : {getters: true}
}));
export const conversionApprovalModel = model('conversion_approval', new Schema({
    conversion_id: { type: Schema.Types.ObjectId, ref: ' conversion' },
    done_by: { type: Schema.Types.ObjectId, ref: 'user' },
    date_time: { type: Date, default: Date.now },
    is_approved: { type: Boolean, default: true },
    reason: String,
}, {
    timestamps: true,
    toObject : {getters: true},
    toJSON : {getters: true}
}));
