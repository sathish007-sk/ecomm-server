import { Schema, model } from 'mongoose';
export default model('day_to_day_activity_sales', new Schema({
    book_id: { type: Schema.Types.ObjectId, ref: 'book' },
    sub_book_id: { type: Schema.Types.ObjectId, ref: 'sub_book' },
    date: { type: Date, default: Date.now},
    party_id: { type: Schema.Types.ObjectId, ref: 'party' },
    party_name:String,
    product: { type: Schema.Types.ObjectId, ref: 'product' },
    quantity: Number,
    weight: Number,
    rate: Number,
    total: Number,
    done_by: { type: Schema.Types.ObjectId, ref: 'user' },
    date_time: { type: Date, default: Date.now},
}, {
    timestamps: true,
    toObject : {getters: true},
    toJSON : {getters: true}
}));

