import { Schema, model } from 'mongoose';
export interface ItemDetail{
    product: string;
    description: string;
    quantity: number;
    gross_weight: number;
    stone?: number;
    waste?: number;
    touch: number;
    touch_difference?: number;
    net_weight: number;
    mc_per_gram?: number;
    mc_per_piece?: number;
    mc_amount?: number;    
}
export interface MetalReturn{
    _id?:string;
    book_id:string | null;
    sub_book_id:string | null;
    reference_no?:string;
    party_id:string;
    party_name:string;
    financial_year:string;
    invoice_no:number;
    invoice_date:Date;
    remark?:string;
    old_balance_amount?:number;
    old_balance_metal?:number;
    done_by?:string |  null;
    date_time?:Date;
    item_details: ItemDetail[];
    metal_discount: number;
}

export const metalReturnModal = model('metal_return', new Schema<MetalReturn>({
    book_id: { type: Schema.Types.ObjectId, ref: 'book' },
    sub_book_id: { type: Schema.Types.ObjectId, ref: 'sub_book' },
    reference_no: String,
    party_id: { type: Schema.Types.ObjectId, ref: 'party' },
    party_name:String,
    financial_year:String,
    invoice_no: Number,
    invoice_date: { type: Date, default: Date.now },
    item_details: [{
        product: { type: Schema.Types.ObjectId, ref: 'product' ,required:true},
        description: String,
        quantity: Number,
        less:Number,
        gross_weight: Number,
        stone: Number,
        waste: Number,
        touch: Number,
        touch_difference: Number,
        net_weight: Number,
        mc_per_gram: Number,
        mc_per_piece: Number,
        mc_amount: Number,
    }],
    remark: String,
    old_balance_amount: Number,
    old_balance_metal: Number,
    metal_discount: Number,
    done_by: { type: Schema.Types.ObjectId, ref: 'user' },
    date_time: { type: Date, default: Date.now },
}, {
    timestamps: true,
    toObject : {getters: true},
    toJSON : {getters: true}
}));