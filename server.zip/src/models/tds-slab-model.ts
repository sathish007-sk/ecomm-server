import { Schema, model } from 'mongoose';
export interface TdsSlab {
    _id?:string;
    book_id?:string;
    min_amount: number;
    max_amount:number;
    tax_percentage: number;
    status: boolean;
}
export default model('tds_slab', new Schema<TdsSlab>({
    book_id: { type: Schema.Types.ObjectId, ref: 'book' },
    min_amount:{type:Number},
    max_amount:{type:Number},
    tax_percentage:{type:Number, required:true},
	status:{type:Boolean,default:true},
}, {
    timestamps: true,
}));
