import { Schema, model } from 'mongoose';
export default model('terms', new Schema({
    for:{type: String,
        enum : ['sales','purchase','sales return','purchase return','quotation','proforma'],
        unique : true,
        trim:true,
    },
    points:[{type: String,trim:true}]
}, {
    timestamps: true,
}));