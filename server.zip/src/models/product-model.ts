import { Schema, model } from 'mongoose';
export interface Product{
    _id?:string;
    book_id: string | null;
    sub_book_id: string | null;
    product_name: string;
    print_name: string;
    code: string;
    group: string;
    category: string[];
    brand: string;
    tax_id: string;
    unit: string;
    decimals: number;
    touch: number;
    do_not_maintain_inventory?: boolean; 
    stop_transaction?: boolean; 
    remarks?: string;
    opening_balance_date:Date;
    opening_stock:number;
    done_by: string;
    date_time: Date;
    status: boolean; 
}
export const productModel= model('product', new Schema<Product>({
    book_id: { type: Schema.Types.ObjectId, ref: 'book' },
    sub_book_id: { type: Schema.Types.ObjectId, ref: 'sub_book' },
    product_name: {type:String,trim:true,uppercase:true},
    print_name: {type:String,trim:true,uppercase:true},
    code:  {type:String,trim:true,uppercase:true},
    group: { type: Schema.Types.ObjectId, ref: 'product_group' },
    category: [{ type: Schema.Types.ObjectId, ref: 'product_category' }],
    brand: { type: Schema.Types.ObjectId, ref: 'product_brand' },
    tax_id: { type: Schema.Types.ObjectId, ref: 'tax' },
    unit: String,
    decimals: Number,
    touch: Number,
    do_not_maintain_inventory: { type: Boolean, default: false },
    stop_transaction: { type: Boolean, default: false },
    remarks: String,
    opening_balance_date:Date,
    opening_stock:Number,
    done_by: { type: Schema.Types.ObjectId, ref: 'user' },
    status: { type: Boolean, default: true },
}, {
    timestamps: true,
}));
export const openingStockModel=model('product_opening_stock', new Schema({
    product_id: { type: Schema.Types.ObjectId, ref: 'product' },
    date:{ type: Date, default: Date.now },
    quantity:Number,
    value:Number,
    done_by: { type: Schema.Types.ObjectId, ref: 'user' },
}, {
    timestamps: true,
    toObject : {getters: true},
    toJSON : {getters: true}
}));

export const productCategoryModel = model('product_category', new Schema({
    book_id: { type: Schema.Types.ObjectId, ref: 'book' },
    sub_book_id: { type: Schema.Types.ObjectId, ref: 'sub_book' },
    name:{type:String,unique:true,required:true},
    parent:{type:Schema.Types.ObjectId,ref:'product_category'},
	status:{type:Boolean,default:true},
    done_by: { type: Schema.Types.ObjectId, ref: 'user' },
}, {
    timestamps: true,
}));
export const productGroupModel = model('product_group', new Schema({
    book_id: { type: Schema.Types.ObjectId, ref: 'book' },
    sub_book_id: { type: Schema.Types.ObjectId, ref: 'sub_book' },
    name:{type:String,unique:true,required:true},
	status:{type:Boolean,default:true},
    done_by: { type: Schema.Types.ObjectId, ref: 'user' },
}, {
    timestamps: true,
}));
export const productBrandModel = model('product_brand', new Schema({
    book_id: { type: Schema.Types.ObjectId, ref: 'book' },
    sub_book_id: { type: Schema.Types.ObjectId, ref: 'sub_book' },
    name:{type:String,unique:true,required:true},
	status:{type:Boolean,default:true},
    done_by: { type: Schema.Types.ObjectId, ref: 'user' },
}, {
    timestamps: true,
}));