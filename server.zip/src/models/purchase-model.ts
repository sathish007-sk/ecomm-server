import { Schema, model } from 'mongoose';

export interface ItemDetail{
    product: string;
    description: string;
    quantity: number;
    gross_weight: number;
    stone?: number;
    waste?: number;
    touch: number;
    touch_difference?: number;
    net_weight: number;
    rate_per_gram: number;
    tax_id:string,
    tax_percentage:number,
    tax_amount:number,
    amount: number;
    mc_per_gram?: number;
    mc_per_piece?: number;
    mc_amount?: number;
    cost_rate?: number;
    
}
export interface OtherExpenses{
    ledger_id: string,
    ledger_name: string,
    description?: string,
    amount: number,  
}
export interface Purchase{
    _id?:string;
    book_id:string | null;
    sub_book_id:string | null;
    reference_no?:string;
    is_igst:boolean;
    party_id:string;
    party_name:string;
    financial_year:string;
    invoice_no:number;
    invoice_date:Date;
    invoice_amount:number;
    invoice_type:'Cash' | 'Credit';
    remark:string;
    old_balance_amount:number;
    old_balance_metal:number;
    done_by:string;
    date_time:Date;
    item_details: ItemDetail[];
    round_off: number;
    metal_discount: number;
    other_expenses? :OtherExpenses[];
}

export const purchaseModel = model('purchase', new Schema<Purchase>({
    book_id: { type: Schema.Types.ObjectId, ref: 'book' },
    sub_book_id: { type: Schema.Types.ObjectId, ref: 'sub_book' },
    reference_no: String,
    party_id: { type: Schema.Types.ObjectId, ref: 'party' },
    party_name:String,
    financial_year:String,
    invoice_no: String,
    invoice_date:{ type: Date, default: Date.now},
    invoice_amount: Number,
    invoice_type:{ type: String, enum: ['Cash', 'Credit'] },
    pure_weight: Number,
    is_igst:{type:Boolean,default:false},
    item_details: [{
        product: { type: Schema.Types.ObjectId, ref: 'product',required:true },
        description: String,
        quantity: Number,
        gross_weight: Number,
        stone: Number,
        waste: Number,
        touch: Number,
        touch_difference: Number,
        net_weight: Number,
        rate_per_gram: Number,
        tax_id: { type: Schema.Types.ObjectId, ref: 'tax',required:true },
        tax_percentage:Number,
        tax_amount:Number,
        amount: Number,
        mc_per_gram: Number,
        mc_per_piece: Number,
        mc_amount: Number,
        cost_rate: Number,  
        tds_amount:Number,
        tcs_amount:Number, 
        balance:Number,    
    }],
    remark: String,
    old_balance_amount: Number,
    old_balance_metal: Number,
    metal_pure_round: Number,
    round_off: Number,
    metal_discount: Number,
    other_expenses: [{
        ledger_id: { type: Schema.Types.ObjectId, ref: ' ledger' },
        ledger_name: String,
        description: String,
        amount: Number,
    }],
    done_by: { type: Schema.Types.ObjectId, ref: 'user' },
    date_time:{ type: Date, default: Date.now},
}, {
    timestamps: true,
    toObject : {getters: true},
    toJSON : {getters: true}
}));

export const purchaseLogModel = model('purchase_log', new Schema({
    purchase_id: { type: Schema.Types.ObjectId, ref: ' purchase' },
    done_by: { type: Schema.Types.ObjectId, ref: 'user' },
    date_time:{ type: Date, default: Date.now},
    action:{ type: String, enum: ['Add', 'Edit' , 'Delete','Print'] },
}, {
    timestamps: true,
    toObject : {getters: true},
    toJSON : {getters: true}
}));