import { Voucher, voucherModel } from "../models/accounts-model";
import financialYearService from "../utils/financial-year-service";
import {
  CRUD,
  ValidateAdd,
  ValidateDelete,
  ValidateEdit,
  ValidateResponse,
} from "./crud-service";
export interface ReceiptPaymentContra {
  _id: string;
  book_id: string;
  sub_book_id: string | null;
  date: Date;
  voucher_no: number;
  financial_year: string;
  debit: string;
  credit: string;
  amount: string;
  narration?: string;
  done_by?: string;
  date_time?: Date;
}
export default class ReceiptService extends CRUD<any> {
  public model = voucherModel;
  protected voucherType = "Receipt";
  constructor() {
    super();
  }
  validateAdd: ValidateAdd = async (
    data: ReceiptPaymentContra
  ): Promise<ValidateResponse> => {
    let check = await this.checkExists(
      data.book_id,
      data.sub_book_id,
      data.voucher_no,
      data.financial_year
    );
    if (check) {
      return { success: false, message: "Already exists" };
    } else return { success: true };
  };
  validateEdit: ValidateEdit = async (
    data: ReceiptPaymentContra,
    _id: string
  ): Promise<ValidateResponse> => {
    let check = await this.checkExists(
      data.book_id,
      data.sub_book_id,
      data.voucher_no,
      data.financial_year,
      _id
    );
    if (check) {
      return { success: false, message: "Already exists" };
    } else return { success: true };
  };
  validateDelete: ValidateDelete = async (
    _id: string
  ): Promise<ValidateResponse> => {
    return { success: true };
  };
  async list(filter?: any) {
    try {
      let date = {};
      if (filter.from_date) {
        let fromDate = new Date(filter.from_date);
        fromDate.setHours(0, 0, 0, 0);
        delete filter.from_date;
        date = { $gte: fromDate, ...date };
      }
      if (filter?.to_date) {
        let toDate = new Date(filter.to_date);
        toDate.setHours(0, 0, 0, 0);
        toDate.setDate(toDate.getDate() + 1);
        delete filter.to_date;
        date = { $lte: toDate, ...date };
      }
      if (Object.keys(date).length > 0) {
        filter.date = date;
      }

      let result = await this.model
        .find({ voucher_type: this.voucherType, ...filter })
        .populate("detail.ledger")
        .sort({ date: -1 });
      return result.map((e: Voucher) => {
        let credit, debit;
        e.detail?.forEach((ele: any) => {
          if (ele.posting == "Dr") debit = ele.ledger?.ledger_name;
          else credit = ele.ledger?.ledger_name;
        });
        return {
          _id: e._id,
          date: e.date,
          voucher_no: e.voucher_no,
          financial_year: e.financial_year,
          debit: debit,
          credit: credit,
          amount: e.detail[0].amount,
          narration: e.detail[0].narration,
          done_by: e.done_by,
          date_time: e.date_time,
        };
      });
    } catch (error: any) {
      return { success: false, message: error.message };
    }
  }
  async retrieve(filter: any) {
    try {
      let e = await this.model.findOne(filter).populate("detail.ledger");
      let credit, debit;
      e.detail?.forEach((ele: any) => {
        if (ele.posting == "Dr") debit = ele.ledger;
        else credit = ele.ledger;
      });
      return {
        _id: e._id,
        date: e.date,
        voucher_no: e.voucher_no,
        financial_year: e.financial_year,
        debit: debit,
        credit: credit,
        amount: e.detail[0].amount,
        narration: e.detail[0].narration,
        done_by: e.done_by,
        date_time: e.date_time,
      };
    } catch (error: any) {
      throw new Error(error);
    }
  }
  async getVoucherNo(
    book_id: string | null,
    sub_book_id: string | null,
    date: Date
  ) {
    try {
      let voucher_no = 1;
      let financial_year = financialYearService(date);
      let check: any = await this.model
        .findOne({
          book_id: book_id,
          sub_book_id: sub_book_id,
          financial_year: financial_year,
          voucher_type: this.voucherType,
        })
        .sort({ voucher_no: -1 });
      if (check) voucher_no = check.voucher_no + 1;
      return {
        success: true,
        voucher_no: voucher_no,
        financial_year: financial_year,
      };
    } catch (error: any) {
      return { success: false, message: error.message };
    }
  }
  async checkExists(
    book_id: string | null,
    sub_book_id: string | null,
    voucher_no: number,
    financial_year: string,
    _id?: string | null
  ) {
    try {
      let filter: any = {
        book_id: book_id,
        sub_book_id: sub_book_id,
        financial_year: financial_year,
        voucher_no: voucher_no,
        voucher_type: this.voucherType,
      };
      if (_id) filter._id = { $ne: _id };
      let check: any = await this.model.findOne(filter);
      return check;
    } catch (error: any) {
      return { success: false, message: error.message };
    }
  }
  async add(data: ReceiptPaymentContra): Promise<any> {
    try {
      let obj = {
        book_id: data.book_id,
        sub_book_id: data.sub_book_id,
        date: data.date,
        voucher_no: data.voucher_no,
        financial_year: data.financial_year,
        voucher_type: this.voucherType,
        detail: [
          {
            ledger: data.debit,
            posting: "Dr",
            amount: data.amount,
            narration: data.narration,
          },
          {
            ledger: data.credit,
            posting: "Cr",
            amount: data.amount,
            narration: data.narration,
          },
        ],
        done_by: data.done_by,
      };
      let res = await super.add(obj);
      return res;
    } catch (error: any) {
      throw error;
    }
  }
  async update(data: ReceiptPaymentContra, filter: any): Promise<any> {
    try {
      let obj = {
        date: data.date,
        voucher_no: data.voucher_no,
        financial_year: data.financial_year,
        voucher_type: this.voucherType,
        detail: [
          {
            ledger: data.debit,
            posting: "Dr",
            amount: data.amount,
            narration: data.narration,
          },
          {
            ledger: data.credit,
            posting: "Cr",
            amount: data.amount,
            narration: data.narration,
          },
        ],
        done_by: data.done_by,
      };
      let res = await super.update(obj, filter);
      return res;
    } catch (error: any) {
      return { success: false, message: error.message };
    }
  }
}
