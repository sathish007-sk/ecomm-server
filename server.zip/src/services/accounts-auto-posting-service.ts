import {
  Ledger,
  Voucher,
  VoucherDetail,
  voucherModel,
} from "../models/accounts-model";
import { OtherExpenses, Purchase } from "../models/purchase-model";
import { ItemDetail, Sales } from "../models/sales-model";
import { TcsSlab } from "../models/tcs-slab-model";
import { TdsSlab } from "../models/tds-slab-model";
import JournalService, { Journal } from "./journal-service";
import LedgerService from "./ledger-service";
import PartyService from "./party-service";
import TcsSlabService from "./tcs-slab-service";
import TdsSlabService from "./tds-slab-service";
export class AccountsAutoPostingService extends LedgerService {
  taxLedgersList!: Ledger[];
  tdsservice = new TdsSlabService();
  tcsservice = new TcsSlabService();
  tdsSlab!: TdsSlab[];
  tcsSlab!: TcsSlab[];
  excemptedValue: number = 0;
  constructor() {
    super();
  }
  async onInit() {
    this.tdsSlab = await this.tdsservice.getSlab();
    this.tcsSlab = await this.tcsservice.getSlab();
    if (this.tdsSlab.length > 0)
      this.excemptedValue = this.tdsSlab[0].min_amount - 1;
    this.taxLedgersList = await this.list({ "reference.ref_from": "tax" });
  }
  findTdsSlab(amount: number) {
    let slab = this.tdsSlab.find(
      (e: TdsSlab) =>
        e.min_amount < amount && (e.max_amount > amount || e.max_amount == 0)
    );
    return slab;
  }
  findTcsSlab(amount: number) {
    let slab = this.tcsSlab.find(
      (e: TcsSlab) =>
        e.min_amount < amount && (e.max_amount > amount || e.max_amount == 0)
    );
    return slab;
  }
  async tds(data: Sales, mode: "Add" | "Edit" | "Delete") {
    let journalservice = new JournalService();
    let tdsAcc = await voucherModel.findOne({
      voucher_type: "Journal",
      ref_id: data._id,
      voucher_for: "Sales",
    });
    if (mode === "Delete") {
      if (tdsAcc) await journalservice.deleteById(tdsAcc._id);
      return false;
    }
    let tax_amount = data.item_details.reduce((carry: number, ele) => {
      if (ele.tds_amount) carry += ele.tds_amount;
      return carry;
    }, 0);

    if (tax_amount > 0) {
      let narration = "TDS RECEIVABLE";
      let date = new Date();
      let tax_ledger = await this.tdsReceivable();
      let partyLedger = await this.getPartyLedger(data.party_id);

      let detail = [
        {
          ledger: partyLedger._id,
          debit: 0,
          credit: tax_amount,
          narration: narration,
        },
        {
          ledger: tax_ledger._id,
          debit: tax_amount,
          credit: 0,
          narration: narration,
        },
      ];
      if (!tdsAcc) {
        let j_no = await journalservice.getVoucherNo(
          data.book_id,
          data.sub_book_id,
          date
        );
        if (j_no.success) {
          let obj: Journal = {
            date: date,
            book_id: data.book_id,
            sub_book_id: data.sub_book_id,
            voucher_for: "Sales",
            voucher_no: j_no?.voucher_no ?? 0,
            financial_year: j_no.financial_year ? j_no.financial_year : "",
            ref_id: data._id,
            ref_no: String(data.invoice_no),
            detail: detail,
            done_by: data.done_by,
          };
          let res = await journalservice.add(obj);
        }
      } else {
        let obj: Journal = {
          date: tdsAcc.date,
          book_id: tdsAcc.book_id,
          sub_book_id: tdsAcc.sub_book_id,
          financial_year: tdsAcc.financial_year,
          voucher_for: tdsAcc.voucher_for,
          voucher_no: tdsAcc.voucher_no,
          detail: detail,
        };
        let res = await journalservice.updateById(obj, tdsAcc._id);
      }
    } else {
      if (tdsAcc) await journalservice.deleteById(tdsAcc._id);
    }

    /*
        let total_sales: number = await salesservice.totalSales(data.party_id, data.financial_year, data._id);
        let slab = this.findTdsSlab(total_sales + data.invoice_amount);
        if (slab) {
            let taxable;
            if (total_sales <= this.excemptedValue) {
                let diff = this.excemptedValue - total_sales
                taxable = data.invoice_amount - diff;
            }
            else taxable = data.invoice_amount;
            if (taxable > 0) {
                let tax_amount = taxable * (slab.tax_percentage / 100);
                
            }
        }
        */
  }
  async tcs(data: Sales, mode: "Add" | "Edit" | "Delete") {
    let journalservice = new JournalService();
    let tcsAcc = await voucherModel.findOne({
      voucher_type: "Journal",
      ref_id: data._id,
      voucher_for: "Sales",
    });
    if (mode === "Delete") {
      if (tcsAcc) await journalservice.deleteById(tcsAcc._id);
      return false;
    }
    let tax_amount = data.item_details.reduce((carry: number, ele) => {
      if (ele.tcs_amount) carry += ele.tcs_amount;
      return carry;
    }, 0);
    if (tax_amount > 0) {
      let narration = "TCS RECEIVABLE";
      let date = new Date();
      let tax_ledger = await this.tcsReceivable();
      let partyLedger = await this.getPartyLedger(data.party_id);

      let detail = [
        {
          ledger: partyLedger._id,
          debit: 0,
          credit: tax_amount,
          narration: narration,
        },
        {
          ledger: tax_ledger._id,
          debit: tax_amount,
          credit: 0,
          narration: narration,
        },
      ];
      if (!tcsAcc) {
        let j_no = await journalservice.getVoucherNo(
          data.book_id,
          data.sub_book_id,
          date
        );
        if (j_no.success) {
          let obj: Journal = {
            date: date,
            book_id: data.book_id,
            sub_book_id: data.sub_book_id,
            voucher_for: "Sales",
            voucher_no: j_no?.voucher_no ?? 0,
            financial_year: j_no.financial_year ? j_no.financial_year : "",
            ref_id: data._id,
            ref_no: String(data.invoice_no),
            detail: detail,
            done_by: data.done_by,
          };
          let res = await journalservice.add(obj);
        }
      } else {
        let obj: Journal = {
          date: tcsAcc.date,
          book_id: tcsAcc.book_id,
          sub_book_id: tcsAcc.sub_book_id,
          financial_year: tcsAcc.financial_year,
          voucher_for: tcsAcc.voucher_for,
          voucher_no: tcsAcc.voucher_no,
          detail: detail,
        };
        let res = await journalservice.updateById(obj, tcsAcc._id);
      }
    } else {
      if (tcsAcc) await journalservice.deleteById(tcsAcc._id);
    }
  }
  async sales(data: Sales, mode: "Add" | "Edit" | "Delete") {
    await this.onInit();
    let acc = await voucherModel.findOne({
      voucher_type: "Sales",
      ref_id: data._id,
      voucher_for: { $exists: false },
    });
    let roundAcc = await voucherModel.findOne({
      voucher_type: "Sales",
      ref_id: data._id,
      voucher_for: "Round Off",
    });
    if (mode === "Delete") {
      if (acc) await acc.deleteOne();
      if (roundAcc) await roundAcc.deleteOne();
      await this.tds(data, mode);
      return false;
    }
    var narration = "Sales Bill No: " + data.invoice_no;
    let taxGroup = data.item_details.reduce(
      (carry: any, element: ItemDetail) => {
        let index = carry.findIndex(
          (e: any) => String(e.tax_id) === String(element.tax_id)
        );
        if (index == -1) {
          let obj = {
            tax_id: element.tax_id,
            tax_percentage: element.tax_percentage,
            tax_amount: Number(element.tax_amount),
            taxable: Number(element.amount) - Number(element.tax_amount),
          };
          carry.push(obj);
        } else {
          carry[index].tax_amount += Number(element.tax_amount);
          carry[index].taxable +=
            Number(element.amount) - Number(element.tax_amount);
        }
        return carry;
      },
      []
    );

    let detail: VoucherDetail[] = [];
    if (data.is_igst === false) {
      taxGroup.forEach((element: any) => {
        let ledger = this.taxLedgersList.find(
          (e) =>
            String(e.reference?.ref_id) == String(element.tax_id) &&
            e.operation == "LOCAL SALES"
        );
        if (ledger && ledger._id) {
          detail.push({
            ledger: ledger._id,
            posting: "Cr",
            amount: element.taxable,
            narration: narration,
          });
        }
      });

      taxGroup.forEach((element: any) => {
        let ledger = this.taxLedgersList.find(
          (e) =>
            String(e.reference?.ref_id) == String(element.tax_id) &&
            e.operation == "OUTPUT CGST"
        );
        if (ledger && ledger._id) {
          detail.push({
            ledger: ledger._id,
            posting: "Cr",
            amount: element.tax_amount / 2,
            narration: narration,
          });
        }
        ledger = this.taxLedgersList.find(
          (e) =>
            String(e.reference?.ref_id) == String(element.tax_id) &&
            e.operation == "OUTPUT SGST"
        );
        if (ledger && ledger._id) {
          detail.push({
            ledger: ledger._id,
            posting: "Cr",
            amount: element.tax_amount / 2,
            narration: narration,
          });
        }
      });
    } else {
      taxGroup.forEach((element: any) => {
        let ledger = this.taxLedgersList.find(
          (e) =>
            String(e.reference?.ref_id) == String(element.tax_id) &&
            e.operation == "INTERSTATE SALES"
        );
        if (ledger && ledger._id) {
          detail.push({
            ledger: ledger._id,
            posting: "Cr",
            amount: element.taxable,
            narration: narration,
          });
        }
      });
      taxGroup.forEach((element: any) => {
        let ledger = this.taxLedgersList.find(
          (e) =>
            String(e.reference?.ref_id) == String(element.tax_id) &&
            e.operation == "OUTPUT IGST"
        );
        if (ledger && ledger._id && element?.tax_amount>0) {
          detail.push({
            ledger: ledger._id,
            posting: "Cr",
            amount: element.tax_amount,
            narration: narration,
          });
        }
      });
    }

    if (data.round_off > 0) {
      let ledger: Ledger = await this.roundOff();
      if (ledger._id) {
        detail.push({
          ledger: ledger._id,
          posting: "Cr",
          amount: data.round_off,
          narration: narration,
        });
      }
    }

    let partyLedger = await this.getPartyLedger(data.party_id);
    if (partyLedger._id) {
      detail.push({
        ledger: partyLedger._id,
        posting: "Dr",
        amount: data.invoice_amount,
        narration: narration,
      });
    }

    if (!acc) {
      let obj: Voucher = {
        financial_year: data.financial_year,
        book_id: data.book_id,
        sub_book_id: data.sub_book_id,
        date: data.invoice_date,
        voucher_type: "Sales",
        ref_id: data._id,
        ref_no: String(data.invoice_no),
        done_by: data.done_by,
        detail: detail,
      };
      let save = await voucherModel.create(obj);
    } else {
      acc.ref_no = String(data.invoice_no);
      acc.financial_year = data.financial_year;
      acc.date = data.invoice_date;
      acc.detail = detail;
      let save = await acc.save();
    }

    detail = [];
    if (data.round_off < 0) {
      let ledger: Ledger = await this.roundOff();
      if (ledger._id) {
        detail.push({
          ledger: ledger._id,
          posting: "Dr",
          amount: Math.abs(data.round_off),
          narration: narration,
        });
      }

      if (partyLedger._id) {
        detail.push({
          ledger: partyLedger._id,
          posting: "Cr",
          amount: Math.abs(data.round_off),
          narration: narration,
        });
      }
      if (!roundAcc) {
        let rData = {
          financial_year: data.financial_year,
          book_id: data.book_id,
          sub_book_id: data.sub_book_id,
          date: data.invoice_date,
          voucher_type: "Sales",
          voucher_for: "Round Off",
          ref_id: data._id,
          ref_no: String(data.invoice_no),
          done_by: data.done_by,
          detail: detail,
        };
        let save = await voucherModel.create(rData);
      } else {
        roundAcc.ref_no = String(data.invoice_no);
        roundAcc.financial_year = data.financial_year;
        roundAcc.date = data.invoice_date;
        roundAcc.detail = detail;
        let save = await roundAcc.save();
      }
    } else if (roundAcc) {
      await roundAcc.deleteOne();
    }

    let partyservice = new PartyService();
    let party = await partyservice.retrieveById(data.party_id);
    if (party.tds_applicable) {
      await this.tds(data, mode);
    } else if (party.tcs_applicable) {
      await this.tcs(data, mode);
    }
  }

  async purchase(data: Purchase, mode: "Add" | "Edit" | "Delete") {
    try {
      await this.onInit();
      let acc = await voucherModel.findOne({
        voucher_type: "Purchase",
        ref_id: data._id,
        voucher_for: { $exists: false },
      });
      let roundAcc = await voucherModel.findOne({
        voucher_type: "Purchase",
        ref_id: data._id,
        voucher_for: "Round Off",
      });

      if (mode === "Delete") {
        if (acc) await acc.deleteOne();
        if (roundAcc) await roundAcc.deleteOne();
        this.purchaseTdsOrTcs(data, mode);
        return false;
      }
      var narration = "Purchase Bill No: " + data.invoice_no;
      let taxGroup = data.item_details.reduce(
        (carry: any, element: ItemDetail) => {
          let index = carry.findIndex(
            (e: any) => String(e.tax_id) === String(element.tax_id)
          );
          if (index == -1) {
            let obj = {
              tax_id: element.tax_id,
              tax_percentage: element.tax_percentage,
              tax_amount: Number(element.tax_amount),
              taxable: Number(element.amount) - Number(element.tax_amount),
            };
            carry.push(obj);
          } else {
            carry[index].tax_amount += Number(element.tax_amount);
            carry[index].taxable +=
              Number(element.amount) - Number(element.tax_amount);
          }
          return carry;
        },
        []
      );

      let detail: VoucherDetail[] = [];
      if (data.is_igst === false) {
        taxGroup?.forEach((element: any) => {
          let ledger = this.taxLedgersList.find(
            (e) =>
              String(e.reference?.ref_id) == String(element.tax_id) &&
              e.operation == "LOCAL PURCHASE"
          );
          if (ledger && ledger._id) {
            detail.push({
              ledger: ledger._id,
              posting: "Dr",
              amount: element.taxable,
              narration: narration,
            });
          }
        });

        taxGroup?.forEach((element: any) => {
          let ledger = this.taxLedgersList.find(
            (e) =>
              String(e.reference?.ref_id) == String(element.tax_id) &&
              e.operation == "INPUT CGST"
          );
          if (ledger && ledger._id) {
            detail.push({
              ledger: ledger._id,
              posting: "Dr",
              amount: element.tax_amount / 2,
              narration: narration,
            });
          }
          ledger = this.taxLedgersList.find(
            (e) =>
              String(e.reference?.ref_id) == String(element.tax_id) &&
              e.operation == "INPUT SGST"
          );
          if (ledger && ledger._id) {
            detail.push({
              ledger: ledger._id,
              posting: "Dr",
              amount: element.tax_amount / 2,
              narration: narration,
            });
          }
        });
      } else {
        taxGroup?.forEach((element: any) => {
          let ledger = this.taxLedgersList.find(
            (e) =>
              String(e.reference?.ref_id) == String(element.tax_id) &&
              e.operation == "INTERSTATE PURCHASE"
          );
          if (ledger && ledger._id) {
            detail.push({
              ledger: ledger._id,
              posting: "Dr",
              amount: element.taxable,
              narration: narration,
            });
          }
        });
        taxGroup?.forEach((element: any) => {
          let ledger = this.taxLedgersList.find(
            (e) =>
              String(e.reference?.ref_id) == String(element.tax_id) &&
              e.operation == "INPUT IGST"
          );
          if (ledger && ledger._id) {
            detail.push({
              ledger: ledger._id,
              posting: "Dr",
              amount: element.tax_amount,
              narration: narration,
            });
          }
        });
      }

      if (data.round_off > 0) {
        let ledger: Ledger = await this.roundOff();
        if (ledger._id) {
          detail.push({
            ledger: ledger._id,
            posting: "Dr",
            amount: data.round_off,
            narration: narration,
          });
        }
      }
      data.other_expenses?.forEach((ele: OtherExpenses) => {
        if (ele.ledger_id) {
          detail.push({
            ledger: ele.ledger_id,
            posting: "Dr",
            amount: ele.amount,
            narration: ele.description,
          });
        }
      });

      let partyLedger = await this.getPartyLedger(data.party_id);
      if (partyLedger._id) {
        detail.push({
          ledger: partyLedger._id,
          posting: "Cr",
          amount: data.invoice_amount,
          narration: narration,
        });
      }

      if (!acc) {
        let obj: Voucher = {
          financial_year: data.financial_year,
          book_id: data.book_id,
          sub_book_id: data.sub_book_id,
          date: data.invoice_date,
          voucher_type: "Purchase",
          ref_id: data._id,
          ref_no: String(data.invoice_no),
          done_by: data.done_by,
          detail: detail,
        };
        let save = await voucherModel.create(obj);
      } else {
        acc.ref_no = String(data.invoice_no);
        acc.financial_year = data.financial_year;
        acc.date = data.invoice_date;
        acc.detail = detail;
        let save = await acc.save();
      }

      detail = [];
      if (data.round_off < 0) {
        let ledger: Ledger = await this.roundOff();
        if (ledger._id) {
          detail.push({
            ledger: ledger._id,
            posting: "Cr",
            amount: Math.abs(data.round_off),
            narration: narration,
          });
        }

        if (partyLedger._id) {
          detail.push({
            ledger: partyLedger._id,
            posting: "Dr",
            amount: Math.abs(data.round_off),
            narration: narration,
          });
        }
        if (!roundAcc) {
          let rData = {
            financial_year: data.financial_year,
            book_id: data.book_id,
            sub_book_id: data.sub_book_id,
            date: data.invoice_date,
            voucher_type: "Purchase",
            voucher_for: "Round Off",
            ref_id: data._id,
            ref_no: String(data.invoice_no),
            done_by: data.done_by,
            detail: detail,
          };
          let save = await voucherModel.create(rData);
        } else {
          roundAcc.ref_no = String(data.invoice_no);
          roundAcc.financial_year = data.financial_year;
          roundAcc.date = data.invoice_date;
          roundAcc.detail = detail;
          let save = await roundAcc.save();
        }
      } else if (roundAcc) {
        await roundAcc.deleteOne();
      }
      this.purchaseTdsOrTcs(data, mode);
    } catch (error) {
      throw error;
    }
  }
  async purchaseTdsOrTcs(data: Purchase, mode: "Add" | "Edit" | "Delete") {
    try {
      let narration;
      let date = new Date();
      let journalservice = new JournalService();
      let tcsAcc = await voucherModel.findOne({
        voucher_type: "Journal",
        ref_id: data._id,
        voucher_for: "Purchase",
      });
      if (mode === "Delete") {
        if (tcsAcc) await journalservice.deleteById(tcsAcc._id);
        return false;
      }
      let tdsAmount = data.item_details.reduce((c: number, e: any) => {
        return c + e.tds_amount ?? 0;
      }, 0);
      let tcsAmount = data.item_details.reduce((c: number, e: any) => {
        return c + e.tcs_amount ?? 0;
      }, 0);
      if (tdsAmount > 0 || tcsAmount > 0) {
        let tax_ledger, amount;
        if (tdsAmount > 0) {
          narration = "TDS Payable";
          tax_ledger = await this.tdsPayable();
          amount = tdsAmount;
        } else {
          narration = "TCS Payable";
          tax_ledger = await this.tcsPayable();
          amount = tcsAmount;
        }
        let partyLedger = await this.getPartyLedger(data.party_id);

        let detail = [
          {
            ledger: tax_ledger._id,
            debit: 0,
            credit: amount,
            narration: narration,
          },
          {
            ledger: partyLedger._id,
            debit: amount,
            credit: 0,
            narration: narration,
          },
        ];
        if (!tcsAcc) {
          let j_no = await journalservice.getVoucherNo(
            data.book_id,
            data.sub_book_id,
            date
          );
          if (j_no.success) {
            let obj: Journal = {
              date: date,
              book_id: data.book_id,
              sub_book_id: data.sub_book_id,
              voucher_for: "Purchase",
              voucher_no: j_no?.voucher_no ?? 0,
              financial_year: j_no.financial_year ? j_no.financial_year : "",
              ref_id: data._id,
              ref_no: String(data.invoice_no),
              detail: detail,
              done_by: data.done_by,
            };
            let res = await journalservice.add(obj);
          }
        } else {
          let obj: Journal = {
            date: tcsAcc.date,
            book_id: tcsAcc.book_id,
            sub_book_id: tcsAcc.sub_book_id,
            financial_year: tcsAcc.financial_year,
            voucher_for: tcsAcc.voucher_for,
            voucher_no: tcsAcc.voucher_no,
            detail: detail,
          };
          let res = await journalservice.updateById(obj, tcsAcc._id);
        }
      } else {
        if (tcsAcc) await journalservice.deleteById(tcsAcc._id);
      }
    } catch (error) {
      throw error;
    }
  }
}
