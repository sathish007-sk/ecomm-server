export const date=()=>{
   return new Date();
}