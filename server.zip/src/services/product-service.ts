import { Product, productModel } from '../models/product-model';
import { CRUD, ValidateAdd, ValidateDelete, ValidateEdit, ValidateResponse } from './crud-service';
import StockService from './stock-service';

export default class ProductService extends CRUD<Product>{
    public model=productModel;
    private stockservice=new StockService();
    constructor(){
       super();
    }
    validateAdd: ValidateAdd=async(data:Product):Promise<ValidateResponse>=>{
        try {
            let check=await this.model.findOne({ book_id:data.book_id,product_name: { $regex: new RegExp("^" + data.product_name.toLowerCase()+"$", "i")}});
            if(check)return {success:false, message:"Already Exists"};
            return {success:true};
        } catch (error:any) {
            throw new Error(error);
        }       
    }
    validateEdit: ValidateEdit=async(data:Product,id:string):Promise<ValidateResponse>=>{
        try {
            let check=await this.model.findOne({ book_id:data.book_id,product_name: { $regex: new RegExp("^" + data.product_name.toLowerCase()+"$", "i")},_id:{$ne:id}});
            if(check)return {success:false, message:"Already Exists"};
            return {success:true};
        } catch (error:any) {
            throw new Error(error);
        }       
    }
    validateDelete: ValidateDelete=async(id:string):Promise<ValidateResponse>=>{
        return {success:true};
    }
    async callBackEdit(data:Product){
        try {
            await this.stockservice.openingStock(data,"Edit") 
        } catch (error:any) {
            throw new Error(error);
        }
    }
    async callBackAdd(data:Product){
        try {
            await this.stockservice.openingStock(data,"Add")
        } catch (error:any) {
            throw new Error(error);
        }
    }
    async callBackDelete(data:Product){
        try {
            await this.stockservice.openingStock(data,"Delete")  
        } catch (error:any) {
            throw new Error(error);
        }
    }
}