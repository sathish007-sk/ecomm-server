import { MetalReturn, metalReturnModal } from '../models/metal-return-schema';
import financialYearService from '../utils/financial-year-service';
import { CRUD, ValidateAdd, ValidateDelete, ValidateEdit, ValidateResponse } from './crud-service';
import StockService from './stock-service';
export class MetalReturnService extends CRUD<MetalReturn>{
    model= metalReturnModal;
    stockservice=new StockService();
    validateAdd: ValidateAdd = async (data: MetalReturn): Promise<ValidateResponse> => {
       return { success: true }
    }
    validateEdit: ValidateEdit = async (data: MetalReturn, id: string): Promise<ValidateResponse> => {
        let check = await this.checkExists(data.book_id,data.sub_book_id,data.invoice_no, data.financial_year,id);
        if (check) {
            return { success: false, message: 'Already exists' };
        }
        return { success: true };
    }
    validateDelete: ValidateDelete = async (id: string): Promise<ValidateResponse> => {
       return { success: true };
    }  
    async list(filter?:any){
        try {
            let date = {};
            if (filter.from_date) {
              let fromDate = new Date(filter.from_date);
              fromDate.setHours(0, 0, 0, 0);
              delete filter.from_date;
              date = { $gte: fromDate, ...date };
            }
            if (filter?.to_date) {
              let toDate = new Date(filter.to_date);
              toDate.setHours(0, 0, 0, 0);
              toDate.setDate(toDate.getDate() + 1);
              delete filter.to_date;
              date = { $lte: toDate, ...date };
            }
            if (Object.keys(date).length > 0) {
              filter.invoice_date = date;
            }
            let result = await this.model.find(filter).sort({invoice_date:-1}) as MetalReturn[];
            return result;
        } catch (error:any) {
           throw new Error(error);
        }
    }
    async callBackAdd(data:MetalReturn){
        await this.stockservice.metalReturn(data,"Add");
    }   
    async callBackEdit(data:MetalReturn){
        await this.stockservice.metalReturn(data,"Edit");
    }   
    async callBackDelete(data:MetalReturn){
        await this.stockservice.metalReturn(data,'Delete');
    }
    async getBillNo(book_id:string |null ,sub_book_id:string | null,date: Date) {
       
        try {          
            let invoice_no = 1;
            let financial_year = financialYearService(date);
            let check:any=await this.model.findOne({financial_year:financial_year,book_id:book_id,sub_book_id:sub_book_id}).sort({invoice_no:-1});
            if (check) invoice_no = check.invoice_no + 1;
            return { success: true, invoice_no: invoice_no, financial_year: financial_year };
        } catch (error:any) {
            throw new Error(error);
        }
    }
    async checkExists(book_id:string | null,sub_book_id:string | null,invoice_no: number, financial_year: string, _id?: string | null) {
        try {
            let filter: any = {book_id:book_id,sub_book_id:sub_book_id,financial_year: financial_year, invoice_no: invoice_no };
            if(_id) filter._id = { $ne: _id };
            let check: MetalReturn = await this.model.findOne(filter);
            return check;
    
        } catch (error:any) {
            throw new Error(error);
        }
    
    }
    async preAdd(data: MetalReturn): Promise<MetalReturn> {    
        let check = await this.checkExists(
          data.book_id,
          data.sub_book_id,
          data.invoice_no,
          data.financial_year
        );
        if (check) {
          let obj = await this.getBillNo(
            data.book_id,
            data.sub_book_id,
            data.invoice_date
          );
          data.invoice_no = obj.invoice_no;
          data.financial_year = obj.financial_year;
        }
        return data;
    }
}