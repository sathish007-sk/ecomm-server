import { Voucher } from "../models/accounts-model";

import dashboardMappingModel, { DashboardMapping } from "../models/dashboard-mapping-model";
import { CRUD, ValidateAdd, ValidateDelete, ValidateEdit, ValidateResponse } from "./crud-service";

export default class DashboardMappingService extends CRUD<DashboardMapping>{
    model=dashboardMappingModel;
    constructor() {
        super();
    }
    validateAdd: ValidateAdd = async (data: DashboardMapping): Promise<ValidateResponse> => {
        return { success: true }
    }
    validateEdit: ValidateEdit = async (data: DashboardMapping, _id: string): Promise<ValidateResponse> => {
        return { success: true }
    }
    validateDelete: ValidateDelete = async (_id: string): Promise<ValidateResponse> => {
        return { success: true }
    }
    save=async(data:DashboardMapping)=>{
        try {
            let check=await this.model.findOne({user_id:data.user_id,sub_book_id:data.sub_book_id});
            if(check){
                await this.updateById({
                    book_id: data.book_id,
                    sub_book_id: data.sub_book_id,
                    user_id:data.user_id,
                    dashboard_id:data.dashboard_id,
                    done_by: data.done_by,
                },check._id);
               
                
            }
            else{
                await this.add({
                    book_id: data.book_id,
                    sub_book_id: data.sub_book_id,
                    user_id:data.user_id,
                    dashboard_id:data.dashboard_id,
                    done_by: data.done_by,
                })
            }
            return {success:true,message:"Saved Successfully"};
        } catch (error) {
            throw error;
        }
    }
}
