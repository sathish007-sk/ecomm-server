import {
  Ledger,
  Voucher,
  VoucherDetail,
  voucherModel,
} from "../models/accounts-model";
import financialYearService from "../utils/financial-year-service";
import {
  CRUD,
  ValidateAdd,
  ValidateDelete,
  ValidateEdit,
  ValidateResponse,
} from "./crud-service";

export interface JournalDetail {
  ledger: string | Ledger;
  credit: number;
  debit: number;
  narration: string;
}
export interface Journal {
  _id?: string;
  book_id: string | null;
  sub_book_id: string | null;
  date: Date;
  voucher_no: number;
  financial_year: string;
  detail: JournalDetail[];
  done_by?: string | null;
  ref_id?: string | null;
  ref_no?: string;
  voucher_for?: string;
}
export default class JournalService extends CRUD<any> {
  public model = voucherModel;
  protected voucherType = "Journal";
  constructor() {
    super();
  }
  validateAdd: ValidateAdd = async (
    data: Voucher
  ): Promise<ValidateResponse> => {
    let check = await this.checkExists(
      data.book_id,
      data.sub_book_id,
      Number(data.voucher_no),
      data.financial_year
    );
    if (check) {
      return { success: false, message: "Already exists" };
    } else return { success: true };
  };
  validateEdit: ValidateEdit = async (
    data: Voucher,
    _id: string
  ): Promise<ValidateResponse> => {
    let check = await this.checkExists(
      data.book_id,
      data.sub_book_id,
      Number(data.voucher_no),
      data.financial_year,
      _id
    );
    if (check) {
      return { success: false, message: "Already exists" };
    } else return { success: true };
  };
  validateDelete: ValidateDelete = async (
    _id: string
  ): Promise<ValidateResponse> => {
    return { success: true };
  };
  async list(filter: any) {
    try {
      let date = {};
      if (filter.from_date) {
        let fromDate = new Date(filter.from_date);
        fromDate.setHours(0, 0, 0, 0);
        delete filter.from_date;
        date = { $gte: fromDate, ...date };
      }
      if (filter?.to_date) {
        let toDate = new Date(filter.to_date);
        toDate.setHours(0, 0, 0, 0);
        toDate.setDate(toDate.getDate() + 1);
        delete filter.to_date;
        date = { $lte: toDate, ...date };
      }
      if (Object.keys(date).length > 0) {
        filter.date = date;
      }
      let result = await this.model
        .find({ voucher_type: this.voucherType, ...filter })
        .populate("detail.ledger")
        .sort({ date: -1 });
      return result.map((e: any) => {
        return {
          _id: e._id,
          date: e.date,
          voucher_no: e.voucher_no,
          ref_no: e.ref_no,
          ref_id: e.ref_id,
          financial_year: e.financial_year,
          voucher_for: e.voucher_for,
          dr: e.detail
            .filter((e: any) => e.posting == "Dr")
            .map((e: any) => {
              return e.ledger?.ledger_name;
            }),
          cr: e.detail
            .filter((e: any) => e.posting == "Cr")
            .map((e: any) => {
              return e.ledger?.ledger_name;
            }),
        };
      });
    } catch (error: any) {
      return { success: false, message: error.message };
    }
  }
  async getVoucherNo(
    book_id: string | null,
    sub_book_id: string | null,
    date: Date
  ) {
    try {
      let voucher_no = 1;
      let financial_year = financialYearService(date);
      let check: any = await this.model
        .findOne({
          book_id: book_id,
          sub_book_id: sub_book_id,
          financial_year: financial_year,
          voucher_type: this.voucherType,
        })
        .sort({ voucher_no: -1 });
      if (check) voucher_no = check.voucher_no + 1;
      return {
        success: true,
        voucher_no: voucher_no,
        financial_year: financial_year,
      };
    } catch (error: any) {
      return { success: false, message: error.message };
    }
  }
  async checkExists(
    book_id: string | null,
    sub_book_id: string | null,
    voucher_no: number,
    financial_year: string,
    _id?: string | null
  ) {
    try {
      let filter: any = {
        book_id: book_id,
        sub_book_id: sub_book_id,
        financial_year: financial_year,
        voucher_no: voucher_no,
        voucher_type: this.voucherType,
      };
      if (_id) filter._id = { $ne: _id };
      let check: any = await this.model.findOne(filter);
      return check;
    } catch (error: any) {
      return { success: false, message: error.message };
    }
  }
  async add(data: Journal) {
    try {
      let obj: any = {};
      let tdata: any = data;
      Object.keys(tdata).forEach((key) => {
        obj[key] = tdata[key] as any;
      });
      obj["voucher_type"] = this.voucherType;
      obj["detail"] = data.detail?.map((e) => ({
        ledger: e.ledger,
        posting: e.credit > 0 ? "Cr" : "Dr",
        amount: e.credit > 0 ? e.credit : e.debit,
        narration: e.narration,
      }));
      let res = await super.add(obj);
      return res;
    } catch (error: any) {
      throw new Error(error);
    }
  }
  async updateById(data: Journal, id:any) {
    try {
      return await this.update(data,{_id:id});
    } catch (error: any) {
      throw new Error(error);
    }
  }
  async update(data: Journal, filter:any) {
    try {     
      let obj: any = {};
      let tdata: any = data;
      Object.keys(tdata).forEach((key) => {
        obj[key] = tdata[key] as any;
      });
      obj["voucher_type"] = this.voucherType;
      obj["detail"] = data.detail?.map((e) => ({
        ledger: e.ledger,
        posting: e.credit > 0 ? "Cr" : "Dr",
        amount: e.credit > 0 ? e.credit : e.debit,
        narration: e.narration,
      }));
      let res = await super.update(obj, filter);
      return res;
    } catch (error: any) {
      throw new Error(error);
    }
  }
  async callBackRetrieve(data: Voucher): Promise<Journal> {
    let obj = {
      book_id: data.book_id,
      sub_book_id: data.sub_book_id,
      date: data.date,
      voucher_no: data.voucher_no ? data.voucher_no : 0,
      financial_year: data.financial_year,
      voucher_type: data.voucher_type,
      voucher_for: data.voucher_for,
      detail: data.detail?.map((e) => ({
        ledger: e.ledger,
        credit: e.posting == "Cr" ? e.amount : 0,
        debit: e.posting == "Dr" ? e.amount : 0,
        narration: e.narration ? e.narration : "",
      })),
      done_by: data.done_by,
    };
    return obj;
  }
}
