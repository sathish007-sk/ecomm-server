import { Types } from 'mongoose';
import stockModel from '../models/stock-model';
import LedgerService from './ledger-service';
import PartyService from './party-service';
import VoucherService from './voucher-service';
export default class ReportService {
    model = stockModel;
    ledgerservice = new LedgerService();
    partyservice = new PartyService();
    voucherservice = new VoucherService();
    async getOutStanding(filter?: any) {
        try {

            let filterArray: any = {};
            if (filter.party_id) filterArray.party_id = Types.ObjectId(filter.party_id);
            if (filter.product_id) filterArray.product = Types.ObjectId(filter.product_id);
            if (filter.to_date) {
                let toDate = new Date(filter.to_date);
                toDate.setHours(0, 0, 0, 0);
                toDate.setDate(toDate.getDate() + 1);
            }
            let party = await this.partyservice.retrieveById(filter.party_id)
            let ledger = await this.ledgerservice.getPartyLedger(filter.party_id)
            let res = await this.voucherservice.getVouchers({ ledger_id: ledger._id });


            let agg: any[] = [];
            if (Object.keys(filterArray).length > 0) {
                agg = [
                    {
                        $match:
                        {
                            ...filterArray
                        }
                    }
                ]
            }
            let data: any = await this.model.aggregate([
                {
                    $match: {
                        module: {
                            $in: ['Metal Transfer', 'Metal Return']
                        }
                    }
                },
                {
                    $unwind: '$item_details'
                },
                {
                    $project: { party_name: 1, ref_no: 1, date: 1, module: 1, party_id: 1, product: '$item_details.product', quantity: '$item_details.quantity', gross_weight: '$item_details.gross_weight', touch: '$item_details.touch', touch_difference: '$item_details.touch_difference', net_weight: '$item_details.net_weight', rate: '$item_details.rate', total: '$item_details.total', status: '$item_details.status',is_discount:'$item_details.is_discount', date_time: 1 }
                },
                ...agg
            ]);

            res = res.map(e => {
                return {
                    "_id": e._id,
                    "date": e.date,
                    "ref_no": e.voucher_no && e.voucher_no != 0 ? e.voucher_no : e.ref_no,
                    "module": e.voucher_type,
                    "date_time": e.date_time,
                    "product": "",
                    "quantity": 0,
                    "gross_weight": 0,
                    "touch": 0,
                    "touch_difference": null,
                    "net_weight": 0,
                    "total": e.amount,
                   
                }
            });


            let opb_metal = {};         
            if (party.metal_balance > 0) {
                opb_metal = {
                    date: party.opening_balance_date,
                    module: "Opening Balance",
                    net_weight: party.metal_balance,
                }
            }


            let array = [opb_metal, ...res, ...data];
            array.sort((a, b) => +new Date(a.date) - +new Date(b.date));
            let cAmount = 0, cWeight = 0;
            let result = array.map((e: any) => {
                let net_weight = 0;
                let module=e.module
                if(e.is_discount==true){
                    module+=" (Discount)";
                }
                if (e.module == "Metal Transfer") {
                   
                    if(e.status=="out") net_weight = e.net_weight;
                    else net_weight -= e.net_weight;
                    cWeight+= net_weight;

                }
                else if (e.module == "Metal Return") {
                    
                    if(e.status=="out") net_weight = e.net_weight;
                    else net_weight -= e.net_weight;
                    cWeight+= net_weight;
                }
                else if (e.module == "Sales") {
                    cAmount += e.total;
                }
                else if (e.module == "Receipt") {
                    cAmount += e.total;
                }
                else if (e.module == "Payment") {
                    cAmount += e.total;
                }
                else if (e.module == "Journal") {
                    cAmount += e.total;
                }
                else if (e.module == "Purchase") {
                    //  cWeight -= e.net_weight;
                    cAmount += e.total;
                    // net_weight-=e.net_weight;
                }
                else if (e.module == "Opening Balance") {
                    net_weight=Number(e.net_weight??0);
                    cWeight +=net_weight;
                    cAmount += Number(e.total??0);
                   
                }


                return {
                    date: e.date,
                    ref_no: e.ref_no,
                    module: module,
                    gross_weight: e.gross_weight,
                    touch: e.touch,
                    touch_difference: e.touch_difference,
                    net_weight: net_weight,
                    amount: e.total,
                    c_weight: Number(cWeight.toFixed(3)),
                    c_amount: Number(cAmount.toFixed(2))
                }
            });
            let fromDate: Date;
            if (filter.from_date) {
                fromDate = new Date(filter.from_date);
                fromDate.setHours(0, 0, 0, 0);
            }

            let closingWeight = 0, closingAmount = 0;
            let finalData = [];
            result.forEach(e => {
                if (fromDate && new Date(e.date) < fromDate) {
                    closingWeight = e.c_weight;
                    closingAmount = e.c_amount;
                }
                else {

                    finalData.push(e);


                }
            })

            if (closingWeight != 0 || closingAmount != 0) {
                finalData.unshift({
                    date: filter.from_date,
                    module: 'Opening Balance',
                    gross_weight: 0,
                    touch: 0,
                    touch_difference: 0,
                    net_weight: closingWeight,
                    amount: closingAmount,
                    c_weight: closingWeight,
                    c_amount: closingAmount,
                })
            }
            return finalData;
        } catch (error: any) {
            throw new Error(error);
        }
    }
}