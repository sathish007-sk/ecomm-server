import ReceiptService from './receipt-service';
export default class PaymentService extends ReceiptService{
    public voucherType = "Payment";
    constructor() {
        super();
    }
}