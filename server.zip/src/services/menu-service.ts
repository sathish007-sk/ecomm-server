import { AccessMenu } from "../models/access-menu-model";
import { AccessModule } from "../models/access-module-model";
import AccessMenuService from "./access-menu-service";
import AccessModuleService from "./access-module-service";
import AccessSettingService from "./access-setting-service";
import UserService from "./user-service";

export default class MenuService {
  moduleservice = new AccessModuleService();
  menuservice = new AccessMenuService();
  accesssettingservice = new AccessSettingService();
  data!: any[];
  constructor() {
    this.init();
  }
  async init() {
    try {
      let menuList: AccessMenu[] = await this.menuservice.menu();
      let moduleList: AccessModule[] = await this.moduleservice.list({
        status: true,
      });
      let data1 = menuList.map((e) => ({
        _id: e._id,
        menu_name: e.menu_name,
        parent: e.module,
        options: e.options,
        route: e.route,
      }));
      let data2 = moduleList.map((e) => ({
        _id: e._id,
        menu_name: e.module_name,
        parent: e.parent,
        icon: e.icon,
      }));
      this.data = [...data1, ...data2];
    } catch (error: any) {
      throw new Error(error);
    }
  }
  grouping(parent: string | null | undefined, data: any[]): any {
    let res = data.filter(
      (e: AccessModule) => String(e.parent) === String(parent)
    );
    res.sort((a:any,b:any)=>a.order_no - b.order_no);
    return res.map((e) => {
      let obj = e;
      let children = this.grouping(e._id, data);
      if (children.length > 0) obj.children = children;
      return obj;
    });
  }
  async getMenus(user_id: string) {
    try {
        let menuList!: AccessMenu[];
      let userservice = new UserService();
      let user = await userservice.retrieveById(user_id);
      if (user.role?.toLowerCase() == "super admin") {          
        menuList=await this.menuservice.model.find({status:true}).populate('options');
      } else {
        let assignedMenus = await this.accesssettingservice.menuList(user_id);
        menuList= assignedMenus?.map((e) => {
          let obj: any = e.menu_id;
          obj.options = e.options;
          return obj;
        });
      }
      
      let moduleList: AccessModule[] = await this.moduleservice.list({
        status: true,
      });
      let moduleListArray: any[] = [];
      menuList.forEach((e) => {
        let parent: any = e.module;
        do {
          let gp = moduleList.find((el) => String(el._id) === String(parent));
          if(!gp) break;
          let i = moduleListArray.findIndex(
            (el) => String(el._id) === String(parent)
          );
          if (i === -1) moduleListArray.push(gp);
          if (gp?.parent != null) {
            let m = gp.parent as any;
            parent = m._id;
          } else parent = null;
        } while (parent && parent != null);
      });
      let data1 = menuList.map((e) => ({
        _id: e._id,
        menu_name: e.menu_name,
        parent: e.module,
        options: e.options,
        route: e.route,
        order_no:e.order_no??0,
      }));
      let data2 = moduleListArray.map((e) => {
        let parent: any = e.parent;
        return {
          _id: e._id,
          menu_name: e.module_name,
          parent: parent ? parent?._id : null,
          icon: e.icon,
          order_no:e.order_no??0,
        };
      });

      let data = [...data2, ...data1];
      data.sort((a:any,b:any) => a.order_no - b.order_no);
      return { menu: menuList, menu_tree: this.grouping(null, data) };
    } catch (error: any) {
      throw new Error(error);
    }
  }
}
