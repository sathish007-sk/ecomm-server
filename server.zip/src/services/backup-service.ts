import { spawn } from "child_process";
import { appendFileSync, existsSync, mkdirSync,  readdirSync,  statSync, unlinkSync, writeFileSync } from "fs";
 //mongorestore --gzip --archive=backupLockation/  -- to restore
export default class BackupDb{
    private dailyDir!:string;
    private weeklyDir!:string;
    private monthlyDir!:string;
    constructor(){
        this.dailyDir='backup/daily';
        this.weeklyDir='backup/weekly';
        this.monthlyDir='backup/monthly';
        if(!existsSync('backup')) mkdirSync('backup');
        if(!existsSync(this.dailyDir)) mkdirSync(this.dailyDir);
        if(!existsSync(this.weeklyDir)) mkdirSync(this.weeklyDir);
        if(!existsSync(this.monthlyDir)) mkdirSync(this.monthlyDir);        
    }
    backup=(...str:any[])=>{
        let path=str.join('/');
        let backupProcess = spawn('mongodump', [
            '--db='+process.env.DB,
            '--archive=./'+path+'.gz',
            '--gzip'
        ]);
        backupProcess.on('exit', (code, signal) => {
            if(code) this.log(str[0],'Backup process exited with code '+ code)
            else if (signal) this.log(str[0],'Backup process was killed with singal '+ signal)
            else  this.log(str[0],'Successfully backedup the database')
        });
    }
    daily=()=>{
        let date=new Date();
        let sDate=new Date(date);
        sDate.setDate(sDate.getDate()-7);
        let files=readdirSync(this.dailyDir);
        files.forEach(file=>{
           let stat=statSync(this.dailyDir+'/'+file)
           if(new Date(stat.birthtime)<sDate){
               unlinkSync(this.dailyDir+'/'+file)
           }
        })
        let fileName=date.toString();
        this.backup(this.dailyDir,fileName);
    }
    weekly=()=>{
        let date=new Date();
        let sDate=new Date(date);
        sDate.setDate(sDate.getMonth()-1);
        let files=readdirSync(this.weeklyDir);
        files.forEach(file=>{
           let stat=statSync(this.weeklyDir+'/'+file)
           if(new Date(stat.birthtime)<sDate){
               unlinkSync(this.weeklyDir+'/'+file)
           }
        })
        let fileName=date.toString();
        this.backup(this.weeklyDir,fileName);    
    }
    monthly=()=>{
        let date=new Date();
        let sDate=new Date(date);
        sDate.setDate(sDate.getMonth()-6);
        let files=readdirSync(this.monthlyDir);
        files.forEach(file=>{
           let stat=statSync(this.monthlyDir+'/'+file)
           if(new Date(stat.birthtime)<sDate){
               unlinkSync(this.monthlyDir+'/'+file)
           }
        })
        let fileName=date.toString();
        this.backup(this.monthlyDir,fileName);
    }
    log=(path:string,message:string)=>{
        let msg=new Date()+" "+message+"\n";
        if(!existsSync(path+'.log')){
            writeFileSync(path+'.log',msg);
        }
        else{
            appendFileSync(path+'.log',msg)
        }
    };
    
}






   
