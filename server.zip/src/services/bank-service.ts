import bankModel, { Bank } from '../models/bank-model';
import { CRUD, ValidateAdd, ValidateDelete, ValidateEdit, ValidateResponse } from './crud-service';
import LedgerService from './ledger-service';

export default class BankService extends CRUD<Bank>{
    public model=bankModel;
    private ledgerService=new LedgerService();
    constructor(){
       super();
    }
    validateAdd: ValidateAdd=async(data:Bank):Promise<ValidateResponse>=>{
        try {
            let check=await this.model.findOne({ book_id:data.book_id,account_no: { $regex: new RegExp("^" + data.account_no.toLowerCase()+"$", "i")}});
            if(check)return {success:false, message:"Already Exists"};
            return {success:true};
        } catch (error:any) {
            throw new Error(error);
        }       
    }
    validateEdit: ValidateEdit=async(data:Bank,id:string):Promise<ValidateResponse>=>{
        try {
            let check=await this.model.findOne({ book_id:data.book_id,account_no: { $regex: new RegExp("^" + data.account_no.toLowerCase()+"$", "i")},_id:{$ne:id}});
            if(check)return {success:false, message:"Already Exists"};
            return {success:true};
        } catch (error:any) {
            throw new Error(error);
        }       
    }
    validateDelete: ValidateDelete=async(id:string):Promise<ValidateResponse>=>{
        return {success:true};
    }
    callBackAdd=async(data:Bank)=>{
        await this.ledgerService.bankLedger(data,"Add")
    }
    callBackEdit=async(data:Bank)=>{
        await this.ledgerService.bankLedger(data,"Edit")
    }
    callBackDelete=async(data:Bank)=>{
        await this.ledgerService.bankLedger(data,"Delete")
    }
}