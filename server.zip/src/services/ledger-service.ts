import { Ledger, ledgerModel, groupModel, Group } from '../models/accounts-model';
import { Bank } from '../models/bank-model';
import { Tax } from '../models/tax-model';
import AccountsGroupService from './accounts-group-service';
import { CRUD, ValidateAdd, ValidateDelete, ValidateEdit, ValidateResponse } from './crud-service';
import { Party } from '../models/party-model';
import VoucherService from './voucher-service';
export default class LedgerService extends CRUD<Ledger>{
    public model = ledgerModel;
    private voucherService=new VoucherService();
    private groupService=new AccountsGroupService();
    constructor() {
        super();
    }
    async list(filter = {}) {
        try {
            let result = await this.model.find(filter).populate('group');
            return result;
        } catch (error:any) {
            throw new Error(error);
        }
    }
    validateAdd: ValidateAdd = async (data: Ledger): Promise<ValidateResponse> => {
        return { success: true };
    }
    validateEdit: ValidateEdit = async (data: Ledger, id: string): Promise<ValidateResponse> => {
        return { success: true };
    }
    validateDelete: ValidateDelete = async (id: string): Promise<ValidateResponse> => {
        return { success: true };
    }
    callBackAdd=async(data:Ledger)=>{
        await this.voucherService.openingBalance(data,'Add');
    }
    callBackEdit=async(data:Ledger)=>{
        await this.voucherService.openingBalance(data,'Edit');
    }
    callBackDelete=async(data:Ledger)=>{
        await this.voucherService.openingBalance(data,'Delete');
    }
    async getBankAndCashLedger(groupName:string[]=["BANK ACCOUNTS", "CASH IN HAND"]) {
        try {
            let group = await this.groupService.getByName(groupName);
            let group_id = group.map((e: Group) => e._id);

            let resultTemp = await this.list({
                group: { $in: group_id }
            })
            let result = group.map((e: Group) => ({
                group: e.group_name,
                ledgers: resultTemp.filter((ele: any) => String(e._id) == String(ele.group?._id)),
            }));
            return result;
        } catch (error:any) {
            throw new Error(error);
        }

    }
    getPartyLedger = async (id: string) => {
        let doc = await ledgerModel.findOne({ 'reference.ref_from': 'party', 'reference.ref_id': id });
        return doc;
    }
    getExpLedger = async (id: string) => {
        let doc = await ledgerModel.findOne({ 'group': id , 'ledger_name':
        'DISCOUNT NEW'});
        
        return doc;
    }
    savePartyLedger= async(data:Party,mode:"Add" | "Edit" | "Delete")=>{        
        let check:any=await this.getPartyLedger(data._id);
        if(mode==="Delete"){
            if(check) await check.deleteOne();
            return false;
        }
        let group;
        if(data.account_type=="Customer") {
            group = await this.groupService.getOneByName('SUNDRY DEBTORS');    
        }
        else{
            group = await this.groupService.getOneByName('SUNDRY CREDITORS');
        }
        let val = {
            ledger_name: data.account_name,
            status: data.status,
            operation: data.account_type,
            group: group?._id,
            reference: {
                ref_from: "party",
                ref_id: data?._id
            },
            opening_balance_date:data.opening_balance_date,
            opening_balance: data.opening_balance,
            posting:data.posting,
        };
        if (check?._id) await this.updateById(val,check._id);
        else await this.add(val);
    }
    roundOff = async () => {
        let doc = await ledgerModel.findOne({ operation: 'round off' });
        if (!doc) {
            let group = await this.groupService.getOneByName('INDIRECT EXPENSES');
            let save = await ledgerModel.create({
                ledger_name: "ROUND OFF A/C",
                group: group._id,
                operation: 'round off',
            });
            return save;
        }
        else return doc;
    }
    cashPurchase = async () => {
        let doc = await ledgerModel.findOne({ operation: 'cash purchase' });
        if (!doc) {
            let group = await this.groupService.getOneByName('DIRECT EXPENSES');
            let save = await ledgerModel.create({
                ledger_name: "CASH PURCHASES A/C",
                group: group._id,
                operation: 'cash purchase',
            });
            return save;
        }
        else return doc;
    }
    cashSales = async () => {
        let doc = await ledgerModel.findOne({ operation: 'cash sales' });
        if (!doc) {
            let group = await this.groupService.getOneByName('DIRECT INCOMES');
            let save = await ledgerModel.create({
                ledger_name: "CASH SALES A/C",
                group: group._id,
                operation: 'cash sales',
            });
            return save;
        }
        else return doc;
    }
    async getBankLedger(id:string):Promise<Ledger>{
        try {
            let operation="bank account";
            let ref_from="bank";        
            let check:Ledger=await this.retrieve({ operation: operation, 'reference.ref_from': ref_from, 'reference.ref_id': id });          
            return check;
        } catch (error) {
            throw error;
            
        }
    }
    async bankLedger(data:Bank,mode:"Add" | "Edit" | "Delete") {
        let operation="bank account";
        let ref_from="bank";        
        let check:Ledger=await this.retrieve({ operation: operation, 'reference.ref_from': ref_from, 'reference.ref_id': data._id });          
        if(mode==="Delete"){
            if(check._id) await this.deleteById(check._id);
            return false;
        }
        let group = await this.groupService.getOneByName('BANK ACCOUNTS');
        let val = { 
            ledger_name: data.account_no,
            status: data.status,
            operation: operation,
            group: group?._id,
            reference: {
                ref_from: ref_from,
                ref_id: data?._id
            }
        };       
        if (check?._id) await this.updateById(val,check._id);
        else await this.add(val);
    }
    async tcsPayable(){
        let check:Ledger=await this.retrieve({ operation: 'TCS PAYABLE'});           
        if (check)return check;
       
        let taxGroup = await groupModel.findOne({ group_name: "DUTIES & TAXES" });
        let obj={
            ledger_name: 'TCS PAYABLE',
            group: taxGroup._id,
            operation: 'TCS PAYABLE',
        };
        let res=await this.add(obj);
        return res.data
    }
    async tcsReceivable(){
        let check:Ledger=await this.retrieve({ operation: 'TCS RECEIVABLE'});           
        if (check)return check;
       
        let taxGroup = await groupModel.findOne({ group_name: "DUTIES & TAXES" });
        let obj={
            ledger_name: 'TCS RECEIVABLE',
            group: taxGroup._id,
            operation: 'TCS RECEIVABLE',
        };
        let res=await this.add(obj);
        return res.data
    }
    async tdsPayable(){
        let check:Ledger=await this.retrieve({ operation: 'TDS PAYABLE'});           
        if (check)return check;
       
        let taxGroup = await groupModel.findOne({ group_name: "DUTIES & TAXES" });
        let obj={
            
            ledger_name: 'TDS PAYABLE',
            group: taxGroup._id,
            operation: 'TDS PAYABLE',
        };
        let res=await this.add(obj);
        return res.data
    }
    async tdsReceivable(){
        let check:Ledger=await this.retrieve({ operation: 'TDS RECEIVABLE'});           
        if (check)return check;
       
        let taxGroup = await groupModel.findOne({ group_name: "DUTIES & TAXES" });
        let obj={
            ledger_name: 'TDS RECEIVABLE',
            group: taxGroup._id,
            operation: 'TDS RECEIVABLE',
        };
        let res=await this.add(obj);
        return res.data
    }
    async taxLedgers(doc:Tax) {
        let taxGroup = await groupModel.findOne({ group_name: "DUTIES & TAXES" });
        let incomeGroup = await groupModel.findOne({ group_name: "DIRECT INCOMES" })
        let expenseGroup = await groupModel.findOne({ group_name: "DIRECT EXPENSES" })
        let tax_percentage = doc.tax_percentage;
        let id = doc._id;
        let array = [
            {
                ledger_name: 'INPUT CGST ' + (tax_percentage / 2).toString() + " %",
                group: taxGroup._id,
                operation: 'INPUT CGST',
                reference: {
                    ref_from: "tax",
                    ref_id: id,
                }
            },
            {
                ledger_name: 'INPUT SGST ' + (tax_percentage / 2).toString() + " %",
                group: taxGroup._id,
                operation: 'INPUT SGST',
                reference: {
                    ref_from: "tax",
                    ref_id: id,
                }
            },
            {
                ledger_name: 'INPUT IGST ' + (tax_percentage).toString() + " %",
                group: taxGroup._id,
                operation: 'INPUT IGST',
                reference: {
                    ref_from: "tax",
                    ref_id: id,
                }
            },
            {
                ledger_name: 'OUTPUT CGST ' + (tax_percentage / 2).toString() + " %",
                group: taxGroup._id,
                operation: 'OUTPUT CGST',
                reference: {
                    ref_from: "tax",
                    ref_id: id,
                }
            },
            {
                ledger_name: 'OUTPUT SGST ' + (tax_percentage / 2).toString() + " %",
                group: taxGroup._id,
                operation: 'OUTPUT SGST',
                reference: {
                    ref_from: "tax",
                    ref_id: id,
                }
            },
            {
                ledger_name: 'OUTPUT IGST ' + (tax_percentage).toString() + " %",
                group: taxGroup._id,
                operation: 'OUTPUT IGST',
                reference: {
                    ref_from: "tax",
                    ref_id: id,
                }
            },

            {
                ledger_name: 'LOCAL SALES ' + (tax_percentage).toString() + " %",
                group: incomeGroup._id,
                operation: 'LOCAL SALES',
                reference: {
                    ref_from: "tax",
                    ref_id: id,
                }
            },
            {
                ledger_name: 'INTERSTATE SALES ' + (tax_percentage).toString() + " %",
                group: incomeGroup._id,
                operation: 'INTERSTATE SALES',
                reference: {
                    ref_from: "tax",
                    ref_id: id,
                }
            },
            {
                ledger_name: 'LOCAL PURCHASE ' + (tax_percentage).toString() + " %",
                group: expenseGroup._id,
                operation: 'LOCAL PURCHASE',
                reference: {
                    ref_from: "tax",
                    ref_id: id,
                }
            },
            {
                ledger_name: 'INTERSTATE PURCHASE ' + (tax_percentage).toString() + " %",
                group: expenseGroup._id,
                operation: 'INTERSTATE PURCHASE',
                reference: {
                    ref_from: "tax",
                    ref_id: id,
                }
            },
        ];
        array.forEach(async (val:Ledger) => {
            let check:Ledger=await this.retrieve({ operation: val.operation, 'reference.ref_from': val?.reference?.ref_from, 'reference.ref_id': val?.reference?.ref_id });           
            if (check?._id) await this.updateById(val,check._id);
            else await this.add(val);
        });
    }
    
    
}
