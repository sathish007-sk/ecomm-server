import { Party, partyModel } from "../models/party-model";
import { CRUD, ValidateAdd, ValidateDelete, ValidateEdit, ValidateResponse } from "./crud-service";
import LedgerService from "./ledger-service";

export default class PartyService extends CRUD<Party>{
    model=partyModel
    private ledgerservice=new LedgerService();
    constructor() {
        super();
    }
    validateAdd: ValidateAdd=async(data:Party):Promise<ValidateResponse>=>{
        try {
            if(data.tds_applicable===false && data.tcs_applicable===false){
                return {success:false, message:"TDS or TCS is mandatory"};
            } 
            let check=await this.model.findOne({ book_id:data.book_id,account_name: { $regex: new RegExp("^" + data.account_name?.toLowerCase()+"$", "i")}});
            if(check)return {success:false, message:"Already Exists"};
            return {success:true};
        } catch (error:any) {
            throw new Error(error);
        }       
    }
    validateEdit: ValidateEdit=async(data:Party,id:string):Promise<ValidateResponse>=>{
        try {  
            if(data.tds_applicable===false && data.tcs_applicable===false){
                return {success:false, message:"TDS or TCS is mandatory"};
            }         
            let check=await this.model.findOne({ book_id:data.book_id,account_name: { $regex: new RegExp("^" + data.account_name?.toLowerCase()+"$", "i")},_id:{$ne:id}});
            
            if(check)return {success:false, message:"Already Exists"};
            return {success:true};
        } catch (error:any) {
            throw new Error(error);
        }    
    }
    validateDelete: ValidateDelete=async(id:string):Promise<ValidateResponse>=>{
        return {success:true};
    }
    async callBackAdd(data:Party){
        try {            
            await this.ledgerservice?.savePartyLedger(data,"Add");

        } catch (error:any) {
            throw new Error(error);
        }
    }
    async callBackEdit(data:Party){
        try {          
            await this.ledgerservice?.savePartyLedger(data,"Edit");
        } catch (error:any) {
            throw new Error(error);
        }
    }
    async callBackDelete(data:Party){
        try {
            await this.ledgerservice?.savePartyLedger(data,"Delete");
        } catch (error:any) {
            throw new Error(error);
        }
    }
}