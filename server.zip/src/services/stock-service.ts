import { MaterialTransfer } from "../models/material-transfer-model";
import { MetalReturn } from "../models/metal-return-schema";
import { Purchase } from "../models/purchase-model";
import { Sales } from "../models/sales-model";
import stockModel, { Stock, StockDetail } from "../models/stock-model";
import { Types } from "mongoose";
import { Product } from "../models/product-model";
import BookService from "./book-service";
import SubBookService from "./sub-book-service";
import { StockJournal } from "../models/stock-journal-model";
export default class StockService {
  model = stockModel;
  constructor() {
    
    this.updateOp();
    
   
    
  }
  updateOp=async()=>{
    try {
      let data=await this.model.find({module:'Opening Balance'});
      data.forEach(async(element:any) => {
        let obj=element._doc;
        let object=obj.item_details?.map(({_doc}:any)=>{
          return {
            ..._doc,
            touch:100,
            gross_weight:_doc.net_weight
          }
        });
        await this.model.updateOne({_id:obj._id},{item_details:object});
        
      });



     
     
    } catch (error) {
      console.log(error);
      
    }
   
  }

  dashboardStock = async (fromDate: Date, toDate: Date) => {
    fromDate.setHours(0, 0, 0, 0);
    toDate.setHours(0, 0, 0, 0);
    let endDate = new Date(fromDate);
    endDate.setMonth(endDate.getMonth() + 1);
    // endDate.setDate(endDate.getDate() - 1);

    try {
      let stock = await this.model.aggregate([
        {
          $unwind: "$item_details",
        },
        {
          $project: {
            date: 1,
            module: 1,
            ref_id: 1,
            ref_no: 1,
            product: "$item_details.product",
            weight: "$item_details.net_weight",
            status: "$item_details.status",
          },
        },
        { $sort: { date: 1 } },
      ]);
      let op = 0;
      let closing: any = {};
      stock.forEach((e: any) => {
        let date = new Date(e.date);
        if (date < fromDate) {
          if (e.status == "in") op += e.weight;
          else op -= e.weight;
        } else if (date >= fromDate && date < endDate) {
          let day = date.getDate();
          if (!closing[day]) closing[day] = 0;
          if (e.status == "in") closing[day] += e.weight;
          else closing[day] -= e.weight;
        } else if (date >= endDate) {
          return false;
        }
      });
      let result = [];
      let ob = op;
      let cdate = toDate.getDate();
      endDate.setDate(endDate.getDate() - 1);
      for (let i = 1; i <= endDate.getDate(); i++) {
        let weight = 0;

        if (Number(cdate) >= Number(i)) {
          if (closing[i]) weight = closing[i];
          ob += weight;
        } else ob = 0;
        result.push({
          date: i,
          weight: ob,
        });
      }
      return result;
    } catch (error: any) {
      throw new Error(error);
    }
  };
  async getData() {
    try {
      let stock = await this.model.aggregate([
        {
          $unwind: "$item_details",
        },
        {
          $project: {
            product: "$item_details.product",
            quantity: "$item_details.quantity",
            weight: "$item_details.net_weight",
            rate: "$item_details.rate",
            total: "$item_details.total",
            status: "$item_details.status",
          },
        },
        {
          $group: {
            _id: "$product",
            in: {
              $sum: {
                $cond: [{ $eq: ["$status", "in"] }, "$weight", 0],
              },
            },
            out: {
              $sum: {
                $cond: [{ $eq: ["$status", "out"] }, "$weight", 0],
              },
            },
          },
        },
        {
          $project: {
            _id: 0,
            product: "$_id",
            in: 1,
            out: 1,
            stock: { $subtract: ["$in", "$out"] },
          },
        },
        {
          $lookup: {
            from: "products",
            localField: "product",
            foreignField: "_id",
            as: "product",
          },
        },
        {
          $unwind: "$product",
        },
        {
          $project: {
            in: 1,
            out: 1,
            stock: 1,
            product: "$product._id",
            product_name: "$product.product_name",
            code: "$product.code",
          },
        },
        { $sort: { stock: 1 } },
      ]);
      return stock;
    } catch (error: any) {
      throw new Error(error);
    }
  }
  closingStock = async (date: Date, isAll?: boolean) => {
    let result = await this.model.aggregate([
      {
        $match: { date: { $lt: date } },
      },
      {
        $unwind: "$item_details",
      },
      {
        $match: { "item_details.is_discount": { $ne: true } },
      },
      {
        $project: {
          gross_weight: "$item_details.gross_weight",
          quantity: "$item_details.net_weight",
          product: "$item_details.product",
          status: "$item_details.status",
        },
      },
      {
        $group: {
          _id: "$product",
          closing: {
            $sum: {
              $cond: [
                { $eq: ["$status", "in"] },
                "$quantity",
                { $subtract: [0, "$quantity"] },
              ],
            },
          },
          gross_closing: {
            $sum: {
              $cond: [
                { $eq: ["$status", "in"] },
                "$gross_weight",
                { $subtract: [0, "$gross_weight"] },
              ],
            },
          },
        },
      },
    ]);
    if (isAll) {
      return result.reduce(
        (carry: any, e: any) => {
          carry.net_weight += e.closing;
          carry.gross_weight += e.gross_closing;
          return carry;
        },
        { gross_weight: 0, net_weight: 0 }
      );
    }
    return result;
  };
  dayStock = async (fromDate: Date, toDate: Date) => {
    try {
      fromDate.setHours(0, 0, 0, 0);
      toDate.setHours(0, 0, 0, 0);
      toDate.setDate(toDate.getDate() + 1);
      let result = await this.model.find({ date: { $gte: fromDate, $lt: toDate }}).sort({data:1});


      let res: any[] = [];
      let closing = await this.closingStock(fromDate, true);
      let closing_qty = closing.gross_weight;
      if (closing_qty != 0 && closing_qty) {
        let in_qty = 0,
        out_qty = 0;
        if(closing_qty>0) {
          in_qty=closing_qty;
        }
        else {
          out_qty=Math.abs(closing_qty);
        }
        res.push({
          date: fromDate,
          particular: "Opening Balance",
          in_qty: in_qty,
          out_qty: out_qty,
          closing_qty: closing_qty,
        });
      }
      result.forEach((element:Stock) => {
        let quantity=element.item_details?.reduce((c:number,e:any)=>{
          if(e.status=='in') c+=e.gross_weight;
          else c-=e.gross_weight
          return c;
        },0)
        let in_qty = 0,
          out_qty = 0;
        closing_qty+=quantity;
        if(quantity>0) {
          in_qty=quantity;
        }
        else {
          out_qty=Math.abs(quantity);
        }

        res.push({
          date: element.date,
          particular: element.module,
          ref_id: element.ref_id,
          ref_no: element.ref_no,
          party_name: element.party_name,
          in_qty: in_qty,
          out_qty: out_qty,
          closing_qty: closing_qty,
        });        
      });
     /* result.forEach((e: any) => {
        let in_qty = 0,
          out_qty = 0;
        if (e.status === "in") {
          in_qty = e.quantity;
          closing_qty += in_qty;
        } else {
          out_qty = e.quantity;
          closing_qty -= out_qty;
        }

        if (in_qty || out_qty) {
          res.push({
            date: e.date,
            particular: e.module,
            ref_no: e.ref_no,
            ref_id: e.ref_id,
            party_name: e.party_name,
            product: e.product,
            in_qty: in_qty,
            out_qty: out_qty,
            closing_qty: closing_qty,
          });
        }
      });*/

      return res;
    } catch (error: any) {
      throw new Error(error);
    }
  };
  getStockDetail = async (id: string) => {
    try {
      let result = await this.model.aggregate([
        {
          $match: { "item_details.product": Types.ObjectId(id) },
        },
        {
          $unwind: "$item_details",
        },
        {
          $match: { "item_details.product": Types.ObjectId(id) },
        },
        {
          $project: {
            date: 1,
            module: 1,
            ref_id: 1,
            ref_no: 1,
            product: "$item_details.product",
            quantity: "$item_details.net_weight",
            rate: "$item_details.rate",
            total: "$item_details.total",
            mode: "$item_details.status",
          },
        },
        { $sort: { date: 1 } },
      ]);
      let input: any[] = [];
      let data = result.map((e: any, i: number) => {
        let quantity = e.quantity;
        let inData, outData, closingData;
        if (e.mode == "in") {
          input.push({
            module: e.module,
            ref_id: e.ref_id,
            input_qty: quantity,
            quantity: quantity,
            rate: e.rate,
            total: e.total,
          });
          inData = {
            quantity: quantity,
            rate: e.rate,
            total: e.total,
          };
        } else {
          let tempQty = quantity;
          let index: number | null = 0;
          do {
            if (input[index]) {
              if (input[index].quantity > tempQty) {
                input[index].quantity -= tempQty;
                tempQty = 0;
              } else {
                tempQty -= input[index].quantity;
                input[index].quantity = 0;
              }
              ++index;
            } else index = null;
          } while (index != null && tempQty > 0 && input[index]);
          outData = {
            quantity: quantity,
            rate: e.rate,
            total: e.total,
          };
        }

        closingData = input.reduce(
          (c, ele) => {
            c.quantity += ele.quantity;
            c.total += ele.quantity * ele.rate;
            return c;
          },
          { total: 0, quantity: 0 }
        );
        closingData.rate = closingData.total / closingData.quantity;
        return {
          sno: i + 1,
          date: e.date,
          module: e.module,
          ref_no: e.ref_no,
          ref_id: e.ref_id,
          in: inData,
          out: outData,
          closing: closingData,
        };
      });
      return data;
    } catch (error: any) {
      throw new Error(error);
    }
  };
  async purchase(data: Purchase, mode: "Add" | "Edit" | "Delete") {
    let module = "Purchase";
    let check: any = await stockModel.findOne({
      ref_id: data._id,
      module: module,
    });
    if (mode === "Delete") {
      if (check) await check.deleteOne();
      return false;
    }
    let obj: Stock = {
      book_id: data.book_id,
      sub_book_id: data.sub_book_id,
      date: data.invoice_date,
      ref_id: data._id,
      ref_no: data.invoice_no,
      party_name: data.party_name,
      party_id: data.party_id,
      module: module,
      item_details: data.item_details.map((e: any) => ({
        product: e.product,
        quantity: e.quantity,
        gross_weight: e.gross_weight,
        stone: e.stone,
        waste: e.waste,
        touch: e.touch,
        touch_difference: e.touch_difference,
        net_weight: e.net_weight,
        rate: e.rate_per_gram,
        total: e.amount,
        status: "in",
      })),
      done_by: data.done_by,
      date_time: data.date_time,
    };
    if (!check) await stockModel.create(obj);
    else await stockModel.findByIdAndUpdate(check._id, obj);
  }
  async sales(data: Sales, mode: "Add" | "Edit" | "Delete") {
    let module = "Sales";
    let check: any = await stockModel.findOne({
      ref_id: data._id,
      module: module,
    });
    if (mode === "Delete") {
      if (check) await check.deleteOne();
      return false;
    }

    let item_details: StockDetail[] = data.item_details.map((e: any) => ({
      product: e.product,
      quantity: e.quantity,
      gross_weight: e.gross_weight,
      stone: e.stone,
      waste: e.waste,
      touch: e.touch,
      touch_difference: e.touch_difference,
      net_weight: e.net_weight,
      rate: e.rate_per_gram,
      total: e.amount,
      status: "out",
    }));
    if (data.metal_discount > 0) {
      item_details.push({
        product: null,
        quantity: 0,
        gross_weight: 0,
        stone: 0,
        waste: 0,
        touch: 0,
        touch_difference: 0,
        net_weight: data.metal_discount,
        rate: 0,
        total: 0,
        status: "in",
        is_discount: true,
      });
    }

    let obj: Stock = {
      book_id: data.book_id,
      sub_book_id: data.sub_book_id,
      date: data.invoice_date,
      ref_id: data._id,
      ref_no: data.invoice_no,
      party_name: data.party_name,
      party_id: data.party_id,
      module: module,
      item_details: item_details,
      done_by: data.done_by,
      date_time: data.date_time,
    };
    if (!check) await stockModel.create(obj);
    else await stockModel.findByIdAndUpdate(check._id, obj);
  }
  async metalTransfer(data: MaterialTransfer, mode: "Add" | "Edit" | "Delete") {
    let module = "Metal Transfer";
    let check: any = await stockModel.findOne({
      ref_id: data._id,
      module: module,
    });
    if (mode === "Delete") {
      if (check) await check.deleteOne();
      return false;
    }

    let item_details: StockDetail[] = data.item_details.map((e: any) => ({
      product: e.product,
      quantity: e.quantity,
      gross_weight: e.gross_weight,
      stone: e.stone,
      waste: e.waste,
      touch: e.touch,
      touch_difference: e.touch_difference,
      net_weight: e.net_weight,
      rate: e.rate_per_gram,
      total: e.amount,
      status: "out",
    }));
    if (data.metal_discount > 0) {
      item_details.push({
        product: null,
        quantity: 0,
        gross_weight: 0,
        stone: 0,
        waste: 0,
        touch: 0,
        touch_difference: 0,
        net_weight: data.metal_discount,
        rate: 0,
        total: 0,
        status: "in",
        is_discount: true,
      });
    }
    let obj: Stock = {
      book_id: data.book_id,
      sub_book_id: data.sub_book_id,
      date: data.invoice_date,
      ref_id: data._id,
      ref_no: data.invoice_no,
      party_name: data.party_name,
      party_id: data.party_id,
      module: module,
      item_details: item_details,
      done_by: data.done_by,
      date_time: data.date_time,
    };
    if (!check) await stockModel.create(obj);
    else await stockModel.findByIdAndUpdate(check._id, obj);
  }
  async metalReturn(data: MetalReturn, mode: "Add" | "Edit" | "Delete") {
    let module = "Metal Return";
    let check: any = await stockModel.findOne({
      ref_id: data._id,
      module: module,
    });
    if (mode === "Delete") {
      if (check) await check.deleteOne();
      return false;
    }
    let item_details: StockDetail[] = data.item_details.map((e: any) => ({
      product: e.product,
      quantity: e.quantity,
      gross_weight: e.gross_weight,
      stone: e.stone,
      waste: e.waste,
      touch: e.touch,
      touch_difference: e.touch_difference,
      net_weight: e.net_weight,
      rate: e.rate_per_gram,
      total: e.amount,
      status: "in",
    }));
    if (data.metal_discount > 0) {
      item_details.push({
        product: null,
        quantity: 0,
        gross_weight: 0,
        stone: 0,
        waste: 0,
        touch: 0,
        touch_difference: 0,
        net_weight: data.metal_discount,
        rate: 0,
        total: 0,
        status: "out",
        is_discount: true,
      });
    }
    let obj: Stock = {
      book_id: data.book_id,
      sub_book_id: data.sub_book_id,
      date: data.invoice_date,
      ref_id: data._id,
      ref_no: data.invoice_no,
      party_name: data.party_name,
      party_id: data.party_id,
      module: module,
      item_details: item_details,
      done_by: data.done_by ? data.done_by : null,
      date_time: data.date_time,
    };
    if (!check) await stockModel.create(obj);
    else await stockModel.findByIdAndUpdate(check._id, obj);
  }
  openingStock = async (data: Product, mode: "Add" | "Edit" | "Delete") => {
    try {
      let module = "Opening Balance";
      let check = await this.model.findOne({
        module: module,
        ref_id: data._id,
      });
      if (mode === "Delete") {
        if (check) await check.deleteOne();
        return false;
      }

      if (data.opening_stock && data.opening_stock!=0) {
        let bookservice = new BookService();
        let subbookservice = new SubBookService();
        let book = await bookservice.list();
        let subbook = await subbookservice.list();

        let obj: Stock = {
          book_id: book.length > 0 ? book[0]._id : null,
          sub_book_id: subbook.length > 0 ? subbook[0]._id : null,
          date: data.opening_balance_date,
          module: module,
          ref_id: data._id,
          item_details: [
            {
              product: String(data._id),
              net_weight: Math.abs(data.opening_stock),
              status: data.opening_stock > 0 ? "in" : "out",
              quantity: 0,
              gross_weight: Math.abs(data.opening_stock),
              stone: 0,
              waste: 0,
              touch: 100,
              touch_difference: 0,
              rate: 0,
              total: 0,
            },
          ],
        };

        if (!check) {
          await this.model.create(obj);
        } else {
          await this.model.updateOne({ _id: check._id }, obj);
        }
      } else {
        if (check) await check.deleteOne();
        return false;
      }
    } catch (error: any) {
      throw new Error(error);
    }
  };
  stockJournal=async(data:StockJournal,mode:"Add" | "Edit" | "Delete")=>{
    try {
      let module = "Stock Journal";
      let check: any = await stockModel.findOne({
        ref_id: data._id,
        module: module,
      });
      if (mode === "Delete") {
        if (check) await check.deleteOne();
        return false;
      }
      let item_details1: StockDetail[] = data.production.map((e: any) => ({
        quantity: 0,
        gross_weight: 0,
        stone: 0,
        waste: 0,
        touch: 0,
        touch_difference: 0,
        product: e.product,
        net_weight: e.net_weight,
        rate: e.rate,
        total: e.total,
        status: "in",
      }));
      let item_details2: StockDetail[] = data.consumption.map((e: any) => ({
        quantity: 0,
        gross_weight: 0,
        stone: 0,
        waste: 0,
        touch: 0,
        touch_difference: 0,
        product: e.product,
        net_weight: e.net_weight,
        rate: e.rate,
        total: e.total,
        status: "out",
      }));
     
      let obj: Stock = {
        book_id: data.book_id,
        sub_book_id: data.sub_book_id,
        date: data.date,
        ref_id: data._id,
        ref_no: data.ref_no,
        module: module,
        item_details: [...item_details1,...item_details2],
        done_by: data.done_by ? data.done_by : null,
      };
      if (!check) await stockModel.create(obj);
      else await stockModel.findByIdAndUpdate(check._id, obj);
    } catch (error) {
      throw error;
    }
  }
}
