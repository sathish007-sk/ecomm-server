import {group} from 'console';
import {Group, groupModel} from '../models/accounts-model';
import {
    CRUD,
    ValidateAdd,
    ValidateDelete,
    ValidateEdit,
    ValidateResponse
} from './crud-service';
export default class AccountsGroupService extends CRUD < Group > {
    public model = groupModel;
    constructor() {
        super();
    }
    async list(filter = {}) {
        try {
            let result = await this.model.find(filter).populate('parent');
            return result;
        } catch (error : any) {
            throw new Error(error);
        }

    }

    getChild(parent : string, data : Group[]) {
        let check = data.filter((e : Group) => {
            return String(e.parent) == String(parent)
        });
        let result: any[] = check.map((e : Group) => {
            let obj: any = e;
            return {
                ... obj._doc,
                children: this.getChild(e._id, data)
            }
        });
        return result;
    }
    async getChildern(data : Group[], parent : string) {
        await this.list({status: true});
    }
    async getPartyGroup(id? : string) {
        let groupList = await this.model.find({status: true});
        let party: any;
        if (!id) {
            party = groupList.filter((e : Group) => (e.group_name == 'SUNDRY CREDITORS' || e.group_name == 'SUNDRY DEBTORS'));
        } else {
            party = groupList.filter((e : Group) => String(e._id) === String(id));
        }
        let partyList = party.map((e : any) => {
            let groupTree: any = e._doc;
            groupTree.children = this.getChild(e._id, groupList);
            return groupTree;
        });
        return this.flatData(partyList);
    }
    // async getPartyGroup(id? : string) {
    //     let groupList = await this.model.find({status: true});
    //     let party: any;
    //     if (!id) {
    //         party = groupList.filter((e : Group) => (e.group_name == 'EXPENSES' || e.group_name == 'EXPENSES'));
    //     } else {
    //         party = groupList.filter((e : Group) => String(e._id) === String(id));
    //     }
    //     let partyList = party.map((e : any) => {
    //         let groupTree: any = e._doc;
    //         groupTree.children = this.getChild(e._id, groupList);
    //         return groupTree;
    //     });
    //     return this.flatData(partyList);
    // }
    flatData = (data : any, level? : number): any => {
        if (!level) 
            level = 1;
        
        let flat: any = [];
        for (let x of data) {
            flat.push({_id: x._id, parent: x.parent, group_name: x.group_name, level: level});
            if (x.children ?. length > 0) {
                let res: any = this.flatData(x.children, level + 1);
                flat = [
                    ... flat,
                    ... res
                ];
            }
        }
        return flat;
    }


    async getByName(group_name : string[]): Promise < Group[] > {
        try {
            let result = await this.model.find({
                group_name: {
                    $in: group_name
                }
            }).populate('parent');
            return result;
        } catch (error : any) {
            throw new Error(error);
        }
    }
    async getOneByName(group_name : string): Promise < Group > {
        try {
            let result = await this.getByName([group_name]);
            return result[0];
        } catch (error : any) {
            throw new Error(error);
        }
    }

    validateAdd : ValidateAdd = async (data : Group): Promise < ValidateResponse > => {
        return {success: true};
    }
    validateEdit : ValidateEdit = async (data : Group, id : string): Promise < ValidateResponse > => {
        return {success: true};
    }
    validateDelete : ValidateDelete = async (id : string): Promise < ValidateResponse > => {
        return {success: true};
    }
    async init(): Promise < void > {
        try {


            let check = await this.model.countDocuments();
            if (check == 0) {
                await this.model.insertMany([
                    {
                        "_id": "602225c331092a24cde6ec58",
                        "status": true,
                        "group_name": "ASSET",
                        "parent": null
                    },
                    {
                        "_id": "6022260931092a24cde6ec59",

                        "status": true,
                        "group_name": "EXPENSES",
                        "parent": null
                    },
                    {
                        "_id": "6022261031092a24cde6ec5a",

                        "status": true,
                        "group_name": "REVENUE/INCOME",
                        "parent": null
                    },
                    {
                        "_id": "6022261d31092a24cde6ec5b",

                        "status": true,
                        "group_name": "LIABILITIES",
                        "parent": null
                    }, {
                        "_id": "6022262431092a24cde6ec5c",
                        "status": true,
                        "group_name": "CAPITAL ACCOUNT",
                        "parent": null
                    }, {
                        "_id": "602282dfdd085f6441ec783f",
                        "status": true,
                        "group_name": "CURRENT ASSET",
                        "parent": "602225c331092a24cde6ec58"
                    }, {
                        "_id": "602282f5dd085f6441ec7840",
                        "status": true,
                        "group_name": "CURRENT EXPENSES",
                        "parent": "6022260931092a24cde6ec59"
                    }, {
                        "_id": "602a50d5f19e723dddee0c51",
                        "status": true,
                        "group_name": "FIXED ASSET",
                        "parent": "602225c331092a24cde6ec58"
                    }, {
                        "_id": "602a50ddf19e723dddee0c52",
                        "status": true,
                        "group_name": "INTANGIBLE",
                        "parent": "602225c331092a24cde6ec58"
                    }, {
                        "_id": "602a50e6f19e723dddee0c53",
                        "status": true,
                        "group_name": "TANGIBLE",
                        "parent": "602225c331092a24cde6ec58"
                    }, {
                        "_id": "602a5159f19e723dddee0c54",
                        "status": true,
                        "group_name": "DIRECT INCOMES",
                        "parent": "6022261031092a24cde6ec5a"
                    }, {
                        "_id": "602a5168f19e723dddee0c55",
                        "status": true,
                        "group_name": "INDIRECT INCOMES",
                        "parent": "6022261031092a24cde6ec5a"
                    }, {
                        "_id": "602a5175f19e723dddee0c56",
                        "status": true,
                        "group_name": "DIRECT EXPENSES",
                        "parent": "6022260931092a24cde6ec59"
                    }, {
                        "_id": "602a517ef19e723dddee0c57",
                        "status": true,
                        "group_name": "INDIRECT EXPENSES",
                        "parent": "6022260931092a24cde6ec59"
                    }, {
                        "_id": "602a5188f19e723dddee0c58",
                        "status": true,
                        "group_name": "CURRENT LIABILITIES",
                        "parent": "6022261d31092a24cde6ec5b"
                    }, {
                        "_id": "602a5193f19e723dddee0c59",
                        "status": true,
                        "group_name": "LOANS (LIABILITY)",
                        "parent": "6022261d31092a24cde6ec5b"
                    }, {
                        "_id": "602a519df19e723dddee0c5a",
                        "status": true,
                        "group_name": "RESERVES & SURPLUS",
                        "parent": "6022262431092a24cde6ec5c"
                    }, {
                        "_id": "602a51a8f19e723dddee0c5b",
                        "status": true,
                        "group_name": "SHARE CAPITAL",
                        "parent": "6022262431092a24cde6ec5c"
                    }, {
                        "_id": "602a51b0f19e723dddee0c5c",
                        "status": true,
                        "group_name": "DRAWINGS",
                        "parent": "6022262431092a24cde6ec5c"
                    }, {
                        "_id": "602a51c2f19e723dddee0c5d",
                        "status": true,
                        "group_name": "SUNDRY DEBTORS",
                        "parent": "602282dfdd085f6441ec783f"
                    }, {
                        "_id": "602a51ccf19e723dddee0c5e",
                        "status": true,
                        "group_name": "CASH IN HAND",
                        "parent": "602282dfdd085f6441ec783f"
                    }, {
                        "_id": "602a51d6f19e723dddee0c5f",
                        "status": true,
                        "group_name": "BANK ACCOUNTS",
                        "parent": "602282dfdd085f6441ec783f"
                    }, {
                        "_id": "602a51e6f19e723dddee0c60",
                        "status": true,
                        "group_name": "DEPOSITS (ASSET)",
                        "parent": "602282dfdd085f6441ec783f"
                    }, {
                        "_id": "602a51f1f19e723dddee0c61",
                        "status": true,
                        "group_name": "LOANS & ADVANCES (ASSET)",
                        "parent": "602282dfdd085f6441ec783f"
                    }, {
                        "_id": "602a520bf19e723dddee0c62",
                        "status": true,
                        "group_name": "SALES ACCOUNTS",
                        "parent": "602a5159f19e723dddee0c54"
                    }, {
                        "_id": "602a5216f19e723dddee0c63",
                        "status": true,
                        "group_name": "PURCHASE ACCOUNTS",
                        "parent": "602a5175f19e723dddee0c56"
                    }, {
                        "_id": "602a5224f19e723dddee0c64",
                        "status": true,
                        "group_name": "SUNDRY CREDITORS",
                        "parent": "602a5188f19e723dddee0c58"
                    }, {
                        "_id": "602a5232f19e723dddee0c65",
                        "status": true,
                        "group_name": "DUTIES & TAXES",
                        "parent": "602a5188f19e723dddee0c58"
                    }, {
                        "_id": "602a523ef19e723dddee0c66",
                        "status": true,
                        "group_name": "BRANCH / DIVISIONS",
                        "parent": "602a5188f19e723dddee0c58"
                    }, {
                        "_id": "602a524bf19e723dddee0c67",
                        "status": true,
                        "group_name": "BANK OD A/C",
                        "parent": "602a5188f19e723dddee0c58"
                    }, {
                        "_id": "602a525cf19e723dddee0c68",
                        "status": true,
                        "group_name": "SUPPLIERS",
                        "parent": "602a5224f19e723dddee0c64"
                    }, {
                        "_id": "602a526af19e723dddee0c69",
                        "status": true,
                        "group_name": "TDS ON COMMISION",
                        "parent": "602a5232f19e723dddee0c65"
                    }, {
                        "_id": "602a527df19e723dddee0c6a",
                        "status": true,
                        "group_name": "TDS PAYABLE",
                        "parent": "602a5232f19e723dddee0c65"
                    }, {
                        "_id": "602a5290f19e723dddee0c6b",
                        "status": true,
                        "group_name": "COMMISSION ADVANCE",
                        "parent": "602a51f1f19e723dddee0c61"
                    }
                ])
            }
        } catch (error : any) {
            console.log(error);
        }
    }
}
