import { Product } from "../models/product-model";
import { User } from "../models/user-model";
import LedgerService from "./ledger-service";
import { MaterialTransferService } from "./material-transfer-service";
import { MetalReturnService } from "./metal-return-service";
import PartyService from "./party-service";
import ProductService from "./product-service";
import { PurchaseService } from "./purchase-service";
import { salesService } from "./sales-service";
import StockService from "./stock-service";
import UserService from "./user-service";
import VoucherService from "./voucher-service";
export default class DashboardService {
  constructor() {}
  ledgerservice = new LedgerService();
  voucherservice = new VoucherService();
  stockservice = new StockService();
  partyservice = new PartyService();
  bankBalance = async () => {
    let closingBalance = await this.voucherservice.closingBalance();
    let cb: any = {};
    closingBalance.forEach((e: any) => {
      cb[e.ledger_id] = e.closing;
    });

    let ledgerList = await this.ledgerservice.getBankAndCashLedger([
      "BANK ACCOUNTS",
    ]);
    let result = ledgerList[0]?.ledgers?.map((e: any) => {
      let closing = cb[e._id] ? cb[e._id] : 0;
      return {
        ledger_id: e._id,
        ledger_name: e.ledger_name,
        closing: closing,
      };
    });
    return {
      span: 8,
      chart: {
        height: 300,
        type: "pie",
      },
      title: "Bank Balance",
      series: result.map((e: any) => e.closing),
      labels: result.map((e: any) => e.ledger_name),
    };
  };
  closingStock = async () => {
    try {
      let fromDate=new Date();
      fromDate.setDate(1);
      let toDate=new Date();    
      let stock = await this.stockservice.dashboardStock(fromDate,toDate);
      return {
        span: 16,
        chart: {
          height: 265,
          type: "area",
        },
        colors: ["#9c27b0"],
        title: "Stock",
        series: [
          {
            name: "Weight",
            data: stock.map((e: any) => Math.round(e.weight)),
          },
        ],
        labels: stock.map((e: any) => e.date),
      };
    } catch (error: any) {
      throw new Error(error);
    }
  };
  partyClosing = async () => {
    try {
      let closingBalance = await this.voucherservice.closingBalance();
      let cb: any = {};
      closingBalance.forEach((e: any) => {
        cb[e.ledger_id] = e.closing;
      });

      let party = await this.partyservice.list({ account_type: "Customer" });
      let party_id = party.map((e) => e._id);
      let party_balance = 0,
        party_advance = 0;
      if (party_id.length > 0) {
        let ledgerList = await this.ledgerservice.list({
          "reference.ref_from": "party",
          "reference.ref_id": { $in: party_id },
        });          
        ledgerList.forEach((e: any) => {
          let closing = cb[e._id] ? cb[e._id] : 0;
          if (closing > 0) party_balance += closing;
          else party_advance += Math.abs(closing);
        });
      }

      // let result = ledgerList.map((e: any) => {
      //   let closing = cb[e._id] ? cb[e._id] : 0;
      //   return {
      //     ledger_name: e.ledger_name,
      //     closing: closing,
      //   };
      // });

      return { party_advance: Math.round(party_advance), party_balance: Math.round(party_balance) };
    } catch (error: any) {
      throw new Error(error);
    }
  };
  processDailyData = (data: any[]): any[] => {
    let fromDate = new Date();
    fromDate.setHours(0, 0, 0, 0);
    fromDate.setDate(1);
    let toDate = new Date(fromDate);
    toDate.setMonth(toDate.getMonth() + 1);
    let result = data.reduce((carry: any, e: any) => {
      let date = new Date(e.invoice_date).getDate();
      if (carry[date]) carry[date] += e.invoice_amount;
      else carry[date] = e.invoice_amount;
      return carry;
    }, {});
    let res: any[] = [];
    toDate.setDate(toDate.getDate() - 1);
    for (let i = 1; i <= toDate.getDate(); i++) {
      let amount = 0;
      if (result[i]) amount = result[i];
      res.push({
        date: i,
        amount: amount,
      });
    }
    return res;
  };
  processDailyMetalData = (data: any[]): any[] => {
    let fromDate = new Date();
    fromDate.setHours(0, 0, 0, 0);
    fromDate.setDate(1);
    let toDate = new Date(fromDate);
    toDate.setMonth(toDate.getMonth() + 1);
    let result = data.reduce((carry: any, e: any) => {
      let w = e.item_details
        ?.map((e: any) => e.net_weight)
        .reduce((carry: number, e: number) => carry + e, 0);

      let date = new Date(e.invoice_date).getDate();
      if (carry[date]) carry[date] += w;
      else carry[date] = w;
      return carry;
    }, {});
    let res: any[] = [];
    toDate.setDate(toDate.getDate() - 1);
    for (let i = 1; i <= toDate.getDate(); i++) {
      let weight = 0;
      if (result[i]) weight = result[i];
      res.push({
        date: i,
        weight: weight,
      });
    }
    return res;
  };
  dailyPurchase = async () => {
    let fromDate = new Date();
    fromDate.setHours(0, 0, 0, 0);
    fromDate.setDate(1);
    let toDate = new Date(fromDate);
    toDate.setMonth(toDate.getMonth() + 1);
    let service = new PurchaseService();
    let data = await service.list({
      invoice_date: { $gte: fromDate, $lt: toDate },
    });
    let res = this.processDailyData(data);
    return {
      span: 8,
      chart: {
        type: "line",
        sparkline: {
          enabled: true,
        },
      },

      stroke: {
        width: 2,
      },
      colors: ["#1890ff"],
      title: "Purchase",
      series: [
        {
          name: "Amount",
          data: res.map((e: any) => Math.round(e.amount)),
        },
      ],
      labels: res.map((e: any) => e.date),
    };
  };
  dailySales = async () => {
    try {
      let fromDate = new Date();
      fromDate.setHours(0, 0, 0, 0);
      fromDate.setDate(1);
      let toDate = new Date(fromDate);
      toDate.setMonth(toDate.getMonth() + 1);
      let service = new salesService();
      let data = await service.list({
        invoice_date: { $gte: fromDate, $lt: toDate },
      });
      let res = this.processDailyData(data);

      return {
        span: 8,
        chart: {
          type: "line",
          sparkline: {
            enabled: true,
          },
        },

        stroke: {
          width: 2,
        },

        title: "Sales",
        series: [
          {
            name: "Amount",
            data: res.map((e: any) => Math.round(e.amount)),
          },
        ],
        labels: res.map((e: any) => e.date),
      };
    } catch (error: any) {
      throw new Error(error);
    }
  };
  dailyMetalTransfer = async () => {
    let fromDate = new Date();
    fromDate.setHours(0, 0, 0, 0);
    fromDate.setDate(1);
    let toDate = new Date(fromDate);
    toDate.setMonth(toDate.getMonth() + 1);
    let service = new MaterialTransferService();
    let data = await service.list({
      invoice_date: { $gte: fromDate, $lt: toDate },
    });
    let res = this.processDailyMetalData(data);

    let ret: any[] = await this.dailyMetalReturn();
    return {
      span: 8,
      chart: {
        type: "bar",
        sparkline: {
          enabled: true,
        },
      },

      stroke: {
        width: 2,
      },

      title: "Metal Transfer",
      series: [
        {
          color: "#52c41a",
          name: "Metal Transfer",
          data: res.map((e: any) => Math.round(e.weight)),
        },
        {
          color: "#faad14",
          name: "Metal Return",
          data: ret.map((e: any) => Math.round(e.weight)),
        },
      ],
      labels: res.map((e: any) => e.date),
    };
  };
  dailyMetalReturn = async () => {
    let fromDate = new Date();
    fromDate.setHours(0, 0, 0, 0);
    fromDate.setDate(1);
    let toDate = new Date(fromDate);
    toDate.setMonth(toDate.getMonth() + 1);
    let service = new MetalReturnService();
    let data = await service.list({
      invoice_date: { $gte: fromDate, $lt: toDate },
    });
    return this.processDailyMetalData(data);
  };
  users = async () => {
    let service = new UserService();
    let users = await service.list();
    let res = users.reduce(
      (carry: any, e: User) => {
        carry.total += 1;
        if (e.status == true) carry.active += 1;
        return carry;
      },
      { total: 0, active: 0 }
    );
    return res;
  };
  products = async () => {
    let service = new ProductService();
    let product = await service.list();
    let res = product.reduce(
      (carry: any, e: Product) => {
        carry.total += 1;
        if (e.status == true) carry.active += 1;
        return carry;
      },
      { total: 0, active: 0 }
    );
    return res;
  };
}
