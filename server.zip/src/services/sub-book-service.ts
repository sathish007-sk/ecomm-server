import subBookModel, { SubBook } from '../models/sub-book-model';
import { CRUD, ValidateAdd, ValidateDelete, ValidateEdit, ValidateResponse } from './crud-service';
export default class SubBookService extends CRUD<SubBook>{
    public model=subBookModel;
    constructor(){
       super();
    }
    validateAdd: ValidateAdd=async(data:SubBook):Promise<ValidateResponse>=>{
        let ck=await this.list();
        if(ck.length>0)  return {success:false,message:'Only one Sub Book allowed'};
        
        return {success:true};
    }
    validateEdit: ValidateEdit=async(data:SubBook,id:string):Promise<ValidateResponse>=>{
        return {success:true};
    }
    validateDelete: ValidateDelete=async(id:string):Promise<ValidateResponse>=>{
        return {success:false};
    }
    init = async()=>{
        try{
            let count = await this.model.countDocuments();
            if(count === 0){
                await this.model.create({
                    code: "SB001",
                    name: 'Your Sub Book Name',
                });
            }
        }
        catch(error){
            throw error;
        }
    }
}