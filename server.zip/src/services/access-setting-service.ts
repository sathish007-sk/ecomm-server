import accessSettingModel, { AccessSetting } from '../models/access-setting-model';
import { CRUD, ValidateAdd, ValidateDelete, ValidateEdit, ValidateResponse } from './crud-service';

export default class AccessSettingService extends CRUD<AccessSetting>{
    public model = accessSettingModel;
    constructor() {
        super();
    }
    async retrieveById(id: string) {
        try {
            let result = await this.model.find({ user_id: id });
            return result;
        } catch (error: any) {
            throw new Error(error);
        }
    }
    validateAdd: ValidateAdd = async (data: AccessSetting): Promise<ValidateResponse> => {
        return { success: true };
    }
    validateEdit: ValidateEdit = async (data: AccessSetting, id: string): Promise<ValidateResponse> => {
        return { success: true };
    }
    validateDelete: ValidateDelete = async (id: string): Promise<ValidateResponse> => {
        return { success: true };
    }
    async menuList(user_id:string):Promise<AccessSetting[]>{
        try {
            let result = await this.model.find({ user_id: user_id }).populate('menu_id').populate('options');           
            return result;
        } catch (error: any) {
            throw new Error(error);
        }
    }
    async save(book_id: string, sub_book_id: string, done_by: string, menu: any, user_id: string) {
        try {
            menu.forEach(async (element: any) => {
                if (element.options.length == 0) {
                    await this.model.findOneAndDelete({ user_id: user_id, menu_id: element.menu_id });
                }
                else {
                    let check = await this.model.findOne({ user_id: user_id, menu_id: element.menu_id });
                    if (!check) {
                        let obj = {
                            book_id: book_id,
                            sub_book_id: sub_book_id,
                            user_id: user_id,
                            done_by: done_by,
                            options: element.options,
                            menu_id: element.menu_id
                        };
                        await this.model.create(obj);
                    }
                    else {
                        check.options = element.options;
                        await check.save();
                    }

                }
            });
            let result = await this.model.findOne({ user_id: user_id });
            return { success: true, data: result, message: 'Successfully Saved' };

        } catch (error: any) {
            throw new Error(error);
        }
    }
}