import stockJournalModel, { StockJournal } from "../models/stock-journal-model";
import {
  CRUD,
  ValidateAdd,
  ValidateDelete,
  ValidateEdit,
  ValidateResponse,
} from "./crud-service";
import StockService from "./stock-service";

export default class StockJournalService extends CRUD<StockJournal> {
  public model = stockJournalModel;
  stockservice = new StockService();
  constructor() {
    super();
  }

  validateAdd: ValidateAdd = async (
    data: StockJournal
  ): Promise<ValidateResponse> => {
    try {
      let check = await this.model.findOne({
        ref_no: {
          $regex: new RegExp("^" + data.ref_no.toLowerCase() + "$", "i"),
        },
      });
      if (check) return { success: false, message: "Already Exists" };
      return { success: true };
    } catch (error: any) {
      throw new Error(error);
    }
  };
  validateEdit: ValidateEdit = async (
    data: StockJournal,
    id: string
  ): Promise<ValidateResponse> => {
    try {
      let check = await this.model.findOne({
        ref_no: {
          $regex: new RegExp("^" + data.ref_no.toLowerCase() + "$", "i"),
        },
        _id: { $ne: id },
      });
      if (check) return { success: false, message: "Already Exists" };
      return { success: true };
    } catch (error: any) {
      throw new Error(error);
    }
  };
  validateDelete: ValidateDelete = async (
    id: string
  ): Promise<ValidateResponse> => {
    return { success: true };
  };
  async callBackAdd(data: StockJournal) {
    await this.stockservice.stockJournal(data, "Add");
  }
  async callBackEdit(data: StockJournal) {
    if (data?._id) await this.stockservice.stockJournal(data, "Edit");
  }
  async callBackDelete(data: StockJournal) {
    await this.stockservice.stockJournal(data, "Delete");
  }
  async list(filter?:any){
    try {
        let date = {};
        if (filter.from_date) {
          let fromDate = new Date(filter.from_date);
          fromDate.setHours(0, 0, 0, 0);
          delete filter.from_date;
          date = { $gte: fromDate, ...date };
        }
        if (filter?.to_date) {
          let toDate = new Date(filter.to_date);
          toDate.setHours(0, 0, 0, 0);
          toDate.setDate(toDate.getDate() + 1);
          delete filter.to_date;
          date = { $lte: toDate, ...date };
        }
        if (Object.keys(date).length > 0) {
          filter.date = date;
        }
       
        let result = await this.model.find(filter).sort({date:-1});
        return result;
    } catch (error:any) {
       throw new Error(error);
    }
}
}
