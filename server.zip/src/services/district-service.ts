import { District, districtModel } from '../models/location-model';
import { CRUD, ValidateAdd, ValidateDelete, ValidateEdit, ValidateResponse } from './crud-service';

export default class DistrictService extends CRUD<District>{
    public model=districtModel;
    constructor(){
       super();
    }
    async list(filter={}){
        try {
            let result = await this.model.find(filter).populate('state') as District[];
            return result;
        } catch (error:any) {
           throw new Error(error);
        }

    }
    validateAdd: ValidateAdd=async(data:District):Promise<ValidateResponse>=>{
        try {
            let check=await this.model.findOne({name: { $regex: new RegExp("^" + data.name.toLowerCase()+"$", "i")}});
            if(check)return {success:false, message:"Already Exists"};
            return {success:true};
        } catch (error:any) {
            throw new Error(error);
        }       
    }
    validateEdit: ValidateEdit=async(data:District,id:string):Promise<ValidateResponse>=>{
        try {
            let check=await this.model.findOne({name: { $regex: new RegExp("^" + data.name.toLowerCase()+"$", "i")},_id:{$ne:id}});
            if(check)return {success:false, message:"Already Exists"};
            return {success:true};
        } catch (error:any) {
            throw new Error(error);
        }      
    }
    validateDelete: ValidateDelete=async(id:string):Promise<ValidateResponse>=>{
        return {success:true};
    }
}