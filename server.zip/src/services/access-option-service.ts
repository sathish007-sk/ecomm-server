import accessOption, { AccessOption } from "../models/access-option-model";
import {
  CRUD,
  ValidateAdd,
  ValidateDelete,
  ValidateEdit,
  ValidateResponse,
} from "./crud-service";

export default class AccessOptionService extends CRUD<AccessOption> {
  public model = accessOption;
  constructor() {
    super();
  }
  init = async () => {
    let ck = await this.model.countDocuments();
    if (ck == 0) {
      await this.model.insertMany([
        {
          status: true,
          _id: "613e11741fbcc20ca8cb42c1",
          option_name: "Add",
          __v: 0,
        },
        {
          status: true,
          _id: "613e117a1fbcc20ca8cb42c4",
          option_name: "Edit",
          __v: 0,
        },
        {
          status: true,
          _id: "613e11801fbcc20ca8cb42c7",
          option_name: "Delete",
          __v: 0,
        },
        {
          status: true,
          _id: "613e11861fbcc20ca8cb42ca",
          option_name: "View",
          __v: 0,
        },
        {
          status: true,
          _id: "613e118d1fbcc20ca8cb42cd",
          option_name: "List",
          __v: 0,
        },
        {
          status: true,
          _id: "613e11931fbcc20ca8cb42d0",
          option_name: "Print",
          __v: 0,
        },
        {
          status: true,
          _id: "61406d4a08bd750c198fa3aa",
          option_name: "PDF",
          createdAt: "2021-09-14T09:37:14.744Z",
          updatedAt: "2021-09-14T09:37:14.744Z",
          __v: 0,
        },
      ]);
    }
  };
  validateAdd: ValidateAdd = async (
    data: AccessOption
  ): Promise<ValidateResponse> => {
    return { success: true };
  };
  validateEdit: ValidateEdit = async (
    data: AccessOption,
    id: string
  ): Promise<ValidateResponse> => {
    return { success: true };
  };
  validateDelete: ValidateDelete = async (
    id: string
  ): Promise<ValidateResponse> => {
    return { success: true };
  };
}
