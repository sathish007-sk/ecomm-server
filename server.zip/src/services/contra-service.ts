import ReceiptService from './receipt-service';
export default class ContraService extends ReceiptService{
    public voucherType = "Contra";
    constructor() {
        super();
    }
}