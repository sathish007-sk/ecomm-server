import userModel, { User } from '../models/user-model';
import { CRUD, ValidateAdd, ValidateDelete, ValidateEdit, ValidateResponse } from './crud-service';
import { sign } from 'jsonwebtoken';
import BookService from './book-service';
import SubBookService from './sub-book-service';
export default class UserService extends CRUD<User>{
    public model = userModel;
    constructor() {
        super();
    }
    async insertData(): Promise<void> {
        let check = await this.model.countDocuments();
        if (check==0) {
            await this.model.create({
                code: '001',
                user_name: 'Blazon',
                password: '654321',
                role:'Super Admin'
            });
        }
    }
    validateAdd: ValidateAdd = async (data: User): Promise<ValidateResponse> => {
        try {
            let check=await this.model.findOne({ code: { $regex: new RegExp("^" + data.code.toLowerCase()+"$", "i")}});
            if(check)return {success:false, message:"Already Exists"};
            return {success:true};
        } catch (error:any) {
            throw new Error(error);
        }       
    }
    validateEdit: ValidateEdit = async (data: User, id: string): Promise<ValidateResponse> => {
        try {
            let check=await this.model.findOne({ code: { $regex: new RegExp("^" + data.code.toLowerCase()+"$", "i")},_id:{$ne:id}});
            if(check)return {success:false, message:"Already Exists"};
            return {success:true};
        } catch (error:any) {
            throw new Error(error);
        }    
    }
    validateDelete: ValidateDelete = async (id: string): Promise<ValidateResponse> => {
        return { success: true };
    }

    async login(code: string, password: string): Promise<any> {
        debugger;
        try {        
            let user: User = await this.model.findOne({ code: code });
            if (!user) return { success: false, message: "Unable to find your account" };
            if (user.password !== password) return { success: false, message: "Incorrect password" };
            if (user._id) {
                let bookservice=new BookService();
                let bookId=await bookservice.retrieve();
                let obj:any={ user_id: user._id ,book_id:bookId._id }
                let subbookservice=new SubBookService();
                let subBookList=await subbookservice.list();
                if(subBookList.length){
                    obj.sub_book_id=subBookList[0]._id;
                }
                let privateKey: any = process.env.KEY;
                let token = sign(obj, privateKey);
                return { success: true, token: token, message: 'Successfully signed in',user_name:user.user_name,role:user.role };
            }
        } catch (error:any) {
            throw new Error(error);
        }
    }
}