import LedgerService from "./ledger-service";
import { PurchaseService } from "./purchase-service";
import { salesService } from "./sales-service";
import VoucherService from "./voucher-service";
export default class PrintService{
    voucherservice = new VoucherService();
    ledgerservice = new LedgerService();
    async print(party_id:string,date:Date){       
        try{       
            let fromDate = new Date(date);
            fromDate.setHours(0, 0, 0, 0);
            let toDate = new Date(fromDate);
            toDate.setDate(toDate.getDate() + 1);
            let ledger=await this.ledgerservice.getPartyLedger(party_id)
            let data=await this.voucherservice.getVouchers({ledger_id:ledger._id,date:date});
            let salesservice = new salesService();
            let purchaseservice = new PurchaseService();  
            let saleList = await salesservice.list({ party_id: party_id, invoice_date: {$gte:fromDate,$lt:toDate} });
            let purchaseList = await purchaseservice.list({ party_id: party_id, invoice_date: {$gte:fromDate,$lt:toDate} });
            let result: any = [];
            data.forEach((e:any) => {
                if (e.voucher_type == "Sales") {
                    let sales = saleList.find(el => String(el._id) === String(e.ref_id));
                    sales?.item_details?.forEach(el => {
                        result.push({
                            voucher_type: e.voucher_type,
                            ref_no: e.ref_no,
                            voucher_no: e.voucher_no,
                            date: e.date,
                            amount: el.amount,
                            gross_weight: el.gross_weight,
                            rate: el.rate_per_gram,
                            touch: el.touch,
                            narration:e.voucher_type,
                        });
                    });
                }
                else if (e.voucher_type == "Purchase") {
                    let purchase = purchaseList.find(el => String(el._id) === String(e.ref_id));
                    purchase?.item_details?.forEach(el => {
                        result.push({
                            voucher_type: e.voucher_type,
                            ref_no: e.ref_no,
                            voucher_no: e.voucher_no,
                            date: e.date,
                            amount: el.amount,
                            gross_weight: el.gross_weight,
                            rate: el.rate_per_gram,
                            touch: el.touch,
                            narration:e.voucher_type,
                        });
                    });
                }
                else {
                    result.push({
                        voucher_type: e.voucher_type,
                        ref_no: e.ref_no,
                        voucher_no: e.voucher_no,
                        date: e.date,
                        amount: e.amount,
                        narration:e.narration?.substr(0,50),
                    })
                }
            });

            return result
        }
        catch(error:any){
            throw new Error(error)
        }

       
    }

}