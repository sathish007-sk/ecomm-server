import taxModel, { Tax } from '../models/tax-model';
import { CRUD, ValidateAdd, ValidateDelete, ValidateEdit, ValidateResponse } from './crud-service';
import LedgerService from './ledger-service';

export default class TaxService extends CRUD<Tax>{
    public model=taxModel;
    private ledgerService=new LedgerService();
    constructor(){
       super();
    }
    validateAdd: ValidateAdd=async(data:Tax):Promise<ValidateResponse>=>{
        try {
            let check=await this.model.findOne({ book_id:data.book_id,tax_name: { $regex: new RegExp("^" + data.tax_name.toLowerCase()+"$", "i")}});
            if(check)return {success:false, message:"Already Exists"};
            return {success:true};
        } catch (error:any) {
            throw new Error(error);
        }       
    }
    validateEdit: ValidateEdit=async(data:Tax,id:string):Promise<ValidateResponse>=>{
        try {
            let check=await this.model.findOne({ book_id:data.book_id,tax_name: { $regex: new RegExp("^" + data.tax_name.toLowerCase()+"$", "i")},_id:{$ne:id}});
            if(check)return {success:false, message:"Already Exists"};
            return {success:true};
        } catch (error:any) {
            throw new Error(error);
        }       
    }
    validateDelete: ValidateDelete=async(id:string):Promise<ValidateResponse>=>{
        return {success:true};
    }
    async add(data:Tax):Promise<any>{
        let result=await super.add(data);
        if(result.success){
            this.ledgerService.taxLedgers(result.data);
            return result;
        }
    }
    async updateById(data:Tax,id:string):Promise<any>{
        let result=await super.updateById(data,id);
        if(result.success){
            this.ledgerService.taxLedgers(result.data);
            return result;
        }
    }
}