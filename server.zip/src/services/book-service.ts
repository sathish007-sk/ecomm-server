import bookModel from '../models/book-model';
import { CRUD, ValidateAdd, ValidateDelete, ValidateEdit, ValidateResponse } from './crud-service';

export default class BookService extends CRUD<any>{
    public model=bookModel;
    constructor(){
       super();
    }
    validateAdd: ValidateAdd=async(data:any):Promise<ValidateResponse>=>{
        return {success:true};
    }
    validateEdit: ValidateEdit=async(data:any,id:string):Promise<ValidateResponse>=>{
        return {success:true};
    }
    validateDelete: ValidateDelete=async(id:string):Promise<ValidateResponse>=>{
        return {success:false};
    }
    init = async()=>{
        try{
            let count = await this.model.countDocuments();
            if(count === 0){
                await this.model.create({
                    code: "C001",
                    name: 'Your Company Name',
                });
            }
        }
        catch(error){
            throw error;
        }
    }
}