import { Types } from "mongoose";
import { Ledger, voucherModel } from "../models/accounts-model";
import { purchaseModel } from "../models/purchase-model";
import { salesModel } from "../models/sales-model";

import financialYearService from "../utils/financial-year-service";
import AccountsGroupService from "./accounts-group-service";
import LedgerService from "./ledger-service";

import { PurchaseService } from "./purchase-service";
import { salesService } from "./sales-service";
function getClosing(parent: any, iniData: any) {
  let data = iniData.filter((e: any) => {
    return String(e.parent?._id) === String(parent);
  });
  let amount = data.reduce((carry: any, e: any) => {
    carry += e.closing;
    carry += getClosing(e._id, iniData);
    return carry;
  }, 0);
  return amount;
}
export default class VoucherService {
  public model = voucherModel;
  constructor() {}
  openingBalance = async (ledger: Ledger, mode: "Add" | "Edit" | "Delete") => {
    let voucher_type = "Opening Balance";
    if (ledger._id) {
      let check = await this.model.findOne({
        ref_id: ledger._id,
        voucher_type: voucher_type,
      });
      if (mode == "Delete") {
        if (check) await check.deleteOne();
        return false;
      }
      if (ledger.opening_balance) {
        let financial_year = financialYearService(ledger.opening_balance_date);
        let obj: any = {
          date: ledger.opening_balance_date,
          financial_year: financial_year,
          voucher_type: voucher_type,
          ref_id: ledger._id,
          detail: [
            {
              ledger: ledger._id,
              posting: ledger.posting,
              amount: ledger.opening_balance,
              narration: "Opening Balance entered on master creation",
            },
          ],
        };
        if (!check) {
          await this.model.create(obj);
        } else {
          await this.model.updateOne({ _id: check._id }, obj);
        }
      }
    }
  };
  ledgerReport = async (ledger_id: string, fromDate?: Date, toDate?: Date) => {
    try {
      let filter: any = { "detail.ledger": ledger_id };
      let dateFilter: any = {};
      if (fromDate) {
        fromDate.setHours(0, 0, 0, 0);
        dateFilter = { $gte: fromDate };
      }
      if (toDate) {
        toDate.setHours(0, 0, 0, 0);
        toDate.setDate(toDate.getDate() + 1);
        dateFilter = { ...dateFilter, $lt: toDate };
      }
      if (Object.keys(dateFilter).length > 0) {
        filter = { ...filter, date: dateFilter };
      }

      let result = await this.model
        .find(filter)
        .populate("detail.ledger")
        .sort({ date: 1 });
        
        let data: any = [];
        let opening_balance = 0;
      if (fromDate) {
        let ob=await this.closingBalance(fromDate,ledger_id);
        if(ob?.length>0) opening_balance=ob[0].closing;
        
         
        if (opening_balance != 0) {
          data.unshift({
            particular: "Opening Balance",
            date: fromDate,
            voucher_type: "Opening Balance",
            narration: "Opening Balance as on " + fromDate.toLocaleDateString(),
            cr: opening_balance < 0 ? Math.abs(opening_balance) : 0,
            dr: opening_balance > 0 ? opening_balance : 0,
            closing: opening_balance,
          });
        }
      }
 
      let closing = opening_balance;

     for(let ele of result){ 
    //  result.forEach(async (ele: any) => {
        let target = ele.detail?.find(
          (e: any) => String(e.ledger._id) === String(ledger_id)
        );
       
      
          if (ele.voucher_type == "Opening Balance") {
            let weight=0;
            if (target.posting == "Dr") {
              closing += target.amount;
            } else closing -= target.amount;
            data.push({
              date: ele.date,
              voucher_type: ele.voucher_type,
              voucher_for: ele.voucher_for,
              ref_id: ele.ref_id,
              ref_no: ele.ref_no,
              voucher_no: ele.voucher_no,
              done_by: ele.done_by,
              ledger_id: target.ledger._id,
              ledger_name: target.ledger.ledger_name,
              cr: target.posting == "Cr" ? target.amount : 0,
              dr: target.posting == "Dr" ? target.amount : 0,
              closing: closing,
              narration: target.narration,
              weight:weight,
            });
          } else {
            let weight=0;
            if(ele.voucher_type=="Sales") {
              let sales=await salesModel.findById(ele.ref_id);
              weight=sales.item_details.reduce((c:number,e:any)=>{
                return c+=e.net_weight;
              },0);
            }
            if(ele.voucher_type=="Purchase") {
              let purchase=await purchaseModel.findById(ele.ref_id);
              weight=purchase.item_details.reduce((c:number,e:any)=>{
                return c+=e.net_weight;
              },0);
            }

            
            let ledgers = ele.detail?.filter(
              (e: any) => e.posting != target.posting
            );
            ledgers?.forEach((e: any) => {
              let amount=0;
              if(e.amount<target.amount) amount=e.amount;
              else amount=target.amount;

              if (target.posting == "Dr") {
                closing += amount;
              } else closing -= amount;
              data.push({
                date: ele.date,
                voucher_type: ele.voucher_type,
                voucher_for: ele.voucher_for,
                ref_id: ele.ref_id,
                ref_no: ele.ref_no,
                voucher_no: ele.voucher_no,
                done_by: ele.done_by,
                ledger_id: e.ledger._id,
                ledger_name: e.ledger.ledger_name,
                cr: target.posting == "Cr" ? amount : 0,
                dr: target.posting == "Dr" ? amount : 0,
                closing: closing,
                narration: e.narration,
                weight:weight,
              });
            });
          }
        }
      // });

     

      return data;
    } catch (error: any) {
      throw new Error(error);
    }
  };
  dayBook = async (params: any) => {
    try {
      let fromDate = new Date(params.date);
      fromDate.setHours(0, 0, 0, 0);
      let toDate = new Date(fromDate);
      toDate.setDate(toDate.getDate() + 1);
      let result = await this.model.aggregate([
        {
          $match: { date: { $gte: fromDate, $lt: toDate } },
        },

        {
          $unwind: "$detail",
        },

        {
          $lookup: {
            from: "ledgers",
            localField: "detail.ledger",
            foreignField: "_id",
            as: "ledger",
          },
        },
        {
          $unwind: "$ledger",
        },
        {
          $project: {
            financial_year: 1,
            branch: 1,
            date: 1,
            voucher_type: 1,
            voucher_for: 1,
            voucher_no: 1,
            ref_id: 1,
            ref_no: 1,
            done_by: 1,
            ledger_id: "$ledger._id",
            ledger_name: "$ledger.ledger_name",
            cr: {
              $cond: [{ $eq: ["$detail.posting", "Cr"] }, "$detail.amount", 0],
            },
            dr: {
              $cond: [{ $eq: ["$detail.posting", "Dr"] }, "$detail.amount", 0],
            },
            posting: "$detail.posting",
            narration: "$detail.narration",
          },
        },
      ]);
      let data = result;
      let closing = 0;
      data = data.map((e: any, i: number) => {
        if (e.dr) closing += e.dr;
        else closing -= e.cr;
        e.closing = closing;
        return e;
      });

      return data;
    } catch (error: any) {
      throw new Error(error);
    }
  };
  trialBalance = async (params?: any) => {
    try {
      let groupservice = new AccountsGroupService();
      let closing = await this.closingBalance();
      let group = await groupservice.list({ status: true });
      let gp = group.map((e: any) => {
        let ledgers = closing.filter(
          (ele) => String(ele.group) == String(e._id)
        );
        let closing_balance = ledgers.reduce((carry, ele) => {
          if (ele.posting == "Dr") carry += ele.amount;
          else carry -= ele.amount;
          return carry;
        }, 0);
        return {
          _id: e._id,
          name: e.group_name,
          parent: e.parent,
          closing: closing_balance,
          mode: "g",
        };
      });
      let parent: string | null = null;
      if (params.parent && params.parent != "null") parent = params.parent;
      let data = gp
        .filter((e: any) => e.parent?._id == parent)
        .map((e: any) => {
          let obj = e;
          obj.closing += getClosing(e._id, gp);
          return obj;
        });
      let data2 = closing
        .filter((e) => String(e.group) == String(parent))
        .map((e: any) => {
          let obj = e;
          obj.closing += getClosing(e._id, gp);
          return obj;
        })
        .map((e) => {
          return {
            _id: e.ledger_id,
            name: e.ledger_name,
            parent: e.group,
            closing: e.dr - e.cr,
            mode: "l",
          };
        });
      return [...data, ...data2];
    } catch (error: any) {
      throw new Error(error);
    }
  };

  closingBalance = async (
    date: Date = new Date(),
    ledger_id?: string
  ) => {
    try {
      let filter: any = [];
      if (ledger_id) {
        filter = [{ $match: { ledger_id: Types.ObjectId(ledger_id) } }];
      }
      let result = await this.model.aggregate([
        { $match: { date: { $lt: date } } },
        { $unwind: "$detail" },
        {
          $project: {
            ledger_id: "$detail.ledger",
            posting: "$detail.posting",
            amount: "$detail.amount",
          },
        },
        ...filter,
        {
          $group: {
            _id: "$ledger_id",
            dr: {
              $sum: {
                $cond: [{ $eq: ["$posting", "Dr"] }, "$amount", 0],
              },
            },
            cr: {
              $sum: {
                $cond: [{ $eq: ["$posting", "Cr"] }, "$amount", 0],
              },
            },
          },
        },
        {
          $project: {
            _id: 0,
            dr: 1,
            cr: 1,
            ledger: "$_id",
            closing: { $subtract: ["$dr", "$cr"] },
            posting: { $cond: [{ $gte: ["$dr", "$cr"] }, "Dr", "Cr"] },
          },
        },
        {
          $lookup: {
            from: "ledgers",
            localField: "ledger",
            foreignField: "_id",
            as: "ledger",
          },
        },
        { $unwind: "$ledger" },
        {
          $project: {
            ledger_id: "$ledger._id",
            ledger_name: "$ledger.ledger_name",
            group: "$ledger.group",
            closing: 1,
            amount: { $abs: "$closing" },
            cr: 1,
            dr: 1,
            posting: 1,
          },
        },
      ]);
      return result;
    } catch (error: any) {
      throw new Error(error);
    }
  };
  async getVouchers(
    filter?: any,
    voucher_type: string[] = [
      "Receipt",
      "Payment",
      "Journal",
      "Sales",
      "Purchase",
      "Opening Balance",
    ]
  ) {
    let filterArray: any = { voucher_type: { $in: voucher_type } };
    if (filter.date) {
      let fromDate = new Date(filter.date);
      fromDate.setHours(0, 0, 0, 0);
      let toDate = new Date(fromDate);
      toDate.setDate(toDate.getDate() + 1);
      filterArray.date = { $gte: fromDate, $lt: toDate };
    }
    let ledger_id;
    let ob: any[] = [];
    if (filter.ledger_id) {
      ledger_id = filter.ledger_id;
      filterArray = {
        ...filterArray,
        "detail.ledger": Types.ObjectId(ledger_id),
      };
      let obDate = new Date(filter.date);
      obDate.setDate(obDate.getDate() - 1);
      let openingBalance = await this.closingBalance(obDate, ledger_id);
      ob = openingBalance.map((e) => ({
        date: "",
        voucher_type: "Opening Balance",
        amount: e.closing,
      }));
    }

    let data = await voucherModel.aggregate([
      {
        $match: filterArray,
      },
      {
        $unwind: "$detail",
      },
      {
        $match: filterArray,
      },
      {
        $project: {
          date: 1,
          ref_no: 1,
          ref_id: 1,
          voucher_no: 1,
          financial_year: 1,
          voucher_type: 1,
          amount: {
            $cond: [
              { $eq: ["$detail.posting", "Dr"] },
              "$detail.amount",
              { $subtract: [0, "$detail.amount"] },
            ],
          },
          narration: "$detail.narration",
          date_time: 1,
        },
      },
    ]);

    return [...ob, ...data];
  }
  ledgerBrief = async (ledger_id: string, fromDate?: Date, toDate?: Date) => {
    try {
         
      let filter: any = { "detail.ledger": ledger_id };
      let dateFilter: any = {};
      if (fromDate) {
        fromDate.setHours(0, 0, 0, 0);
        dateFilter = { $gte: fromDate };
      }
      if (toDate) {
        toDate.setHours(0, 0, 0, 0);
        toDate.setDate(toDate.getDate() + 1);
        dateFilter = { ...dateFilter, $lt: toDate };
      }
      if (Object.keys(dateFilter).length > 0) {
        filter = { ...filter, date: dateFilter };
      }

      let result = await this.model
        .find(filter)
        .populate("detail.ledger")
        .sort({ date: 1 });
      let data: any = [];
      let opening_balance = 0;
      if (fromDate) {
        let ob=await this.closingBalance(fromDate,ledger_id);
        if(ob?.length>0) opening_balance=ob[0].closing;
        
         
        if (opening_balance != 0) {
          data.unshift({
            particular: "Opening Balance",
            date: fromDate,
            voucher_type: "Opening Balance",
            narration: "Opening Balance as on " + fromDate.toLocaleDateString(),
            cr: opening_balance < 0 ? Math.abs(opening_balance) : 0,
            dr: opening_balance > 0 ? opening_balance : 0,
            closing: opening_balance,
          });
        }
      }
      let closing = opening_balance;
      
      
      // result?.forEach(async(ele: any) => {

      for(let ele of result){

        let target = ele.detail.find(
          (e: any) => String(e.ledger?._id) == String(ledger_id)
        );
        if (target.posting == "Dr") {
          closing += target.amount;
        } else closing -= target.amount;
        let ledgers = ele.detail.filter(
          (e: any) => e.posting != target.posting
        );
        let particular;
        if (ledgers.length == 1) particular = ledgers[0]?.ledger?.ledger_name;
        else particular = ele.voucher_type;
       
        let weight=0;
        if(ele.voucher_type=="Sales") {
          let sales=await salesModel.findById(ele.ref_id);
          weight=sales.item_details.reduce((c:number,e:any)=>{
            return c+=e.net_weight;
          },0);
        }
        if(ele.voucher_type=="Purchase") {
          let purchase=await purchaseModel.findById(ele.ref_id);
          weight=purchase.item_details.reduce((c:number,e:any)=>{
            return c+=e.net_weight;
          },0);
        }
       
        data.push({
          particular: particular,
          date: ele.date,
          voucher_type: ele.voucher_type,
          voucher_for: ele.voucher_for,
          voucher_no: ele.voucher_no,
          ref_id: ele.ref_id,
          ref_no: ele.ref_no,
          weight:weight,
          done_by: ele.done_by,
          cr: target.posting == "Cr" ? target.amount : 0,
          dr: target.posting == "Dr" ? target.amount : 0,
          closing: closing,
          narration: target.narration,
        });
      }

      return data;
    } catch (error: any) {
      
      
      throw new Error(error);
    }
  };

  ledgerExp = async (ledger_id: string,  toDate?: Date, fromDate?: Date,) => {
    try {
      let filter: any = { "detail.ledger": ledger_id };
      
      let dateFilter: any = {};
      if (fromDate) {
        fromDate.setHours(0, 0, 0, 0);
        dateFilter = { $gte: fromDate };
      }
      if (toDate) {
        toDate.setHours(0, 0, 0, 0);
        toDate.setDate(toDate.getDate() + 1);
        dateFilter = { ...dateFilter, $lt: toDate };
      }
      if (Object.keys(dateFilter).length > 0) {
        filter = { ...filter, date: dateFilter };
      }

      let result = await this.model
        .find(filter)
        .populate("detail.ledger")
        .sort({ date: 1 });
        
        let data: any = [];
        let opening_balance = 0;
      if (fromDate) {
        let ob=await this.closingBalance(fromDate,ledger_id);
        if(ob?.length>0) opening_balance=ob[0].closing;
        
         
        if (opening_balance != 0) {
          data.unshift({
            particular: "Opening Balance",
            date: fromDate,
            voucher_type: "Opening Balance",
            narration: "Opening Balance as on " + fromDate.toLocaleDateString(),
            cr: opening_balance < 0 ? Math.abs(opening_balance) : 0,
            dr: opening_balance > 0 ? opening_balance : 0,
            closing: opening_balance,
          });
        }
      }
 
      let closing = opening_balance;

     for(let ele of result){ 
    //  result.forEach(async (ele: any) => {
        let target = ele.detail?.find(
          (e: any) => String(e.ledger._id) === String(ledger_id)
        );

      
          
            let weight=0;
            if (target.posting == "Dr") {
              closing += target.amount;
            } else closing -= target.amount;
            data.push({
              date: ele.date,
              voucher_type: ele.voucher_type,
              voucher_for: ele.voucher_for,
              ref_id: ele.ref_id,
              ref_no: ele.ref_no,
              voucher_no: ele.voucher_no,
              done_by: ele.done_by,
              ledger_id: target.ledger._id,
              ledger_name: target.ledger.ledger_name,
              cr: target.posting == "Cr" ? target.amount : 0,
              dr: target.posting == "Dr" ? target.amount : 0,
              closing: closing,
              narration: target.narration,
              weight:weight,
            })
        }
      // });

    const res = Array.from(data.reduce(
      (m: { set: (arg0: any, arg1: any) => any; get: (arg0: any) => any; }, {ledger_id, dr}: any) => m.set(ledger_id, (m.get(ledger_id) || 0) + dr), new Map
    ), ([ledger_id, dr]) => ({ledger_id, dr}));

    const res2 = Array.from(data.reduce(
      (m: { set: (arg0: any, arg1: any) => any; get: (arg0: any) => any; }, {ledger_id, cr}: any) => m.set(ledger_id, (m.get(ledger_id) || 0) + cr), new Map
    ), ([ledger_id, cr]) => ({ledger_id, cr}));

    // let arr: any = [] ;
    // arr.push(res)
    // arr.push(res2)
    //   let final : any =[]
    // for(let x of arr){
    //   for(let y of x){
        
    //     final.push(y);
    //   }
    // }

    function  mergeArrayObjects(arr1: any,arr2 : any){
      return arr1.map((item:any,i: any)=>{
         if(item.ledger_id === arr2[i].ledger_id){
             //merging two objects
           return Object.assign({},item,arr2[i])
         }
      })
    }
    let ledgerservice = new LedgerService();
    let final = mergeArrayObjects(res,res2)
    const result1 = await Promise.all(final.map( async  (e:any ) => {
      let data = await ledgerservice.retrieveById(e.ledger_id)
      e.data = data;
      return e
    }))
      return result1
    } catch (error: any) {
      throw new Error(error);
    }
  };
}


