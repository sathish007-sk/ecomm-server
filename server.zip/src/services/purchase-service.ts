import { Purchase, purchaseModel } from '../models/purchase-model';
import financialYearService, { financialYearReverse } from '../utils/financial-year-service';
import { AccountsAutoPostingService } from './accounts-auto-posting-service';
import { CRUD, ValidateAdd, ValidateDelete, ValidateEdit, ValidateResponse } from './crud-service';
import PartyService from './party-service';
import StockService from './stock-service';
import SubBookService from './sub-book-service';
import { Types } from "mongoose";
export class PurchaseService extends CRUD<Purchase>{
    partyservice=new PartyService();
    stockservice=new StockService();
    subbookservice=new SubBookService()
    accountsService=new AccountsAutoPostingService();
    model= purchaseModel;
    validateAdd: ValidateAdd = async (data: any): Promise<ValidateResponse> => {
        return { success: true }
    }
    validateEdit: ValidateEdit = async (data: any, id: string): Promise<ValidateResponse> => {
        return { success: true };
    }
    validateDelete: ValidateDelete = async (id: string): Promise<ValidateResponse> => {
        return { success: true };
    }
    async list(filter?:any){
        try {
            let date = {};
            if (filter.from_date) {
              let fromDate = new Date(filter.from_date);
              fromDate.setHours(0, 0, 0, 0);
              delete filter.from_date;
              date = { $gte: fromDate, ...date };
            }
            if (filter?.to_date) {
              let toDate = new Date(filter.to_date);
              toDate.setHours(0, 0, 0, 0);
              toDate.setDate(toDate.getDate() + 1);
              delete filter.to_date;
              date = { $lte: toDate, ...date };
            }
            if (Object.keys(date).length > 0) {
              filter.invoice_date = date;
            }
           
            let result = await this.model.find(filter).sort({invoice_date:-1}) as Purchase[];
            return result;
        } catch (error:any) {
           throw new Error(error);
        }
    }
    async add(data:Purchase):Promise<any>{
        let fy=financialYearService(data.invoice_date);
        let save=await super.add({...data,financial_year:fy});
        return save;
    }
    async update(data:Purchase,filter:any):Promise<any>{
        let fy=financialYearService(data.invoice_date);
        let save=await super.update({...data,financial_year:fy},filter);
        return save;
    }
    async updateById(data:Purchase,id:string):Promise<any>{
        let fy=financialYearService(data.invoice_date);
        let save=await super.updateById({...data,financial_year:fy},id);
        return save;
    }
    async callBackAdd(data:Purchase){
        await this.accountsService.purchase(data,"Add");
        await this.stockservice.purchase(data,"Add");
    }   
    async callBackEdit(data:Purchase){
        await this.accountsService.purchase(data,'Edit');
       await this.stockservice.purchase(data,'Edit');
    }   
    async callBackDelete(data:Purchase){
        await this.accountsService.purchase(data,'Delete');
        await this.stockservice.purchase(data,'Delete');
    }
    async preAdd(data:Purchase):Promise<Purchase>{
        let party=await this.partyservice.retrieveById(data.party_id);
        if(data.sub_book_id){
            let subBook=await this.subbookservice.retrieveById(data.sub_book_id);
            if(subBook.gst_no && party.gst_no){
               if(subBook.gst_no.substr(0,2) != party.gst_no.substr(0,2)){
                   data.is_igst=true;
               }
            }
            let partyState=party.address.find(e=>e.type=="Billing" && e.is_primary==true);
            if(subBook.state && partyState){
                if(String(subBook.state) != String(partyState)){
                    data.is_igst=true;
                }
             }
        }
        return data;
    }
    async preEdit(data:Purchase):Promise<Purchase>{
        let party=await this.partyservice.retrieveById(data.party_id);
        if(data.sub_book_id){
            let subBook=await this.subbookservice.retrieveById(data.sub_book_id);
            if(subBook.gst_no && party.gst_no){
               if(subBook.gst_no.substr(0,2) != party.gst_no.substr(0,2)){
                   data.is_igst=true;
               }
            }
            let partyState=party.address.find(e=>e.type=="Billing" && e.is_primary==true);
            if(subBook.state && partyState){
                if(String(subBook.state) != String(partyState)){
                    data.is_igst=true;
                }
             }
        }
        return data;
    }
    async totalPurchase(
        party_id: string,
        date: Date,
        id?: string
      ): Promise<number> {
        let financial_year=financialYearService(date);
        let party = await this.partyservice.retrieveById(party_id);
        let amount = 0;
        let dateRange = financialYearReverse(financial_year);
        if (party.transaction_amount && dateRange.min <= party.opening_balance_date && dateRange.max >= party.opening_balance_date) amount = Number(party.transaction_amount);
    
        
    
        let filter: any = {
          party_id: Types.ObjectId(party_id),
          financial_year: financial_year,
        };
        if (id) filter._id = { $lt: Types.ObjectId(id) };
        
        let data: any = await this.model.aggregate([
          {
            $match: filter,
          },
          {
            $group: { _id: null, sum: { $sum: "$invoice_amount" } },
          },
          {
            $project: { _id: 0, sum: 1 },
          },
        ]);
        amount += data[0]?.sum ?? 0;
        return amount;
      }
}