import LogService from "../logging";


export interface ValidateResponse{
   success:boolean;
   message?:string;
}
export interface ValidateAdd{
    (input:any):Promise<ValidateResponse>
}
export interface ValidateEdit{
    (input:any,_id:string):Promise<ValidateResponse>
}
export interface ValidateDelete{
    (_id:string):Promise<ValidateResponse>
}
export abstract class CRUD<T>{
    abstract model:any;
    abstract validateAdd:ValidateAdd;
    abstract validateEdit:ValidateEdit;
    abstract validateDelete:ValidateDelete;
    private logservice=new LogService();
    constructor(){
        
    }
    async list(filter={}):Promise<T[]>{
        try {
            let result = await this.model.find(filter) as T[];
            return result;
        } catch (error:any) {
           throw new Error(error);
        }

    }
    async add(data:T){
        try {        
            let check =await this.validateAdd(data);
            if(check.success!==true) throw new Error(check.message);
            let fData=await this.preAdd(data);
            let result = await this.model.create(fData);
            await this.callBackAdd(result);
           
            await this.logservice.appendLog(this.model.modelName,result,"Add");
            return {success:true,data:result,message:'Successfully Saved'};
        } catch (error:any) {
           throw error;
        }
    }
    async update(data:T,filter:any){
        try {           
            if(this.validateEdit) {
                let check =await this.validateEdit(data,filter);
                if(check.success!==true) throw new Error(check.message);
            }
            let fData=await this.preEdit(data);
            await this.model.updateOne(filter,fData);
            let result = await this.retrieve(filter);
            await this.callBackEdit(result);
            await this.logservice.appendLog(this.model.modelName,result,"Update");
            return {success:true,data:result,message:'Successfully Updated'};
        } catch (error:any) {
           throw new Error(error);
        }
    }
    async delete(filter:any){
        try {
            if(this.validateDelete) {
                let check =await this.validateDelete(filter);
                if(check.success!==true) throw new Error(check.message);
            }
            let result = await this.model.findOneAndDelete(filter);
            await this.callBackDelete(result);
            await this.logservice.appendLog(this.model.modelName,result,"Delete");
            return {success:true,data:result,message:'Successfully Deleted'};
        } catch (error:any) {
           throw new Error(error);
        }
    }
    async updateById(data:T,id:string){
        try {
            if(this.validateEdit) {
                let check =await this.validateEdit(data,id);
                if(check.success!==true) throw new Error(check.message);
            }
            await this.model.updateOne({_id:id},data);
            let result = await this.retrieveById(id);
            await this.callBackEdit(result);
            await this.logservice.appendLog(this.model.modelName,result,"Update");
            return {success:true,data:result,message:'Successfully Updated'};
        } catch (error:any) {
           throw new Error(error);
        }
    }
    async deleteById(id:string){
        try {
            if(this.validateDelete) {
                let check =await this.validateDelete(id);
                if(check.success!==true) throw new Error(check.message);
            }
            let result = await this.model.findByIdAndDelete(id);
            await this.callBackDelete(result);
            await this.logservice.appendLog(this.model.modelName,result,"Delete");
            return {success:true,data:result,message:'Successfully Deleted'};
        } catch (error:any) {
           throw new Error(error);
        }
    }
    async retrieve(filter?:any){
        try {
            let result = await this.model.findOne(filter) as T;
            let res=await this.callBackRetrieve(result);
            return res;
        } catch (error:any) {
           throw new Error(error);
        }
    }
    async retrieveById(id:string){
        try {
            let result = await this.model.findById(id) as T;
            let res=await this.callBackRetrieve(result);
            return res;
        } catch (error:any) {
           throw new Error(error);
        }
    }

    async preAdd(data:any):Promise<T>{
        return data;
    }
    async preEdit(data:any):Promise<T>{
        return data;
    }
    async preDelete(data:any):Promise<T>{
        return data;
    }
    async callBackEdit(data:T){

    }
    async callBackAdd(data:T){
        
    }
    async callBackDelete(data:T){

    }
    async callBackRetrieve(data:T){
        return data;
    }
}