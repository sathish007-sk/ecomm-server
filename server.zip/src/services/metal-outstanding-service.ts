import { Types } from 'mongoose';
import stockModel from '../models/stock-model';
import LedgerService from './ledger-service';
import PartyService from './party-service';
import VoucherService from './voucher-service';
export default class MetalOutstandingService {
  model = stockModel;
  ledgerservice = new LedgerService();
  voucherservice = new VoucherService();
  partyservice = new PartyService();
  constructor() {}
  async outStanding(
    party_id?: string,
    date: Date = new Date()
  ) {
    try {
      let filterParty: any = {};

      let filter: any = {
        module: { $in: ["Metal Transfer", "Metal Return"] },
        date: { $lt: date },
      };
      if (party_id) {
        filter.party_id = Types.ObjectId(party_id);
        filterParty._id = Types.ObjectId(party_id);
      }

      let party = await this.partyservice.list(filterParty);
      let data: any = await this.model.aggregate([
        {
          $match: filter,
        },
        { $unwind: "$item_details" },
        {
          $project: {
            party_name: 1,
            ref_no: 1,
            date: 1,
            module: 1,
            party_id: 1,
            product: "$item_details.product",
            quantity: "$item_details.quantity",
            gross_weight: "$item_details.gross_weight",
            touch: "$item_details.touch",
            touch_difference: "$item_details.touch_difference",
            net_weight: "$item_details.net_weight",
            rate: "$item_details.rate",
            total: "$item_details.total",
            status: "$item_details.status",
            description: "$item_details.description",
            date_time: 1,
          },
        },
        {
          $group: {
            _id: "$party_id",
            in: {
              $sum: {
                $cond: [{ $eq: ["$status", "in"] }, "$net_weight", 0],
              },
            },
            out: {
              $sum: {
                $cond: [{ $eq: ["$status", "out"] }, "$net_weight", 0],
              },
            },
          },
        },
        {
          $project: {
            _id: 1,
            outstanding: {
              $subtract: ["$out", "$in"],
            },
          },
        },
      ]);
      let result = party.map((e) => {
        let opb = data.find((el: any) => String(el._id) === String(e._id));

        let opbDate = new Date(e.opening_balance_date);
        opbDate.setHours(0, 0, 0, 0);
        let opn_bal: number = 0;
        if (date > opbDate) {
          opn_bal += e.metal_balance;
        }
        if (opb) {
          opn_bal += opb?.outstanding;
        }
        return {
          _id: e._id,
          outstanding: opn_bal,
          date: e.opening_balance_date
        };
      });
      return result;
    } catch (error: any) {
      throw new Error(error);
    }
  }
  async getOutStandingList(party_id: string, date: Date) {
    try {
      let fromDate = new Date(date);
      fromDate.setHours(0, 0, 0, 0);
      let toDate = new Date(fromDate);
      toDate.setDate(toDate.getDate() + 1);
      let filter: any = {
        module: { $in: ["Metal Transfer", "Metal Return"] },
        party_id: Types.ObjectId(party_id),
        date: { $gte: fromDate, $lt: toDate },
      };
      let result = await this.model.find(filter);
      let data: any[] = [];
      let obDate = new Date(fromDate);
      obDate.setDate(obDate.getDate() - 1);
      let outstanding = await this.outStanding(party_id, obDate);

      if (outstanding.length) {
        data.push({
          date: obDate,
          module: "Opening Balance",
          net_weight:
            outstanding[0].outstanding > 0
              ? 0 - outstanding[0].outstanding
              : Math.abs(outstanding[0].outstanding),
        });
      }

      result.forEach((ele: any) => {
        ele.item_details.forEach((e: any) => {
          let module = e.module;
          if (e.is_discount == true) {
            module += " (Discount)";
          }

          data.push({
            date: ele.date,
            ref_no: ele.ref_no,
            module: module,
            gross_weight: e.gross_weight,
            touch: e.touch,
            touch_difference: e.touch_difference,
            net_weight: e.status == "out" ? e.net_weight : 0 - e.net_weight,
          });
        });
      });
      return data;
    } catch (error: any) {
      throw new Error(error);
    }
  }
}