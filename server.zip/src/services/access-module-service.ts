import accessModule, { AccessModule } from "../models/access-module-model";
import {
  CRUD,
  ValidateAdd,
  ValidateDelete,
  ValidateEdit,
  ValidateResponse,
} from "./crud-service";

export default class AccessModuleService extends CRUD<AccessModule> {
  public model = accessModule;
  constructor() {
    super();
  }

  init = async () => {
    let ck = await this.model.countDocuments();
    if (ck == 0) {
      await this.model.insertMany([
        {
          status: true,
          _id: "613e10dc1fbcc20ca8cb4292",
          module_name: "Master",
          parent: null,
          __v: 0,
          icon: "setting",
          updatedAt: "2021-09-28T06:35:16.716Z",
        },
        {
          status: true,
          _id: "613e10e21fbcc20ca8cb4296",
          module_name: "Process",
          parent: null,
          __v: 0,
          icon: "project",
          updatedAt: "2021-09-28T06:36:23.945Z",
        },
        {
          status: true,
          _id: "613e10ea1fbcc20ca8cb429a",
          module_name: "Accounts",
          parent: null,
          __v: 0,
          icon: "idcard",
          updatedAt: "2021-09-28T06:37:34.103Z",
        },
        {
          status: true,
          _id: "613e10f21fbcc20ca8cb429e",
          module_name: "Report",
          parent: null,
          __v: 0,
          icon: "pie-chart",
          updatedAt: "2021-09-28T06:34:41.972Z",
        },
        {
          status: false,
          _id: "613e11001fbcc20ca8cb42a3",
          module_name: "Access",
          parent: null,
          __v: 0,
          icon: "security-scan",
          updatedAt: "2021-09-28T14:08:41.292Z",
        },
        {
          status: true,
          _id: "613f4f33342df65d4d497f14",
          module_name: "Voucher",
          icon: "",
          parent: {
            status: true,
            _id: "613e10ea1fbcc20ca8cb429a",
            module_name: "Accounts",
            parent: null,
            __v: 0,
            icon: "idcard",
            updatedAt: "2021-09-28T06:37:34.103Z",
          },
          createdAt: "2021-09-13T13:16:35.080Z",
          updatedAt: "2021-09-13T13:16:35.080Z",
          __v: 0,
        },
        {
          status: true,
          _id: "615ac0426d42c45c1af8f61a",
          module_name: "Location",
          icon: "",
          parent: {
            status: true,
            _id: "613e10dc1fbcc20ca8cb4292",
            module_name: "Master",
            parent: null,
            __v: 0,
            icon: "setting",
            updatedAt: "2021-09-28T06:35:16.716Z",
          },
          createdAt: "2021-10-04T08:50:10.263Z",
          updatedAt: "2021-10-04T08:50:10.263Z",
          __v: 0,
        },
        {
          status: true,
          _id: "615ac1ff6d42c45c1af8f806",
          module_name: "Product",
          icon: "",
          parent: {
            status: true,
            _id: "613e10dc1fbcc20ca8cb4292",
            module_name: "Master",
            parent: null,
            __v: 0,
            icon: "setting",
            updatedAt: "2021-09-28T06:35:16.716Z",
          },
          createdAt: "2021-10-04T08:57:35.227Z",
          updatedAt: "2021-10-04T08:57:35.227Z",
          __v: 0,
        },
        {
          status: true,
          _id: "615ac20d6d42c45c1af8f81e",
          module_name: "Tax",
          icon: "",
          parent: {
            status: true,
            _id: "613e10dc1fbcc20ca8cb4292",
            module_name: "Master",
            parent: null,
            __v: 0,
            icon: "setting",
            updatedAt: "2021-09-28T06:35:16.716Z",
          },
          createdAt: "2021-10-04T08:57:49.568Z",
          updatedAt: "2021-10-04T08:57:49.568Z",
          __v: 0,
        },
      ]);
    }
  };

  async list(filter = {}) {
    try {
      let result = (await this.model.find(filter).populate("parent")) as any[];
      return result;
    } catch (error: any) {
      throw new Error(error);
    }
  }
  validateAdd: ValidateAdd = async (
    data: AccessModule
  ): Promise<ValidateResponse> => {
    return { success: true };
  };
  validateEdit: ValidateEdit = async (
    data: AccessModule,
    id: string
  ): Promise<ValidateResponse> => {
    return { success: true };
  };
  validateDelete: ValidateDelete = async (
    id: string
  ): Promise<ValidateResponse> => {
    return { success: true };
  };
  grouping(parent: string | null | undefined, data: any[]): any {
    let res = data.filter(
      (e: AccessModule) => String(e.parent) === String(parent)
    );
    return res.map((e) => {
      let obj = e;
      let children = this.grouping(e._id, data);
      if (children.length > 0) obj.children = children;
      return obj;
    });
  }
  async getModule() {
    let moduleList: AccessModule[] = await this.list({ status: true });
    let data = moduleList.map((e) => {
      let parent: any = e.parent;
      return {
        _id: e._id,
        menu_name: e.module_name,
        parent: parent ? parent?._id : null,
        icon: e.icon,
      };
    });
    return this.grouping(null, data);
  }
}
