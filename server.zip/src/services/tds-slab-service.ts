
import tdsSlabModel, { TdsSlab } from '../models/tds-slab-model';
import { CRUD, ValidateAdd, ValidateDelete, ValidateEdit, ValidateResponse } from './crud-service';
export default class TdsSlabService extends CRUD<TdsSlab>{
    public model=tdsSlabModel;
    constructor(){
       super();
    }

    async getSlab():Promise<TdsSlab[]>{
       let data=await this.model.find({status:true}).sort({min_amount:1}); 
       return data;
    }
    validateAdd: ValidateAdd=async(data:TdsSlab):Promise<ValidateResponse>=>{
        try {
            // let check=await this.model.findOne({ book_id:data.book_id,min_amount: { $lte: data.min_amount,$gte:data.min_amount},max_amount:{}});
            // if(check)return {success:false, message:"Already Exists"};
            return {success:true};
        } catch (error:any) {
            throw new Error(error);
        }       
    }
    validateEdit: ValidateEdit=async(data:TdsSlab,id:string):Promise<ValidateResponse>=>{
        try {
            
            return {success:true};
        } catch (error:any) {
            throw new Error(error);
        }       
    }
    validateDelete: ValidateDelete=async(id:string):Promise<ValidateResponse>=>{
        return {success:true};
    }
    
}