import jwt,{ verify } from 'jsonwebtoken';

export const user =(headers:any)=>{  
    if(headers.authorization){
        let privateKey: any = process.env.KEY;
        let token:any = jwt.verify(headers.authorization, privateKey);
        return token?.user_id;
    }
    return null;
    
}
export const book =(headers:any)=>{
        let privateKey: any = process.env.KEY;
        let token:any = jwt.verify(headers.authorization, privateKey);
    return token.book_id;
}
export const sub_book =(headers:any)=>{
    let privateKey: any = process.env.KEY;
    let token:any = verify(headers.authorization, privateKey);
    return token.sub_book_id;
}