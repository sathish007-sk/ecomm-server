import { Country, countryModel } from '../models/location-model';
import { CRUD, ValidateAdd, ValidateDelete, ValidateEdit, ValidateResponse } from './crud-service';

export default class CountryService extends CRUD<Country>{
    public model=countryModel;
    
    constructor(){
        super();      
    }
    validateAdd: ValidateAdd=async(data:Country):Promise<ValidateResponse>=>{
        try {
            let check=await this.model.findOne({name: { $regex: new RegExp("^" + data.name.toLowerCase()+"$", "i")}});
            if(check)return {success:false, message:"Already Exists"};
            return {success:true};
        } catch (error:any) {
            throw new Error(error);
        }       
    }
    validateEdit: ValidateEdit=async(data:Country,id:string):Promise<ValidateResponse>=>{
        try {
            let check=await this.model.findOne({name: { $regex: new RegExp("^" + data.name.toLowerCase()+"$", "i")},_id:{$ne:id}});
            if(check)return {success:false, message:"Already Exists"};
            return {success:true};
        } catch (error:any) {
            throw new Error(error);
        }      
    }
    validateDelete: ValidateDelete=async(id:string):Promise<ValidateResponse>=>{
        return {success:true};
    }
}