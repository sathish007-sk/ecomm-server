import { Voucher } from "../models/accounts-model";
import dashboardCalculationModel, { DashboardCalculation } from "../models/dashboard-calculation-model";
import { CRUD, ValidateAdd, ValidateDelete, ValidateEdit, ValidateResponse } from "./crud-service";

export default class DashboardCalculationService extends CRUD<DashboardCalculation>{
    model=dashboardCalculationModel;
    constructor() {
        super();
    }
    validateAdd: ValidateAdd = async (data: DashboardCalculation): Promise<ValidateResponse> => {
        return { success: true }
    }
    validateEdit: ValidateEdit = async (data: DashboardCalculation, _id: string): Promise<ValidateResponse> => {
        return { success: true }
    }
    validateDelete: ValidateDelete = async (_id: string): Promise<ValidateResponse> => {
        return { success: true }
    }
}
