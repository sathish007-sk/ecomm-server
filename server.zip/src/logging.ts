import fs, { readdirSync, readFileSync } from "fs";
import path from "path";
import userModel from "./models/user-model";

export default class LogService {
  dataLogDir!: string;
  constructor() {
    try {
      this.dataLogDir = path.join(`${__dirname}/../`, "data-log");
      if (!fs.existsSync(this.dataLogDir)) {
        fs.mkdirSync(this.dataLogDir);
      }
    } catch (error) {
      console.log(error);
    }
  }
  appendLog = async (
    collection: string,
    data: any,
    mode: "Add" | "Update" | "Delete",
    done_by?: string
  ) => {
    try {
      let done_by_name: string = "";
      if (done_by) {
        let user = await userModel.findById(done_by);
        done_by_name = user.code;
      }
      // let dir=path.join(this.dataLogDir,collection);
      // if (!fs.existsSync(dir)){
      //     fs.mkdirSync(dir);
      // }
      let obj = {
        at: new Date(),
        done_by_id: done_by,
        done_by_code: done_by_name,
        data: data,
        mode: mode,
      };

      let fileName = path.join(this.dataLogDir, `${collection}.json`);
      let json = [];
      if (fs.existsSync(fileName)) {
        let fileData = fs.readFileSync(fileName);
        json = JSON.parse(fileData.toString());
      }
      json.push(obj);
      fs.writeFileSync(fileName, JSON.stringify(json));
    } catch (error: any) {
      console.log(error);
    }
  };
  listFile() {
    try {
      let files = readdirSync(this.dataLogDir);
      return files;
    } catch (error: any) {
      new Error(error.message);
    }
  }
  readFile(fileName: string) {
    try {
      let data=readFileSync(path.join(this.dataLogDir, fileName));
      let obj=JSON.parse(String(data))
      let str=obj.map((e:any)=>{
          return {
              ...e,
              _id:e.data._id
          }
      })
      return str;
    } catch (error: any) {
      new Error(error.message);
    }
  }
}
