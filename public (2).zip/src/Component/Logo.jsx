import React from 'react'

const Logo = () => {
 
  
  return (
    <React.Fragment>
     coming soon..
    </React.Fragment>
  )
}

export default Logo