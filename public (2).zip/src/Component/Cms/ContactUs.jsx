import React, { useState, useEffect, useRef } from "react";
import {
  Button,
  Form,
  Input,
  Select,
  Tabs,
  Space,
  Divider,
  Checkbox,
  Row,
  Col,
  Modal,
  Upload,
  message,
} from "antd";
import styled from "styled-components";
import API from "../../Store/Api/ApiService";
import ReactQuill from "react-quill";
import "react-quill/dist/quill.snow.css";
import { useNavigate } from "react-router-dom";
import { InboxOutlined } from '@ant-design/icons';

import {
  SafetyOutlined,
  ToolOutlined,
  TagOutlined,
  ApartmentOutlined,
  ProfileOutlined,
  SettingOutlined,
  MinusCircleOutlined,
  PlusOutlined,
  HighlightOutlined,
  AccountBookOutlined,
  ArrowLeftOutlined,
} from "@ant-design/icons";
const { Dragger } = Upload;
const { TextArea } = Input;
const { Option } = Select;

const ContactUs = () => {
const[value,setValue]=useState('')
 const navigate=useNavigate()

  return (
    <React.Fragment>
      <ContactUsSection>
        <div className="page_back_align">
          <p onClick={() => navigate(-1)} className="go_back">
            <ArrowLeftOutlined /> &nbsp; ContactUs
          </p>
        </div>
        <Form
          layout="vertical"
          size="medium"
          name="add_new_product"
         
         
        >
             <BgWight>


             <Dragger >
    <p className="ant-upload-drag-icon">
      <InboxOutlined />
    </p>
    <p className="ant-upload-text">Click or drag file to this area to upload</p>
    <p className="ant-upload-hint">
      Support for a single or bulk upload. Strictly prohibit from uploading company data or other
      band files
    </p>
  </Dragger>
               
                <Form.Item
                  label="Product Description"
                  tooltip="Product Description"
                >
                  <ReactQuill
                    theme="snow"
                    value={value}
                    onChange={setValue}
                    className="pro_dec"
                  />
                </Form.Item>
              </BgWight>
         
        </Form>
      </ContactUsSection>
    </React.Fragment>
  );
};

export default ContactUs;

const ContactUsSection = styled.section`
  .ant-form-vertical .ant-form-item-label > label {
    color: #2e2e2e;
    font-family: "q_medium";
  }
`;

const Dimension2 = styled.div`
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 0 24px;
  align-items: flex-end;

  @media screen and (max-width: 580px) {
    grid-template-columns: repeat(1, 1fr);
  }
`;

const CatsNew = styled.div`
  width: 100%;
  margin: 20px 0 0 0;
`;

const Thumbnail = styled.div`
  .ant-upload-wrapper.ant-upload-picture-card-wrapper
    .ant-upload.ant-upload-select {
    height: 80px;
    width: 80px;
  }
`;

const H4 = styled.div`
  font-size: 18px;
  font-family: "q_bold";
  margin: 0 0 20px;
`;
const CatsBox = styled.div`
  height: 215px;
  overflow: auto;
  border: 1px solid #d9d9d9;
  padding: 20px;
  border-radius: 4px;
  .ant-col-24 {
    margin: 0 0 10px;
  }
`;

const PublishRow = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 15px;
`;
const Text = styled.div``;

const NewProductSection = styled.div`
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  flex-wrap: wrap;

  .pro_dec {
    margin: 0 0 0px;
  }

  .ql-toolbar.ql-snow {
    border-radius: 6px 6px 0 0;
  }
  .ql-container.ql-snow {
    border-radius: 0 0 6px 6px;
    height: 150px;
  }

  .ant-tabs-left
    > .ant-tabs-content-holder
    > .ant-tabs-content
    > .ant-tabs-tabpane,
  .ant-tabs-left
    > div
    > .ant-tabs-content-holder
    > .ant-tabs-content
    > .ant-tabs-tabpane {
    padding: 24px;
  }

  .ant-form-item.flex_row .ant-row.ant-form-item-row {
    display: flex !important;
    flex-direction: row !important;
  }
  .ant-form-item.flex_row
    .ant-row.ant-form-item-row
    .ant-col-24.ant-form-item-label,
  .ant-col-xl-24.ant-form-item-label,
  .ant-form-vertical .ant-form-item-label {
    flex: 1 !important;
  }
  .ant-form-item.flex_row
    .ant-row.ant-form-item-row
    .ant-form-vertical
    .ant-form-item
    .ant-form-item-control {
    width: 100% !important;
    flex: 3 !important;
  }
  /* width */
  .catboxs::-webkit-scrollbar {
    width: 5px;
  }

  /* Track */
  .catboxs::-webkit-scrollbar-track {
    background: #f1f1f1;
  }

  /* Handle */
  .catboxs::-webkit-scrollbar-thumb {
    background: #888;
    border-radius: 5px;
  }

  /* Handle on hover */
  .catboxs::-webkit-scrollbar-thumb:hover {
    background: #555;
  }
`;
const MyAccountAlign = styled.div`
  width: 100%;
  display: inline-block;
  position: relative;
  margin: 10px 0 0 0;
  border: 1px solid #d9d9d97a;
  .ant-tabs.ant-tabs-left {
    padding: 0px 0;
  }
  .ant-tabs-content-holder {
    padding: 20px 0;
  }
  .ant-tabs-tab {
    padding: 4px 20px !important;
    font-size: 14px;

    width: 180px;
    color: #000;
  }
  .ant-tabs > .ant-tabs-nav .ant-tabs-nav-list,
  .ant-tabs > div > .ant-tabs-nav .ant-tabs-nav-list {
    padding: 15px 0;
  }
  .ant-tabs-tab.ant-tabs-tab-active .ant-tabs-tab-btn {
    color: rgb(13 110 253);
    font-weight: 400;
    font-size: 14px;
  }
  .ant-tabs-tab-btn,
  .ant-tabs-tab-btn,
  .ant-tabs-tab-remove,
  .ant-tabs-tab-remove {
    font-family: "q_bold";
    font-size: 14px;
  }
  .ant-tabs-ink-bar {
    background: rgb(13 110 253);
  }

  @media screen and (max-width: 768px) {
    .ant-tabs-content-holder {
      padding: 20px 15px;
    }
  }
`;
const NewProductLeft = styled.div`
  width: 72%;
  display: flex;
  flex-direction: column;
  gap: 30px;
  position: relative;
  /* padding: 24px; */
  /* box-shadow: 2px 4px 20px 1px rgb(201 201 201 / 30%);
  background: #fff; */
  min-height: 550px;

  @media screen and (max-width: 992px) {
    width: 100%;
  }

  @media screen and (max-width: 768px) {
    .ant-tabs > .ant-tabs-nav .ant-tabs-nav-list,
    .caKiHo .ant-tabs > div > .ant-tabs-nav .ant-tabs-nav-list {
      padding: 9px 0;
    }
  }
`;

const BgWight = styled.div`
  padding: 24px;
  box-shadow: 2px 4px 20px 1px rgb(201 201 201 / 30%);
  background: #fff;
  display: inline-block;
  width: 100%;
  border-radius: 5px;
`;
const NewProductRight = styled.div`
  width: 25%;
  display: inline-block;
  position: relative;
  padding: 24px;
  box-shadow: 2px 4px 20px 1px rgb(201 201 201 / 30%);
  background: #fff;
  min-height: 550px;
  border-radius: 8px;
  .ant-upload.ant-upload-select-picture-card,
  .ant-upload-list-picture-card-container {
    width: 85px !important;
    height: 85px !important;
  }

  @media screen and (max-width: 992px) {
    width: 100%;
    margin: 30px 0 0 0;
  }
`;
