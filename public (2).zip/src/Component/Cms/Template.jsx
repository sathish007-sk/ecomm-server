import React, { useState, useEffect, useRef } from "react";
import {
  Button,
  Form,
  Input,
  Select,
  Tabs,
  Space,
  Divider,
  Checkbox,
  Popconfirm,
  Row,
  Col,
  Modal,
  Upload,
  message,
} from "antd";
import { Image } from 'antd';
import editicon from "../../Assets/Images/edit.png";
import deleteicion from "../../Assets/Images/delete.png";
import styled from "styled-components";
import API from "../../Store/Api/ApiService";
import ReactQuill from "react-quill";
import "react-quill/dist/quill.snow.css";
import { useNavigate } from "react-router-dom";
import { InboxOutlined } from '@ant-design/icons';

import {
  SafetyOutlined,
  ToolOutlined,
  TagOutlined,
  ApartmentOutlined,
  ProfileOutlined,
  SettingOutlined,
  MinusCircleOutlined,
  PlusOutlined,
  HighlightOutlined,
  AccountBookOutlined,
  ArrowLeftOutlined,
} from "@ant-design/icons";
const { Dragger } = Upload;
const { TextArea } = Input;
const { Option } = Select;

const Template = () => {
const[value,setValue]=useState('')
 const navigate=useNavigate()

  return (
    <React.Fragment>
      <TemplateSection>
        <div className="page_back_align">
          <p onClick={() => navigate(-1)} className="go_back">
            <ArrowLeftOutlined /> &nbsp; Template
          </p>
        </div>
       
             <BgWight>

             <Divider orientation="left">Responsive</Divider>
    <Row  gutter={[0,30]}>
      <Col  className="gutter-row"    xs={{ span: 24 }}  md={{span:12}}lg={{ span: 12}} xl={{span:12}}>
      <Image
    width={200}
    height={200}
    src="error"
    fallback="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMIAAADDCAYAAADQvc6UAAABRWlDQ1BJQ0MgUHJvZmlsZQAAKJFjYGASSSwoyGFhYGDIzSspCnJ3UoiIjFJgf8LAwSDCIMogwMCcmFxc4BgQ4ANUwgCjUcG3awyMIPqyLsis7PPOq3QdDFcvjV3jOD1boQVTPQrgSkktTgbSf4A4LbmgqISBgTEFyFYuLykAsTuAbJEioKOA7DkgdjqEvQHEToKwj4DVhAQ5A9k3gGyB5IxEoBmML4BsnSQk8XQkNtReEOBxcfXxUQg1Mjc0dyHgXNJBSWpFCYh2zi+oLMpMzyhRcASGUqqCZ16yno6CkYGRAQMDKMwhqj/fAIcloxgHQqxAjIHBEugw5sUIsSQpBobtQPdLciLEVJYzMPBHMDBsayhILEqEO4DxG0txmrERhM29nYGBddr//5/DGRjYNRkY/l7////39v///y4Dmn+LgeHANwDrkl1AuO+pmgAAADhlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAAqACAAQAAAABAAAAwqADAAQAAAABAAAAwwAAAAD9b/HnAAAHlklEQVR4Ae3dP3PTWBSGcbGzM6GCKqlIBRV0dHRJFarQ0eUT8LH4BnRU0NHR0UEFVdIlFRV7TzRksomPY8uykTk/zewQfKw/9znv4yvJynLv4uLiV2dBoDiBf4qP3/ARuCRABEFAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghggQAQZQKAnYEaQBAQaASKIAQJEkAEEegJmBElAoBEgghgg0Aj8i0JO4OzsrPv69Wv+hi2qPHr0qNvf39+iI97soRIh4f3z58/u7du3SXX7Xt7Z2enevHmzfQe+oSN2apSAPj09TSrb+XKI/f379+08+A0cNRE2ANkupk+ACNPvkSPcAAEibACyXUyfABGm3yNHuAECRNgAZLuYPgEirKlHu7u7XdyytGwHAd8jjNyng4OD7vnz51dbPT8/7z58+NB9+/bt6jU/TI+AGWHEnrx48eJ/EsSmHzx40L18+fLyzxF3ZVMjEyDCiEDjMYZZS5wiPXnyZFbJaxMhQIQRGzHvWR7XCyOCXsOmiDAi1HmPMMQjDpbpEiDCiL358eNHurW/5SnWdIBbXiDCiA38/Pnzrce2YyZ4//59F3ePLNMl4PbpiL2J0L979+7yDtHDhw8vtzzvdGnEXdvUigSIsCLAWavHp/+qM0BcXMd/q25n1vF57TYBp0a3mUzilePj4+7k5KSLb6gt6ydAhPUzXnoPR0dHl79WGTNCfBnn1uvSCJdegQhLI1vvCk+fPu2ePXt2tZOYEV6/fn31dz+shwAR1sP1cqvLntbEN9MxA9xcYjsxS1jWR4AIa2Ibzx0tc44fYX/16lV6NDFLXH+YL32jwiACRBiEbf5KcXoTIsQSpzXx4N28Ja4BQoK7rgXiydbHjx/P25TaQAJEGAguWy0+2Q8PD6/Ki4R8EVl+bzBOnZY95fq9rj9zAkTI2SxdidBHqG9+skdw43borCXO/ZcJdraPWdv22uIEiLA4q7nvvCug8WTqzQveOH26fodo7g6uFe/a17W3+nFBAkRYENRdb1vkkz1CH9cPsVy/jrhr27PqMYvENYNlHAIesRiBYwRy0V+8iXP8+/fvX11Mr7L7ECueb/r48eMqm7FuI2BGWDEG8cm+7G3NEOfmdcTQw4h9/55lhm7DekRYKQPZF2ArbXTAyu4kDYB2YxUzwg0gi/41ztHnfQG26HbGel/crVrm7tNY+/1btkOEAZ2M05r4FB7r9GbAIdxaZYrHdOsgJ/wCEQY0J74TmOKnbxxT9n3FgGGWWsVdowHtjt9Nnvf7yQM2aZU/TIAIAxrw6dOnAWtZZcoEnBpNuTuObWMEiLAx1HY0ZQJEmHJ3HNvGCBBhY6jtaMoEiJB0Z29vL6ls58vxPcO8/zfrdo5qvKO+d3Fx8Wu8zf1dW4p/cPzLly/dtv9Ts/EbcvGAHhHyfBIhZ6NSiIBTo0LNNtScABFyNiqFCBChULMNNSdAhJyNSiECRCjUbEPNCRAhZ6NSiAARCjXbUHMCRMjZqBQiQIRCzTbUnAARcjYqhQgQoVCzDTUnQIScjUohAkQo1GxDzQkQIWejUogAEQo121BzAkTI2agUIkCEQs021JwAEXI2KoUIEKFQsw01J0CEnI1KIQJEKNRsQ80JECFno1KIABEKNdtQcwJEyNmoFCJAhELNNtScABFyNiqFCBChULMNNSdAhJyNSiECRCjUbEPNCRAhZ6NSiAARCjXbUHMCRMjZqBQiQIRCzTbUnAARcjYqhQgQoVCzDTUnQIScjUohAkQo1GxDzQkQIWejUogAEQo121BzAkTI2agUIkCEQs021JwAEXI2KoUIEKFQsw01J0CEnI1KIQJEKNRsQ80JECFno1KIABEKNdtQcwJEyNmoFCJAhELNNtScABFyNiqFCBChULMNNSdAhJyNSiECRCjUbEPNCRAhZ6NSiAARCjXbUHMCRMjZqBQiQIRCzTbUnAARcjYqhQgQoVCzDTUnQIScjUohAkQo1GxDzQkQIWejUogAEQo121BzAkTI2agUIkCEQs021JwAEXI2KoUIEKFQsw01J0CEnI1KIQJEKNRsQ80JECFno1KIABEKNdtQcwJEyNmoFCJAhELNNtScABFyNiqFCBChULMNNSdAhJyNSiEC/wGgKKC4YMA4TAAAAABJRU5ErkJggg=="
  />
      </Col>
      <Col  className="gutter-row"  xs={{ span: 24 }}  md={{span:8}}lg={{ span: 8}} xl={{span:8}}>
        <div  style={{display: "flex", alignItems:'center', justifyContent:'center', height:'100%' , width:'100%'}}>test</div>
      </Col>
      <Col  className="gutter-row"    xs={{ span: 24 }}  md={{span:2}}lg={{ span: 2}} xl={{span:2}}>
      <div style={{ display: "flex", alignItems:'center', justifyContent:'center' ,height:'100%' , width:'100%'}}>
          <p className='action_btn edit' >
            <img src={editicon} alt="Edit" className='action_icon' />
          </p>
          <Popconfirm
            title=" Are you Sure to delete?"
            
         
          >
            <p className='action_btn delete'>
              <img src={deleteicion} alt="Edit" className='action_icon' />
            </p>
          </Popconfirm>
        </div>
      </Col>
     
      
      
    </Row> 
             
               
                
              </BgWight>
         
      
      </TemplateSection>

     
    </React.Fragment>
  );
};

export default Template;

const TemplateSection = styled.section`
  .ant-form-vertical .ant-form-item-label > label {
    color: #2e2e2e;
    font-family: "q_medium";
  }
`;

const Dimension2 = styled.div`
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 0 24px;
  align-items: flex-end;

  @media screen and (max-width: 580px) {
    grid-template-columns: repeat(1, 1fr);
  }
`;

const CatsNew = styled.div`
  width: 100%;
  margin: 20px 0 0 0;
`;

const Thumbnail = styled.div`
  .ant-upload-wrapper.ant-upload-picture-card-wrapper
    .ant-upload.ant-upload-select {
    height: 80px;
    width: 80px;
  }
`;

const H4 = styled.div`
  font-size: 18px;
  font-family: "q_bold";
  margin: 0 0 20px;
`;
const CatsBox = styled.div`
  height: 215px;
  overflow: auto;
  border: 1px solid #d9d9d9;
  padding: 20px;
  border-radius: 4px;
  .ant-col-24 {
    margin: 0 0 10px;
  }
`;

const PublishRow = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 15px;
`;
const Text = styled.div``;

const NewProductSection = styled.div`
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  flex-wrap: wrap;

  .pro_dec {
    margin: 0 0 0px;
  }

  .ql-toolbar.ql-snow {
    border-radius: 6px 6px 0 0;
  }
  .ql-container.ql-snow {
    border-radius: 0 0 6px 6px;
    height: 150px;
  }

  .ant-tabs-left
    > .ant-tabs-content-holder
    > .ant-tabs-content
    > .ant-tabs-tabpane,
  .ant-tabs-left
    > div
    > .ant-tabs-content-holder
    > .ant-tabs-content
    > .ant-tabs-tabpane {
    padding: 24px;
  }

  .ant-form-item.flex_row .ant-row.ant-form-item-row {
    display: flex !important;
    flex-direction: row !important;
  }
  .ant-form-item.flex_row
    .ant-row.ant-form-item-row
    .ant-col-24.ant-form-item-label,
  .ant-col-xl-24.ant-form-item-label,
  .ant-form-vertical .ant-form-item-label {
    flex: 1 !important;
  }
  .ant-form-item.flex_row
    .ant-row.ant-form-item-row
    .ant-form-vertical
    .ant-form-item
    .ant-form-item-control {
    width: 100% !important;
    flex: 3 !important;
  }
  /* width */
  .catboxs::-webkit-scrollbar {
    width: 5px;
  }

  /* Track */
  .catboxs::-webkit-scrollbar-track {
    background: #f1f1f1;
  }

  /* Handle */
  .catboxs::-webkit-scrollbar-thumb {
    background: #888;
    border-radius: 5px;
  }

  /* Handle on hover */
  .catboxs::-webkit-scrollbar-thumb:hover {
    background: #555;
  }
`;
const MyAccountAlign = styled.div`
  width: 100%;
  display: inline-block;
  position: relative;
  margin: 10px 0 0 0;
  border: 1px solid #d9d9d97a;
  .ant-tabs.ant-tabs-left {
    padding: 0px 0;
  }
  .ant-tabs-content-holder {
    padding: 20px 0;
  }
  .ant-tabs-tab {
    padding: 4px 20px !important;
    font-size: 14px;

    width: 180px;
    color: #000;
  }
  .ant-tabs > .ant-tabs-nav .ant-tabs-nav-list,
  .ant-tabs > div > .ant-tabs-nav .ant-tabs-nav-list {
    padding: 15px 0;
  }
  .ant-tabs-tab.ant-tabs-tab-active .ant-tabs-tab-btn {
    color: rgb(13 110 253);
    font-weight: 400;
    font-size: 14px;
  }
  .ant-tabs-tab-btn,
  .ant-tabs-tab-btn,
  .ant-tabs-tab-remove,
  .ant-tabs-tab-remove {
    font-family: "q_bold";
    font-size: 14px;
  }
  .ant-tabs-ink-bar {
    background: rgb(13 110 253);
  }

  @media screen and (max-width: 768px) {
    .ant-tabs-content-holder {
      padding: 20px 15px;
    }
  }
`;
const NewProductLeft = styled.div`
  width: 72%;
  display: flex;
  flex-direction: column;
  gap: 30px;
  position: relative;
  /* padding: 24px; */
  /* box-shadow: 2px 4px 20px 1px rgb(201 201 201 / 30%);
  background: #fff; */
  min-height: 550px;

  @media screen and (max-width: 992px) {
    width: 100%;
  }

  @media screen and (max-width: 768px) {
    .ant-tabs > .ant-tabs-nav .ant-tabs-nav-list,
    .caKiHo .ant-tabs > div > .ant-tabs-nav .ant-tabs-nav-list {
      padding: 9px 0;
    }
  }
`;

const BgWight = styled.div`
  padding: 24px;
  box-shadow: 2px 4px 20px 1px rgb(201 201 201 / 30%);
  background: #fff;
  display: inline-block;
  width: 100%;
  border-radius: 5px;
`;
const NewProductRight = styled.div`
  width: 25%;
  display: inline-block;
  position: relative;
  padding: 24px;
  box-shadow: 2px 4px 20px 1px rgb(201 201 201 / 30%);
  background: #fff;
  min-height: 550px;
  border-radius: 8px;
  .ant-upload.ant-upload-select-picture-card,
  .ant-upload-list-picture-card-container {
    width: 85px !important;
    height: 85px !important;
  }

  @media screen and (max-width: 992px) {
    width: 100%;
    margin: 30px 0 0 0;
  }
`;
