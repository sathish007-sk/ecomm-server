import React, { useEffect, useState } from 'react'
import styled from 'styled-components';
import { FormOutlined } from "@ant-design/icons";
import { Button, Modal, Form, Input, Col, Row, message } from 'antd';
import API from '../Store/Api/ApiService';
const PrimaryDetails = () => {
  const [company, setCompany] = useState([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [form] = Form.useForm();
  const api = new API();
  const get_company_details = () => {
    api.companydetails().then((res) => {
      if (res.status === 200 && res.statusText === "OK") {
        setCompany(res.data[0]);
        form.setFieldsValue(res.data)
      }
    }).catch((err) => { })
  }

  useEffect(() => {
    get_company_details();
  }, []);

  const showModal = () => {
    setIsModalOpen(true);
  };
  const handleOk = () => {
    setIsModalOpen(false);
  };
  const handleCancel = () => {
    setIsModalOpen(false);
  };

  const onFinish = (values) => {
    api.primarydetails(values).then((res)=>{
      
      if(res.status===200 && res.statusText==="OK") {
        get_company_details();
        message.success("Successfully Saved");
        form.resetFields();
        setIsModalOpen(false);
      }
    }).catch((err)=>{})
  }


console.log(company)

  return (
    <React.Fragment>
      <PrimaryDetailsSection>
        <div className='primary_section'>
          <div className='edit_option'>
            <Button type='primary' size='small' onClick={showModal}><FormOutlined />Edit</Button>
          </div>
          <Modal
            title="Edit Company Details"
            open={isModalOpen}
            onOk={handleOk}
            onCancel={handleCancel}
            okText="Save"
            footer={null}
            width={750}
          >
            <Form
              name="country_edit"
              layout="vertical"
              onFinish={onFinish}
              form={form}
            >
              <Row gutter={16}>
                <Col className="gutter-row" xxl={{ span: 12 }} xl={{ span: 12 }} lg={{ span: 12 }} md={{ span: 12 }} sm={{ span: 24 }} xs={{ span: 24 }}>
                  <Form.Item
                    label="Company Name"
                    name="company_name"
                    
                  >
                    <Input name="company_name" />
                  </Form.Item>
                </Col>
                <Col className="gutter-row" xxl={{ span: 12 }} xl={{ span: 12 }} lg={{ span: 12 }} md={{ span: 12 }} sm={{ span: 24 }} xs={{ span: 24 }}>
                  <Form.Item
                    label="GST No"
                    name="gst_no"
                    
                  >
                    <Input name="gst_no" />
                  </Form.Item>
                </Col>
                <Col className="gutter-row" xxl={{ span: 12 }} xl={{ span: 12 }} lg={{ span: 12 }} md={{ span: 12 }} sm={{ span: 24 }} xs={{ span: 24 }}>
                  <Form.Item
                    label="Landline No"
                    name="landline_no"
                   
                  >
                    <Input name="landline_no" />
                  </Form.Item>
                </Col>
                <Col className="gutter-row" xxl={{ span: 12 }} xl={{ span: 12 }} lg={{ span: 12 }} md={{ span: 12 }} sm={{ span: 24 }} xs={{ span: 24 }}>
                  <Form.Item
                    label="e-Mail"
                    name="email"
                    
                  >
                    <Input name="email" />
                  </Form.Item>
                </Col>
                <Col className="gutter-row" xxl={{ span: 12 }} xl={{ span: 12 }} lg={{ span: 12 }} md={{ span: 12 }} sm={{ span: 24 }} xs={{ span: 24 }}>
                  <Form.Item
                    label="Mobile No"
                    name="mobile_no"
                  >
                    <Input name="mobile_no" />
                  </Form.Item>
                </Col>
                <Col className="gutter-row" xxl={{ span: 12 }} xl={{ span: 12 }} lg={{ span: 12 }} md={{ span: 12 }} sm={{ span: 24 }} xs={{ span: 24 }}>
                  <Form.Item
                    label="Website"
                    name="website"

                  >
                    <Input name="website" />
                  </Form.Item>
                </Col>
              </Row>
              <Button type="primary" htmlType="submit">
                Save
              </Button>
            </Form>
          </Modal>
          <div className='primary_details'>
              <Row gutter={[30, 30]}>
              <Col className="gutter-row" xxl={{ span: 12 }} xl={{ span: 12 }} lg={{ span: 12 }} md={{ span: 12 }} sm={{ span: 24 }} xs={{ span: 24 }}>
                <span>Company Name:</span>
                <span>{company?.company_name}</span>
              </Col>
              <Col className="gutter-row" xxl={{ span: 12 }} xl={{ span: 12 }} lg={{ span: 12 }} md={{ span: 12 }} sm={{ span: 24 }} xs={{ span: 24 }}>
                <span>Landline No:</span>
                <span>{company?.landline_no}</span>
                </Col>
                <Col className="gutter-row" xxl={{ span: 12 }} xl={{ span: 12 }} lg={{ span: 12 }} md={{ span: 12 }} sm={{ span: 24 }} xs={{ span: 24 }}>
                <span>Mobile No:</span>
                <span>{company?.mobile_no}</span>
                </Col>
                <Col className="gutter-row" xxl={{ span: 12 }} xl={{ span: 12 }} lg={{ span: 12 }} md={{ span: 12 }} sm={{ span: 24 }} xs={{ span: 24 }}>
                <span>e-Mail:</span>
                <span>{company?.email_id}</span>
                </Col>
              
              <Col className="gutter-row" xxl={{ span: 12 }} xl={{ span: 12 }} lg={{ span: 12 }} md={{ span: 12 }} sm={{ span: 24 }} xs={{ span: 24 }}>
                <span>GST No:</span>
                <span>{company?.gst_no}</span>
                </Col>
                <Col className="gutter-row" xxl={{ span: 12 }} xl={{ span: 12 }} lg={{ span: 12 }} md={{ span: 12 }} sm={{ span: 24 }} xs={{ span: 24 }}>
                <span>Pan No:</span>
                <span>{company?.pan_no}</span>
                </Col>
               
                <Col className="gutter-row" xxl={{ span: 12 }} xl={{ span: 12 }} lg={{ span: 12 }} md={{ span: 12 }} sm={{ span: 24 }} xs={{ span: 24 }}>
                <span>Address:</span>
                <span>{company?.address}</span>
                </Col>
                <Col className="gutter-row" xxl={{ span: 12 }} xl={{ span: 12 }} lg={{ span: 12 }} md={{ span: 12 }} sm={{ span: 24 }} xs={{ span: 24 }}>
                <span>Address Line1:</span>
                <span>{company?.address_line_1}</span>
                </Col>
                <Col className="gutter-row" xxl={{ span: 12 }} xl={{ span: 12 }} lg={{ span: 12 }} md={{ span: 12 }} sm={{ span: 24 }} xs={{ span: 24 }}>
                <span>Address Line2:</span>
                <span>{company?.address_line_2}</span>
                </Col>
                <Col className="gutter-row" xxl={{ span: 12 }} xl={{ span: 12 }} lg={{ span: 12 }} md={{ span: 12 }} sm={{ span: 24 }} xs={{ span: 24 }}>
                <span>Pincode:</span>
                <span>{company?.pincode}</span>
                </Col>
              <Col className="gutter-row" xxl={{ span: 12 }} xl={{ span: 12 }} lg={{ span: 12 }} md={{ span: 12 }} sm={{ span: 24 }} xs={{ span: 24 }}>
                <span>Website:</span>
                <span>{company?.website}</span>
                </Col>

                </Row>
          </div>
        </div>
      </PrimaryDetailsSection>
    </React.Fragment>
  )
}

export default PrimaryDetails;

const PrimaryDetailsSection = styled.section`
  width: 100%;
  display: inline-block;

  .primary_section {
    width:100%;
    display: inline-block;
    position: relative;
  }
  .primary_details {
    width: 100%;
    position: relative;
    display: inline-block;
  }
  ul {
    margin: 15px 0 0 0;
    padding: 0;
    width: 100%;
    display: grid;
    grid-template-columns: repeat(2,1fr);
    gap: 30px 30px;
  }
  li {
    list-style: none;
  }
  .primary_details span:nth-child(1) {
    font-family: "q_bold";
    font-size: 15px;
    width: 100%;
    display: inline-block;
    margin: 0 0 4px;
  }
  .primary_details span:nth-child(2) {
    font-family: "q_regular";
    font-size: 14px;
    width: 100%;
    border: 1px solid #d8dadb;
    display: inline-block;
    padding: 5px 10px;
    border-radius: 4px;
    cursor: not-allowed;
    min-height: 34px;
}

`;