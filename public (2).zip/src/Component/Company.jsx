import React from 'react'
import styled from 'styled-components';
import { ArrowLeftOutlined } from "@ant-design/icons";
import { useNavigate } from 'react-router-dom';
import { Tabs } from 'antd';
import PrimaryDetails from './PrimaryDetails';
import Address from './Address';
import Logo from './Logo';
import Map from './Map';


const Company = () => {
  const navigate = useNavigate();
  return (
    <React.Fragment>
      <CompanySection>
        <div className='page_back_align'>
          <p onClick={() => navigate(-1)} className="go_back">
            <ArrowLeftOutlined /> &nbsp; Company
          </p>

        </div>
        <div className='tabs_company'>
          <Tabs
            defaultActiveKey="1"
            tabPosition="left"
            size='small'
            items={[
              {
                label: 'Company Details',
                key: '1',
                children: <PrimaryDetails />,
              },
              {
                label: 'Company Contact Details',
                key: '2',
                children: "Coming soon.",
              },
              {
                label: 'Company Address',
                key: '3',
                children: "Coming soon.",
              },
              {
                label: 'Map',
                key: '4',
                children: <Map />,
              },
              {
                label: 'Settings',
                key: '5',
                children: 'Coming soon..',
              },
              {
                label: 'Social Media Link',
                key: '6',
                children: 'Coming soon..',
              },
              {
                label: 'Invoice Terms',
                key: '7',
                children: 'Coming soon..',
              },
            ]}
          />
        </div>
      </CompanySection>
    </React.Fragment>
  )
}

export default Company;

const CompanySection = styled.section`
  width: 100%;
  display: inline-block;
  
  .ant-tabs-tab {
    margin: 6px 0 0 0 !important;
    font-family: "q_bold";
  }

  .ant-tabs-tab-btn {
    font-family: "q_bold";
  }

  .tabs_company {
    width: 100%;
    background: #fff;
    position: relative;
    display: inline-block;
    border-radius: 8px;
    padding: 30px 25px 30px 0;
  }

  .ant-tabs .ant-tabs-tab.ant-tabs-tab-active .ant-tabs-tab-btn, .ant-tabs .ant-tabs-tab:hover {
    color:var(--bg) !important;
  }
  .ant-tabs .ant-tabs-ink-bar {
    background:var(--bg) !important;
  }


`;