import React, { useRef, useState, useEffect } from 'react'
import styled from 'styled-components'
import { Button, Input, Space, Table, Tag, Popconfirm, Modal, Form, Switch, message, Select ,InputNumber} from 'antd';
import { ArrowLeftOutlined, EditFilled, DeleteFilled, PlusCircleOutlined } from "@ant-design/icons";
import { useNavigate } from 'react-router-dom';
import { SearchOutlined } from "@ant-design/icons";
import Highlighter from "react-highlight-words";
import API from '../Store/Api/ApiService';
const { TextArea } = Input;
const Staff = () => {
  const [searchText, setSearchText] = useState("");
  const [searchedColumn, setSearchedColumn] = useState("");
  const [country, setCountry] = useState([]);
  const [countryOption, setCountryOption] = useState([]);
  const [tableLoading,setTableLoading] = useState(false);
  const navigate = useNavigate();
  const [form] = Form.useForm();
  const [form1] = Form.useForm();
  const searchInput = useRef(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isModalOpen1, setIsModalOpen1] = useState(false);
  const api = new API();
  const handleSearch = (selectedKeys, confirm, dataIndex) => {
    confirm();
    setSearchText(selectedKeys[0]);
    setSearchedColumn(dataIndex);
  };
  const handleReset = (clearFilters) => {
    clearFilters();
    setSearchText("");
  };
  const getColumnSearchProps = (dataIndex) => ({
    filterDropdown: ({
      setSelectedKeys,
      selectedKeys,
      confirm,
      clearFilters,
    }) => (
      <div
        style={{
          padding: 8,
        }}
      >
        <Input
          ref={searchInput}
          placeholder={`Search ${dataIndex}`}
          value={selectedKeys[0]}
          onChange={(e) =>
            setSelectedKeys(e.target.value ? [e.target.value] : [])
          }
          onPressEnter={() => handleSearch(selectedKeys, confirm, dataIndex)}
          style={{
            marginBottom: 8,
            display: "block",
          }}
        />
        <Space>
          <Button
            type="primary"
            onClick={() => handleSearch(selectedKeys, confirm, dataIndex)}
            icon={<SearchOutlined />}
            size="small"
            style={{
              width: 90,
            }}
          >
            Search
          </Button>
          <Button
            onClick={() => clearFilters && handleReset(clearFilters)}
            size="small"
            style={{
              width: 90,
            }}
          >
            Reset
          </Button>
          <Button
            type="link"
            size="small"
            onClick={() => {
              confirm({
                closeDropdown: false,
              });
              setSearchText(selectedKeys[0]);
              setSearchedColumn(dataIndex);
            }}
          >
            Filter
          </Button>
        </Space>
      </div>
    ),
    filterIcon: (filtered) => (
      <SearchOutlined
        style={{
          color: filtered ? "#1890ff" : undefined,
        }}
      />
    ),
    onFilter: (value, record) =>
      record[dataIndex].toString().toLowerCase().includes(value.toLowerCase()),
    onFilterDropdownOpenChange: (visible) => {
      if (visible) {
        setTimeout(() => searchInput.current?.select(), 100);
      }
    },
    render: (text) =>
      searchedColumn === dataIndex ? (
        <Highlighter
          highlightStyle={{
            backgroundColor: "#ffc069",
            padding: 0,
          }}
          searchWords={[searchText]}
          autoEscape
          textToHighlight={text ? text.toString() : ""}
        />
      ) : (
        text
      ),
  });
  const columns = [
    {
      title: "#",
      dataIndex: "sno",
      key: "sno",
      width: "3%",

    },
    {
      title: "Name",
      dataIndex: "display_name",
      key: "display_name",
      width: "10%",
      ...getColumnSearchProps("display_name"),
    },
    {
      title: "Email ID",
      dataIndex: "email_id",
      key: "email_id",
      width: "10%",
      ...getColumnSearchProps("email_id"),
    },
    {
      title: "Mobile No",
      dataIndex: "mobile_no",
      key: "mobile_no",
      width: "10%",
      ...getColumnSearchProps("mobile_no"),
    },
    {
      title: "Password",
      dataIndex: "password",
      key: "password",
      width: "10%",
      ...getColumnSearchProps("password"),
    },
    {
      title: "Status",
      dataIndex: "status",
      key: "status",
      width: "6%",

      render: (_, { status }) => (
        <>
          {status.map((statu) => {
            let color;
            let text;
            if (statu == 1) {
              color = "green";
              text = "Active";
            } else {
              color = "orange";
              text = " In Active";
            }
            return (
              <Tag color={color} key={statu}>
                {text}
              </Tag>
            );
          })}
        </>
      ),
    },
    {
      title: "Action",
      dataIndex: "action",
      key: "action",
      fixed: 'right',
      width: "5%",
      render: (action) => (
        <div style={{ display: "flex" }}>
          <p className='action_btn edit' onClick={() => editdistrict(action)}>
            <EditFilled />
          </p>
          <Popconfirm
            title=" Are you Sure to delete?"
            onConfirm={() => deletestate(action)}
          >
            <p className='action_btn delete'>
              <DeleteFilled />
            </p>
          </Popconfirm>
        </div>
      ),
    },
  ];

  const showModal = () => {
    setIsModalOpen(true);
  };
  const handleOk = () => {
    setIsModalOpen(false);

  };
  const handleCancel = () => {
    setIsModalOpen(false);
  };
  const deletestate = (action) => {
    api.deletesingledistrict(action).then((res) => {
      console.log(res)
      if (res.status === 200) {
        listdistrict();
        message.success("Deleted Successfully")
      }
    }).catch((err) => { });
  }

  const editdistrict = (action) => {
    listcountry();
    api.getsingledistrict(action).then((res) => {
      if (res.status === 200) {
        form.setFieldsValue(res.data)

      }
    }).catch((err) => {

    });
    setIsModalOpen(true);

  }

  const listdistrict = () => {
    setTableLoading(true);
    api.staff().then((res) => {
      let data = res.data;
      setTableLoading(false);
      setCountry(data)
    }).catch((err) => {

    });

  }

  const onFinish = (values) => {
    api.updatesingledistrict(values).then((res) => {
      if (res.status === 200) {
        form.resetFields();
        setIsModalOpen(false);
        listdistrict()
        message.success("Successfully Saved")
      }

    })
  }
  useEffect(() => {
    listdistrict();
  }, []);
  const data = [];
  {
    country?.map((item, i) => {
      data.push({
        key:i,
        sno: i + 1,
        display_name: item?.display_name,
        staff_name: item?.staff_name,
        email_id: item?.email_id,
        mobile_no: item?.mobile_no,
        password: item?.password,
        status: [item?.status],
        action: item?.staff_id
      });
    })
  }

  const listcountry = () => {
    api.state().then((res) => {
      let data = res.data;
      console.log(data)
      setCountryOption(data)
    }).catch((err) => {

    });

  }

  const country_list = [];

  countryOption?.map((item) => {
    country_list.push({
      value: item?._id,
      label: item?.name,
    })
  });


  const showModal1 = () => {
    setIsModalOpen1(true);
  };
  const handleOk1 = () => {
    setIsModalOpen1(false);

  };
  const handleCancel1 = () => {
    setIsModalOpen1(false);
  };


  const addnew_state = () => {
    listcountry();
    setIsModalOpen1(true);
  }

  const onFinishState = (values) => {
    console.log(values);
    api.createsingledistrict(values).then((res)=>{
     if(res.status===200) {
      form1.resetFields();
      setIsModalOpen1(false);
      listdistrict()
      message.success("Successfully Added")
     }
    }).catch((err)=>{})
  }


  return (
    <React.Fragment>
      <CountrySection>
        <div className='page_back_align'>
          <p onClick={() => navigate(-1)} className="go_back">
          <ArrowLeftOutlined /> &nbsp; Staff
          </p>
          <Button type='primary' size='small' onClick={addnew_state}><PlusCircleOutlined />New</Button>
        </div>


        <Modal title="Create Country" open={isModalOpen1} onOk={handleOk1} onCancel={handleCancel1} okText="Create" width={400} footer={null}>
          <Form
            name="country_edit"
            layout="vertical"
            onFinish={onFinishState}
            form={form1}
          >
            
            <Form.Item
              label="District Name"
              name="name"
              rules={[
                {
                  required: true,
                  message: 'Please entry state name!',
                },
              ]}
            >
              <Input name="name" />
            </Form.Item>
            
            <Form.Item
              label="State"
              name="state"
              rules={[
                {
                  required: true,
                  message: 'Please entry country name!',
                },
              ]}
            >
              <Select
                showSearch

                placeholder="Search State"
                optionFilterProp="children"
                filterOption={(input, option) => (option?.label ?? '').includes(input)}
                filterSort={(optionA, optionB) =>
                  (optionA?.label ?? '').toLowerCase().localeCompare((optionB?.label ?? '').toLowerCase())
                }
                options={country_list} />
            </Form.Item>
            <Form.Item
              label="Latitude"
              name="latitude"
            >
              <Input name="latitude" />
            </Form.Item>
            <Form.Item
              label="Longitude"
              name="longitude"

            >
              <Input name="longitude" />
            </Form.Item>
            <Form.Item label="Description" name="description">
              <TextArea rows={3} name="description" />
            </Form.Item>
            <div className='switch_btn'>
              <Form.Item label="Status" valuePropName="checked" name="status">
                <Switch name="status" />
              </Form.Item>
            </div>
            <Button type="primary" htmlType="submit">
              Save
            </Button>
          </Form>
        </Modal>




        <Modal title="Edit State" open={isModalOpen} onOk={handleOk} onCancel={handleCancel} okText="Save" width={400} footer={null}>
          <Form
            name="country_edit"
            layout="vertical"
            onFinish={onFinish}
            form={form}
          >
            <Form.Item
              label=""
              name="_id"
              type="hidden"
              style={{ height: 0 }}
            >
              <Input name="_id" type="hidden" />
            </Form.Item>
            <Form.Item
              label="State Name"
              name="name"
              rules={[
                {
                  required: true,
                  message: 'Please entry state name!',
                },
              ]}
            >
              <Input name="name" />
            </Form.Item>
           
            <Form.Item
              label="State"
              name="state"
              rules={[
                {
                  required: true,
                  message: 'Please enter state name!',
                },
              ]}
            >
              <Select
                showSearch

                placeholder="Search to Select"
                optionFilterProp="children"
                filterOption={(input, option) => (option?.label ?? '').includes(input)}
                filterSort={(optionA, optionB) =>
                  (optionA?.label ?? '').toLowerCase().localeCompare((optionB?.label ?? '').toLowerCase())
                }
                options={country_list} />
            </Form.Item>
            <Form.Item
              label="Latitude"
              name="latitude"
            >
              <Input name="latitude" />
            </Form.Item>
            <Form.Item
              label="Longitude"
              name="longitude"

            >
              <Input name="longitude" />
            </Form.Item>
            <Form.Item label="Description" name="description">
              <TextArea rows={3} name="description" />
            </Form.Item>
            <div className='switch_btn'>
              <Form.Item label="Status" valuePropName="checked" name="status">
                <Switch name="status" />
              </Form.Item>
            </div>
            <Button type="primary" htmlType="submit">
              Save
            </Button>
          </Form>
        </Modal>
        
        <Table
          columns={columns}
          dataSource={data}
          bordered
          responsive={true}
          loading={tableLoading}
          scroll={{
            x: 1000,
          }}
        />
      </CountrySection>
    </React.Fragment>
  )
}

export default Staff


const CountrySection = styled.section`
  width: 100%;
  display: inline-block;
  position: relative;
  .go_back {
    font-family: "q_bold";
    cursor: pointer;
  }

`;