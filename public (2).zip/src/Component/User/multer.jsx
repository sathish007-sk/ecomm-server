import { PlusOutlined, LoadingOutlined } from "@ant-design/icons";
import { Form, message, Upload } from "antd";
import axios from "axios";
import { useEffect, useState } from "react";
const getBase64 = (img, callback) => {
  const reader = new FileReader();
  reader.addEventListener("load", () => callback(reader.result));
  reader.readAsDataURL(img);
};
const beforeUpload = (file) => {
  const isJpgOrPng = file.type === "image/jpeg" || file.type === "image/png";
  if (!isJpgOrPng) {
    message.error("You can only upload JPG/PNG file!");
  }
  const isLt2M = file.size / 1024 / 1024 < 2;
  if (!isLt2M) {
    message.error("Image must smaller than 2MB!");
  }
  return isJpgOrPng && isLt2M;
};

const Multer = () => {
  const [loading, setLoading] = useState(false);
  const [imageUrl, setImageUrl] = useState();
  const[state,setState]=useState()
    useEffect(() => {
      axios
        .get("http://localhost:5000/api/v1/banner/getBanner")
        .then((res) => console.log(res))
        .catch((err) => console.log(err));
    });
  const handleChange = (info) => {
    if (info.file.status === "uploading") {
      setLoading(true);
      return;
    }
    if (info.file.status === "done") {
      // Get this url from response in real world.
      getBase64(info.file.originFileObj, (url) => {
        setLoading(false);
        console.log(info.file.originFileObj);
        setImageUrl(info.file.originFileObj);
      });
    }
  };
  const uploadButton = (
    <div>
      {loading ? <LoadingOutlined /> : <PlusOutlined />}
      <div
        style={{
          marginTop: 8,
        }}
      >
        Upload
      </div>
    </div>
  );
 const uploadFile =(e)=>{
   e.preventDefault()
   console.log(imageUrl)
       var formData = new FormData();
       formData.append("content", state);
       formData.append("image", imageUrl);

          // for (let index = 0; index < imageUrl.length; index++) {
          //   const element = imageUrl[index];
          //    formData.append("files", element);
          // }
     
             console.log(imageUrl)  
               console.log(formData);
             axios
               .post(
                 "http://192.168.100.154:5000/api/v1/admin/dynamic/refund-policy",
                 formData
               )
               .then((res) => console.log(res))
               .catch((err) => console.log(err));
             
   }
    
 const handleOnChange=(e)=>{
  const{name,value}=e.target
     if(name==='image'){
             console.log(e.target.files[0])
           setImageUrl(e.target.files[0]);
     }
    }
    //  setState(e.taget.value);
     
  return (
    <>
      {/* <Form onFinish={uploadFile}>
        <Upload
          name="avatar"
          listType="picture-card"
          className="avatar-uploader"
          showUploadList={false}
          action="http://localhost:5000/"
          beforeUpload={beforeUpload}
          onChange={handleChange}
        >
          {imageUrl ? (
            <img
              src={imageUrl}
              alt="avatar"
              style={{
                width: "100%",
              }}
            />
          ) : (
            uploadButton
          )}
        </Upload>
        <button type="submit">submit</button>
      </Form> */}
      <form onSubmit={uploadFile}>
        <label className="form-label">Image</label>
        <input
          name="image"
          type="file"
  
          onChange={handleOnChange}
          className="form-control"
        />
        <button type="submit"></button>
        
      </form>
    </>
  );
};
export default Multer;

 
// import { PlusOutlined } from "@ant-design/icons";
// import { Form, Modal, Upload } from "antd";
// import { useState } from "react";
// import axios from "axios";
// const getBase64 = (file) =>
//   new Promise((resolve, reject) => {
//     const reader = new FileReader();
//     reader.readAsDataURL(file);
//     reader.onload = () => resolve(reader.result);
//     reader.onerror = (error) => reject(error);
//   });
// const Multer = () => {
//   const [previewOpen, setPreviewOpen] = useState(false);
//   const [previewImage, setPreviewImage] = useState("");
//   const [previewTitle, setPreviewTitle] = useState("");
//      const [imageUrl, setImageUrl] = useState();
//      const[state,setState]=useState()
//   const [fileList, setFileList] = useState([]);
//   const handleCancel = () => setPreviewOpen(false);
//   const handlePreview = async (file) => {
//     if (!file.url && !file.preview) {
//       file.preview = await getBase64(file.originFileObj);
//     }
//     setPreviewImage(file.url || file.preview);
//     setPreviewOpen(true);
//     setPreviewTitle(
//       file.name || file.url.substring(file.url.lastIndexOf("/") + 1)
//     );
//   };
//   const uploadFile = (e) => {
//     // e.preventDefault();
//     // console.log(imageUrl);
//     console.log(fileList);
//     var formData = new FormData();
//     formData.append("name", state);

//     //  for (let index = 0; index < fileList.length; index++) {
//     //   const element = fileList[index];
//     //   // console.log(element)
//     //    formData.append("files",element)

//     //  }
//       fileList.fileList.forEach((file) => {
//         console.log(file.originFileObj);
//         formData.append("files", file.originFileObj);
//       });
//               // for (let index = 0; index < fileList.length; index++) {
//               //   const element = fileList[index];
//               //    formData.append("files", element);
//               // }

//     console.log(imageUrl);
//     console.log(formData);
//     axios
//       .post("http://192.168.100.154:5000/api/v1/banner/addBanner", formData)
//       .then((res) => console.log(res))
//       .catch((err) => console.log(err));
//   };
//   const handleChange = (info) =>{ 
    
//      console.log(info);
//      setFileList(info);
//   }
//   const uploadButton = (
//     <div>
//       <PlusOutlined />
//       <div
//         style={{
//           marginTop: 8,
//         }}
//       >
//         Upload
//       </div>
//     </div>
//   );
//   return (
//     <>
//       <Form onFinish={uploadFile}>
//         <Upload
//           action="http://192.168.100.154:5000/"
//           listType="picture-card"
//           multiple
//           // fileList={fileList}
//           onPreview={handlePreview}
//           onChange={handleChange}
//         >
//           {fileList.length >= 8 ? null : uploadButton}
//         </Upload>
//         <Modal
//           open={previewOpen}
//           title={previewTitle}
//           footer={null}
//           onCancel={handleCancel}
//         >
//           <img
//             alt="example"
//             style={{
//               width: "100%",
//             }}
//             src={previewImage}
//           />
//         </Modal>
//         <button type="submit">submit</button>
//       </Form>
//     </>
//   );
// };
// export default Multer;