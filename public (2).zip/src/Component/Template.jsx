import React from 'react'
import styled from 'styled-components';
import { useNavigate } from 'react-router-dom';
import { Button } from 'antd';
import { ArrowLeftOutlined, PlusCircleOutlined } from "@ant-design/icons";

const Template = () => {
  const navigate = useNavigate();


  return (
    <React.Fragment>
      <TemplateSection>
        <div className='page_back_align'>
          <p onClick={() => navigate(-1)} className="go_back">
          <ArrowLeftOutlined /> &nbsp; Template
          </p>
          <Button type='primary' size='small'><PlusCircleOutlined />New</Button>
        </div>
      </TemplateSection>
    </React.Fragment>
  )
}

export default Template;

const TemplateSection = styled.section`
  display: inline-block;
  width: 100%;
  position: relative;


`;