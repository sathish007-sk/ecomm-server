import React, { useEffect, useState, useRef } from "react";
import styled from "styled-components";
import {
  Button,
  Input,
  Space,
  Table,
  Tag,
  Popconfirm,
  Modal,
  TreeSelect,
  Form,
  Switch,
  message,
  Spin,
  Select,
} from "antd";
import API from "../Store/Api/ApiService";
import { useNavigate } from "react-router-dom";
import axios from 'axios'
import {
  ArrowLeftOutlined,
  PlusCircleOutlined,
  SearchOutlined,
} from "@ant-design/icons";
import Highlighter from "react-highlight-words";
import editicon from "../Assets/Images/edit.png";
import deleteicion from "../Assets/Images/delete.png";
// import e from 'express';

const ProductImage = () => {
  const [searchText, setSearchText] = useState("");
  const [searchedColumn, setSearchedColumn] = useState("");
  const [category, setCategory] = useState([]);
  const [brand, setBrand] = useState([]);
  const [categorydata, setcategorydata] = useState([]);
  const [tableLoading, setTableLoading] = useState(false);
  const [loading, setLoading] = useState(false);
  const [loading1, setLoading1] = useState(false);
  const [loading2, setLoading2] = useState(false);
  const [loading3, setLoading3] = useState(false);
  const [isModalOpen1, setIsModalOpen1] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [checked, setChecked] = useState(false);
  const searchInput = useRef(null);
  const api = new API();
  const [form] = Form.useForm();
  const [form1] = Form.useForm();
  const navigate = useNavigate();
   const [value, setValue] = useState();
  const [menu, setMenu] = useState([]);
  const [parentMenu, setParentMenu] = useState([]);
 
   useEffect(() => {
     getMenuAll();
   }, []);

   const getMenuAll = () => {
     setLoading(true);
      let data={
         mode:'category'
      }
     axios
       .get("http://192.168.100.154:5000/api/v1/mastersetting/getMastersetting" ,{params:data})
       .then((res) => {
         console.log(res);
         let data = res.data;
         if (data?.success === true) {
           console.log("data1.result", data.result);
           setMenu(data.result);
           let id = data.result.filter((e) => {
             console.log(e)
             return e.parent_id === null;
           });
            console.log('id',id)

           setParentMenu(
             data.result.filter((e) => {
               return e.parent_id == null;
             })
           );
           setLoading(false);
         } else {
           setLoading(false);
         }
       })
       .catch((err) => {
         console.log(err);
         setLoading(false);
       });
   };
    let levelTwo;
  let levelThree;
  let levelFour;
  let levelFive;

  
  const items = [];

   

  const levelOne = () => {
 
    // parentMenu?.forEach(element => {
    //      Object.values(element) .forEach(e => {
    //           console.log(e)
    //       });
    // }); 
      parentMenu?.map((item, i) => {
        console.log(item);
        levelTwo = menu.filter((e) => {
          // console.log(e.module)
          return e.parent_id == item._id;
        });
        console.log("dwddeeeee", levelTwo);
         items.push({
           value: item._id,
           title: item.name,
           children: levelTwo.length>1?
           levelTwo.map((e) => {
                  // console.log(e)
                  return {
                    value: e._id,
                    title: e.name,
                  };
                }):''
         });})}
         
    levelOne()    
   const getAllBrand = () => {
     setTableLoading(true);
     const data = {
       url1: "mastersetting",
       Url1: "Mastersetting",
       params:'brand' 
     };
     api
       .getdata(data)
       .then((res) => {
         if (res.data.success === true) {
          console.log('reskkkk',res)
           setBrand(res.data.result);
           setTableLoading(false);
         } else {
           setBrand([]);
           setTableLoading(false);
         }
       })
       .catch((err) => {
         setBrand([]);
         setTableLoading(false);
       });
   };
   const getAllCategorys = () => {
     setTableLoading(true);
     const data = {
       url1: "mastersetting",
       Url1: "Mastersetting",
       params: "category",
     };
     api
       .getdata(data)
       .then((res) => {
         if (res.data.success === true) {
           console.log("reskkkk", res);
           setcategorydata(res.data.result);
           setTableLoading(false);
         } else {
           setcategorydata([]);
           setTableLoading(false);
         }
       })
       .catch((err) => {
         setcategorydata([]);
         setTableLoading(false);
       });
   };

   useEffect(() => {
     getAllBrand();
     getAllCategorys();
   }, []);
  const getAllCategory = () => {
    setTableLoading(true);
    const data = {
      url1: "product",
      Url1: "Product",
    };
    api
      .getdata(data)
      .then((res) => {
        console.log('wdddd',res)
        if (res.data.success === true) {
          setCategory(res.data.result);
          setTableLoading(false);
        } else {
          setCategory([]);
          setTableLoading(false);
        }
      })
      .catch((err) => {
        setCategory([]);
        setTableLoading(false);
      });
  };

  useEffect(() => {
    getAllCategory();
  }, []);
   const onChange = (newValue) => {
     console.log(newValue);
     setValue(newValue);
   };

  const brand_list = [];
  const category_list = [];

  brand?.map((item) => {
    brand_list.push({
      value: item?._id,
      label: item?.name,
    });
  });
    categorydata?.map((item) => {
      category_list.push({
        value: item?._id,
        label: item?.name,
      });
    });

  const data = [];
  {
    category?.map((item, i) => {
       let categoryname=item?.category?.length-1
       console.log('ddd',categoryname)
      data.push({
        key: i,
        sno: i + 1,
        description: item?.description,
        category: item?.category[categoryname]?.name,
        brand: item?.brand?.name,

        status: [item?.status],
        publish: [item?.publish],
        featured: [item?.publish],
        action: item?._id,
      });
    });
  }

  //Delete Category
  const deleteCategory = (action) => {
    console.log(action);
    setLoading3(true);
    let deleteaction = {
      url1: "product",
      Url1: "Product",
      id: action,
    };
    api.deletedata(deleteaction).then((res) => {
      if (res.data.success === true) {
        setLoading3(false);
        message.success("Deleted successfully");
        getAllCategory();
      } else if (res.data.success === false) {
        message.warning(res.data.msg);
        setLoading3(false);
      } else {
        message.error("Something went wrong!. Please try again!");
        setLoading3(false);
      }
    });
  };

  //Add New Category

  const addnew_category = () => {
    setIsModalOpen1(true);
  };

  const onFinishCategory = (values) => {
    setLoading2(true);
   
    const brand = values["brand"];
    const category=values['category']
    const description = values["name"];
  


    const status = values["status"] === true ? 1 : 0;
    console.log('brand',brand)
    let getSingle = {
      url1: "product",
      Url1: "Product",
    };
    let addNew = {
       category:value,
       brand,
       description,
      status,
    };

    if (
      (brand!== "" || brand !== undefined) &&
      (status !== "" || status !== undefined)
    ) {
      api
        .adddata(getSingle, addNew)
        .then((res) => {
          if (res.data.success === true) {
            console.log(res.data.result._id);
            setLoading2(false);
            form.resetFields();
          
            setValue()
            setIsModalOpen1(false);
            message.success("Added successfully");
            getAllCategory();
              navigate(`/addproduct/${res.data.result._id}`)
          } else if (res.data.success === false) {
            message.warning(res.data.msg);
            setLoading2(false);
          } else {
            message.error("Something went wrong!. Please try again!");
            setLoading2(false);
          }
        })
        .catch((err) => {
          setLoading2(false);
        });
    } else {
      message.error("Something went wrong!. Please try again!");
      setLoading2(false);
    }
  };

  //Edit Category

  const updateCategory = (action) => {
       navigate(`/editproduct/${action}`);
  };
 let res=0;
  let ress = 0;
  const updateCategoryApi = (values) => {
        const description = values["description"];
    const category = values["category"];
    const image_path = values["e_path"];
    setLoading1(true);
    setChecked(false);
      res = 0;
      if (checked == true) {
        res = 1;
      } else {
        res = values["publish"] === true ? 1 : 0;
      }
      if (values["publish"] === false) {
        res = 0;
      }
    ress = 0;
    if (checked == true) {
      ress = 1;
    } else {
      ress = values["e_status"] === true ? 1 : 0;
    }
    if (values["e_status"] === false) {
      ress = 0;
    }
    console.log(values["e_id"]);
    let getSingle = {
      url1: "product",
      Url1: "Product",
      id: values["e_id"],
    };

    let updateApi = {
      description,
 
      category,
      publish:res,
      status: ress,
    };
    console.log(updateApi)

    if (
      (values?.description !== "" || values?.description !== undefined) &&
      (values?.e_status !== "" || values?.e_status !== undefined)
    ) {
      api
        .editdata(getSingle, updateApi)
        .then((res) => {
          if (res.data.success === true) {
            setIsModalOpen(false);
            setLoading1(false);
            message.success("Updated successfully");
            getAllCategory();
          } else if (res.data.success === false) {
            message.warning(res.data.msg);
            setLoading1(false);
          } else {
            message.error("Something went wrong!. Please try again!");
            setLoading1(false);
          }
        })
        .catch((err) => {});
    } else {
      message.error("Something went wrong!. Please try again!");
      setLoading1(false);
    }
  };

  //Popup Model
  const handleOk1 = () => {
    setIsModalOpen1(false);
  };
  const handleCancel1 = () => {
    setIsModalOpen1(false);
  };

  const handleOk = () => {
    setIsModalOpen(false);
  };
  const handleCancel = () => {
    setIsModalOpen(false);
  };

  //Table
  const handleSearch = (selectedKeys, confirm, dataIndex) => {
    confirm();
    setSearchText(selectedKeys[0]);
    setSearchedColumn(dataIndex);
  };
  const handleReset = (clearFilters) => {
    clearFilters();
    setSearchText("");
  };
  const getColumnSearchProps = (dataIndex) => ({
    filterDropdown: ({
      setSelectedKeys,
      selectedKeys,
      confirm,
      clearFilters,
    }) => (
      <div
        style={{
          padding: 8,
        }}
      >
        <Input
          ref={searchInput}
          placeholder={`Search ${dataIndex}`}
          value={selectedKeys[0]}
          onChange={(e) =>
            setSelectedKeys(e.target.value ? [e.target.value] : [])
          }
          onPressEnter={() => handleSearch(selectedKeys, confirm, dataIndex)}
          style={{
            marginBottom: 8,
            display: "block",
          }}
        />
        <Space>
          <Button
            type="primary"
            onClick={() => handleSearch(selectedKeys, confirm, dataIndex)}
            icon={<SearchOutlined />}
            size="small"
            style={{
              width: 90,
            }}
          >
            Search
          </Button>
          <Button
            onClick={() => clearFilters && handleReset(clearFilters)}
            size="small"
            style={{
              width: 90,
            }}
          >
            Reset
          </Button>
          <Button
            type="link"
            size="small"
            onClick={() => {
              confirm({
                closeDropdown: false,
              });
              setSearchText(selectedKeys[0]);
              setSearchedColumn(dataIndex);
            }}
          >
            Filter
          </Button>
        </Space>
      </div>
    ),
    filterIcon: (filtered) => (
      <SearchOutlined
        style={{
          color: filtered ? "#1890ff" : undefined,
        }}
      />
    ),
    onFilter: (value, record) =>
      record[dataIndex].toString().toLowerCase().includes(value.toLowerCase()),
    onFilterDropdownOpenChange: (visible) => {
      if (visible) {
        setTimeout(() => searchInput.current?.select(), 100);
      }
    },
    render: (text) =>
      searchedColumn === dataIndex ? (
        <Highlighter
          highlightStyle={{
            backgroundColor: "#ffc069",
            padding: 0,
          }}
          searchWords={[searchText]}
          autoEscape
          textToHighlight={text ? text.toString() : ""}
        />
      ) : (
        text
      ),
  });
  const columns = [
    {
      title: "#",
      dataIndex: "sno",
      key: "sno",
      width: "2%",
    },
    {
      title: "Description",
      dataIndex: "description",
      key: "description",
      width: "10%",
      ...getColumnSearchProps("description"),
    },
    {
      title: "brand",
      dataIndex: "brand",
      key: "brand",
      width: "10%",
      ...getColumnSearchProps("brand"),
    },
    {
      title: "category",
      dataIndex: "category",
      key: "category",
      width: "10%",
      ...getColumnSearchProps("category"),
    },

    {
      title: "publish",
      dataIndex: "publish",
      key: "publish",
      width: "4%",

      render: (_, { status }) => (
        <>
          {status.map((statu) => {
            let color;
            let text;
            if (statu == 1) {
              color = "green";
              text = "Yes";
            } else {
              color = "orange";
              text = " No";
            }
            return (
              <Tag color={color} key={statu}>
                {text}
              </Tag>
            );
          })}
        </>
      ),
    },
    {
      title: "Status",
      dataIndex: "status",
      key: "status",
      width: "4%",

      render: (_, { status }) => (
        <>
          {status.map((statu) => {
            let color;
            let text;
            if (statu == 1) {
              color = "green";
              text = "Active";
            } else {
              color = "orange";
              text = " In Active";
            }
            return (
              <Tag color={color} key={statu}>
                {text}
              </Tag>
            );
          })}
        </>
      ),
    },
    {
      title: "Action",
      dataIndex: "action,name",
      key: "action,name",
      fixed: "right",
      width: "3%",
      render: (action, name) => (
        <div style={{ display: "flex" }}>
          <p
            className="action_btn edit"
            onClick={() => updateCategory(name?.action)}
          >
            <img src={editicon} alt="Edit" className="action_icon" />
          </p>
          <Popconfirm
            title=" Are you Sure to delete?"
            onConfirm={() => deleteCategory(name?.action)}
            okButtonProps={{
              loading: loading3,
            }}
          >
            <p className="action_btn delete">
              <img src={deleteicion} alt="Edit" className="action_icon" />
            </p>
          </Popconfirm>
        </div>
      ),
    },
  ];

  return (
    <React.Fragment>
      <CategorySection>
        <Modal
          title="Create ProductImage"
          open={isModalOpen1}
          onOk={handleOk1}
          onCancel={handleCancel1}
          okText="Create"
          width={400}
          footer={null}
        >
          <Form
            name="country_edit"
            layout="vertical"
            onFinish={onFinishCategory}
            form={form}
          >
            <Form.Item
              label="ProductDescription"
              name="name"
              rules={[
                {
                  required: true,
                  message: "ProductDescription is required!",
                },
              ]}
            >
              <Input type="text" name="name" />
            </Form.Item>
            <Form.Item label="Brand" name="brand">
              <Select
                showSearch
                placeholder="Search to Select"
                optionFilterProp="children"
                filterOption={(input, option) =>
                  (option?.label ?? "").includes(input)
                }
                filterSort={(optionA, optionB) =>
                  (optionA?.label ?? "")
                    .toLowerCase()
                    .localeCompare((optionB?.label ?? "").toLowerCase())
                }
                options={brand_list}
              />
            </Form.Item>
            <Form.Item
              label="Category"
              rules={[
                {
                  required: true,
                  message: "category is required",
                },
              ]}
            >
              <TreeSelect
                showSearch
                style={{
                  width: "100%",
                }}
                value={value}
                dropdownStyle={{
                  maxHeight: 400,
                  overflow: "auto",
                }}
                placeholder="Please select"
                allowClear
                multiple
                treeDefaultExpandAll
                onChange={onChange}
                treeData={items}
              />
            </Form.Item>

            {/* <Form.Item label="Category" name="category">
              <Select
                showSearch
                placeholder="Search to Select"
                optionFilterProp="children"
                filterOption={(input, option) =>
                  (option?.label ?? "").includes(input)
                }
                filterSort={(optionA, optionB) =>
                  (optionA?.label ?? "")
                    .toLowerCase()
                    .localeCompare((optionB?.label ?? "").toLowerCase())
                }
                options={category_list}
              />
            </Form.Item> */}

            <div className="switch_btn">
              <Form.Item
                label="Status"
                valuePropName="checked"
                name="status"
                rules={[
                  {
                    required: true,
                    message: "Status is required!",
                  },
                ]}
              >
                <Switch />
              </Form.Item>
            </div>
            <Button type="primary" htmlType="submit" loading={loading2}>
              Save
            </Button>
          </Form>
        </Modal>
        <Modal
          title="Edit ProductImage"
          open={isModalOpen}
          onOk={handleOk}
          onCancel={handleCancel}
          okText="Update"
          width={400}
          footer={null}
        >
          {loading === true ? (
            <div className="spin_center">
              <Spin />
            </div>
          ) : (
            <Form
              name="category_edit"
              layout="vertical"
              onFinish={updateCategoryApi}
              form={form1}
            >
              <Form.Item
                label=""
                name="e_id"
                type="hidden"
                style={{ height: 0 }}
              >
                <Input name="e_id" type="hidden" />
              </Form.Item>
              <Form.Item
                label="ProductimageTitle "
                name="description"
                rules={[
                  {
                    required: true,
                    message: "ProductimageTitle is required!",
                  },
                ]}
              >
                <Input name="description" />
              </Form.Item>
              <Form.Item
                label="ProductimageDescription"
                name="category"
                rules={[
                  {
                    required: true,
                    message: "ProductimageDescription is required!",
                  },
                ]}
              >
                <Input name="category" />
              </Form.Item>
              <Form.Item
                label="ProductimagePath"
                name="e_path"
                rules={[
                  {
                    required: true,
                    message: "Productimagepath is required!",
                  },
                ]}
              >
                <Input name="e_path" />
              </Form.Item>

              <div className="switch_btn">
                <Form.Item label="Status" name="e_status">
                  {checked == true ? <Switch defaultChecked /> : <Switch />}
                </Form.Item>
              </div>
              <Button type="primary" htmlType="submit" loading={loading1}>
                Save
              </Button>
            </Form>
          )}
        </Modal>

        <div className="page_back_align">
          <p onClick={() => navigate(-1)} className="go_back">
            <ArrowLeftOutlined /> &nbsp; Product
          </p>
          <Button type="primary" size="small" onClick={() => addnew_category()}>
            <PlusCircleOutlined />
            New
          </Button>
        </div>
        <Table
          columns={columns}
          dataSource={data}
          bordered
          loading={tableLoading}
          responsive={true}
          size="small"
          scroll={{
            x: 800,
          }}
        />
      </CategorySection>
    </React.Fragment>
  );
};

export default ProductImage;

const CategorySection = styled.section`
  width: 100%;
  display: inline-block;
  position: relative;
  .go_back {
    font-family: "q_bold";
    cursor: pointer;
  }

  .switch_btn .ant-row.ant-form-item-row.css-dev-only-do-not-override-sk7ap8 {
    flex-wrap: wrap !important;
  }
  .switch_btn .ant-row {
    display: flex !important;
    flex-direction: row !important;
    flex-flow: nowrap !important;
    align-items: center;
  }
`;
