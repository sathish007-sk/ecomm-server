import React, { useEffect, useState } from 'react'
import {
  DesktopOutlined,
  SettingOutlined,
  BarChartOutlined,
  UserOutlined,
  PieChartOutlined,
  GiftOutlined,
  ShoppingCartOutlined,
  FileProtectOutlined,
} from '@ant-design/icons';
import axios from 'axios';
import { Layout, Menu, Spin } from 'antd';
import { Link } from 'react-router-dom'
import API from '../Store/Api/ApiService';

const { Sider } = Layout;
const MenuBar = () => {
  const [collapsed, setCollapsed] = useState(false);


  const [menu, setMenu] = useState([]);
  const [parentMenu, setParentMenu] = useState([]);
  const [loading, setLoading] = useState(false);
  const api = new API();

  useEffect(() => {
    getMenuAll();
  }, [])

  const getMenuAll = () => {
    setLoading(true)
    axios
      .get("http://192.168.100.154:5000/api/v1/menu/getMenu")
      .then((res) => {
        console.log(res);
        let data = res.data;
        if (data?.success === true) {
          console.log("data.result", data.result);
          setMenu(data.result);
          let id = data.result.filter((e) => {
            return e.module == null;
          });

          setParentMenu(
            data.result.filter((e) => {
              return e.module == null;
            })
          );
          setLoading(false);
        } else {
          setLoading(false);
        }
      })
      .catch((err) => {
        console.log(err);
        setLoading(false);
      });
  }






  let levelTwo;
  let levelThree;
  let levelFour;
  let levelFive;

  
  const items = [];

   

  const levelOne = () => {
 
    // parentMenu?.forEach(element => {
    //      Object.values(element) .forEach(e => {
    //           console.log(e)
    //       });
    // }); 
      parentMenu?.map((item, i) => {
        console.log(item);
        levelTwo = menu.filter((e) => {
          // console.log(e.module)
          return e.module == item._id;
        });
        console.log("dwdd", levelTwo);
        items.push({
          key: item?._id,
          icon: <DesktopOutlined />,
          label: <Link to={item.url}>{item.menu_name}</Link>,
          children:
            levelTwo?.length > 1
              ? levelTwo.map((e) => {
                  // console.log(e)
                  return {
                    key: e._id,
                    label: <Link to={e.url}>{e.menu_name}</Link>,
                  };
                })
              : "",
        });

        // items.push({
        //   key: item?._id,
        //   icon: <DesktopOutlined />,
        //   children: levelTwo?.length > 1 ? levelTwo.map((e) => {
        //     levelThree = menu.filter((t) => {
        //       return t.parentid == e.menuid
        //     });
        //     return {
        //       key: e.menuid,
        //       label: <Link to={e.link}>{e.menuname}</Link>,
        //       children: levelThree?.length > 1 ? levelThree.map((f) => {
        //         levelFour = menu.filter((t) => {
        //           return t.parentid == f.menuid
        //         });
        //         return {
        //           key: f.menuid,
        //           label: <Link to={f.link}>{f.menuname}</Link>,
        //           children: levelFour?.length > 1 ? levelFour.map((f) => {
        //             levelFive = menu.filter((t) => {
        //               return t.parentid == f.menuid
        //             });
        //             return {
        //               key: f.menuid,
        //               label: <Link to={f.link}>{f.menuname}</Link>,
        //               children: levelFive?.length > 1 ? levelFive.map((f) => {
        //                 return {
        //                   key: f.menuid,
        //                   label: <Link to={f.link}>{f.menuname}</Link>,
        //                 }
        //               }) : "",
        //             }
        //           }) : "",
        //         }
        //       }) : "",
        //     }
        //   }) : "",
        //   label: item?.menuname,
        // })
      });

    // parentMenu?.map((item, i) => {
    //   levelTwo = menu.filter((e) => {
    //     return e.parentid == item.menuid
    //   });
    //   items.push({
    //     key: item?.menuid,
    //     icon: <DesktopOutlined />,
    //     children: levelTwo?.length > 1 ? levelTwo.map((e) => {
           
    //       levelThree = menu.filter((t) => {
    //         return t.parentid == e.menuid
    //       });
    //       return {
    //         key: e.menuid,
    //         label: <Link to={e.link}>{e.menuname}</Link>,
    //         children: levelThree?.length > 1 ? levelThree.map((f) => {
    //           levelFour = menu.filter((t) => {
    //             return t.parentid == f.menuid
    //           });
    //           return {
    //             key: f.menuid,
    //             label: <Link to={f.link}>{f.menuname}</Link>,
    //             children: levelFour?.length > 1 ? levelFour.map((f) => {
    //               levelFive = menu.filter((t) => {
    //                 return t.parentid == f.menuid
    //               });
    //               return {
    //                 key: f.menuid,
    //                 label: <Link to={f.link}>{f.menuname}</Link>,
    //                 children: levelFive?.length > 1 ? levelFive.map((f) => {
    //                   return {
    //                     key: f.menuid,
    //                     label: <Link to={f.link}>{f.menuname}</Link>,
    //                   }
    //                 }) : "",
    //               }
    //             }) : "",
    //           }
    //         }) : "",
    //       }
    //     }) : "",
    //     label: item?.menuname,
    //   })
    // })

  }
  levelOne()






  return (
    <React.Fragment>
      <Sider collapsible collapsed={collapsed} onCollapse={(value) => setCollapsed(value)}>
        <div
          style={{
            height: 25,
            margin: 16,
            background: 'rgba(255, 255, 255, 0.2)',
          }}
        />
        {
          loading === true ? <div className='spin_center'><Spin /></div> : <Menu theme="light" defaultSelectedKeys={['1']} mode="inline" items={items} />
        }

      </Sider>

    </React.Fragment>
  )
}

export default MenuBar;