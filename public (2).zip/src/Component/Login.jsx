import React, { useState } from "react";
import styled from 'styled-components';
import { message, Button, Form, Input } from "antd";
import { LockOutlined, UserOutlined, LoginOutlined } from "@ant-design/icons";
import { Link } from "react-router-dom"
import bg from '../Assets/Images/login-bg.png';
import logo from '../Assets/Images/logo.png';
import Api from '../Store/Api/ApiService'
import { useDispatch } from "react-redux";
import moment from "moment"

const Login = () => {
  const [form] = Form.useForm();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [saving, setSaving] = useState(false);



  const api = new Api();
  const dispatch = useDispatch();
  const onFinish = (values) => {
    const date = moment().format("hh:mm A");
    values["time"] = date;
    console.log(values)
    setSaving(true);
     let data={
        email_id:values['Email'],
        password:values['password']
     }
     console.log('dxss',data)
    api
      .login(dispatch,data)
      .then((res) => {
        let data = res.data;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            
        if (data.success === true) {
          form.resetFields();
          message.success("Logged in successfully");
          window.location.reload()
          setSaving(false);
        } else {
          //  message.error(data.message);
          message.error("Username or password is incorrect");
          setSaving(false);
        }
      })
      .catch((err) => {
        message.error("Login Failed!");
        setSaving(false);
      });


  }




  return (
    <React.Fragment>
      <LoginSection>
        <div className="login_header">
          <div className="login_header_align">
            <div className="login_header_left">
              <img src={logo} alt="ecDigi Technologies" />
            </div>
            <div className="login_header_right">
              <span>Don't have an account? </span><Link to="/signup"><Button>Sign up</Button></Link>
            </div>
          </div>
        </div>
        <div className="login_section">
          <h1>Welcome back!</h1>
          <Form
            form={form}
            name="admin_login"
            layout="vertical"
            onFinish={onFinish}
            autoComplete="off"
          >
            <Form.Item
              label="Email"
              name="Email"
              values={email}
              onChange={(event) => setEmail(event.target.values)}
              rules={[
                {
                  required: true,
                  message: "Please enter valid Email",
                },
              ]}
            >
              <Input
                prefix={<UserOutlined className="site-form-item-icon" />}
                placeholder="Username"
              />
            </Form.Item>

            <Form.Item
              label="Password"
              name="password"
              values={password}
              onChange={(event) => setPassword(event.target.values)}
              rules={[
                {
                  required: true,
                  message: "Please enter valid password!",
                },
              ]}
            >
              <Input.Password
                prefix={<LockOutlined className="site-form-item-icon" />}
                placeholder="Password"
              />
            </Form.Item>

            <Button type="primary" htmlType="submit" loading={saving}>
              <LoginOutlined /> Sign In
            </Button>
          </Form>
          <div className="login_with_otp">
            <span>or</span>
            <p>Login with OTP?</p>

          </div>
        </div>
      </LoginSection>
    </React.Fragment>
  )
}

export default Login;




const LoginSection = styled.section`
  
  display: flex;
  align-items: center;
  justify-content: center;
  width:100%;
  min-height: 100vh;
  overflow: hidden;
  position: relative;
  background: #fafbfc;

  ::after {
    content: '';
    position: absolute;
    width: calc(100%);
    height: calc(100% - 25vh);
    width: 100%;
    top: 25vh;
    background: url('${bg}');
    background-repeat: no-repeat;
    background-size: 100%;
    background-position: center top ;
    z-index: 5;
  }

  ::before {
    content: '';
    background: #f59209;
    position: absolute;
    height: 100%;
    width: 100%;
    top: 25vh;
    z-index: 3;
  }

  .login_section {
    width: 440px;
    background: #fff;
    box-shadow: 0 24px 64px #26214a1a;
    border-radius: 12px;
    padding: 25px 45px;
    position: relative;
    z-index: 10;
    margin: 130px 0 50px 0;
}

h1 {
  font-family: 'q_bold';
    margin: 0 0 20px;
    text-align: center;
    font-size: 25px;
}
  label {
    color: #292d34 !important;
    font-family: 'q_medium';
  }
  .ant-form-item-label {
    padding: 0 0 7px !important;
  }
  svg {
    color: #d9d9d9 !important;
  }

  span.ant-input-affix-wrapper {
    padding: 6px 11px !important;
  }
  span.ant-input-affix-wrapper:hover, span.ant-input-affix-wrapper:focus {
    border-color: var(--bg) !important;
  }

  .ant-form-item {
    margin-bottom: 13px !important;
  }

  button {
    background: var(--bg);
    margin: 9px 0 0 0;
    width: 100%;
    padding: 7px 15px;
    height: auto;
   span {
    font-family: 'q_bold';
    color: #fff;
    svg {
      color: #fff !important;
    }
   }
}
button:hover {
  background: #000 !important;
}

.login_with_otp {
  width: 100%;
  display: inline-block;
  margin: 17px 0 0 0;
}
.login_with_otp span {
  color: #292d34;
  font-family: "q_bold";
  text-align: center;
  width: 100%;
  display: inline-block;
  font-style: italic;
  font-size: 14px;

}
.login_with_otp p {
  font-size: 12px;
  font-family: "q_medium";
  
  color: var(--bg) !important;
  text-align: center;
  margin: 10px 0 0 0;
  cursor: pointer;
}
.login_with_otp p:hover {
  color: #000 !important;
}

.login_header {
  position: absolute;
  top: 0;
  left:0;
  width:100%;
  z-index: 11;
  padding: 20px 30px 12px 30px;
    background: #fafbfc;
}
.login_header_align {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.login_header_left {
  width:fit-content;
  img {
    height: 45px;
  }
}
.login_header_right {
  width: fit-content;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 15px;
  span {
    display: inline-block;
    font-family: 'q_medium';
    font-size: 14px;
  }
  button {
    width: fit-content;
    margin: 0;
    box-shadow: 0 10px 25px rgb(245 146 9 / 30%);
    border-color: var(--bg);
    padding: 5px 13px;
}


}



@media screen and (max-width:580px) {

  ::before {
    background: #f9fafb;
  }
  .login_header_right span {
    display: none;
  }

  .login_header {
    padding: 13px 15px 0 15px;
  }
  .login_header_left img {
    height: 40px;
}
.login_section {
    width: 90%;
    padding: 30px 25px;
    margin: auto;
    display: flex;
    flex-direction: column;
}



}


`;