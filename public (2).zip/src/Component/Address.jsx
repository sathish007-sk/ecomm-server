import React, { useEffect, useState } from 'react'
import styled from 'styled-components';
import { FormOutlined } from "@ant-design/icons";
import { Button, Modal, Form, Input, Col, Row, message,InputNumber,Select } from 'antd';
import API from '../Store/Api/ApiService';
const { TextArea } = Input;
const Address = () => {
  const [company, setCompany] = useState([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [country, setCountry] = useState([]);
  const [state, setState] = useState([]);
  const [district, setDistrict] = useState([]);
  const [countryList, setCountryList] = useState([]);
  const [stateList, setStateList] = useState([]);
  const [districtList, setDistrictList] = useState([]);
  const [form] = Form.useForm();
  const api = new API();
  const get_company_details = () => {
    setLoading(true)
    api.companydetails().then((res) => {
      if (res.status === 200 && res.statusText === "OK") {
        setCompany(res.data);
        form.setFieldsValue(res?.data?.address)
        setLoading(false)
      }
    }).catch((err) => { })
  }
  
  useEffect(() => {
    get_company_details();
    listcountry();
    liststate();
    listdistrict();
  }, []);

  const showModal = () => {

    setIsModalOpen(true);
  };
  const handleOk = () => {
    setIsModalOpen(false);
  };
  const handleCancel = () => {
    setIsModalOpen(false);
  };

  const onFinish = (values) => {
    api.primaryaddress(values).then((res)=>{
      if(res.status===200 && res.statusText==="OK") {
        get_company_details();
        message.success("Successfully Saved");
        form.resetFields();
        setIsModalOpen(false);
      }
    }).catch((err)=>{})
  }

  const listcountry = () => {
    api.country().then((res) => {
      let data = res.data;
      setCountry(data?.filter((item)=>{
        return item?._id == company?.address?.country;
      }))
      setCountryList(data)
    
    }).catch((err) => {});
  }

  
  const liststate = () => {
    api.state().then((res) => {
      let data = res.data;
      setState(data?.filter((item)=>{
        return item?._id == company?.address?.state;
      }))
      setStateList(data)
    }).catch((err) => {

    });

  }

  const listdistrict = () => {
    api.district().then((res) => {
      let data = res.data;
      setDistrict(data?.filter((item)=>{
        return item?._id == company?.address?.district;
      }))
      setDistrictList(data)
    }).catch((err) => {

    });

  }
  console.log(company)
  useEffect(()=>{
    listcountry();
    liststate();
    listdistrict();
  },[loading])


  const country_list = [];

  countryList?.map((item) => {
    country_list.push({
      value: item?._id,
      label: item?.name,
    })
  });

  const state_list = [];

  stateList?.map((item) => {
    state_list.push({
      value: item?._id,
      label: item?.name,
    })
  });

  const district_list = [];

  districtList?.map((item) => {
    district_list.push({
      value: item?._id,
      label: item?.name,
    })
  });
  return (
    <React.Fragment>
      <CompanyAddress>
        <div className='company_address'>
        <div className='edit_option'>
            <Button type='primary' size='small' onClick={showModal}><FormOutlined />Edit</Button>
          </div>
          <Modal
            title="Edit Primary Details"
            open={isModalOpen}
            onOk={handleOk}
            onCancel={handleCancel}
            okText="Save"
            footer={null}
            width={750}
          >
            <Form
              name="country_edit"
              layout="vertical"
              onFinish={onFinish}
              form={form}
            >
              <Row gutter={16}>
              <Col className="gutter-row" xxl={{ span: 24 }} xl={{ span: 24 }} lg={{ span: 24 }} md={{ span: 24 }} sm={{ span: 24 }} xs={{ span: 24 }}>
              <Form.Item label="Description" name="address_line1">
              <TextArea rows={3} name="address_line1" />
            </Form.Item>
                </Col>
                
                <Col className="gutter-row" xxl={{ span: 12 }} xl={{ span: 12 }} lg={{ span: 12 }} md={{ span: 12 }} sm={{ span: 24 }} xs={{ span: 24 }}>
                  <Form.Item
                    label="Locality"
                    name="address_line2"
                    
                  >
                    <Input name="address_line2" />
                  </Form.Item>
                </Col>
                <Col className="gutter-row" xxl={{ span: 12 }} xl={{ span: 12 }} lg={{ span: 12 }} md={{ span: 12 }} sm={{ span: 24 }} xs={{ span: 24 }}>
                <Form.Item
              label="Country"
              name="country"
              rules={[
                {
                  required: true,
                  message: 'Please entry country name!',
                },
              ]}
            >
              <Select
                showSearch

                placeholder="Search Country"
                optionFilterProp="children"
                filterOption={(input, option) => (option?.label ?? '').includes(input)}
                filterSort={(optionA, optionB) =>
                  (optionA?.label ?? '').toLowerCase().localeCompare((optionB?.label ?? '').toLowerCase())
                }
                options={country_list} />
            </Form.Item>
                </Col>
                <Col className="gutter-row" xxl={{ span: 12 }} xl={{ span: 12 }} lg={{ span: 12 }} md={{ span: 12 }} sm={{ span: 24 }} xs={{ span: 24 }}>
                <Form.Item
              label="State"
              name="state"
              rules={[
                {
                  required: true,
                  message: 'Please entry state name!',
                },
              ]}
            >
              <Select
                showSearch

                placeholder="Search Country"
                optionFilterProp="children"
                filterOption={(input, option) => (option?.label ?? '').includes(input)}
                filterSort={(optionA, optionB) =>
                  (optionA?.label ?? '').toLowerCase().localeCompare((optionB?.label ?? '').toLowerCase())
                }
                options={state_list} />
            </Form.Item>
                </Col>
                <Col className="gutter-row" xxl={{ span: 12 }} xl={{ span: 12 }} lg={{ span: 12 }} md={{ span: 12 }} sm={{ span: 24 }} xs={{ span: 24 }}>
                <Form.Item
              label="District"
              name="district"
              rules={[
                {
                  required: true,
                  message: 'Please entry district name!',
                },
              ]}
            >
              <Select
                showSearch

                placeholder="Search Country"
                optionFilterProp="children"
                filterOption={(input, option) => (option?.label ?? '').includes(input)}
                filterSort={(optionA, optionB) =>
                  (optionA?.label ?? '').toLowerCase().localeCompare((optionB?.label ?? '').toLowerCase())
                }
                options={district_list} />
            </Form.Item>
                </Col>
                <Col className="gutter-row" xxl={{ span: 12 }} xl={{ span: 12 }} lg={{ span: 12 }} md={{ span: 12 }} sm={{ span: 24 }} xs={{ span: 24 }}>
                  <Form.Item
                    label="Area"
                    name="area"
                  >
                    <Input name="area" />
                  </Form.Item>
                </Col>
                <Col className="gutter-row" xxl={{ span: 12 }} xl={{ span: 12 }} lg={{ span: 12 }} md={{ span: 12 }} sm={{ span: 24 }} xs={{ span: 24 }}>
                  <Form.Item
                    label="Pincode"
                    name="pincode"

                  >
                    <InputNumber name="pincode" style={{width:"100%"}} />
                  </Form.Item>
                </Col>
              </Row>
              <Button type="primary" htmlType="submit">
                Save
              </Button>
            </Form>
          </Modal>
          <div className='primary_details'>
              <Row gutter={[30, 30]}>
              <Col className="gutter-row" xxl={{ span: 24 }} xl={{ span: 24 }} lg={{ span: 24 }} md={{ span: 24 }} sm={{ span: 24 }} xs={{ span: 24 }}>
                <span>Door Number / Street:</span>
                <span className='span_textarea'>{company?.address?.address_line1}</span>
              </Col>
              <Col className="gutter-row" xxl={{ span: 12 }} xl={{ span: 12 }} lg={{ span: 12 }} md={{ span: 12 }} sm={{ span: 24 }} xs={{ span: 24 }}>
                <span>Locality:</span>
                <span>{company?.address?.address_line2}</span>
              </Col>
              <Col className="gutter-row" xxl={{ span: 12 }} xl={{ span: 12 }} lg={{ span: 12 }} md={{ span: 12 }} sm={{ span: 24 }} xs={{ span: 24 }}>
                <span>Country:</span>
                <span>{country[0]?.name}</span>
                </Col>
              <Col className="gutter-row" xxl={{ span: 12 }} xl={{ span: 12 }} lg={{ span: 12 }} md={{ span: 12 }} sm={{ span: 24 }} xs={{ span: 24 }}>
                <span>State:</span>
                <span>{state[0]?.name}</span>
                </Col>
              <Col className="gutter-row" xxl={{ span: 12 }} xl={{ span: 12 }} lg={{ span: 12 }} md={{ span: 12 }} sm={{ span: 24 }} xs={{ span: 24 }}>
                <span>District:</span>
                <span>{district[0]?.name}</span>
                </Col>
              <Col className="gutter-row" xxl={{ span: 12 }} xl={{ span: 12 }} lg={{ span: 12 }} md={{ span: 12 }} sm={{ span: 24 }} xs={{ span: 24 }}>
                <span>Area:</span>
                <span>{company?.address?.area}</span>
                </Col>
              <Col className="gutter-row" xxl={{ span: 12 }} xl={{ span: 12 }} lg={{ span: 12 }} md={{ span: 12 }} sm={{ span: 24 }} xs={{ span: 24 }}>
                <span>Pincode:</span>
                <span>{company?.address?.pincode}</span>
                </Col>
              
                </Row>
          </div>
        </div>
      </CompanyAddress>
    </React.Fragment>
  )
}

export default Address;

const CompanyAddress = styled.section`
  width: 100%;
  display: inline-block;
  position: relative;

  .company_address {
    display: inline-block;
    width: 100%;
    position: relative;
  }


  .primary_details {
    width: 100%;
    position: relative;
    display: inline-block;
  }
  ul {
    margin: 15px 0 0 0;
    padding: 0;
    width: 100%;
    display: grid;
    grid-template-columns: repeat(2,1fr);
    gap: 30px 30px;
  }
  li {
    list-style: none;
  }
  .primary_details span:nth-child(1) {
    font-family: "q_bold";
    font-size: 15px;
    width: 100%;
    display: inline-block;
    margin: 0 0 4px;
  }
  .primary_details span:nth-child(2) {
    font-family: "q_regular";
    font-size: 14px;
    width: 100%;
    border: 1px solid #d8dadb;
    display: inline-block;
    padding: 5px 10px;
    border-radius: 4px;
    cursor: not-allowed;
    min-height: 34px;
}

.span_textarea {
  min-height: 85px;
}




`;