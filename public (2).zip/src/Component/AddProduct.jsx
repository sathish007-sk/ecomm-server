import React, { useState, useEffect, useRef } from "react";
import {
  Button,
  Form,
  Input,
  Select,
  Tabs,
  Switch,
  Space,
  Divider,
  Checkbox,
  Row,
  InputNumber,
  DatePicker,
  Card,
  Col,
  Modal,
  Upload,
  message,
 
} from "antd";
import {

  PlusCircleOutlined,

} from "@ant-design/icons";
import styled from "styled-components";
import API from "../Store/Api/ApiService";
import ReactQuill from "react-quill";
import "react-quill/dist/quill.snow.css";
import { useNavigate } from "react-router-dom";
import { TreeSelect } from "antd";
import { useParams } from "react-router-dom";
import {
  SafetyOutlined,
  ToolOutlined,
  TagOutlined,
  ApartmentOutlined,
  ProfileOutlined,
  SettingOutlined,
  MinusCircleOutlined,
  PlusOutlined,
  HighlightOutlined,
  AccountBookOutlined,
  ArrowLeftOutlined,
} from "@ant-design/icons";
import { useForm } from "antd/es/form/Form";
const { TextArea } = Input;
const { Option } = Select;

const AddProduct = () => {
  const [value, setValue] = useState("");
  const [form] = Form.useForm();
  const [productTitle, setProductTitle] = useState("");
  const [previewOpen, setPreviewOpen] = useState(false);
  const [previewImage, setPreviewImage] = useState("");
  const [previewTitle, setPreviewTitle] = useState("");
  const [fileList, setFileList] = useState([]);
  const [saving, setSaving] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [tabRes, setTabRes] = useState("left");
  const [loading2, setLoading2] = useState(false);


  const navigate = useNavigate();
  const windowSize = useRef([window.innerWidth, window.innerHeight]);
  const api = new API();
  const [category, setCategory] = useState([]);
  const [c_name, setCategoryname] = useState([]);
   const [isModalOpen1, setIsModalOpen1] = useState(false);
  const [c_id, setC_id] = useState("");
  const [brand, setbrand] = useState([]);
  const [b_name, setBrandname] = useState([]);
   const handleOk1 = () => {
     setIsModalOpen1(false);
   };
   const params = useParams();

   useEffect(() => {
     console.log(params);
     let { id } = params;

     const data = {
       url1: "product",
       Url1: "Product",
       id: id,
     };
     api
       .Viewdata(data)
       .then((res) => {
         console.log("wddddee", res);
         if (res.data.success === true) {
           console.log("uuuuuu", res.data.result.description);
           setCategory(res.data.result);
             form.setFieldsValue({
               description: res?.data?.result?.description
                 ? res?.data?.result?.description
                 : "",
               sp: res?.data?.result?.sp

                 ? res?.data?.result?.description
                 : "",
               e_parent: res?.data?.data[0]?.sparentid
                 ? res?.data?.data[0]?.sparentid
                 : "",

               e_id: res?.data?.data[0]?.mainid
                 ? res?.data?.data[0]?.mainid
                 : "",
             });

         } else {
           setCategory([]);
         }
       })
       .catch((err) => {
         setCategory([]);
       });
   }, []);
   
  
 

   const addnew_category = () => {
     setIsModalOpen1(true);
   };  

  const onChangeSelect =(e)=>{
       setValue(e);
  }
    const onFinishCategory = (values) => {
      setLoading2(true);
      const brand_name = values["name"];
      const parent_name = values["parent"];
      const status = values["status"] === true ? 1 : 0;
      let addNew = {
        name: brand_name,
        status: status,
        type: "brand",
        parentid: parent_name,
      };

      if (
        (brand_name !== "" || brand_name !== undefined) &&
        (status !== "" || status !== undefined) &&
        addNew?.type === "brand"
      ) {
        api
          .addbrand(addNew)
          .then((res) => {
            if (res.data.success === true) {
              setLoading2(false);
              form.resetFields();
              setIsModalOpen1(false);
              message.success("Added successfully");
              getAllCategory();
            } else if (res.data.success === false) {
              message.warning(res.data.msg);
              setLoading2(false);
            } else {
              message.error("Something went wrong!. Please try again!");
              setLoading2(false);
            }
          })
          .catch((err) => {
            setLoading2(false);
          });
      } else {
        message.error("Something went wrong!. Please try again!");
        setLoading2(false);
      }
    };
  

  const getAllCategory = () => {
 
      const data = {
        url1: "mastersetting",
        Url1: "Mastersetting",
     };
    const mode = {
      mode: "category",
    };

    api
      .getbrandlist(data,mode)
      .then((res) => {
     
        if (res.data.success === true) {
         
          setCategory(res.data.result);
     
        } else {
       
          setCategory([]);
        }
      })
      .catch((err) => {
    
        setCategory([]);
      });
  };
  const getAllBrand = () => {
           const data = {
             url1: "mastersetting",
             Url1: "Mastersetting",
           };
           const mode = {
             mode: "brand",
           };

           api
             .getbrandlist(data, mode)
             .then((res) => {
               if (res.data.success === true) {
                 setbrand(res.data.result);
               } else {
                 setbrand([]);
               }
             })
             .catch((err) => {
               setbrand([]);
             });
  };
  const singleCategory = (action) => {
    let getSingle = {
      mainid: action,
      tete: "category",
    };
    api
      .getbrandsingle(getSingle)
      .then((res) => {
        if (res.data.success === true) {
          setCategoryname(res.data.data.name);
        } else {
          setCategoryname([]);
          message.error("Something went wrong!. Please try again!");
        }
      })
      .catch((err) => {
        setCategoryname([]);
      });
  };
  const singleBrand = (action) => {
    let getSingle = {
      mainid: action,
      type: "brand",
    };
    api
      .getbrandsingle(getSingle)
      .then((res) => {
        if (res.data.success === true) {
          console.log("---", res.data.data);
          setBrandname(res.data.data.name);
        } else {
          setBrandname([]);
          message.error("Something went wrong!. Please try again!");
        }
      })
      .catch((err) => {
        setBrandname([]);
      });
  };
  useEffect(() => {
    getAllCategory();
    getAllBrand();
  }, []);
  useEffect(() => {
    
  }, []);

  console.log("width", windowSize.current[0]);
  console.log("height", windowSize.current[1]);

  const tabCheck = () => {
    if (windowSize.current[0] <= 768) {
      setTabRes("top");
    } else {
      setTabRes("left");
    }
  };

  useEffect(() => {
    tabCheck();
  }, []);
   const handleCancel = () => {
     setIsModalOpen1(false);
   };
  const handlePreview = async (file) => {
    if (!file.url && !file.preview) {
      file.preview = await getBase64(file.originFileObj);
    }
    setPreviewImage(file.url || file.preview);
    setPreviewOpen(true);
    setPreviewTitle(
      file.name || file.url.substring(file.url.lastIndexOf("/") + 1)
    );
  };
  const getBase64 = (file) =>
    new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result);
      reader.onerror = (error) => reject(error);
    });
  const handleChange = ({ fileList: newFileList }) => setFileList(newFileList);
  const uploadButton = (
    <div>
      <PlusOutlined />
      <div
        style={{
          marginTop: 8,
        }}
      >
        Upload
      </div>
    </div>
  );
  const beforeUpload = (file) => {
    const isJpgOrPng =
      file.type === "image/jpeg" ||
      file.type === "image/png" ||
      file.type === "image/webp" ||
      file.type === "image/jpg";
    if (!isJpgOrPng) {
      message.error("You can only upload JPG/PNG/WEBP file!");
    }
    const isLt2M = file.size / 1024 / 1024 < 2;
    if (!isLt2M) {
      message.error("Image must smaller than 2MB!");
    }
    return isJpgOrPng && isLt2M;
  };

  const showModal = () => {
    setIsModalOpen(true);
  };
  const handleOk = () => {
    setIsModalOpen(false);
  };
  const handleCancel1 = () => {
    setIsModalOpen(false);
  };
  const user = JSON.parse(localStorage.getItem("persist:root"))?.user;
  const addedby = user && JSON.parse(user).user?.user?._id;
  const company = user && JSON.parse(user).user?.user?.company;
  const brand_list = [];
  const treeData = [];


  brand?.map((item) => {
    brand_list.push({
      value: item?._id,
      label: item?.name,
    });
  });
   const Category_list = [];

  category?.map((item) => {
     Category_list.push({
       value: item?._id,
       label: item?.name,
     });
   });

  const addNewProduct = (values) => {
    console.log(values);
    console.log("-value", c_id);

    const productname = values["name"];
    const productcode = values["p_code"];
    const hsncode = values["hsncode"];
    const tax = values['tax']
    const categorysubid = "3";

    const costprice = values["mrp"];
    const sellingprice = values["sp"];
    const categoryid = values["c_id"];
    const brandid = values["b_id"];

    const unit = values["unit"];
    const pack = values["pack"];
    const inclusivetax = "ev";
    const description = values["des"];
    const defaultmargin = values["d_margin"];
    const status = values["status"] === true ? 1 : 0;
    const companyid = "aE4yYkZka1NtZHh2eTBYQ28yRFZIUT09";

    // const status = 1;

    let addNew = {
      productname,
      productcode,
      hsncode,
      costprice,
      sellingprice,
      companyid,
      categorysubid,
      tax,
      unit,
      status,
      brandid,
      categoryid: c_id,
      description,
      pack,
      status,
      defaultmargin,
      inclusivetax,
    };

    // let data = {
    //   companyid: "ZUwxQ3dnT3JUb1BiWWpEbkl0NFY2UT09",
    //   productname: "2.0 cable",
    //   hsncode: 45546563,
    //   tax: 11.0,
    //   productcode: "AA126",
    //   costprice: 100.0,
    //   defaultmargin: 10.0,
    //   sellingprice: 150.0,
    //   unit: "Nos",
    //   brandid: 35,
    //   categoryid: 37,
    //   categorysubid: 41,
    //   description: "poly wire wrapping",
    //   pack: 5,
    //   inclusivetax: 1,
    //   status: 1,
    // };

     let data={

      companyid: "aE4yYkZka1NtZHh2eTBYQ28yRFZIUT09",
      productname: "Sathish",
      hsncode: "445577",
      tax: "18.000",
      productcode: "9087",
      costprice: "750.0000",
      defaultmargin: "20.00",
      sellingprice: "90.0000",
      unit: "Nos",
      brandid: "1",
      categoryid: "1",
      categorysubid: "1",
      description: "test case",
    pack: "2",
    inclusivetax: "1",
      status: "1",


     }

    console.log("addNew", addNew);

    api
      .addbrand(data)
      .then((res) => {
        console.log(res);

        if (res.data.success === true) {
          setLoading2(false);
          message.success("Added successfully");
          form.resetFields();

          getAllCategory();
        } else if (res.data.success === false) {
          message.warning(res.data.msg);
        } else {
          message.error("Something went wrong!. Please try again!");
        }
      })
      .catch((err) => {
        setLoading2(false);
      });
 
    if ((productname !== "" || productname !== undefined) && (status !== "" || status !== undefined) ) {
      api.addproduct(addNew).then((res) => {
        if (res.data.success === true) {
            console.log('----res', res)
              setLoading2(false)
                form.resetFields();

               message.success("Added successfully");
                  navigate('/product')
          getAllCategory();

        } else if (res.data.success === false) {
          message.warning(res.data.msg);
          setLoading2(false)
        } else {
          message.error("Something went wrong!. Please try again!");
          setLoading2(false)
        }
      }).catch((err) => { setLoading2(false) })
    } else {
      message.error("Something went wrong!. Please try again!");
      setLoading2(false)
    }
  };

  return (
    <React.Fragment>
      {/* <Modal
        title="Create ProductImage"
        open={isModalOpen1}
        onOk={handleOk1}
        onCancel={handleCancel1}
        okText="Create"
        width={400}
        footer={null}
      >
        <Form
          name="country_edit"
          layout="vertical"
          onFinish={onFinishCategory}
          form={form}
        >
          <Form.Item
            label="ProductimageTitle"
            name="name"
            rules={[
              {
                required: true,
                message: "ProductimageTitle is required!",
              },
            ]}
          >
            <Input type="text" name="name" />
          </Form.Item>
          <Form.Item
            label="Category"
            rules={[
              {
                required: true,
                message: "category is required",
              },
            ]}
          >
            <TreeSelect
              showSearch
              style={{
                width: "100%",
              }}
              value={value}
              dropdownStyle={{
                maxHeight: 400,
                overflow: "auto",
              }}
              placeholder="Please select"
              allowClear
              multiple
              treeDefaultExpandAll
              // onChange={onChange}
              // treeData={items}
            />
          </Form.Item>

          <Form.Item label="Brand" name="brand">
            <Select
              showSearch
              placeholder="Search to Select"
              optionFilterProp="children"
              filterOption={(input, option) =>
                (option?.label ?? "").includes(input)
              }
              filterSort={(optionA, optionB) =>
                (optionA?.label ?? "")
                  .toLowerCase()
                  .localeCompare((optionB?.label ?? "").toLowerCase())
              }
              options={brand_list}
            />
          </Form.Item>
          <Form.Item label="Category" name="category">
            <Select
              showSearch
              placeholder="Search to Select"
              optionFilterProp="children"
              filterOption={(input, option) =>
                (option?.label ?? "").includes(input)
              }
              filterSort={(optionA, optionB) =>
                (optionA?.label ?? "")
                  .toLowerCase()
                  .localeCompare((optionB?.label ?? "").toLowerCase())
              }
              // options={category_list}
            />
          </Form.Item>

          <div className="switch_btn">
            <Form.Item
              label="Status"
              valuePropName="checked"
              name="status"
              rules={[
                {
                  required: true,
                  message: "Status is required!",
                },
              ]}
            >
              <Switch />
            </Form.Item>
          </div>
          <Button type="primary" htmlType="submit" loading={loading2}>
            Save
          </Button>
        </Form>
      </Modal> */}
      {/* <Card
        title="Card title"
        bordered={false}
        style={{
          width: 600,
          height: 200,
        }}
      >
        <Button type="primary" size="small" onClick={() => addnew_category()}>
          <PlusCircleOutlined />
          New
        </Button>
        <BgWight>
          <Form.Item
            label="Enter Product Name"
            values={productTitle}
            onChange={(e) => setProductTitle(e.target.value.trim())}
            tooltip="Product Name"
            name="name"
            rules={[
              {
                required: true,
                message: "Please enter product name",
              },
            ]}
          >
            <Input placeholder="Product name" />
          </Form.Item>
          <Form.Item label="Product Description" tooltip="Product Description">
            <ReactQuill
              theme="snow"
              value={value}
              onChange={setValue}
              className="pro_dec"
            />
          </Form.Item>
        </BgWight>
      </Card> */}
      <AddProductSection>
        <div className="page_back_align">
          <p onClick={() => navigate(-1)} className="go_back">
            <ArrowLeftOutlined /> &nbsp; Add Product
          </p>
        </div>
        <Form
          layout="vertical"
          size="medium"
          name="add_new_product"
          onFinish={addNewProduct}
          form={form}
        >
          <NewProductSection>
            <NewProductLeft>
              <BgWight>
                <Form.Item
                  label="Enter Product Name"
                  values={productTitle}
                  onChange={(e) => setProductTitle(e.target.value.trim())}
                  tooltip="Product Name"
                  name="name"
                  rules={[
                    {
                      required: true,
                      message: "Please enter product name",
                    },
                  ]}
                >
                  <Input placeholder="Product name" />
                </Form.Item>
                <Form.Item
                  label="Product Description"
                  name="description"
                  rules={[
                    {
                      required: true,
                      message: "Please enter product name",
                    },
                  ]}
                >
                  <Input placeholder="description" name="description" />
                </Form.Item>
              </BgWight>
              <BgWight>
                <Form.Item
                  label="Product Type"
                  layout="inline"
                  name="producttype"
                  tooltip="Product Type"
                  rules={[
                    {
                      required: true,
                      message: "Please choose product type",
                    },
                  ]}
                >
                  <Select placeholder="Product Type" allowClear>
                    <Option value="simple">Simple Product</Option>
                    <Option value="varible">Varible Product</Option>
                  </Select>
                </Form.Item>
                <Form.Item label="Product Data" tooltip="Product Data">
                  <MyAccountAlign>
                    <Tabs defaultActiveKey="1" tabPosition={tabRes}>
                      <Tabs.TabPane
                        tab={
                          <>
                            <ToolOutlined />
                            Product rate
                          </>
                        }
                        key="1"
                      >
                        <Dimension2>
                          <Form.Item
                            label="Buying price"
                            name="mrp"
                            className="flex_row"
                          >
                            <InputNumber name="mrp " />
                          </Form.Item>
                          <Form.Item
                            label="Selling price"
                            name="sp"
                            className="flex_row"
                          >
                            <InputNumber name="sp " />
                          </Form.Item>
                          <Form.Item
                            label="Selling price Margin"
                            name="spm"
                            className="flex_row"
                          >
                            <InputNumber name="min_order_qty " />
                          </Form.Item>
                          <Form.Item
                            label="Discount"
                            name="discount"
                            className="flex_row"
                          >
                            <Input placeholder="Discount" />
                          </Form.Item>
                          <Form.Item
                            label="Min Order Quantity"
                            name="min_order_qty"
                            className="flex_row"
                          >
                            <InputNumber name="min_order_qty " />
                          </Form.Item>
                          {/*  <Form.Item
                            label="Default Margin"
                            name="d_margin"
                            className="flex_row"
                            rules={[
                              {
                                required: true,
                                message: "Please enter SKU ID",
                              },
                            ]}
                          >
                            <Input placeholder="Default margin" />
                          </Form.Item>
                          <Form.Item
                            label="Unit"
                            name="unit"
                            className="flex_row"
                            rules={[
                              {
                                required: true,
                                message: "Please enter SKU ID",
                              },
                            ]}
                          >
                            <Input placeholder="Unit" />
                          </Form.Item>
                          <Form.Item
                            label="Pack"
                            name="pack"
                            className="flex_row"
                            rules={[
                              {
                                required: true,
                                message: "Please enter Pack",
                              },
                            ]}
                          >
                            <Input placeholder="Pack" />
                          </Form.Item>

                          <Form.Item label="brand" name="b_id">
                            <Select
                              showSearch
                              placeholder="Search to Select"
                              optionFilterProp="children"
                              filterOption={(input, option) =>
                                (option?.label ?? "").includes(input)
                              }
                              filterSort={(optionA, optionB) =>
                                (optionA?.label ?? "")
                                  .toLowerCase()
                                  .localeCompare(
                                    (optionB?.label ?? "").toLowerCase()
                                  )
                              }
                              options={brand_list}
                            />
                          </Form.Item>
                          {/* Tree */}
                          {/* <TreeSelect
                            style={{ width: "100%" }}
                            value={value}
                            dropdownStyle={{ maxHeight: 400, overflow: "auto" }}
                            treeData={treeData}
                            placeholder="Please select"
                            treeDefaultExpandAll
                            onChange={onChangeSelect}
                          />
                          <Form.Item label="Category" name="c_id">
                            <Select
                              showSearch
                              placeholder="Search to Select"
                              optionFilterProp="children"
                              filterOption={(input, option) =>
                                (option?.label ?? "").includes(input)
                              }
                              filterSort={(optionA, optionB) =>
                                (optionA?.label ?? "")
                                  .toLowerCase()
                                  .localeCompare(
                                    (optionB?.label ?? "").toLowerCase()
                                  )
                              }
                              options={Category_list}
                            />
                          </Form.Item>
                          <Form.Item
                            label="Brand Id"
                            name="b_id"
                            className="flex_row"
                            rules={[
                              {
                                required: true,
                                message: "Please enter Brand Id",
                              },
                            ]}
                          >
                            <Input placeholder="Brand Id" />
                          </Form.Item>
                          <Form.Item
                            label="Description"
                            name="des"
                            className="flex_row"
                            rules={[
                              {
                                required: true,
                                message: "Please enter Description",
                              },
                            ]}
                          >
                            <Input placeholder="Description" />
                          </Form.Item>
                          <div className="switch_btn">
                            <Form.Item
                              label="Status"
                              valuePropName="checked"
                              name="status"
                              rules={[
                                {
                                  required: true,
                                  message: "Status is required!",
                                },
                              ]}
                            >
                              <Switch />
                            </Form.Item>
                          </div>
                          <Form.Item
                            label="AddProduct"
                            name="tax"
                            className="flex_row"
                            rules={[
                              {
                                required: true,
                                message: "Please enter AddProduct",
                              },
                            ]}
                          >
                            <Input placeholder="AddProduct" />
                          </Form.Item>
                          <Form.Item
                            label="SKU"
                            name="sku"
                            className="flex_row"
                            tooltip="Product SKU"
                            rules={[
                              {
                                required: true,
                                message: "Please enter SKU ID",
                              },
                            ]}
                          >
                            <Input placeholder="SKU ID" />
                          </Form.Item>
                          <Form.Item
                            label="Brand Name"
                            layout="inline"
                            name="b_name"
                            tooltip="Brand Name"
                          >
                            <Select placeholder="Choose Brand Name" allowClear>
                              <Option value="Smile">Smile</Option>
                            </Select>
                          </Form.Item>
                          <Form.Item
                            label="Model ID"
                            name="model"
                            className="flex_row"
                            tooltip="Model ID"
                          >
                            <Input placeholder="Model id" />
                          </Form.Item>
                          <Form.Item
                            label="Unit"
                            name="unit"
                            className="flex_row"
                            rules={[
                              {
                                required: true,
                                message: "Please enter unit",
                              },
                            ]}
                          >
                            <Input placeholder="Unit" />
                          </Form.Item>{" "}
                          */}
                          <Form.Item
                            label="Delivery Date"
                            name="deliverydate"
                            className="flex_row"
                            tooltip="Delivery Date"
                          >
                            <DatePicker name="deliverydate " />
                          </Form.Item>
                          <Form.Item
                            label="Delivery Days"
                            name="d_days"
                            className="flex_row"
                            tooltip="Delivery Days"
                          >
                            <InputNumber name="d_days" />
                          </Form.Item>
                        </Dimension2>
                      </Tabs.TabPane>

                      <Tabs.TabPane
                        tab={
                          <>
                            <TagOutlined />
                            Inventory
                          </>
                        }
                        key="2"
                      >
                        <Dimension2>
                          <Form.Item
                            label="Stock Quantity"
                            name="stockquantity"
                            className="flex_row"
                            tooltip="Stock Quantity"
                          >
                            <Input placeholder="Stock Quantity" />
                          </Form.Item>
                          <Form.Item
                            label="Stock Status"
                            layout="inline"
                            name="managestock"
                            tooltip="Stock Status"
                          >
                            <Select
                              placeholder="Choose stock status"
                              allowClear
                            >
                              <Option value="instock">In Stock</Option>
                              <Option value="outofstock">Out of Stock</Option>
                            </Select>
                          </Form.Item>
                        </Dimension2>
                      </Tabs.TabPane>
                      <Tabs.TabPane
                        tab={
                          <>
                            <ApartmentOutlined />
                            Paking
                          </>
                        }
                        key="3"
                      >
                        <Dimension2>
                          <Form.Item
                            label="Weight"
                            name="weight"
                            className="flex_row"
                            tooltip="Weight "
                          >
                            <InputNumber name="weight" />
                          </Form.Item>
                          <Form.Item
                            label="Height"
                            name="height"
                            className="flex_row"
                            tooltip="Weight "
                          >
                            <InputNumber name="height" />
                          </Form.Item>
                          <Form.Item
                            label="Length"
                            name="length"
                            className="flex_row"
                            tooltip="Length"
                          >
                            <InputNumber name="length" />
                          </Form.Item>
                          <Form.Item
                            label="Breadth"
                            name="breadth"
                            className="flex_row"
                            tooltip="Breadth"
                          >
                            <InputNumber name="breadth" />
                          </Form.Item>
                        </Dimension2>
                      </Tabs.TabPane>
                      <Tabs.TabPane
                        tab={
                          <>
                            <ApartmentOutlined />
                            DeliveryCharges
                          </>
                        }
                        key="3"
                      >
                        <Dimension2>
                          <Form.Item
                            label="Local Delivery Charge"
                            name="local_d_cahrges"
                            className="flex_row"
                            tooltip="Local Delivery Charge "
                          >
                            <InputNumber name="local_d_cahrges" />
                          </Form.Item>
                          <Form.Item
                            label="Zonal Delivery Charge"
                            name="zonal_d_charge"
                            className="flex_row"
                            tooltip="Zonal Delivery Charge "
                          >
                            <InputNumber name="zonal_d_charge" />
                          </Form.Item>
                          <Form.Item
                            label="National Delivery Charge"
                            name="national_d_charge"
                            className="flex_row"
                            tooltip="Zonal Delivery Charge "
                          >
                            <InputNumber name="national_d_charge" />
                          </Form.Item>
                        </Dimension2>
                      </Tabs.TabPane>
                      <Tabs.TabPane
                        tab={
                          <>
                            <ProfileOutlined />
                            Specification
                          </>
                        }
                        key="4"
                      >
                        <Form.List name="specification">
                          {(fields, { add, remove }) => (
                            <>
                              {fields.map(({ key, name, ...restField }) => (
                                <Space
                                  key={key}
                                  style={{
                                    display: "flex",
                                    marginBottom: 8,
                                  }}
                                  align="baseline"
                                >
                                  <Form.Item
                                    {...restField}
                                    name={[name, "sname"]}
                                    rules={[
                                      {
                                        required: true,
                                        message: "Enter Name",
                                      },
                                    ]}
                                  >
                                    <Input
                                      placeholder="Enter Name"
                                      style={{ width: "150px" }}
                                    />
                                  </Form.Item>
                                  <Form.Item
                                    {...restField}
                                    name={[name, "svalue"]}
                                    rules={[
                                      {
                                        required: true,
                                        message: "Enter Description",
                                      },
                                    ]}
                                  >
                                    <Input
                                      placeholder="Enter Description"
                                      style={{ width: "300px" }}
                                    />
                                  </Form.Item>
                                  <MinusCircleOutlined
                                    onClick={() => remove(name)}
                                  />
                                </Space>
                              ))}
                              <Form.Item>
                                <Button
                                  type="dashed"
                                  onClick={() => add()}
                                  block
                                  icon={<PlusOutlined />}
                                >
                                  Add Specification
                                </Button>
                              </Form.Item>
                            </>
                          )}
                        </Form.List>
                      </Tabs.TabPane>

                      <Tabs.TabPane
                        tab={
                          <>
                            <HighlightOutlined />
                            Highlights
                          </>
                        }
                        key="7"
                      >
                        <Form.List name="highlights">
                          {(fields, { add, remove }) => (
                            <>
                              {fields.map(({ key, name, ...restField }) => (
                                <Space
                                  key={key}
                                  style={{
                                    display: "flex",
                                    marginBottom: 8,
                                  }}
                                  align="baseline"
                                >
                                  <Form.Item
                                    {...restField}
                                    name={[name, "hname"]}
                                    rules={[
                                      {
                                        required: true,
                                        message: "Enter Name",
                                      },
                                    ]}
                                  >
                                    <Input placeholder="Enter Name" />
                                  </Form.Item>
                                  <Form.Item
                                    {...restField}
                                    name={[name, "hvalue"]}
                                    rules={[
                                      {
                                        required: true,
                                        message: "Enter Description",
                                      },
                                    ]}
                                  >
                                    <Input placeholder="Enter Description" />
                                  </Form.Item>
                                  <MinusCircleOutlined
                                    onClick={() => remove(name)}
                                  />
                                </Space>
                              ))}
                              <Form.Item>
                                <Button
                                  type="dashed"
                                  onClick={() => add()}
                                  block
                                  icon={<PlusOutlined />}
                                >
                                  Add Highlights
                                </Button>
                              </Form.Item>
                            </>
                          )}
                        </Form.List>
                      </Tabs.TabPane>
                      <Tabs.TabPane
                        tab={
                          <>
                            <AccountBookOutlined />
                            AddProduct and GST
                          </>
                        }
                        key="9"
                      >
                        <Dimension2>
                          <Form.Item
                            label="AddProduct Persentage"
                            layout="inline"
                            name="tax"
                            tooltip="AddProduct Persentage"
                          >
                            <Select
                              placeholder="Choose AddProduct Persentage"
                              allowClear
                            >
                              <Option value="18">18</Option>
                            </Select>
                          </Form.Item>
                          <Form.Item
                            label="HSN Code"
                            name="hsncode"
                            className="flex_row"
                            tooltip="HSN Code"
                          >
                            <Input placeholder="HSN Code" />
                          </Form.Item>
                        </Dimension2>
                      </Tabs.TabPane>
                      <Tabs.TabPane
                        tab={
                          <>
                            <SettingOutlined />
                            Advanced
                          </>
                        }
                        key="5"
                      >
                        <Form.Item
                          label="Purchase Notes"
                          name="purchasenote"
                          tooltip="Purchase Notes"
                        >
                          <TextArea rows={4} />
                        </Form.Item>
                        <Dimension2>
                          <Form.Item
                            label="Product Visible Type"
                            layout="inline"
                            name="visible"
                            tooltip="Product Visible Type"
                          >
                            <Select
                              placeholder="Choose Visible Type"
                              allowClear
                            >
                              <Option value="true">True</Option>
                              <Option value="false">False</Option>
                            </Select>
                          </Form.Item>
                          <Form.Item
                            label="Product Publish Type"
                            layout="inline"
                            name="publish"
                            tooltip="Product Publish Type"
                          >
                            <Select
                              placeholder="Choose Publish Type"
                              allowClear
                            >
                              <Option value="true">True</Option>
                              <Option value="false">False</Option>
                            </Select>
                          </Form.Item>
                        </Dimension2>
                      </Tabs.TabPane>
                    </Tabs>
                  </MyAccountAlign>
                </Form.Item>
              </BgWight>
              <BgWight>
                <Form.Item
                  label="Meta Title"
                  values={productTitle}
                  onChange={(e) => setProductTitle(e.target.value.trim())}
                  tooltip="Meta Title"
                  name="p_title"
                  rules={[
                    {
                      required: true,
                      message: "Please enter product name",
                    },
                  ]}
                >
                  <Input placeholder="Meta Title" />
                </Form.Item>
                <Form.Item
                  label="Meta Description"
                  name="metadescription"
                  tooltip="Meta Description"
                >
                  <TextArea rows={3} placeholder="Meta Description" />
                </Form.Item>
                <Form.Item
                  label="Meta Keywords"
                  name="metakeywords"
                  tooltip="Meta Keywords"
                >
                  <TextArea rows={3} placeholder="Meta Keywords" />
                </Form.Item>
              </BgWight>
            </NewProductLeft>
            <NewProductRight>
              <PublishRow>
                <Text></Text>
                <Button
                  type="primary"
                  size="small"
                  htmlType="submit"
                  loading={saving}
                >
                  <SafetyOutlined />
                  Publish
                </Button>
              </PublishRow>
              <Divider />
              <H4>Product Categories</H4>
              <CatsBox className="catboxs">
                <Checkbox.Group>
                  <Row>
                    <Col span={24}>
                      <Form.Item label="categories" layout="inline" name="c_id">
                        {category?.map((item, i) => (
                          <Checkbox
                            value={item.mainid}
                            onChange={(e) => setC_id(e.target.value)}
                            key={i}
                          >
                            {item.name}
                          </Checkbox>
                        ))}
                      </Form.Item>
                    </Col>
                  </Row>
                </Checkbox.Group>
              </CatsBox>
              <CatsNew>
                <Button type="dashed" block onClick={showModal}>
                  <PlusOutlined />
                  Add New Category
                </Button>
                <Modal
                  title="Add New Category"
                  open={isModalOpen}
                  onOk={handleOk}
                  onCancel={handleCancel1}
                  footer={null}
                >
                  <p>Some contents...</p>
                  <p>Some contents...</p>
                  <p>Some contents...</p>
                </Modal>
              </CatsNew>
              <Divider />
              <CatsBox className="catboxs">
                <Checkbox.Group>
                  <Row>
                    {category?.map((item, i) => (
                      <Col span={24} key={i}>
                        <Checkbox value={c_id}>{item.categoryname}</Checkbox>
                      </Col>
                    ))}
                  </Row>
                </Checkbox.Group>
              </CatsBox>
              <Thumbnail>
                <H4>Product Image</H4>
                <Upload
                  action={process.env.REACT_APP_API}
                  listType="picture-card"
                  fileList={fileList}
                  multiple
                  name="image"
                  onPreview={handlePreview}
                  beforeUpload={beforeUpload}
                  onChange={handleChange}
                >
                  {fileList.length >= 5 ? null : uploadButton}
                </Upload>
                <Modal
                  open={previewOpen}
                  title={previewTitle}
                  footer={null}
                  onCancel={handleCancel}
                >
                  <img
                    alt="example"
                    style={{
                      width: "100%",
                    }}
                    src={previewImage}
                  />
                </Modal>
              </Thumbnail>
            </NewProductRight>
          </NewProductSection>
        </Form>
      </AddProductSection>
    </React.Fragment>
  );
};

export default AddProduct;

const AddProductSection = styled.section`
  .ant-form-vertical .ant-form-item-label > label {
    color: #2e2e2e;
    font-family: "q_medium";
  }
  .switch_btn .ant-row.ant-form-item-row.css-dev-only-do-not-override-sk7ap8 {
    flex-wrap: wrap !important;
  }
  .switch_btn .ant-row {
    display: flex !important;
    flex-direction: row !important;
    flex-flow: nowrap !important;
    align-items: center;
}
`;

const Dimension2 = styled.div`
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 0 24px;
  align-items: flex-end;

  @media screen and (max-width: 580px) {
    grid-template-columns: repeat(1, 1fr);
  }
`;

const CatsNew = styled.div`
  width: 100%;
  margin: 20px 0 0 0;
`;

const Thumbnail = styled.div`
  .ant-upload-wrapper.ant-upload-picture-card-wrapper
    .ant-upload.ant-upload-select {
    height: 80px;
    width: 80px;
  }
`;

const H4 = styled.div`
  font-size: 18px;
  font-family: "q_bold";
  margin: 0 0 20px;
`;
const CatsBox = styled.div`
  height: 215px;
  overflow: auto;
  border: 1px solid #d9d9d9;
  padding: 20px;
  border-radius: 4px;
  .ant-col-24 {
    margin: 0 0 10px;
  }
`;

const PublishRow = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 15px;
`;
const Text = styled.div``;

const NewProductSection = styled.div`
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  flex-wrap: wrap;

  .pro_dec {
    margin: 0 0 0px;
  }

  .ql-toolbar.ql-snow {
    border-radius: 6px 6px 0 0;
  }
  .ql-container.ql-snow {
    border-radius: 0 0 6px 6px;
    height: 150px;
  }

  .ant-tabs-left
    > .ant-tabs-content-holder
    > .ant-tabs-content
    > .ant-tabs-tabpane,
  .ant-tabs-left
    > div
    > .ant-tabs-content-holder
    > .ant-tabs-content
    > .ant-tabs-tabpane {
    padding: 24px;
  }

  .ant-form-item.flex_row .ant-row.ant-form-item-row {
    display: flex !important;
    flex-direction: row !important;
  }
  .ant-form-item.flex_row
    .ant-row.ant-form-item-row
    .ant-col-24.ant-form-item-label,
  .ant-col-xl-24.ant-form-item-label,
  .ant-form-vertical .ant-form-item-label {
    flex: 1 !important;
  }
  .ant-form-item.flex_row
    .ant-row.ant-form-item-row
    .ant-form-vertical
    .ant-form-item
    .ant-form-item-control {
    width: 100% !important;
    flex: 3 !important;
  }
  /* width */
  .catboxs::-webkit-scrollbar {
    width: 5px;
  }

  /* Track */
  .catboxs::-webkit-scrollbar-track {
    background: #f1f1f1;
  }

  /* Handle */
  .catboxs::-webkit-scrollbar-thumb {
    background: #888;
    border-radius: 5px;
  }

  /* Handle on hover */
  .catboxs::-webkit-scrollbar-thumb:hover {
    background: #555;
  }
`;
const MyAccountAlign = styled.div`
  width: 100%;
  display: inline-block;
  position: relative;
  margin: 10px 0 0 0;
  border: 1px solid #d9d9d97a;
  .ant-tabs.ant-tabs-left {
    padding: 0px 0;
  }
  .ant-tabs-content-holder {
    padding: 20px 0;
  }
  .ant-tabs-tab {
    padding: 4px 20px !important;
    font-size: 14px;

    width: 180px;
    color: #000;
  }
  .ant-tabs > .ant-tabs-nav .ant-tabs-nav-list,
  .ant-tabs > div > .ant-tabs-nav .ant-tabs-nav-list {
    padding: 15px 0;
  }
  .ant-tabs-tab.ant-tabs-tab-active .ant-tabs-tab-btn {
    color: rgb(13 110 253);
    font-weight: 400;
    font-size: 14px;
  }
  .ant-tabs-tab-btn,
  .ant-tabs-tab-btn,
  .ant-tabs-tab-remove,
  .ant-tabs-tab-remove {
    font-family: "q_bold";
    font-size: 14px;
  }
  .ant-tabs-ink-bar {
    background: rgb(13 110 253);
  }

  @media screen and (max-width: 768px) {
    .ant-tabs-content-holder {
      padding: 20px 15px;
    }
  }
`;
const NewProductLeft = styled.div`
  width: 72%;
  display: flex;
  flex-direction: column;
  gap: 30px;
  position: relative;
  /* padding: 24px; */
  /* box-shadow: 2px 4px 20px 1px rgb(201 201 201 / 30%);
  background: #fff; */
  min-height: 550px;

  @media screen and (max-width: 992px) {
    width: 100%;
  }

  @media screen and (max-width: 768px) {
    .ant-tabs > .ant-tabs-nav .ant-tabs-nav-list,
    .caKiHo .ant-tabs > div > .ant-tabs-nav .ant-tabs-nav-list {
      padding: 9px 0;
    }
  }
`;

const BgWight = styled.div`
  padding: 24px;
  box-shadow: 2px 4px 20px 1px rgb(201 201 201 / 30%);
  background: #fff;
  display: inline-block;
  width: 100%;
  border-radius: 5px;
`;
const NewProductRight = styled.div`
  width: 25%;
  display: inline-block;
  position: relative;
  padding: 24px;
  box-shadow: 2px 4px 20px 1px rgb(201 201 201 / 30%);
  background: #fff;
  min-height: 550px;
  border-radius: 8px;
  .ant-upload.ant-upload-select-picture-card,
  .ant-upload-list-picture-card-container {
    width: 85px !important;
    height: 85px !important;
  }

  @media screen and (max-width: 992px) {
    width: 100%;
    margin: 30px 0 0 0;
  }
`;





  
