import React,{useState,useEffect} from 'react'
import styled from 'styled-components'
import { Button,Row,Col,Form,Modal,Input,message } from 'antd';
import { FormOutlined } from "@ant-design/icons";
import API from '../Store/Api/ApiService';
const { TextArea } = Input;
const Map = () => {
  const [company, setCompany] = useState([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const api = new API();
  const [form] = Form.useForm();
  const get_company_details = () => {
    api.companydetails().then((res) => {
      if (res.status === 200 && res.statusText === "OK") {
        setCompany(res.data);
        form.setFieldsValue(res.data)
      }
    }).catch((err) => { })
  }
  console.log(company)
  useEffect(() => {
    get_company_details();
  }, []);

  const showModal = () => {
    setIsModalOpen(true);
  };
  const handleOk = () => {
    setIsModalOpen(false);
  };
  const handleCancel = () => {
    setIsModalOpen(false);
  };

  const onFinish = (values ) => {
    api.map(values).then((res)=>{
      if(res.status===200 && res.statusText==="OK") {
        get_company_details();
        message.success("Successfully Saved");
        form.resetFields();
        setIsModalOpen(false);
      }
    }).catch((err)=>{})
  }

  return (
    <React.Fragment>
      <MapSection>
          <div className='edit_option'>
            <Button type='primary' size='small' onClick={showModal}><FormOutlined />Edit</Button>
          </div>
          <Modal
            title="Edit Primary Details"
            open={isModalOpen}
            onOk={handleOk}
            onCancel={handleCancel}
            okText="Save"
            footer={null}
            width={750}
          >
            <Form
              name="country_edit"
              layout="vertical"
              onFinish={onFinish}
              form={form}
            >
              <Row gutter={16}>
                <Col className="gutter-row" xxl={{ span: 24 }} xl={{ span: 24 }} lg={{ span: 24 }} md={{ span: 24 }} sm={{ span: 24 }} xs={{ span: 24 }}>
                  <Form.Item
                    label="Map Embed"
                    name="map"
                    
                  >
                    <TextArea rows={5} name="map" />
                  </Form.Item>
                </Col>
                </Row>
              <Button type="primary" htmlType="submit">
                Save
              </Button>
            </Form>
          </Modal>
          <div className='primary_details'>
              <Row gutter={[30, 30]}>
              <Col className="gutter-row" xxl={{ span: 24 }} xl={{ span: 24 }} lg={{ span: 24 }} md={{ span: 24 }} sm={{ span: 24 }} xs={{ span: 24 }}>
                <span>Map Embed:</span>
                <span>{company?.map}</span>
              </Col>
              
                </Row>
          </div>
      </MapSection>
    </React.Fragment>
  )
}

export default Map

const MapSection = styled.section`
  width: 100%;
    position: relative;
    display: inline-block;
  .primary_details {
    width: 100%;
    position: relative;
    display: inline-block;
  }
  ul {
    margin: 15px 0 0 0;
    padding: 0;
    width: 100%;
    display: grid;
    grid-template-columns: repeat(2,1fr);
    gap: 30px 30px;
  }
  li {
    list-style: none;
  }
  .primary_details span:nth-child(1) {
    font-family: "q_bold";
    font-size: 15px;
    width: 100%;
    display: inline-block;
    margin: 0 0 4px;
  }
  .primary_details span:nth-child(2) {
    font-family: "q_regular";
    font-size: 14px;
    width: 100%;
    border: 1px solid #d8dadb;
    display: inline-block;
    padding: 5px 10px;
    border-radius: 4px;
    cursor: not-allowed;
    min-height: 34px;
    word-break: break-all;
}

`;