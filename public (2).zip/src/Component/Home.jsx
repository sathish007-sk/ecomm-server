import React from 'react'
import styled from 'styled-components';
import { Col, Row, Breadcrumb, Button, Table, Tag,Space } from 'antd';
import { ArrowUpOutlined, UserOutlined, ShoppingCartOutlined, WalletOutlined, DollarOutlined } from '@ant-design/icons';
import { Link } from 'react-router-dom';
import { Line, Column } from '@ant-design/plots';



const Home = () => {

  const columns = [
    {
      title: "Order Id",
      dataIndex: "id",
      key: "id",

    },
    {
      title: "Amout",
      dataIndex: "amout",
      key: "amout",
    },
    {
      title: "Payment Method",
      dataIndex: "method",
      key: "method",
    },
    {
      title: "Status",
      key: "status",
      dataIndex: "status",
      render: (_, { tags }) => (
        <>
          {tags.map((tag) => {
            let color = tag.length > 3 ? "geekblue" : "green";
            if (tag === "loser") {
              color = "volcano";
            }
            return (
              <Tag color={color} key={tag}>
                {tag.toUpperCase()}
              </Tag>
            );
          })}
        </>
      ),
    },

  ];

  const dataOrder = [
    {
      key: "1",
      id: "324376",
      amout: 580,
      method: "Bank Transfers",
      tags: ["pending"],
    },
    {
      key: "2",
      id: "324376",
      amout: 580,
      method: "Bank Transfers",
      tags: ["pending"],
    },
    {
      key: "3",
      id: "324376",
      amout: 580,
      method: "Bank Transfers",
      tags: ["pending"],
    },
    {
      key: "4",
      id: "324376",
      amout: 580,
      method: "Bank Transfers",
      tags: ["pending"],
    },

  ];
  const dataNew = [
    {
      year: '1991',
      value: 3,
    },
    {
      year: '1992',
      value: 4,
    },
    {
      year: '1993',
      value: 3.5,
    },
    {
      year: '1994',
      value: 5,
    },
    {
      year: '1995',
      value: 4.9,
    },
    {
      year: '1996',
      value: 6,
    },
    {
      year: '1997',
      value: 7,
    },
    {
      year: '1998',
      value: 9,
    },
    {
      year: '1999',
      value: 13,
    },
  ];
  const confi = {
    dataNew,
    xField: 'year',
    yField: 'value',
    label: {},
    point: {
      size: 5,
      shape: 'diamond',
      style: {
        fill: 'white',
        stroke: '#5B8FF9',
        lineWidth: 2,
      },
    },
    tooltip: {
      showMarkers: false,
    },
    state: {
      active: {
        style: {
          shadowBlur: 4,
          stroke: '#000',
          fill: 'red',
        },
      },
    },
    interactions: [
      {
        type: 'marker-active',
      },
    ],
  };

  const data = [
    {
      type: '1-3',
      value: 0.03,
    },
    {
      type: '4-10',
      value: 0.05,
    },
    {
      type: '16-33',
      value: 0.08,
    },
    {
      type: '45-67',
      value: 0.19,
    },{
      type: '8-10',
      value: 0.05,
    },
    {
      type: '11-30',
      value: 0.08,
    },
    {
      type: '31-60',
      value: 0.19,
    },
    {
      type: '1-3',
      value: 0.22,
    },
    {
      type: '3-10',
      value: 0.05,
    },
    {
      type: '10-30',
      value: 0.01,
    },
    {
      type: '30+',
      value: 0.015,
    },
  ];
  const paletteSemanticRed = '#F4664A';
  const brandColor = '#5B8FF9';
  const config = {
    data,
    xField: 'type',
    yField: 'value',
    seriesField: '',
    color: ({ type }) => {
      if (type === '10-30' || type === '30+') {
        return paletteSemanticRed;
      }

      return brandColor;
    },
    label: {
      content: (originData) => {
        const val = parseFloat(originData.value);

        if (val < 0.05) {
          return (val * 100).toFixed(1) + '%';
        }
      },
      offset: 10,
    },
    legend: false,
    xAxis: {
      label: {
        autoHide: true,
        autoRotate: false,
      },
    },
  };

  return (
    <React.Fragment>
      <HomeSection>
        <Breadcrumb className="BreadCrumb">
          <Breadcrumb.Item style={{ fontFamily: "q_bold", color: "#000" }}>Home</Breadcrumb.Item>
          <Breadcrumb.Item>Dashboard</Breadcrumb.Item>
        </Breadcrumb>
        <div className='total_records'>
          <Row gutter={[16, 16]}>
            <Col className="gutter-row" xxl={{ span: 6 }} xl={{ span: 6 }} lg={{ span: 6 }} md={{ span: 12 }} sm={{ span: 12 }} xs={{ span: 24 }}>
              <div className='total_record_box'>
                <div className='total_record_box_left'>
                  <h4>USERS</h4>
                  <h5>100</h5>
                  <Link>See all users</Link>
                </div>
                <div className='total_record_box_right'>
                  <div className='persentage'>
                    <ArrowUpOutlined /> 20%
                  </div>
                  <div className='box_avator color_1'>
                    <UserOutlined />
                  </div>
                </div>
              </div>
            </Col>
            <Col className="gutter-row" xxl={{ span: 6 }} xl={{ span: 6 }} lg={{ span: 6 }} md={{ span: 12 }} sm={{ span: 12 }} xs={{ span: 24 }}>
              <div className='total_record_box'>
                <div className='total_record_box_left'>
                  <h4>ORDERS</h4>
                  <h5>100</h5>
                  <Link>See all orders</Link>
                </div>
                <div className='total_record_box_right'>
                  <div className='persentage'>
                    <ArrowUpOutlined /> 20%
                  </div>
                  <div className='box_avator color_2'>
                    <ShoppingCartOutlined />
                  </div>
                </div>
              </div>
            </Col>
            <Col className="gutter-row" xxl={{ span: 6 }} xl={{ span: 6 }} lg={{ span: 6 }} md={{ span: 12 }} sm={{ span: 12 }} xs={{ span: 24 }}>
              <div className='total_record_box'>
                <div className='total_record_box_left'>
                  <h4>EARNINGS</h4>
                  <h5>$100</h5>
                  <Link>View net earnings</Link>
                </div>
                <div className='total_record_box_right'>
                  <div className='persentage'>
                    <ArrowUpOutlined /> 20%
                  </div>
                  <div className='box_avator color_3'>
                    <DollarOutlined />
                  </div>
                </div>
              </div>
            </Col>
            <Col className="gutter-row" xxl={{ span: 6 }} xl={{ span: 6 }} lg={{ span: 6 }} md={{ span: 12 }} sm={{ span: 12 }} xs={{ span: 24 }}>
              <div className='total_record_box'>
                <div className='total_record_box_left'>
                  <h4>BALANCE</h4>
                  <h5>100</h5>
                  <Link>See details</Link>
                </div>
                <div className='total_record_box_right'>
                  <div className='persentage'>
                    <ArrowUpOutlined /> 20%
                  </div>
                  <div className='box_avator color_4'>
                    <WalletOutlined />
                  </div>
                </div>
              </div>
            </Col>
          </Row>
        </div>
        <div className='chart_section'>
          <Row gutter={[16, 16]}>
            <Col className="gutter-row" xxl={{ span: 12 }} xl={{ span: 12 }} lg={{ span: 12 }} md={{ span: 24 }} sm={{ span: 24 }} xs={{ span: 24 }}>
              <div className='chart_box'>
                <div className='chart_head'>
                  <div className='chart_head_left'>
                    <h4>Order Status</h4>
                  </div>
                  <div className='chart_head_left'>
                    <Button size='small'>View All</Button>
                  </div>
                </div>
                <div className='chart_view'>
                  <Line {...config} />
                </div>
              </div>
            </Col>
            <Col className="gutter-row" xxl={{ span: 12 }} xl={{ span: 12 }} lg={{ span: 12 }} md={{ span: 24 }} sm={{ span: 24 }} xs={{ span: 24 }}>
              <div className='chart_box'>
                <div className='chart_head'>
                  <div className='chart_head_left'>
                    <h4>Last 6 Months (Revenue)</h4>
                  </div>
                  <div className='chart_head_left'>
                    <Button size='small'>View All</Button>
                  </div>
                </div>
                <div className='chart_view'>
                  <Column {...config} />
                </div>
              </div>
            </Col>
          </Row>
        </div>
        <div className='recent_order_section chart_section'>
          <Row gutter={[16, 16]}>
            <Col className="gutter-row" xxl={{ span: 16 }} xl={{ span: 16 }} lg={{ span: 16 }} md={{ span: 24 }} sm={{ span: 24 }} xs={{ span: 24 }}>
              <div className='chart_box'>
                <div className='chart_head'>
                  <div className='chart_head_left'>
                    <h4>Recent Order</h4>
                  </div>
                  <div className='chart_head_left'>
                    <Button size='small'>View All</Button>
                  </div>
                </div>
                <div className='chart_view'>
                  <Table
                    columns={columns}
                    dataSource={dataOrder}
                    responsive={true}
                    bordered
                    size="middle"
                    scroll={{
                      x: 600,
                    }}
                  />
                </div>
              </div>
            </Col>
            <Col className="gutter-row" xxl={{ span: 8 }} xl={{ span: 8 }} lg={{ span: 8 }} md={{ span: 24 }} sm={{ span: 24 }} xs={{ span: 24 }}>
            <div className='chart_box'>
                <div className='chart_head'>
                  <div className='chart_head_left'>
                    <h4>Total Records</h4>
                  </div>
                  </div>
                   <div className='chart_view'>
                  <ul className="count_pages">
          <li>
            <span>Products</span>
            <span>150</span>
          </li>
          <li>
            <span>Category</span>
            <span>17</span>
          </li>
          <li>
            <span>Orders</span>
            <span>57</span>
          </li>
          <li>
            <span>Users</span>
            <span>35</span>
          </li>
          <li>
            <span>Vendors</span>
            <span>55</span>
          </li>
        </ul>
                </div>
               
                
              </div>
            </Col>
          </Row>
        </div>
      </HomeSection>
    </React.Fragment>
  )
}

export default Home;


const HomeSection = styled.section`
  display: flex;
  flex-wrap: wrap;
  width: 100%;
  position: relative;

  .total_records {
    width: 100%;
    display: inline-block;
    position: relative;
  }
  .total_records .gutter-row {
    display: flex;
    width: 100%;
    position: relative;
  }
  .total_records .gutter-row .total_record_box  {
    background: #fff;
    display: flex;
    flex-wrap: wrap;
    align-items: stretch;
    justify-content: space-between;
    width: 100%;
    position: relative;
    padding: 15px 15px;
    border-radius: 5px;
    box-shadow: 0 0 25px rgb(0 0 0 / 5%);
    min-height: 125px;
}
  .total_records .gutter-row .total_record_box .total_record_box_left {
      width: 70%;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
  }
  .total_records .gutter-row .total_record_box .total_record_box_right {
    width: fit-content;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      text-align: right;
      align-items: flex-end;
  }
  .total_records .gutter-row .total_record_box h4 {
    margin: 0;
    color: #a0a0a0;
    font-size: 12px;
    letter-spacing: 0.7px;
    text-transform: uppercase;
    font-family: "q_medium";
  }
  .total_records .gutter-row .total_record_box h5 {
    margin: 0;
    font-size: 23px;
    font-family: 'q_bold';
    color: #000;

  }
  .total_records .gutter-row .total_record_box a {
    color: #262626;
    font-size: 12px;
    text-decoration: underline;
    font-style: italic;
    font-family: "q_medium";
    line-height: 1.3;
  }
  .total_records .gutter-row .total_record_box .persentage {
    color: #008000;
    font-size: 13px;
  }
  .total_records .gutter-row .total_record_box .box_avator {
    height: 30px;
    width: 30px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 5px;
  }
  .total_records .gutter-row .total_record_box .box_avator.color_1 {
    background: #ffcccc;
  } 
  .total_records .gutter-row .total_record_box .box_avator.color_2 {
    background: #f8edd2;
  } 
  .total_records .gutter-row .total_record_box .box_avator.color_3 {
    background: #cce6cc;
  } 
  .total_records .gutter-row .total_record_box .box_avator.color_4 {
    background: #e6cce6;
  } 

  .total_records .gutter-row .total_record_box .box_avator.color_1 span {
    color: #dc143c;
  }
  .total_records .gutter-row .total_record_box .box_avator.color_2 span {
    color: #daa520;
  }
  .total_records .gutter-row .total_record_box .box_avator.color_3 span {
      color: #008000;
  }
  .total_records .gutter-row .total_record_box .box_avator.color_4 span {
    color: #800080;
  }

  .chart_section {
    width:100%;
    display: inline-block;
    position: relative;
    margin: 30px 0 0 0;
  }
  .chart_section .gutter-row {
    display: flex;
  }

  .chart_section .gutter-row .chart_box {
    background: #fff;
    display: flex;
    flex-direction: column;
    flex-wrap: wrap;
    align-items: stretch;
    justify-content: space-between;
    width: 100%;
    position: relative;
    padding: 25px 20px;
    border-radius: 5px;
    box-shadow: 0 0 25px rgb(0 0 0 / 5%);
    min-height: 125px;
  }
  .chart_section .gutter-row .chart_box .chart_head {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 10px;
    margin: 0 0 35px;
  }
  .chart_section .gutter-row .chart_box .chart_head .chart_head_left {
    width: fit-content;
    display: inline-block;
  }
  .chart_section .gutter-row .chart_box .chart_head .chart_head_right {
    width: fit-content;
    display: inline-block;
  }
  .chart_section .gutter-row .chart_box .chart_head .chart_head_left h4 {
    font-size: 17px;
    font-family: "q_bold";
    color: #000;
    margin: 0;
  }
  .chart_section canvas {
    height: 250px !important;
    width: 100% !important;
  }
  button span {
    font-size: 12px;
    /* font-family: 'q_bold';
    text-transform: uppercase; */
    /* letter-spacing: 0.3px; */
}


  ul.count_pages {
    padding: 0;
    display: flex;
    flex-direction: column;
    gap: 15px;
    list-style: none;
  }
  ul.count_pages li {
    font-size: 14px;
    color: #000;
    font-weight: 600;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 0 10px;
    border-bottom: 0px solid #f5f5f5;
  }
  ul.count_pages li:last-child {
    padding: 0;
  }
  
  ul.count_pages li span:nth-child(2) {
    height: 25px;
    min-width: 30px;
    padding: 0 7px;
    border-radius: 5px;
    display: flex;
    align-items: center;
    justify-content: center;
    text-align: center;
    font-size: 13px;
    font-weight: 600;
  }
  ul.count_pages li:nth-child(1) span:nth-child(2) {
    color: crimson;
    background: rgb(237 20 61 / 20%);
  }
  ul.count_pages li:nth-child(2) span:nth-child(2) {
    color: goldenrod;
    background: rgb(218 165 32 / 20%);
  }
  ul.count_pages li:nth-child(3) span:nth-child(2) {
    color: green;
    background: rgb(0 128 0 / 20%);
  }
  ul.count_pages li:nth-child(4) span:nth-child(2) {
    color: purple;
    background: rgb(128 0 128 / 20%);
  }
  ul.count_pages li:nth-child(5) span:nth-child(2) {
    color: blue;
    background: rgb(0 0 255 / 20%);
  }
.chart_view {
  width: 100%;
}








  @media screen and (max-width:480px) {
    .chart_section canvas {
    height: 200px !important;
   
  }
  }









`;