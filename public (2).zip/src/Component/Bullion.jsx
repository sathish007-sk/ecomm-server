import React,{useEffect,useState} from 'react'
import API from '../Store/Api/ApiService'
const Bullion = () => {
    const [party,setParty] = useState([]);
    const [master,setMaster] = useState([]);
    const [finalRess,setFinalRess] = useState([]);
    const [loading,setLoading] = useState(false);
    const api = new API();
    var _id;
    var transaction_amount;
    var opening_balance;
    var opening_balance_date;
    const category_list = [];
    

    for(let i=0; i<party.length; i++) {
        // if(i>0) continue;
        var singlr = party[i];
        var final = master.filter((item)=>{
        return item?._id===singlr?.party_id;

        })
        category_list.push({
            id:singlr?.party_id,
            name:final[0]?.account_name,
            opening_balance_date:singlr?.date,
            opening_balance:Number(singlr?.closing_balance_amount).toFixed(0),
            metal_balance:Number(singlr?.closing_balance_metal).toFixed(0),
            transaction_amount:0,
        })
    }
   
   

    const getparty = () => {
        setLoading(true)
        api.getpartylist().then((res)=>{
            console.log("res",res)
           setParty(res.data);
                setLoading(false)
           
        });

}
const masterparty = () => {
    setLoading(true)
    api.masterparty().then((res)=>{
        // console.log("master",res)
        setMaster(res.data);
            setLoading(false)
        
    });

}
console.log("category_list",JSON.stringify(category_list))

const finish = () => {
    
    api.finish(category_list).then((res)=>{
        console.log("res",res)
    });
}


    useEffect(() => {
        getparty();
        masterparty();
      }, []);

      console.log("finalRess",category_list);
  return (
    <div><button onClick={()=>finish()}>finish</button></div>
  )
}

export default Bullion