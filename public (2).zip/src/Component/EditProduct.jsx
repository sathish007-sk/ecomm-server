import React, { useState, useEffect, useRef } from "react";
import {
  Button,
  Form,
  Input,
  Select,
  Tabs,
  Space,
  Divider,
  Checkbox,
  InputNumber,
  DatePicker,
  Row,
  Col,
  Modal,
  Upload,
  message,
} from "antd";
import styled from 'styled-components';
import API from '../Store/Api/ApiService'
import ReactQuill from "react-quill";
import "react-quill/dist/quill.snow.css";
import { useNavigate,useParams } from 'react-router-dom';
import {
  SafetyOutlined,
  ToolOutlined,
  TagOutlined,
  ApartmentOutlined,
  ProfileOutlined,
  SettingOutlined,
  MinusCircleOutlined,
  PlusOutlined,
  HighlightOutlined,
  AccountBookOutlined,
  ArrowLeftOutlined,
} from "@ant-design/icons";
const { TextArea } = Input;
const { Option } = Select;




const EditProduct = () => {
  const [value, setValue] = useState("");
  const [form] = Form.useForm();
  const [productTitle, setProductTitle] = useState("");
  const [previewOpen, setPreviewOpen] = useState(false);
  const [previewImage, setPreviewImage] = useState("");
  const [previewTitle, setPreviewTitle] = useState("");
  const [fileList, setFileList] = useState([]);
  const [tax, setTax] = useState([]);
  const [saving, setSaving] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [tabRes, setTabRes] = useState("left");

  const navigate = useNavigate();
  const params =useParams()
  const windowSize = useRef([window.innerWidth, window.innerHeight]);
  const api = new API();
  const [category, setCategory] = useState([]);
  const [c_name, setCategoryname] = useState([]);
  const [brand ,setbrand] = useState([]);
  const [b_name ,setBrandname] = useState([]);
  const higlists=['mango', 'orangwe']


   useEffect(() => {
          let id=params.id
           const data = {
             url1: "product",
             Url1: "Product",
             id:id
           };
             api
               .Viewdata(data)
               .then((res) => {
                 if (res.data.success === true) {
                  console.log('ffffffffffffffffffffffff')
                     form.setFieldsValue({
                       description: res?.data?.result?.description
                         ? res.data.result.description
                         : "",

                       mrp: res?.data?.result?.mrp ? res.data.result.mrp : "",
                       metakeywords: res?.data?.result?.meta_key
                         ? res.data.result.meta_key
                         : "",
                       metadescription: res?.data?.result?.meta_desc
                         ? res.data.result.meta_desc
                         : "",
                       sp: res?.data?.result?.sp ? res.data.result.sp : "",
                       min_order_qty: res?.data?.result?.min_order_qty
                         ? res.data.result.min_order_qty
                         : "",
                       d_days: res?.data?.result?.delivery_days
                         ? res.data.result.delivery_days
                         : "",
                       hsncode: res?.data?.result?.hsn_code
                         ? res.data.result.hsn_code
                         : "",
                     });
                 } else {
                   setCategory([]);
                 } 
               })
               .catch((err) => {
                 setCategory([]);
               });
   }, [])
  
   
   const getAllTax = () => {
     const data = {
       url1: "tax",
       Url1: "Tax",
     };

     api
       .getdata(data)
       .then((res) => {
        console.log(res)
         if (res.data.success === true) {
           console.log('dddd',res);
           setTax(res.data.result);
         } else {
           setTax([]);
         }
       })
       .catch((err) => {
         setTax([]);
       });
   };
   
  const getAllCategory = () => {
    const data = {
      url1: "product",
      Url1: "Product",
      
    };
    
    api.Viewdata(data).then((res) => {
      if (res.data.success === true) {
        setCategory(res.data.data);
        
      } else {
        setCategory([]);
        
      }
    }).catch((err) => {
      setCategory([]);
     
    })
  }
  const getAllBrand= () => {
    
    const data = {
      type: "brand",
    }
    api.getbrandlist(data).then((res) => {
      if (res.data.success === true) {
        console.log('brand',res.data.data);
        setbrand(res.data.data);
      
      } else {
        setbrand([]);
        
      }
    }).catch((err) => {
      setbrand([]);
      
    })
  }
   const singleProduct=(action)=>{
    let getSingle = {
        categ: action,
       
      }
      api.getproductsingle(getSingle).then((res) => {
      //  const productname = values["name"];
    //     const productcode = values["p_code"];
    // const hsncode=values['hsncode']
    
    // const costprice=values['mrp']
    // const sellingprice=values['sp']
    // const categoryid=values['c_id']
    // const brandid=values['b_id']
    // singleBrand(brandid)
    // const unit=values['unit']
    // const pack=values['pack']
    // const inclusivetax=values['inclusivetax']
    // const description=values['des']
         if (res.data.success === true) {
        form.setFieldsValue({
            des: res?.data?.data[0]?.description ? res?.data?.data[0]?.description : "",
            name: res?.data?.data[0]?.productname ? res?.data?.data[0]?.productname : "",
            hsncode:res?.data?.data[0]?.hsncode? res?.data?.data[0]?.hsncode : "",
            unit: res?.data?.data[0]?.unit? res?.data?.data[0]?.unit : "",
            sp: res?.data?.data[0]?.sellingprice? res?.data?.data[0]?.sellingprice : "",
            mrp: res?.data?.data[0]?.costprice? res?.data?.data[0]?.costprice: "",
            pack: res?.data?.data[0]?.pack? res?.data?.data[0]?.pack : "",
          b_id: res?.data?.data[0]?.brandid ? res?.data?.data[0]?.brandid : "",
          inclusivetax:res?.data?.data[0]?.inclusivetax? res?.data?.data[0]?.inclusivetax : "",
          p_code:res?.data?.data[0]?.productcode? res?.data?.data[0]?.productcode : "",
          d_margin:res?.data?.data[0]?.defaultmargin? res?.data?.data[0]?.defaultmargin : "",
        //   e_status: res?.data?.data[0]?.status == 1 ? setChecked(true) : setChecked(false),
          e_id: res?.data?.data[0]?.mainid ? res?.data?.data[0]?.mainid : "",
        })
       
      } else {
      
        message.error("Something went wrong!. Please try again!");
        
      }
    }).catch((err) => { })
          
        
     
    
   }

    //Update product

     let ress=0;
    const updateProductApi = (values) => {
      // setLoading1(true)
      // setChecked(false)
      const productname = values["name"];
      const productcode = values["p_code"];
      const hsncode = values["hsncode"];
      const tax = values['tax']
      const categorysubid = "3";
  
      const costprice = values["mrp"];
      const sellingprice = values["sp"];
      const categoryid = values["c_id"];
      const brandid = values["b_id"];
  
      const description = values["description"];
      const defaultmargin = values["d_margin"];
      const companyid = "aE4yYkZka1NtZHh2eTBYQ28yRFZIUT09";
      const status=1;
      ress = 0
      // if (checked == true) {
      //   ress = 1;
      // }
      // if (!(checked == true)){
      //   ress = values["e_status"] === true ? 1 : 0
      // }
      // if (values["e_status"] === false) {
      //   ress = 0;
      // }
  
      let updateApi = {
        // productname,
        // productcode,
        // hsncode,
        // costprice,
        // sellingprice,
        // companyid,
        // categorysubid,
        // tax,
        // unit,
        // status,
        // brandid,
        // categoryid,
        // description,
        // pack,
        // defaultmargin,
        // inclusivetax,

      }
  
     
  
  
      if ((values?.e_name !== "" || values?.e_name !== undefined) && (values?.e_status !== "" || values?.e_status !== undefined) && (values?.e_id !== "" || values?.e_id !== undefined)) {
        api.updateproduct(updateApi).then((res) => {
          if (res.data.success === true) {
           
          
            message.success("Updated successfully");
            navigate('/product')
            getAllCategory();
          } else if (res.data.success === false) {
            message.warning(res.data.msg);
          
          } else {
            message.error("Something went wrong!. Please try again!");
           
          }
        }).catch((err) => { })
      } else {
        message.error("Something went wrong!. Please try again!");
      
      }
    }


  const singleCategory=(action)=>{
  let getSingle = {
    mainid: action,
    tete: "category",
  }
  api.getbrandsingle(getSingle).then((res) => {
    if (res.data.success === true) {
      setCategoryname(res.data.data.name)
       
    } else {
      setCategoryname([])
      message.error("Something went wrong!. Please try again!");

      
    }
  }).catch((err) => { 
    setCategoryname([])
  })
}
const singleBrand =(action)=>{
  let getSingle = {
    mainid: action,
    type: "brand",
  }
  api.getbrandsingle(getSingle).then((res) => {
    if (res.data.success === true) {
      console.log('---', res.data.data)
      setBrandname(res.data.data.name)
       
    } else {
      setBrandname([])
      message.error("Something went wrong!. Please try again!");

      
    }
  }).catch((err) => { 
    setBrandname([])
  })
}
 useEffect(() => {
     getAllTax()
 }, [])
  useEffect(() => {
    getAllCategory();
  }, []);
  useEffect(() => {
    getAllBrand();
  }, []);

  console.log("width", windowSize.current[0])
  console.log("height", windowSize.current[1])

  const tabCheck = () => {
    if (windowSize.current[0] <= 768) {
      setTabRes("top");
    } else {
      setTabRes("left");
    }
  }

  useEffect(() => {
    tabCheck()
  }, [])
  const handleCancel = () => setPreviewOpen(false);
  const handlePreview = async (file) => {

    if (!file.url && !file.preview) {
      file.preview = await getBase64(file.originFileObj);
    }
    setPreviewImage(file.url || file.preview);
    setPreviewOpen(true);
    setPreviewTitle(
      file.name || file.url.substring(file.url.lastIndexOf("/") + 1)
    );
  };
  const getBase64 = (file) =>
    new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result);
      reader.onerror = (error) => reject(error);
    });
  const handleChange = ({ fileList: newFileList }) => setFileList(newFileList);
  const uploadButton = (
    <div>
      <PlusOutlined />
      <div
        style={{
          marginTop: 8,
        }}
      >
        Upload
      </div>
    </div>
  );
  const beforeUpload = (file) => {
    const isJpgOrPng =
      file.type === "image/jpeg" ||
      file.type === "image/png" ||
      file.type === "image/webp" ||
      file.type === "image/jpg";
    if (!isJpgOrPng) {
      message.error("You can only upload JPG/PNG/WEBP file!");
    }
    const isLt2M = file.size / 1024 / 1024 < 2;
    if (!isLt2M) {
      message.error("Image must smaller than 2MB!");
    }
    return isJpgOrPng && isLt2M;
  };

  const showModal = () => {
    setIsModalOpen(true);
  };
  const handleOk = () => {
    setIsModalOpen(false);
  };
  const handleCancel1 = () => {
    setIsModalOpen(false);
  };
  const user = JSON.parse(localStorage.getItem("persist:root"))?.user;
  const addedby = user && JSON.parse(user).user?.user?._id;
  const company = user && JSON.parse(user).user?.user?.company;
    const brand_list=[];
       const category_list = [];
     
    brand?.map((item) => {
      brand_list.push({
        value: item?.mainid,
        label: item?.name,
      })
    });
     

       tax?.map((item) => {
         category_list.push({
           value: item?._id,
           label: item?.tax_name,
         });
       });



  const addNewProduct = (values) => {
      alert('hi iam')
        console.log(values)

    const name = values["name"];
    const tax = values["tax"];
    const hsncode=values['hsncode'];
    const delivery_days = values["d_days"];
    
    const mrp = values["mrp"];
    const sp=values['sp'];
    const meta_desc = values["metadescription"];
    const meta_key = values["metakeywords"];

    const brandid=values['b_id']
    singleBrand(brandid)
    const unit=values['unit']
    const pack=values['pack']
    const inclusivetax=values['inclusivetax']
    const description = values["description"];
     const categoryname=c_name && c_name 
    const brandname=b_name && b_name 
    let data = {
       url1: "product",
       Url1: "Product",
       id:params.id
     };
     
         

    let addNew = {
      mrp,
      meta_desc,
      meta_key,
      delivery_days,
      tax,
      hsncode,

      sp,
      description,
     
      hsncode ,
     
 
      
    }
     api.editdata(data,addNew).then((res) => {
      console.log('ressss',res)
        if (res.data.success === true) {
       
          form.resetFields();
       
          message.success("Added successfully");
          getAllCategory();
        } else if (res.data.success === false) {
          message.warning(res.data.msg);
         
        } else {
          message.error("Something went wrong!. Please try again!");
         
        }
      }).catch((err) => {console.log(err) })
    
    }


  



   


  return (
    <React.Fragment>
      <EditProductSection>
        <div className="page_back_align">
          <p onClick={() => navigate(-1)} className="go_back">
            <ArrowLeftOutlined /> &nbsp; Edit Product
          </p>
        </div>
        <Form
          layout="vertical"
          size="medium"
          name="add_new_product"
          onFinish={addNewProduct}
          form={form}
        >
          <NewProductSection>
            <NewProductLeft>
              <BgWight>
                <Form.Item
                  label="Enter Product Name"
                  values={productTitle}
                  onChange={(e) => setProductTitle(e.target.value.trim())}
                  tooltip="Product Name"
                  name="name"
                  rules={[
                    {
                      required: true,
                      message: "Please enter product name",
                    },
                  ]}
                >
                  <Input placeholder="Product name" />
                </Form.Item>
                <Form.Item
                  label="Product Description"
                  name="description"
                  tooltip="Product Description"
                >
                  <ReactQuill
                    theme="snow"
                    value={value}
                    onChange={setValue}
                    className="pro_dec"
                  />
                </Form.Item>
              </BgWight>
              <BgWight>
                <Form.Item
                  label="Product Type"
                  layout="inline"
                  name="producttype"
                  tooltip="Product Type"
                  rules={[
                    {
                      required: true,
                      message: "Please choose product type",
                    },
                  ]}
                >
                  <Select placeholder="Product Type" allowClear>
                    <Option value="simple">Simple Product</Option>
                    <Option value="varible">Varible Product</Option>
                  </Select>
                </Form.Item>
                <Form.Item label="Product Data" tooltip="Product Data">
                  <MyAccountAlign>
                    <Tabs defaultActiveKey="1" tabPosition={tabRes}>
                      {/* <Tabs.TabPane
                        tab={
                          <>
                            <ToolOutlined />
                            General
                          </>
                        }
                        key="1"
                      >
                        <Dimension2>
                          <Form.Item
                            label="Regular price"
                            name="mrp"
                            className="flex_row"
                          >
                            <Input placeholder="Regular Price" />
                          </Form.Item>
                          <Form.Item
                            label="Sale price"
                            name="sp"
                            className="flex_row"
                          >
                            <Input placeholder="Sale Price" />
                          </Form.Item>
                          <Form.Item
                            label="Product Code"
                            name="p_code"
                            className="flex_row"
                          >
                            <Input placeholder="Product Code" />
                          </Form.Item>
                          <Form.Item
                            label="Default Margin"
                            name="d_margin"
                            className="flex_row"
                            rules={[
                              {
                                required: true,
                                message: "Please enter SKU ID",
                              },
                            ]}
                          >
                            <Input placeholder="Default margin" />
                          </Form.Item>
                          <Form.Item
                            label="Unit"
                            name="unit"
                            className="flex_row"
                            rules={[
                              {
                                required: true,
                                message: "Please enter SKU ID",
                              },
                            ]}
                          >
                            <Input placeholder="Unit" />
                          </Form.Item>
                          <Form.Item
                            label="Pack"
                            name="pack"
                            className="flex_row"
                            rules={[
                              {
                                required: true,
                                message: "Please enter Pack",
                              },
                            ]}
                          >
                            <Input placeholder="Pack" />
                          </Form.Item>
                        
            <Form.Item
              label="brand"
              name="b_id"

            >
              <Select
                showSearch

                placeholder="Search to Select"
                optionFilterProp="children"
                filterOption={(input, option) => (option?.label ?? '').includes(input)}
                filterSort={(optionA, optionB) =>
                  (optionA?.label ?? '').toLowerCase().localeCompare((optionB?.label ?? '').toLowerCase())
                }
                options={brand_list} />
            </Form.Item>
                          <Form.Item
                            label="Brand Id"
                            name="b_id"
                            className="flex_row"
                            rules={[
                              {
                                required: true,
                                message: "Please enter Brand Id",
                              },
                            ]}
                          >
                            <Input placeholder="Brand Id" />
                          </Form.Item>
                          <Form.Item
                            label="Description"
                            name="des"
                            className="flex_row"
                            rules={[
                              {
                                required: true,
                                message: "Please enter Description",
                              },
                            ]}
                          >
                            <Input placeholder="Description" />
                          </Form.Item>
                          <Form.Item
                            label="Inclusivetax"
                            name="inclusivetax"
                            className="flex_row"
                            rules={[
                              {
                                required: true,
                                message: "Please enter Inclusivetax",
                              },
                            ]}
                          >
                            <Input placeholder="Inclusivetax" />
                          </Form.Item>

                          <Form.Item
                          label="Hsncode"
                          className="flex_row"
                            name="hsncode"
                            rules={[
                              {
                                required: true,
                                message: "Please enter Hsncode",
                              },
                            ]}
                          >
                            <Input placeholder="Hsncode" />
                          </Form.Item>


                          <Form.Item
                            label="SKU"
                            name="sku"
                            className="flex_row"
                            tooltip="Product SKU"
                            rules={[
                              {
                                required: true,
                                message: "Please enter SKU ID",
                              },
                            ]}
                          >
                            <Input placeholder="SKU ID" />
                          </Form.Item>
                          <Form.Item
                            label="Brand Name"
                            layout="inline"
                            name="b_name"
                            tooltip="Brand Name"
                          >
                            <Select placeholder="Choose Brand Name" allowClear>
                              <Option value="Smile">Smile</Option>
                            </Select>
                          </Form.Item>
                          <Form.Item
                            label="Model ID"
                            name="model"
                            className="flex_row"
                            tooltip="Model ID"
                          >
                            <Input placeholder="Model id" />
                          </Form.Item>
                          <Form.Item
                            label="Unit"
                            name="unit"
                            className="flex_row"
                            rules={[
                              {
                                required: true,
                                message: "Please enter unit",
                              },
                            ]}
                          >
                            <Input placeholder="Unit" />
                          </Form.Item>

                          <Form.Item
                            label="Delivery Date"
                            name="deliverydate"
                            className="flex_row"
                            tooltip="Delivery Date"
                          >
                            <Input placeholder="Delivery Date" />
                          </Form.Item>
                        </Dimension2>
                      </Tabs.TabPane> */}
                      <Tabs.TabPane
                        tab={
                          <>
                            <ToolOutlined />
                            Product rate
                          </>
                        }
                        key="1"
                      >
                        <Dimension2>
                          <Form.Item
                            label="Buying price"
                            name="mrp"
                            className="flex_row"
                          >
                            <InputNumber name="mrp" />
                          </Form.Item>
                          <Form.Item
                            label="Selling price"
                            name="sp"
                            className="flex_row"
                          >
                            <InputNumber name="sp" />
                          </Form.Item>
                          <Form.Item
                            label="Selling price Margin"
                            name="min_order_qty"
                            className="flex_row"
                          >
                            <InputNumber name="min_order_qty " />
                          </Form.Item>
                          <Form.Item
                            label="Discount"
                            name="discount"
                            className="flex_row"
                          >
                            <Input placeholder="Discount" />
                          </Form.Item>
                          <Form.Item
                            label="Min Order Quantity"
                            name="min_order_qty"
                            className="flex_row"
                          >
                            <InputNumber name="min_order_qty " />
                          </Form.Item>
                          {/*  <Form.Item
                            label="Default Margin"
                            name="d_margin"
                            className="flex_row"
                            rules={[
                              {
                                required: true,
                                message: "Please enter SKU ID",
                              },
                            ]}
                          >
                            <Input placeholder="Default margin" />
                          </Form.Item>
                          <Form.Item
                            label="Unit"
                            name="unit"
                            className="flex_row"
                            rules={[
                              {
                                required: true,
                                message: "Please enter SKU ID",
                              },
                            ]}
                          >
                            <Input placeholder="Unit" />
                          </Form.Item>
                          <Form.Item
                            label="Pack"
                            name="pack"
                            className="flex_row"
                            rules={[
                              {
                                required: true,
                                message: "Please enter Pack",
                              },
                            ]}
                          >
                            <Input placeholder="Pack" />
                          </Form.Item>

                          <Form.Item label="brand" name="b_id">
                            <Select
                              showSearch
                              placeholder="Search to Select"
                              optionFilterProp="children"
                              filterOption={(input, option) =>
                                (option?.label ?? "").includes(input)
                              }
                              filterSort={(optionA, optionB) =>
                                (optionA?.label ?? "")
                                  .toLowerCase()
                                  .localeCompare(
                                    (optionB?.label ?? "").toLowerCase()
                                  )
                              }
                              options={brand_list}
                            />
                          </Form.Item>
                          {/* Tree */}
                          {/* <TreeSelect
                            style={{ width: "100%" }}
                            value={value}
                            dropdownStyle={{ maxHeight: 400, overflow: "auto" }}
                            treeData={treeData}
                            placeholder="Please select"
                            treeDefaultExpandAll
                            onChange={onChangeSelect}
                          />
                          <Form.Item label="Category" name="c_id">
                            <Select
                              showSearch
                              placeholder="Search to Select"
                              optionFilterProp="children"
                              filterOption={(input, option) =>
                                (option?.label ?? "").includes(input)
                              }
                              filterSort={(optionA, optionB) =>
                                (optionA?.label ?? "")
                                  .toLowerCase()
                                  .localeCompare(
                                    (optionB?.label ?? "").toLowerCase()
                                  )
                              }
                              options={Category_list}
                            />
                          </Form.Item>
                          <Form.Item
                            label="Brand Id"
                            name="b_id"
                            className="flex_row"
                            rules={[
                              {
                                required: true,
                                message: "Please enter Brand Id",
                              },
                            ]}
                          >
                            <Input placeholder="Brand Id" />
                          </Form.Item>
                          <Form.Item
                            label="Description"
                            name="des"
                            className="flex_row"
                            rules={[
                              {
                                required: true,
                                message: "Please enter Description",
                              },
                            ]}
                          >
                            <Input placeholder="Description" />
                          </Form.Item>
                          <div className="switch_btn">
                            <Form.Item
                              label="Status"
                              valuePropName="checked"
                              name="status"
                              rules={[
                                {
                                  required: true,
                                  message: "Status is required!",
                                },
                              ]}
                            >
                              <Switch />
                            </Form.Item>
                          </div>
                          <Form.Item
                            label="AddProduct"
                            name="tax"
                            className="flex_row"
                            rules={[
                              {
                                required: true,
                                message: "Please enter AddProduct",
                              },
                            ]}
                          >
                            <Input placeholder="AddProduct" />
                          </Form.Item>
                          <Form.Item
                            label="SKU"
                            name="sku"
                            className="flex_row"
                            tooltip="Product SKU"
                            rules={[
                              {
                                required: true,
                                message: "Please enter SKU ID",
                              },
                            ]}
                          >
                            <Input placeholder="SKU ID" />
                          </Form.Item>
                          <Form.Item
                            label="Brand Name"
                            layout="inline"
                            name="b_name"
                            tooltip="Brand Name"
                          >
                            <Select placeholder="Choose Brand Name" allowClear>
                              <Option value="Smile">Smile</Option>
                            </Select>
                          </Form.Item>
                          <Form.Item
                            label="Model ID"
                            name="model"
                            className="flex_row"
                            tooltip="Model ID"
                          >
                            <Input placeholder="Model id" />
                          </Form.Item>
                          <Form.Item
                            label="Unit"
                            name="unit"
                            className="flex_row"
                            rules={[
                              {
                                required: true,
                                message: "Please enter unit",
                              },
                            ]}
                          >
                            <Input placeholder="Unit" />
                          </Form.Item>{" "}
                          */}
                          <Form.Item
                            label="Delivery Date"
                            name="deliverydate"
                            className="flex_row"
                            tooltip="Delivery Date"
                          >
                            <DatePicker name="deliverydate " />
                          </Form.Item>
                          <Form.Item
                            label="Delivery Days"
                            name="d_days"
                            className="flex_row"
                            tooltip="Delivery Days"
                          >
                            <InputNumber name="d_days" />
                          </Form.Item>
                        </Dimension2>
                      </Tabs.TabPane>

                      <Tabs.TabPane
                        tab={
                          <>
                            <ApartmentOutlined />
                            Paking
                          </>
                        }
                        key="2"
                      >
                        <Dimension2>
                          <Form.Item
                            label="Weight"
                            name="weight"
                            className="flex_row"
                            tooltip="Weight "
                          >
                            <InputNumber name="weight" />
                          </Form.Item>
                          <Form.Item
                            label="Height"
                            name="height"
                            className="flex_row"
                            tooltip="Weight "
                          >
                            <InputNumber name="height" />
                          </Form.Item>
                          <Form.Item
                            label="Length"
                            name="length"
                            className="flex_row"
                            tooltip="Length"
                          >
                            <InputNumber name="length" />
                          </Form.Item>
                          <Form.Item
                            label="Breadth"
                            name="breadth"
                            className="flex_row"
                            tooltip="Breadth"
                          >
                            <InputNumber name="breadth" />
                          </Form.Item>
                        </Dimension2>
                      </Tabs.TabPane>
                      <Tabs.TabPane
                        tab={
                          <>
                            <ApartmentOutlined />
                            DeliveryCharges
                          </>
                        }
                        key="3"
                      >
                        <Dimension2>
                          <Form.Item
                            label="Local Delivery Charge"
                            name="local_d_cahrges"
                            className="flex_row"
                            tooltip="Local Delivery Charge "
                          >
                            <InputNumber name="local_d_cahrges" />
                          </Form.Item>
                          <Form.Item
                            label="Zonal Delivery Charge"
                            name="zonal_d_charge"
                            className="flex_row"
                            tooltip="Zonal Delivery Charge "
                          >
                            <InputNumber name="zonal_d_charge" />
                          </Form.Item>
                          <Form.Item
                            label="National Delivery Charge"
                            name="national_d_charge"
                            className="flex_row"
                            tooltip="Zonal Delivery Charge "
                          >
                            <InputNumber name="national_d_charge" />
                          </Form.Item>
                        </Dimension2>
                      </Tabs.TabPane>
                      <Tabs.TabPane
                        tab={
                          <>
                            <ProfileOutlined />
                            Specification
                          </>
                        }
                        key="4"
                      >
                        <Form.List name="specification">
                          {(fields, { add, remove }) => (
                            <>
                              {fields.map(({ key, name, ...restField }) => (
                                <Space
                                  key={key}
                                  style={{
                                    display: "flex",
                                    marginBottom: 8,
                                  }}
                                  align="baseline"
                                >
                                  <Form.Item
                                    {...restField}
                                    name={[name, "sname"]}
                                    rules={[
                                      {
                                        required: true,
                                        message: "Enter Name",
                                      },
                                    ]}
                                  >
                                    <Input
                                      placeholder="Enter Name"
                                      style={{ width: "150px" }}
                                    />
                                  </Form.Item>
                                  <Form.Item
                                    {...restField}
                                    name={[name, "svalue"]}
                                    rules={[
                                      {
                                        required: true,
                                        message: "Enter Description",
                                      },
                                    ]}
                                  >
                                    <Input
                                      placeholder="Enter Description"
                                      style={{ width: "300px" }}
                                    />
                                  </Form.Item>
                                  <MinusCircleOutlined
                                    onClick={() => remove(name)}
                                  />
                                </Space>
                              ))}
                              <Form.Item>
                                <Button
                                  type="dashed"
                                  onClick={() => add()}
                                  block
                                  icon={<PlusOutlined />}
                                >
                                  Edit Specification
                                </Button>
                              </Form.Item>
                            </>
                          )}
                        </Form.List>
                      </Tabs.TabPane>
                      {/* <Tabs.TabPane
                        tab={
                          <>
                            <HighlightOutlined />
                            Highlights
                          </>
                        }
                        key="7"
                      >
                        <Form.List name="highlights">
                          {(fields, { add, remove }) => (
                            <>
                              {fields.map(
                                ({ key, name, value, ...restField }) => (
                                  <Space
                                    key={key}
                                    style={{
                                      display: "flex",
                                      marginBottom: 8,
                                    }}
                                    align="baseline"
                                  >
                                    <Form.Item
                                      {...restField}
                                      name={[name, "hname"]}
                                      initialValue={higlists.map((e)=>e  )}
                                      rules={[
                                        {
                                          required: true,
                                          message: "Enter Name",
                                        },
                                      ]}
                                    >
                                      <Input placeholder="Enter Name" />
                                    </Form.Item>
                                    <Form.Item
                                      {...restField}
                                      name={[name, "hvalue"]}
                                      rules={[
                                        {
                                          required: true,
                                          message: "Enter Description",
                                        },
                                      ]}
                                    >
                                      <Input placeholder="Enter Description" />
                                    </Form.Item>
                                    <MinusCircleOutlined
                                      onClick={() => remove(name)}
                                    />
                                  </Space>
                                )
                              )}
                              <Form.Item>
                                <Button
                                  type="dashed"
                                  onClick={() => add()}
                                  block
                                  icon={<PlusOutlined />}
                                >
                                  Edit Highlights
                                </Button>
                              </Form.Item>
                            </>
                          )}
                        </Form.List>
                      </Tabs.TabPane> */}
                      <Tabs.TabPane
                        tab={
                          <>
                            <AccountBookOutlined />
                            Tax and GST
                          </>
                        }
                        key="9"
                      >
                        <Dimension2>
                          <Form.Item
                            label="Tax"
                            name="tax"
                            rules={[
                              {
                                required: true,
                                message: "Tax is required!",
                              },
                            ]}
                          >
                            <Select
                              showSearch
                              placeholder="Search to Select"
                              optionFilterProp="children"
                              filterOption={(input, option) =>
                                (option?.label ?? "").includes(input)
                              }
                              filterSort={(optionA, optionB) =>
                                (optionA?.label ?? "")
                                  .toLowerCase()
                                  .localeCompare(
                                    (optionB?.label ?? "").toLowerCase()
                                  )
                              }
                              options={category_list}
                            />
                          </Form.Item>
                          <Form.Item
                            label="HSN Code"
                            name="hsncode"
                            className="flex_row"
                            tooltip="HSN Code"
                          >
                            <Input placeholder="HSN Code" />
                          </Form.Item>
                        </Dimension2>
                      </Tabs.TabPane>
                      <Tabs.TabPane
                        tab={
                          <>
                            <SettingOutlined />
                            Advanced
                          </>
                        }
                        key="5"
                      >
                        <Form.Item
                          label="Purchase Notes"
                          name="purchasenote"
                          tooltip="Purchase Notes"
                        >
                          <TextArea rows={4} />
                        </Form.Item>
                        <Dimension2>
                          <Form.Item
                            label="Product Visible Type"
                            layout="inline"
                            name="visible"
                            tooltip="Product Visible Type"
                          >
                            <Select
                              placeholder="Choose Visible Type"
                              allowClear
                            >
                              <Option value="true">True</Option>
                              <Option value="false">False</Option>
                            </Select>
                          </Form.Item>
                          <Form.Item
                            label="Product Publish Type"
                            layout="inline"
                            name="publish"
                            tooltip="Product Publish Type"
                          >
                            <Select
                              placeholder="Choose Publish Type"
                              allowClear
                            >
                              <Option value="true">True</Option>
                              <Option value="false">False</Option>
                            </Select>
                          </Form.Item>
                        </Dimension2>
                      </Tabs.TabPane>
                    </Tabs>
                  </MyAccountAlign>
                </Form.Item>
              </BgWight>
              <BgWight>
                <Form.Item
                  label="Meta Title"
                  values={productTitle}
                  onChange={(e) => setProductTitle(e.target.value.trim())}
                  tooltip="Meta Title"
                  name="p_title"
                  rules={[
                    {
                      required: true,
                      message: "Please enter product name",
                    },
                  ]}
                >
                  <Input placeholder="Meta Title" />
                </Form.Item>
                <Form.Item
                  label="Meta Description"
                  name="metadescription"
                  tooltip="Meta Description"
                >
                  <TextArea rows={3} placeholder="Meta Description" />
                </Form.Item>
                <Form.Item
                  label="Meta Keywords"
                  name="metakeywords"
                  tooltip="Meta Keywords"
                >
                  <TextArea rows={3} placeholder="Meta Keywords" />
                </Form.Item>
              </BgWight>
            </NewProductLeft>
            <NewProductRight>
              <PublishRow>
                <Text></Text>
                <Button
                  type="primary"
                  size="small"
                  htmlType="submit"
                  loading={saving}
                >
                  <SafetyOutlined />
                  Publish
                </Button>
              </PublishRow>
              <Divider />
              <H4>Product Categories</H4>
              <CatsBox className="catboxs">
                <Checkbox.Group>
                  <Row>
                    {category?.map((item, i) => (
                      <Col span={24} key={i}>
                        <Checkbox value={item.mainid}>{item.name}</Checkbox>
                      </Col>
                    ))}
                  </Row>
                </Checkbox.Group>
              </CatsBox>
              <CatsNew>
                <Button type="dashed" block onClick={showModal}>
                  <PlusOutlined />
                  Edit New Category
                </Button>
                <Modal
                  title="Edit New Category"
                  open={isModalOpen}
                  onOk={handleOk}
                  onCancel={handleCancel1}
                  footer={null}
                >
                  <p>Some contents...</p>
                  <p>Some contents...</p>
                  <p>Some contents...</p>
                </Modal>
              </CatsNew>
              <Divider />
              <CatsBox className="catboxs">
                <Checkbox.Group>
                  <Row>
                    {category?.map((item, i) => (
                      <Col span={24} key={i}>
                        <Checkbox value={item.productid}>
                          {item.categoryname}
                        </Checkbox>
                      </Col>
                    ))}
                  </Row>
                </Checkbox.Group>
              </CatsBox>
              <Thumbnail>
                <H4>Product Image</H4>
                <Upload
                  action={process.env.REACT_APP_API}
                  listType="picture-card"
                  fileList={fileList}
                  multiple
                  name="image"
                  onPreview={handlePreview}
                  beforeUpload={beforeUpload}
                  onChange={handleChange}
                >
                  {fileList.length >= 5 ? null : uploadButton}
                </Upload>
                <Modal
                  open={previewOpen}
                  title={previewTitle}
                  footer={null}
                  onCancel={handleCancel}
                >
                  <img
                    alt="example"
                    style={{
                      width: "100%",
                    }}
                    src={previewImage}
                  />
                </Modal>
              </Thumbnail>
            </NewProductRight>
          </NewProductSection>
          <Button type="primary" htmlType="submit">
            Save
          </Button>
        </Form>
      </EditProductSection>
    </React.Fragment>
  );
}

export default EditProduct;


const EditProductSection = styled.section`
  .ant-form-vertical .ant-form-item-label>label {
    color: #2e2e2e;
    font-family: "q_medium";
  }


 

`;


const Dimension2 = styled.div`
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 0 24px;
  align-items: flex-end;

  @media screen and (max-width:580px) {
    grid-template-columns: repeat(1, 1fr);
  }



`;

const CatsNew = styled.div`
width:100%;
margin: 20px 0 0 0;







`;

const Thumbnail = styled.div`

.ant-upload-wrapper.ant-upload-picture-card-wrapper .ant-upload.ant-upload-select {
  height: 80px;
  width: 80px;
}


`;

const H4 = styled.div`
font-size: 18px;
font-family: "q_bold";
margin: 0 0 20px;




`;
const CatsBox = styled.div`
  height: 215px;
  overflow: auto;
  border: 1px solid #d9d9d9;
  padding: 20px;
  border-radius: 4px;
  .ant-col-24 {
    margin: 0 0 10px;
  }


`;

const PublishRow = styled.div`
display: flex;
align-items: center;
justify-content: space-between;
gap: 15px;
`;
const Text = styled.div``

const NewProductSection = styled.div`
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  flex-wrap: wrap;

  .pro_dec {
    margin: 0 0 0px;
    
  }

  .ql-toolbar.ql-snow {
    border-radius: 6px 6px 0 0;
  }
  .ql-container.ql-snow {
    border-radius: 0 0 6px 6px;
    height: 150px;
  }

  .ant-tabs-left
    > .ant-tabs-content-holder
    > .ant-tabs-content
    > .ant-tabs-tabpane,
  .ant-tabs-left
    > div
    > .ant-tabs-content-holder
    > .ant-tabs-content
    > .ant-tabs-tabpane {
    padding: 24px;
  }

  .ant-form-item.flex_row .ant-row.ant-form-item-row {
    display: flex !important;
    flex-direction: row !important;
  }
  .ant-form-item.flex_row
    .ant-row.ant-form-item-rowhiglists
    .ant-col-24.ant-form-item-label,
  .ant-col-xl-24.ant-form-item-label,
  .ant-form-vertical .ant-form-item-label {
    flex: 1 !important;
  }
  .ant-form-item.flex_row
    .ant-row.ant-form-item-row
    .ant-form-vertical
    .ant-form-item
    .ant-form-item-control {
    width: 100% !important;
    flex: 3 !important;
  }
  /* width */
  .catboxs::-webkit-scrollbar {
    width: 5px;
  }

  /* Track */
  .catboxs::-webkit-scrollbar-track {
    background: #f1f1f1;
  }

  /* Handle */
  .catboxs::-webkit-scrollbar-thumb {
    background: #888;
    border-radius: 5px;
  }

  /* Handle on hover */
  .catboxs::-webkit-scrollbar-thumb:hover {
    background: #555;
  }
`;
const MyAccountAlign = styled.div`
  width: 100%;
  display: inline-block;
  position: relative;
  margin: 10px 0 0 0;
  border: 1px solid #d9d9d97a;
  .ant-tabs.ant-tabs-left {
    padding: 0px 0;
  }
  .ant-tabs-content-holder {
    padding: 20px 0;
  }
  .ant-tabs-tab {
    padding: 4px 20px !important;
    font-size: 14px;

    width: 180px;
    color: #000;
  }
  .ant-tabs > .ant-tabs-nav .ant-tabs-nav-list,
  .ant-tabs > div > .ant-tabs-nav .ant-tabs-nav-list {
    padding: 15px 0;
  }
  .ant-tabs-tab.ant-tabs-tab-active .ant-tabs-tab-btn {
    color: rgb(13 110 253);
    font-weight: 400;
    font-size: 14px;
  }
  .ant-tabs-tab-btn,
  .ant-tabs-tab-btn,
  .ant-tabs-tab-remove,
  .ant-tabs-tab-remove {
    font-family: "q_bold";
    font-size: 14px;
  }
  .ant-tabs-ink-bar {
    background: rgb(13 110 253);
  }


  @media screen and (max-width:768px) {
    .ant-tabs-content-holder {
    padding: 20px 15px;
  }
  }




  
`;
const NewProductLeft = styled.div`
  width: 72%;
  display: flex;
  flex-direction: column;
  gap: 30px;
  position: relative;
  /* padding: 24px; */
  /* box-shadow: 2px 4px 20px 1px rgb(201 201 201 / 30%);
  background: #fff; */
  min-height: 550px;

  @media screen and (max-width:992px) {
    width: 100%;
  }


  @media screen and (max-width:768px) {
 
.ant-tabs > .ant-tabs-nav .ant-tabs-nav-list, .caKiHo .ant-tabs > div > .ant-tabs-nav .ant-tabs-nav-list {
    padding: 9px 0;
}



  }
  
`;

const BgWight = styled.div`
  padding: 24px;
  box-shadow: 2px 4px 20px 1px rgb(201 201 201 / 30%);
  background: #fff;
  display: inline-block;
  width: 100%;
  border-radius: 5px;
`;
const NewProductRight = styled.div`
  width: 25%;
  display: inline-block;
  position: relative;
  padding: 24px;
  box-shadow: 2px 4px 20px 1px rgb(201 201 201 / 30%);
  background: #fff;
  min-height: 550px;
  border-radius: 8px;
  .ant-upload.ant-upload-select-picture-card,
  .ant-upload-list-picture-card-container {
    width: 85px !important;
    height: 85px !important;
  }

  @media screen and (max-width:992px) {
    width: 100%;
    margin: 30px 0 0 0;
  }
`;
