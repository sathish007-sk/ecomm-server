import {
  NEW_REGISTER_REQUEST,
  NEW_REGISTER_SUCCESS,
  NEW_REGISTER_FAIL,
  NEW_REGISTER_LOGOUT,
} from "../Contans/AdminContans";

export const newregisterReducer = (state={newregister:{}},action) => {
  switch (action.type) {
    case NEW_REGISTER_REQUEST:
      return {
        loading: true,
        isRegister: false,
      };
    case NEW_REGISTER_SUCCESS:
      return {
        ...state,
        loading: false,
        isRegister: true,
        registeraction: action.payload,
      };
    case NEW_REGISTER_FAIL:
      return {
        ...state,
        loading: false,
        isRegister: false,
        registeraction: null,
        error: action.payload,
      };
    case NEW_REGISTER_LOGOUT:
      return {
        loading: false,
        isRegister: false,
        registeraction:null,
      }
    default:
      return state;
  }
}