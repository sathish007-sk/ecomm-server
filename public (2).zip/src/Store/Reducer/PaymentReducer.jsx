import {
  PAYMENT_REQUEST,
  PAYMENT_SUCCESS,
  PAYMENT_FAIL,
  PAYMENT_LOGOUT,
} from "../Contans/AdminContans";

export const paymentReducer = (state={payment:{}},action) => {
  switch (action.type) {
    case PAYMENT_REQUEST:
      return {
        loading: true,
        isPaymented: false,
      };
    case PAYMENT_SUCCESS:
      return {
        ...state,
        loading: false,
        isPaymented: true,
        paymentaction: action.payload,
      };
    case PAYMENT_FAIL:
      return {
        ...state,
        loading: false,
        isPaymented: false,
        paymentaction: null,
        error: action.payload,
      };
    case PAYMENT_LOGOUT:
      return {
        loading: false,
        isPaymented: false,
        paymentaction:null,
      }
    default:
      return state;
  }
}