import {
  ADMIN_LOGIN_STEPONE_REQUEST,
  ADMIN_LOGIN_STEPONE_SUCCESS,
  ADMIN_LOGIN_STEPONE_FAIL,
  ADMIN_LOGOUT,
} from "../Contans/AdminContans";

export const adminReducer = (state={admin:{}},action) => {
  switch (action.type) {
    case ADMIN_LOGIN_STEPONE_REQUEST:
      return {
        loading: true,
        isAuthenticated: false,
      };
    case ADMIN_LOGIN_STEPONE_SUCCESS:
      return {
        ...state,
        loading: false,
        isAuthenticated: true,
        user: action.payload,
      };
    case ADMIN_LOGIN_STEPONE_FAIL:
      return {
        ...state,
        loading: false,
        isAuthenticated: false,
        user: null,
        error: action.payload,
      };
    case ADMIN_LOGOUT:
      return {
        loading: false,
        isAuthenticated: false,
        user:null,
      }
    default:
      return state;
  }
}