import {
  COUNTRY_REQUEST,
  COUNTRY_SUCCESS,
  COUNTRY_FAIL,
 } from "../Contans/AdminContans";

export const countryReducer = (state={country:{}},action) => {
  switch (action.type) {
    case COUNTRY_REQUEST:
      return {
        loading: true,
        isAuthenticated: false,
      };
    case COUNTRY_SUCCESS:
      return {
        ...state,
        loading: false,
        isAuthenticated: true,
        country: action.payload,
      };
    case COUNTRY_FAIL:
      return {
        ...state,
        loading: false,
        isAuthenticated: false,
        country: null,
        error: action.payload,
      };
   default:
      return state;
  }
}