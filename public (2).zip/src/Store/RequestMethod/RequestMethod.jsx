import axios from "axios";

const BASE_URL = process.env.REACT_APP_API;
const BASE_URL_NEW = process.env.REACT_APP_API_NEW;
const LOGIN_URL = process.env.LOGIN_URL;
const AUTH_TOKEN = process.env.AUTH_TOKEN;
const user = JSON.parse(localStorage.getItem("persist:root"))?.admin;
const isAuthenticated = user && JSON.parse(user).isAuthenticated;
const isToken = user && JSON.parse(user).user?.token;
const company = process.env.REACT_APP_COMPANY_NAME;

export const publicRequest = axios.create({
  baseURL: BASE_URL,
});

export const userRequest = axios.create({
  baseURL: BASE_URL_NEW,
  headers: {
    authorization:
      'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9eyJfaWQiOiI2NDI1NmE2NjI4NTAxZWJkYTlkNzA0MDQiLCJ1c2VyX2NvZGUiOiJjMzM0N2ZmYzgxZmE2OTljZmIwZDI2NTciLCJlbWFpbF9pZCI6ImluZm9AYmxhem9uLmluIiwibW9iaWxlX251bWJlciI6IjYzODI3Mzk2MzUiLCJjb21wYW55X2NvZGUiOiJWWFhBVjE1RjdCUTFaOElFV09FNDVUM09TMFJQNDIiLCJyb2xlIjoiU3VwZXJhZG1pbiIsInNlc3Npb25faWQiOiI2NDI2OWMwZGE2MDNkOWYzZTljMDJjY2EiLCJpYXQiOjE2ODAyNTE5MTcsImV4cCI6MTY4MjAxODU2OTc1M30tL1vUm8MKx7p34FcO2k02y - bJtztSMM1ajX3f02KCIE',
  },
});
// 'Content-Type': 'application/json',
    // 'Content-Type': 'application/x-www-form-urlencoded',
export const getRequest = axios.create({
  baseURL: BASE_URL_NEW,
 
  
});

export const getRequestCommon = axios.create({
  baseURL: BASE_URL_NEW,
  headers: {
    "Content-Type": "text/plain",
    Accept: 'application/json, text/plain, */*',
  },
});





