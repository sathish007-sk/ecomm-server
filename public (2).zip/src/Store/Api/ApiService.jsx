import { getRequest, userRequest } from "../RequestMethod/RequestMethod";
import {
  ADMIN_LOGIN_STEPONE_REQUEST,
  ADMIN_LOGIN_STEPONE_SUCCESS,
  ADMIN_LOGIN_STEPONE_FAIL,
  NEW_REGISTER_REQUEST,
  NEW_REGISTER_SUCCESS,
  NEW_REGISTER_FAIL,
  NEW_REGISTER_LOGOUT,
  NEW_REGISTER_UPDATE_REQUEST,
  NEW_REGISTER_UPDATE_SUCCESS,
  NEW_REGISTER_UPDATE_FAIL,
  NEW_REGISTER_UPDATE_LOGOUT,
} from "../Contans/AdminContans";

class API {
  constructor() {
    this.rootUrl1 = process.env.REACT_APP_API;
    this.company = process.env.REACT_APP_COMPANY_NAME;
    this.token = process.env.REACT_APP_COMPANY_NAME;
  }

  login = async (dispatch, data) => {
    try {
      dispatch({ type: ADMIN_LOGIN_STEPONE_REQUEST });
      const res = await getRequest.post("/admin/login", data);
      if (res.data.success === true) {
        dispatch({
          type: ADMIN_LOGIN_STEPONE_SUCCESS,
          payload: [res.data.result],
        });
      } else {
        dispatch({
          type: NEW_REGISTER_FAIL,
          payload: [res.data],
        });
      }
      return res;
    } catch (error) {
      const res = error.response;
      dispatch({
        type: ADMIN_LOGIN_STEPONE_FAIL,
        payload: error.response.data.message,
      });
      return res;
    }
  };

  stepTwo = async (dispatch, data) => {
    try {
      dispatch({ type: NEW_REGISTER_UPDATE_REQUEST });
      const res = await getRequest.put("step1.php", data);
      if (res.data.success === true) {
        dispatch({
          type: NEW_REGISTER_UPDATE_SUCCESS,
          payload: [res.data, res.config.data],
        });
      } else {
        dispatch({
          type: NEW_REGISTER_UPDATE_FAIL,
          payload: [res.data, res.config.data],
        });
      }
      return res;
    } catch (error) {
      const res = error.response;
      dispatch({
        type: NEW_REGISTER_UPDATE_FAIL,
        payload: error.response.data.message,
      });
      return res;
    }
  };

  cancelPayment = async (dispatch) => {
    dispatch({
      type: NEW_REGISTER_LOGOUT,
      isRegister: false,
      registeraction: null,
      payload: [],
    });
  };
  cancelPayment1 = async (dispatch) => {
    dispatch({
      type: NEW_REGISTER_UPDATE_LOGOUT,
      isRegisterUpdate: false,
      registerupdateaction: null,
      payload: [],
    });
  };

  //Brand,Category,SubCategory,Specification,Country,State,District

  getbrandlist = async (data,mode) => {
        let url1 = data.url1;
        let Url1 = data.Url1;
    try {
      const res = await userRequest.get(`${url1}/get${Url1}`,{params:mode} );
      return res;
    } catch (error) {
      const res = error.response;
      return res;
    }
  };

  getbrandsingle = async (data) => {
    try {
      const res = await userRequest.get(`maincategory.php`, { params: data });
      return res;
    } catch (error) {
      const res = error.response;
      return res;
    }
  };

  deletebrand = async (data) => {
    try {
      const res = await userRequest.delete(`maincategory.php`, {
        params: data,
      });
      return res;
    } catch (error) {
      const res = error.response;
      return res;
    }
  };

  addbrand = async (data) => {
    try {
      const res = await userRequest.post(`maincategory.php`, data);
      return res;
    } catch (error) {
      const res = error.response;
      return res;
    }
  };

  updatebrand = async (data) => {
    try {
      const res = await userRequest.put(`maincategory.php`, null, {
        params: data,
      });
      return res;
    } catch (error) {
      const res = error.response;
      return res;
    }
  };

  // ecdigi api

  getTaxdata = async (data) => {
    try {
      const res = await userRequest.get(`tax/getTax`);
      return res;
    } catch (error) {
      const res = error.response;
      return res;
    }
  };
  addTaxdata = async (data) => {
    try {
      const res = await userRequest.post(`tax/addTax`, data);
      return res;
    } catch (error) {
      const res = error.response;
      return res;
    }
  };
  deleteTaxdata = async (data) => {
    try {
      const res = await userRequest.delete(`tax/deleteTax/${data}`);
      return res;
    } catch (error) {
      const res = error.response;
      return res;
    }
  };
  ViewTaxdata = async (data) => {
    try {
      console.log(data);
      const res = await userRequest.get(`tax/viewTax/${data}`);
      console.log(res);
      return res;
    } catch (error) {
      const res = error.response;
      return res;
    }
  };
  editTaxdata = async (id, data) => {
    console.log(id);
    try {
      console.log(data);
      const res = await userRequest.put(`tax/editTax/${id}`, data);
      console.log(res);
      return res;
    } catch (error) {
      const res = error.response;
      return res;
    }
  };
  // product
  getdata = async (data) => {
    let url1 = data.url1;
    let Url1 = data.Url1;
     let data1={}
     if (data.params) {
       data1.mode = data.params;
     }
    try {
      const res = await userRequest.get(`${url1}/get${Url1}`, {params:data1});
      return res;
    } catch (error) {
      const res = error.response;
      return res;
    }
  };
  adddata = async (data, FormData) => {
    let url1 = data.url1;
    let Url1 = data.Url1;

    try {
      const res = await userRequest.post(`${url1}/add${Url1}`, FormData);
      return res;
    } catch (error) {
      const res = error.response;
      return res;
    }
  };
  deletedata = async (data) => {
    let url1 = data.url1;
    let Url1 = data.Url1;
    let _id = data.id;
    try {
      const res = await userRequest.delete(`${url1}/delete${Url1}/${_id}`);
      return res;
    } catch (error) {
      const res = error.response;
      return res;
    }
  };
  Viewdata = async (data) => {
    let url1 = data.url1;
    let Url1 = data.Url1;
    let _id = data.id;
    try {
      console.log(data);
      const res = await userRequest.get(`${url1}/view${Url1}/${_id}`);
      console.log(res);
      return res;
    } catch (error) {
      const res = error.response;
      return res;
    }
  };
  editdata = async (data, Formdata) => {
    let url1 = data.url1;
    let Url1 = data.Url1;
    let _id = data.id;

    try {
      console.log(data);
      const res = await userRequest.put(`${url1}/edit${Url1}/${_id}`, Formdata);
      console.log(res);
      return res;
    } catch (error) {
      const res = error.response;
      return res;
    }
  };
  // Product Data

  //Admin Menu Dynamic

  getdynamicmenulist = async () => {
    try {
      const res = await userRequest.get(`adminmenus.php`);
      return res;
    } catch (error) {
      const res = error.response;
      return res;
    }
  };

  //  brand ,
  getProductsdata = async (data,mode) => {
    let url1 = data.url1;
    let Url1 = data.Url1;
    try {
      const res = await userRequest.get(`${url1}/get${Url1}`,{ params: mode });
      return res;
    } catch (error) {
      const res = error.response;
      return res;
    }
  };

  getproductlist = async () => {
    try {
      const res = await userRequest.get(`product.php`);
      return res;
    } catch (error) {
      const res = error.response;
      return res;
    }
  };

  getproductsingle = async (data) => {
    try {
      const res = await userRequest.get(`product.php`, { params: data });
      return res;
    } catch (error) {
      const res = error.response;
      return res;
    }
  };

  addproduct = async (data) => {
    try {
      const res = await userRequest.post(`product.php`, null, { params: data });
      return res;
    } catch (error) {
      const res = error.response;
      return res;
    }
  };

  deleteproduct = async (data) => {
    try {
      const res = await userRequest.delete(`product.php`, {
        params: data,
      });
      return res;
    } catch (error) {
      const res = error.response;
      return res;
    }
  };

  updateproduct = async (data) => {
    try {
      const res = await userRequest.put(`product.php`, null, {
        params: data,
      });
      return res;
    } catch (error) {
      const res = error.response;
      return res;
    }
  };

  // sub_categoty

  getsubcategorylist = async () => {
    try {
      const res = await userRequest.get(`category_sub.php`);
      return res;
    } catch (error) {
      const res = error.response;
      return res;
    }
  };

  getsubcategorysingle = async (data) => {
    try {
      const res = await userRequest.get(`category_sub.php`, data);
      return res;
    } catch (error) {
      const res = error.response;
      return res;
    }
  };

  addsubcategory = async (data) => {
    try {
      const res = await userRequest.post(`category_sub.php`, null, {
        params: data,
      });
      return res;
    } catch (error) {
      const res = error.response;
      return res;
    }
  };

  deletsubcategory = async (data) => {
    try {
      const res = await userRequest.delete(`category_sub.php`, {
        params: data,
      });
      return res;
    } catch (error) {
      const res = error.response;
      return res;
    }
  };

  updatesubcategory = async (data) => {
    try {
      const res = await userRequest.put(`category_sub.php`, null, {
        params: data,
      });
      return res;
    } catch (error) {
      const res = error.response;
      return res;
    }
  };
}



export default API;
