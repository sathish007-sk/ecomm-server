import React from 'react'
import './Assets/Css/style.css'
import Dashboard from './Pages/Dashboard';

const App = () => {
  
  return (
    <React.Fragment>
      <Dashboard />
    </React.Fragment>
  )
}

export default App;