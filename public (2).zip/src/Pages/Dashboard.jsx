import React, { useLayoutEffect, lazy, Suspense } from 'react';
import {
  MoreOutlined, KeyOutlined, LoginOutlined, UserOutlined
} from '@ant-design/icons';
import { Dropdown, Layout, theme, Spin, Space, Avatar, Input, Badge } from 'antd';
import {
  BrowserRouter as Router,
  Routes,
  Route,
  useLocation,
  Link,
  Navigate
} from "react-router-dom";
import styled from 'styled-components';
import logo from '../Assets/Images/logo.png';
import API from '../Store/Api/ApiService';
import { useDispatch } from "react-redux";
import {
  ADMIN_LOGOUT,
} from "../Store/Contans/AdminContans";
import bell from '../Assets/Images/bell.png';
import message from '../Assets/Images/message.png';



















const { Search } = Input;

//Component Lazy Loading..
const Login = lazy(() => import("../Component/Login"));
const MenuBar = lazy(() => import("../Component/MenuBar"));
const MobileMenu = lazy(() => import("../Component/MobileMenu"));
const Home = lazy(() => import("../Component/Home"));
const Register = lazy(() => import("../Component/Register"));
const NoPage = lazy(() => import("../Component/NoPage"));
const Category = lazy(() => import("../Component/Category"));
const Country = lazy(() => import("../Component/Country"));
const State = lazy(() => import("../Component/State"));
const District = lazy(() => import("../Component/District"));
const Brand = lazy(() => import("../Component/Brand"));
const Specification = lazy(() => import("../Component/Specification"));
const Roles = lazy(() => import("../Component/Roles"));
const BuyerCategory = lazy(() => import("../Component/BuyerCategory"));
const Offers = lazy(() => import("../Component/Offers"));
const AddProduct = lazy(() => import("../Component/AddProduct"));
const EditProduct = lazy(() => import("../Component/EditProduct"));
const Product = lazy(() => import("../Component/Product"));
const Productimage = lazy(() => import("../Component/Productimage"));
const BuyerRegister = lazy(() => import("../Component/BuyerRegister"));

const Test = lazy(() => import("../Component/Test"));
const DeliveryCharges = lazy(() => import("../Component/DeliveryCharges"));
const Tax = lazy(() => import("../Component/Tax"));
const About = lazy(() => import("../Component/Cms/About"));
const Banner = lazy(() => import("../Component/Cms/Banner"));
const Template = lazy(() => import("../Component/Cms/Template"));
const SubCategory = lazy(() => import("../Component/SubCategory"));
const OfferRules = lazy(() => import("../Component/OfferRules"));
const Users = lazy(() => import("../Component/users"));
const Damageinfo = lazy(() => import("../Component/Damageinfo"));
const Deliveryinfo = lazy(() => import("../Component/Deliveryinfo"));
const Dispatchinfo = lazy(() => import("../Component/Dispatchinfo"));
const Mastersettings = lazy(() => import("../Component/MasterSetting"));
const SpeceificationDetail = lazy(() =>
  import("../Component/SpeceificationDeatil")
);


const ContactUs = lazy(() => import("../Component/Cms/ContactUs"));
const DeliveryPolicy = lazy(() => import("../Component/Cms/DeliveryPolicy"));
const PrivacyPolicy = lazy(() => import("../Component/Cms/PrivacyPolicy"));
const RefundPolicy = lazy(() => import("../Component/Cms/RefundPolicy"));
const TermsAndCondition = lazy(() => import("../Component/Cms/TermsAndCondition"));
const CancellationPolicy = lazy(() => import("../Component/Cms/CancellationPolicy"));
const User = lazy(() => import("../Component/User/ListUser"));
const Multer = lazy(() => import("../Component/User/multer"));
const Role = lazy(() => import("../Component/Role/ListRole"));
const InvesterType = lazy(() => import("../Component/Role/InvesterType"));
const ProductSeo = lazy(() => import("../Component/Productseo"));
const ProductVideo = lazy(() => import("../Component/ProductVideo"));
const Discounts = lazy(() => import("../Component/Discounts"));
const DiscountRules = lazy(() => import("../Component/DiscountRules"));
const Bullion = lazy(() => import("../Component/Bullion"));
const Cart = lazy(() => import("../Component/Cart"));
const Sellerinfo = lazy(() => import("../Component/Sellerinfo"));
const PakingInfo = lazy(() => import("../Component/Pakinginfo"));
const Wishlist = lazy(() => import("../Component/Wishlist"));
const Orderinfo = lazy(() => import("../Component/Orderinfo"));





const { Header, Content, Footer } = Layout;



const Dashboard = () => {
  const user = JSON.parse(localStorage.getItem("persist:root"))?.admin;
  console.log(user)
   const isAuthenticated = user && JSON.parse(user).isAuthenticated;
  // const isAuthenticated =true;
  const d = new Date();   
  const dispatch = useDispatch();
  const {
    token: { colorBgContainer },
  } = theme.useToken();
  const api = new API();
  const Wrapper = ({ children }) => {
    const location = useLocation();
    useLayoutEffect(() => {
      document.documentElement.scrollTo(500, 0);
    }, [location.pathname]);
    return children;
  };

  const logout = () => {
    dispatch({ type: ADMIN_LOGOUT });
    window.location.reload();
  }

  const items = [
    {
      label: <><UserOutlined /> My Profile</>,
      key: '0',
    },
    {
      label: <><KeyOutlined /> Change Password</>,
      key: '1',
    },
    {
      label: <><LoginOutlined /> Logout</>,
      key: '2',
    },
  ];

  


  return (
    <React.Fragment>
      <Router basename="/">
        <Wrapper>
          <Suspense
            fallback={
              <div className="suspense_wrap">
                <Spin tip="Loading" size="small" />
              </div>
            }
          >
            {isAuthenticated === true ? (
              <DashboardSection>
                <Layout
                  style={{
                    minHeight: "100vh",
                  }}
                >
                  <MenuBar />
                  <Layout className="site-layout">
                    <Header
                      style={{
                        padding: 0,
                        background: colorBgContainer,
                        position: "fixed",
                        top: 0,
                        left: 0,
                        width: "100%",
                        zIndex: 1000,
                      }}
                    >
                      <div className="header_align">
                        <div className="header_left">
                          <div className="header_left_menu">
                            <MobileMenu />
                          </div>
                          <Link to="/">
                            <img src={logo} alt="ecDigi Technology" />
                          </Link>
                        </div>
                        <div className="header_right">
                          <Search
                            placeholder="Search"
                            size="middle"
                            className="serach_head_btn"
                          />
                          <div className="right_side_bar">
                            <div className="batch_align">
                              <Badge count={0} showZero size="small">
                                <img src={bell} alt="Notification" />
                              </Badge>
                              <Badge count={0} showZero size="small">
                                <img src={message} alt="Message" />
                              </Badge>
                            </div>
                            <Dropdown
                              menu={{
                                items,
                              }}
                              trigger={["click"]}
                            >
                              <a
                                onClick={(e) => e.preventDefault()}
                                className="account_name"
                              >
                                <Space>
                                  <Avatar
                                    className="avator_profile"
                                    size="small"
                                    style={{ backgroundColor: "#87d068" }}
                                    icon={<UserOutlined />}
                                  />
                                  <MoreOutlined />
                                </Space>
                              </a>
                            </Dropdown>
                          </div>
                        </div>
                      </div>
                    </Header>

                    <Content
                      style={{
                        margin: "0 16px",
                        padding: "80px 0px 50px 0px",
                      }}
                    >
                      <Routes>
                        <Route
                          exact
                          path="/signup"
                          element={
                            isAuthenticated === true ? (
                              <Navigate to="/" replace />
                            ) : (
                              <Register />
                            )
                          }
                        />
                        <Route
                          path="/login"
                          element={
                            isAuthenticated === true ? (
                              <Navigate to="/" replace />
                            ) : (
                              <Login />
                            )
                          }
                        />
                        <Route
                          exact
                          index
                          path="/"
                          element={
                            isAuthenticated === true ? (
                              <Home />
                            ) : (
                              <Navigate to="/login" replace />
                            )
                          }
                        />
                        <Route
                          exact
                          path="/category"
                          element={
                            isAuthenticated === true ? (
                              <Category />
                            ) : (
                              <Navigate to="/login" replace />
                            )
                          }
                        />
                        <Route
                          exact
                          path="/productimages"
                          element={
                            isAuthenticated === true ? (
                              <Productimage />
                            ) : (
                              <Navigate to="/login" replace />
                            )
                          }
                        />
                        <Route
                          exact
                          path="/cart"
                          element={
                            isAuthenticated === true ? (
                              <Cart />
                            ) : (
                              <Navigate to="/login" replace />
                            )
                          }
                        />
                        <Route
                          exact
                          path="/sellerinfo"
                          element={
                            isAuthenticated === true ? (
                              <Sellerinfo />
                            ) : (
                              <Navigate to="/login" replace />
                            )
                          }
                        />
                        <Route
                          exact
                          path="/users"
                          element={
                            isAuthenticated === true ? (
                              <Users />
                            ) : (
                              <Navigate to="/login" replace />
                            )
                          }
                        />
                        <Route
                          exact
                          path="/orderinfo"
                          element={
                            isAuthenticated === true ? (
                              <Orderinfo />
                            ) : (
                              <Navigate to="/login" replace />
                            )
                          }
                        />
                        <Route
                          exact
                          path="/dispatchinfo"
                          element={
                            isAuthenticated === true ? (
                              <Dispatchinfo />
                            ) : (
                              <Navigate to="/login" replace />
                            )
                          }
                        />
                        <Route
                          exact
                          path="/mastersetting"
                          element={
                            isAuthenticated === true ? (
                              <Mastersettings />
                            ) : (
                              <Navigate to="/login" replace />
                            )
                          }
                        />
                        <Route
                          exact
                          path="/damageinfo"
                          element={
                            isAuthenticated === true ? (
                              <Damageinfo />
                            ) : (
                              <Navigate to="/login" replace />
                            )
                          }
                        />
                        <Route
                          exact
                          path="/deliveryinfo"
                          element={
                            isAuthenticated === true ? (
                              <Deliveryinfo />
                            ) : (
                              <Navigate to="/login" replace />
                            )
                          }
                        />
                        <Route
                          exact
                          path="/wislist"
                          element={
                            isAuthenticated === true ? (
                              <Wishlist />
                            ) : (
                              <Navigate to="/login" replace />
                            )
                          }
                        />
                        <Route
                          exact
                          path="/pakinginfo"
                          element={
                            isAuthenticated === true ? (
                              <PakingInfo />
                            ) : (
                              <Navigate to="/login" replace />
                            )
                          }
                        />
                        <Route
                          exact
                          path="/productseo"
                          element={
                            isAuthenticated === true ? (
                              <ProductSeo />
                            ) : (
                              <Navigate to="/login" replace />
                            )
                          }
                        />
                        <Route
                          exact
                          path="/deiscound"
                          element={
                            isAuthenticated === true ? (
                              <Discounts />
                            ) : (
                              <Navigate to="/login" replace />
                            )
                          }
                        />
                        <Route
                          exact
                          path="/offerrules"
                          element={
                            isAuthenticated === true ? (
                              <OfferRules />
                            ) : (
                              <Navigate to="/login" replace />
                            )
                          }
                        />
                        <Route
                          exact
                          path="/productvideo"
                          element={
                            isAuthenticated === true ? (
                              <ProductVideo />
                            ) : (
                              <Navigate to="/login" replace />
                            )
                          }
                        />
                        <Route
                          exact
                          path="/country"
                          element={
                            isAuthenticated === true ? (
                              <Country />
                            ) : (
                              <Navigate to="/login" replace />
                            )
                          }
                        />
                        <Route
                          exact
                          path="/buyer"
                          element={
                            isAuthenticated === true ? (
                              <BuyerRegister />
                            ) : (
                              <Navigate to="/login" replace />
                            )
                          }
                        />
                        <Route
                          exact
                          path="/speceification-detail"
                          element={
                            isAuthenticated === true ? (
                              <SpeceificationDetail />
                            ) : (
                              <Navigate to="/login" replace />
                            )
                          }
                        />
                        <Route
                          exact
                          path="/discountrule"
                          element={
                            isAuthenticated === true ? (
                              <DiscountRules />
                            ) : (
                              <Navigate to="/login" replace />
                            )
                          }
                        />
                        <Route
                          exact
                          path="/state"
                          element={
                            isAuthenticated === true ? (
                              <State />
                            ) : (
                              <Navigate to="/login" replace />
                            )
                          }
                        />
                        <Route
                          exact
                          path="/district"
                          element={
                            isAuthenticated === true ? (
                              <District />
                            ) : (
                              <Navigate to="/login" replace />
                            )
                          }
                        />
                        <Route
                          exact
                          path="/brand"
                          element={
                            isAuthenticated === true ? (
                              <Brand />
                            ) : (
                              <Navigate to="/login" replace />
                            )
                          }
                        />
                        <Route
                          exact
                          path="/image"
                          element={
                            isAuthenticated === true ? (
                              <Multer />
                            ) : (
                              <Navigate to="/login" replace />
                            )
                          }
                        />
                        <Route
                          exact
                          path="/offer"
                          element={
                            isAuthenticated === true ? (
                              <Offers />
                            ) : (
                              <Navigate to="/login" replace />
                            )
                          }
                        />
                        <Route
                          exact
                          path="/bullion"
                          element={
                            isAuthenticated === true ? (
                              <Bullion />
                            ) : (
                              <Navigate to="/login" replace />
                            )
                          }
                        />
                        <Route
                          exact
                          path="/addproduct/:id"
                          element={
                            isAuthenticated === true ? (
                              <AddProduct />
                            ) : (
                              <Navigate to="/login" replace />
                            )
                          }
                        />
                        <Route
                          exact
                          path="/buyercategory"
                          element={
                            isAuthenticated === true ? (
                              <BuyerCategory />
                            ) : (
                              <Navigate to="/login" replace />
                            )
                          }
                        />
                        <Route
                          exact
                          path="/speceification"
                          element={
                            isAuthenticated === true ? (
                              <Specification />
                            ) : (
                              <Navigate to="/login" replace />
                            )
                          }
                        />
                        <Route
                          exact
                          path="/product"
                          element={
                            isAuthenticated === true ? (
                              <Product />
                            ) : (
                              <Navigate to="/login" replace />
                            )
                          }
                        />
                        <Route
                          exact
                          path="/sub-category"
                          element={
                            isAuthenticated === true ? (
                              <SubCategory />
                            ) : (
                              <Navigate to="/login" replace />
                            )
                          }
                        />{" "}
                        <Route
                          exact
                          path="/tax"
                          element={
                            isAuthenticated === true ? (
                              <Tax />
                            ) : (
                              <Navigate to="/login" replace />
                            )
                          }
                        />
                        <Route
                          exact
                          path="/tax"
                          element={
                            isAuthenticated === true ? (
                              <Tax />
                            ) : (
                              <Navigate to="/login" replace />
                            )
                          }
                        />
                        <Route
                          exact
                          path="/cms/about"
                          element={
                            isAuthenticated === true ? (
                              <About />
                            ) : (
                              <Navigate to="/login" replace />
                            )
                          }
                        />
                        <Route
                          exact
                          path="/cms/banner"
                          element={
                            isAuthenticated === true ? (
                              <Banner />
                            ) : (
                              <Navigate to="/login" replace />
                            )
                          }
                        />
                        <Route
                          exact
                          path="/cms/template"
                          element={
                            isAuthenticated === true ? (
                              <Template />
                            ) : (
                              <Navigate to="/login" replace />
                            )
                          }
                        />
                        <Route
                          exact
                          path="/cms/privacy-policy"
                          element={
                            isAuthenticated === true ? (
                              <PrivacyPolicy />
                            ) : (
                              <Navigate to="/login" replace />
                            )
                          }
                        />
                        <Route
                          exact
                          path="/cms/delivery-policy"
                          element={
                            isAuthenticated === true ? (
                              <DeliveryPolicy />
                            ) : (
                              <Navigate to="/login" replace />
                            )
                          }
                        />
                        <Route
                          exact
                          path="/cms/refund-policy"
                          element={
                            isAuthenticated === true ? (
                              <RefundPolicy />
                            ) : (
                              <Navigate to="/login" replace />
                            )
                          }
                        />
                        <Route
                          exact
                          path="/cms/cancellation-policy"
                          element={
                            isAuthenticated === true ? (
                              <CancellationPolicy />
                            ) : (
                              <Navigate to="/login" replace />
                            )
                          }
                        />
                        <Route
                          exact
                          path="/user"
                          element={
                            isAuthenticated === true ? (
                              <User />
                            ) : (
                              <Navigate to="/login" replace />
                            )
                          }
                        />
                        <Route
                          exact
                          path="/role"
                          element={
                            isAuthenticated === true ? (
                              <Role />
                            ) : (
                              <Navigate to="/login" replace />
                            )
                          }
                        />
                        <Route
                          exact
                          path="/cms/cancellation-policy"
                          element={
                            isAuthenticated === true ? (
                              <CancellationPolicy />
                            ) : (
                              <Navigate to="/login" replace />
                            )
                          }
                        />
                        <Route
                          exact
                          path="/cms/privacy-policy"
                          element={
                            isAuthenticated === true ? (
                              <ContactUs />
                            ) : (
                              <Navigate to="/login" replace />
                            )
                          }
                        />
                        <Route
                          exact
                          path="/deliverycharge"
                          element={
                            isAuthenticated === true ? (
                              <DeliveryCharges />
                            ) : (
                              <Navigate to="/login" replace />
                            )
                          }
                        />
                        <Route
                          exact
                          path="/editproduct/:id"
                          element={
                            isAuthenticated === true ? (
                              <EditProduct />
                            ) : (
                              <Navigate to="/login" replace />
                            )
                          }
                        />
                        <Route
                          exact
                          path="/invester-type"
                          element={
                            isAuthenticated === true ? (
                              <InvesterType />
                            ) : (
                              <Navigate to="/login" replace />
                            )
                          }
                        />
                        <Route path="*" element={<NoPage />} />
                      </Routes>
                    </Content>

                    <Footer
                      style={{
                        textAlign: "center",
                        fontFamily: "q_bold",
                        fontSize: "13px",
                      }}
                    >
                      ©{d.getFullYear()} Developed by{" "}
                      <a
                        href="https://ecdigi.com/"
                        title="ecDigi Technologies"
                        target="_blank"
                        rel="noreferrer"
                        style={{ color: "var(--bg)", fontWeight: 600 }}
                      >
                        ecDigi Technologies
                      </a>
                    </Footer>
                  </Layout>
                </Layout>
              </DashboardSection>
            ) : (
              <Routes>
                <Route
                  exact
                  path="/signup"
                  element={
                    isAuthenticated === false ? (
                      <Register />
                    ) : (
                      <Navigate to="/" replace />
                    )
                  }
                />

                <Route
                  path="/"
                  element={
                    isAuthenticated === false ? (
                      <Navigate to="/login" replace />
                    ) : (
                      <Login />
                    )
                  }
                />
                <Route
                  path="/login"
                  element={
                    isAuthenticated === false ? (
                      <Login />
                    ) : (
                      <Navigate to="/" replace />
                    )
                  }
                />
                <Route path="*" element={<NoPage />} />
              </Routes>
            )}
          </Suspense>
        </Wrapper>
      </Router>
    </React.Fragment>
  );
}

export default Dashboard;


const DashboardSection = styled.section`
  
  #components-layout-demo-side .logo {
    height: 25px;
    margin: 16px;
    background: rgba(255, 255, 255, 0.3);
  }
  .D_Header {
    position: sticky;
    top: 0;
    left: 0px;
    width: 100%;
    z-index: 100;
  }
  .site-layout .site-layout-background,
  .ant-layout-sider,
  .ant-menu-dark .ant-menu-sub,
  .ant-menu.ant-menu-dark,
  .ant-menu.ant-menu-dark .ant-menu-sub,
  .ant-layout-sider-trigger {
    background: #fff;
  }
  .logo {
    height: 55px;
    border-bottom: 1px solid #f5f5f5;
    border-right: 1px solid #f5f5f5;
    text-align: center;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 23px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.2px;
  }

  .LayoutSection {
    min-height: 100vh;
  }
  .ant-layout-header {
    background: #fff;
    padding: 10px 20px 10px 20px;
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    justify-content: space-between;
    line-height: normal;
    border-bottom: 1px solid #f5f5f5;
    height: 55px;
  }
  .ant-layout,
  body {
    background: #f6f9ff;
  }
  .ant-layout-sider-trigger {
    color: #f6f9ff;
    border-top: 1px solid #f2f2f2;
    background: #000;
    z-index: 120;
    height: 40px;
    line-height: 40px;
}

  .ant-menu-dark .ant-menu-sub,
  .ant-menu.ant-menu-dark,
  .ant-menu.ant-menu-dark .ant-menu-sub,
  .ant-menu-dark .ant-menu-item,
  .ant-menu-dark .ant-menu-item-group-title,
  .ant-menu-dark .ant-menu-item > a,
  .ant-menu-dark .ant-menu-item > span > a {
    color: #000;
  }

  .ant-layout-footer {
    padding: 12px 15px;
    background: #f6f9ff;
    color: #000;
    text-align: center;
    border-top: 1px solid #f5f5f5;
  }
  .Contents {
    width: 100%;
    display: inline-block;
    position: relative;
    padding: 24px;
    margin: 0px 0 0 0;
  }
  .BreadCrumb {
    margin: 0 0 30px;
  }
  .ant-layout-sider-children {
    position: fixed;
    width: 200px;
    z-index: 101;
    top:0;
  }
  ul.ant-menu.ant-menu-root.ant-menu-inline.ant-menu-light,
  .ant-layout-sider-children .ant-menu.ant-menu-inline-collapsed {
    border-right: 1px solid #f0f0f0;
    height: 85vh;
    min-height: 85vh;
    max-height: 85vh;
    overflow: hidden;
    overflow-y: auto;
    padding: 0 0 20px;
  }

  /* width */
  ul.ant-menu.ant-menu-root.ant-menu-inline.ant-menu-light::-webkit-scrollbar,
  .ant-layout-sider-children
    .ant-menu.ant-menu-inline-collapsed::-webkit-scrollbar {
    width: 5px;
  }

  /* Track */
  ul.ant-menu.ant-menu-root.ant-menu-inline.ant-menu-light::-webkit-scrollbar-track,
  .ant-layout-sider-children
    .ant-menu.ant-menu-inline-collapsed::-webkit-scrollbar-track {
    background: #f1f1f1;
  }

  /* Handle */
  ul.ant-menu.ant-menu-root.ant-menu-inline.ant-menu-light::-webkit-scrollbar-thumb,
  .ant-layout-sider-children
    .ant-menu.ant-menu-inline-collapsed::-webkit-scrollbar-thumb {
    background: #888;
    border-radius: 5px;
  }

  /* Handle on hover */
  ul.ant-menu.ant-menu-root.ant-menu-inline.ant-menu-light::-webkit-scrollbar-thumb:hover,
  .ant-layout-sider-children
    .ant-menu.ant-menu-inline-collapsed::-webkit-scrollbar-thumb:hover {
    background: #555;
  }

  .ant-layout-sider.ant-layout-sider-dark.ant-layout-sider-collapsed.ant-layout-sider-has-trigger
    .ant-layout-sider-children {
      width: 60px;
  }
  .ant-menu-item-selected {
    background-color: rgb(245 146 9 / 10%);
    margin: 0 !important;
    width: 100% !important;
    border-radius: 0;
}

.ant-menu-item-selected .ant-menu-item-icon svg {
  color: var(--bg);
}
.ant-menu-title-content {
  font-size: 13px;
  font-family: "q_bold";
}
.ant-menu-item-selected .ant-menu-title-content {
  color: var(--bg);
}
.ant-menu-item {
    height: 37px;
    line-height: 37px;
    width: 100% !important;
    border-radius: 0;
    margin: 5px 0 !important;
}
.ant-menu-submenu-title {
  margin: 5px 0;
  height: 37px !important;
    line-height: 37px !important;
  width: 100% !important;
    border-radius: 0;
}
.ant-layout-sider.ant-layout-sider-dark.ant-layout-sider-collapsed.ant-layout-sider-has-trigger {
  flex: 0 0 60px !important;
    max-width: 60px !important;
    min-width: 60px !important;
    width: 60px !important;
}
.ant-layout-sider.ant-layout-sider-dark.ant-layout-sider-collapsed.ant-layout-sider-has-trigger .ant-layout-sider-trigger {
  width: 60px !important;
}
.ant-menu-sub .ant-menu-title-content {
  font-family: "q_medium" !important;
}

.header_align {
  display: flex;
  align-items: center;
  height: 55px;
  padding: 5px 17px;
  justify-content: space-between;
  width: 100%;
  z-index: 1000;
  box-shadow: 0 0 5px rgb(0 0 0 / 12%);
}
.header_align .header_left {
  width: 235px;
  display: flex;
  align-items: center;
  gap:15px;
}
.header_left_menu {
  display: none;
}
.header_align .header_left svg {
  font-size: 20px;
  cursor: pointer;
}
.header_align .header_right {
  width: 100%;
  display: flex;
  gap: 20px;
 justify-content: space-between;
  align-items: center;
  flex-direction: row;
}
.serach_head_btn {
  width: 220px;
}
.header_align .header_left img {
  height: 35px;
}
/* .header_align .header_right button {
  padding: 2px 8px;
  height: auto;
  font-family: 'q_medium';
  background: var(--bg);
  span {
  font-family: 'q_medium';
  }
}
.header_align .header_right button:hover {
  background: #000;
} */
.account_name .ant-space-item {
  font-size: 13px;
    font-family: "q_bold";
    color: #000;
    width: max-content;
    display: inline-block;
}

.header_align .header_right .ant-input {
  padding: 2px 11px;
}
.header_align .header_right .ant-input-group-addon button {
  height: 28px;
}

.avator_profile {
  width: 28px;
    height: 28px;
    line-height: 25px;
}

.right_side_bar {
  display: flex;
  align-items:center;
  gap: 20px;
}
.right_side_bar .batch_align {
  display: flex;
  gap: 20px;
}

.right_side_bar .batch_align img {
  height: 20px;
}
.ant-badge .ant-badge-count-sm {
    min-width: 12px;
    height: 12px;
    font-size: 9px;
    line-height: 11px;
    border-radius: 7px;
}

@media screen and (max-width:1200px) {
  .header_left_menu {
  display: block;
} 
}




@media screen and (max-width:768px) {

.header_align {
  position: relative;
    height: 100px;
    padding: 0 20px 45px 20px;
    background: #fff;
}

.serach_head_btn {
width: 100%;
    position: absolute;
    bottom: 12px;
    left: 0;
    margin: auto;
    padding: 0 16px;
}

.right_side_bar {
  margin: auto 0 auto auto;
}

main.ant-layout-content {
  padding: 120px 0px 50px !important  ;
}

.header_align .header_left img {
    height: 25px;
}
.account_name .ant-space-item {
    font-size: 12px;
}
.avator_profile {
    width: 23px;
    height: 23px;
    line-height: 21px;
    font-size: 11px;
    gap: 4px;
}

.right_side_bar {
  gap: 18px;
}
.right_side_bar .batch_align {
  gap: 15px;
}
.right_side_bar .batch_align img {
    height: 17px;
}
.ant-badge .ant-badge-count-sm {
    min-width: 11px;
    height: 11px;
    font-size: 9px;
    line-height: 10px;
    border-radius: 7px;
}

.header_align .header_left {
    width: fit-content;
    gap: 9px;
}
.header_align .header_left svg {
    font-size: 18px;
}

/* .account_name .ant-space-item { 

  display: none;
} */







}


@media screen and (max-width:380px) {
  .account_name .ant-space-item {
    font-size: 10px;
}
}








`;