import React, { useEffect, useState } from 'react'
import styled from "styled-components";
import API from '../Api/ApiService';
import { styles } from '../Api/Data';
import AgriTemplate from '../Components/Main/AgriTemplate';
import BannerMain from '../Components/Main/BannerMain';
import DynamicRows from '../Components/Main/DynamicRows';
import FPMain from '../Components/Main/FPMain'
import TCMain from '../Components/Main/TCMain';


const Home = () => {

  const api = new API()
  const [agri, setAgri] = useState([])
  const [furniture, setFurniture] = useState([])

  useEffect(()=>{
    templateCheck()
  },[])
  
  const templateCheck = () => {
    api.template().then((res)=>{
      let data = res.data;
      setAgri(
        data?.filter((item)=>{
          return item?.link==="Theme-5" && item?.install===true;
        })
      )
    }).catch((err)=>{})

    //Furniture
    api.template().then((res)=>{
      let data = res.data;
      setFurniture(
        data?.filter((item)=>{
          return item?.link==="Theme-1" && item?.install===true;
        })
      )
    }).catch((err)=>{})
  }

  


  return (
    <React.Fragment>
        <Section>
          <div className={furniture.length===1 ? "body_furniture" : "normaldiv"}>
          <BannerMain  />
          <TCMain />
          <FPMain />
          <DynamicRows />
          {
            agri?.length===1 ? <AgriTemplate /> : ""
          }
          </div>
        </Section>
        
    </React.Fragment>
  )
}

export default Home


const Section = styled.section`
display: flex;
flex-direction: column;
gap: 65px;
width: 100%;
.body_furniture {
  background: ${styles?.themebg};
  display: flex;
flex-direction: column;
  gap: 80px;
  width: 100%;
}

.normaldiv {
  display: flex;
flex-direction: column;
gap: 65px;
width: 100%;
}


`;