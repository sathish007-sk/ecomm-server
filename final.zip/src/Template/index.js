import React, { useEffect, useState } from "react";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  useLocation,
} from "react-router-dom";
import Home from '../Template/Home'
import Login from '../Ecommerce/Login'
import ForgotPassword from '../Ecommerce/ForgetPassword'
import Shop from '../Ecommerce/Shop'
import Product from '../Ecommerce/Product'
import Register from '../Ecommerce/Register'
import Cart from '../Ecommerce/Cart'
import CheckOut from '../Ecommerce/CheckOut'
import NoPage from '../Components/NoPage'
import LoginOtp from '../Ecommerce/LoginOtp'
import HeaderMain from "../Components/Main/HeaderMain";
import FooterMain from "../Components/Main/FooterMain";
import API from "../Api/ApiService";
import MyProfile from "../Ecommerce/MyProfile"
import MyAddress from "../Ecommerce/MyAddress"
import AddAddress from "../Ecommerce/AddAddress"
import EditAddress from "../Ecommerce/EditAddress"
import MyOrder from '../Ecommerce/MyOrder'
import SingleOrder from '../Ecommerce/SingleOrder'
import {useSelector} from "react-redux"
import AboutMain from "../Components/Main/AboutMain";
import ContactMain from "../Components/Main/ContactMain";
import Enquiry from "../Ecommerce/Enquiry"
import PrivacyPolicy from "../Components/Pages/PrivacyPolicy"
import DeliveryPolicy from "../Components/Pages/DeliveryPolicy"
import TermsAndCondition from "../Components/Pages/TermsAndCondition"
import Refund from "../Components/Pages/Refund"
import ReturnPolicy from "../Components/Pages/ReturnPolicy"
import CancellationPolicy from "../Components/Pages/CancellationPolicy"
import DryFrutes from "../Components/Main/DryFrutes";
import EShop from "../Components/Main/EShop";



const Index = () => {
  const loginTrue = useSelector((state) => state.user.currentUser?.token);
  
 

  const Wrapper = ({ children }) => {
    const location = useLocation();
    React.useLayoutEffect(() => {
      document.documentElement.scrollTo(500, 0);
    }, [location.pathname]);
    return children;
  };


  function RequireAuth({ children }) {
    return children;
  }


  return (
    <React.Fragment>
      <Router>
        <Wrapper>
          <HeaderMain />
          <Routes>
            <Route exact index path="/" element={<Home />} />
            <Route exact path="/login" element={<Login />} />
            <Route exact path="/about" element={<AboutMain />} />
            <Route exact path="/contact" element={<ContactMain />} />
            <Route exact path="/enquiry" element={<Enquiry />} />
            <Route exact path="/privacy-policy" element={<PrivacyPolicy page="privacy-policy" />} />
            <Route exact path="/delivery-policy" element={<DeliveryPolicy page="delivery-policy" />} />
            <Route exact path="/terms" element={<TermsAndCondition page="terms-and-conditions" />} />
            <Route exact path="/refund-policy" element={<Refund page="refund-policy" />} />
            <Route exact path="/return-policy" element={<ReturnPolicy page="return-policy" />} />
            <Route exact path="/cancellation-policy" element={<CancellationPolicy page="cancellation-policy" />} />            
            <Route exact path="/forgot-password" element={<ForgotPassword />} />
            <Route exact path="/login-with-otp" element={<LoginOtp />} />
            <Route exact path="/:catgory" element={RequireAuth && <Shop />} />
            <Route exact path="/:product/:id" element={RequireAuth && <Product />} />
            <Route exact path="/register" element={<Register />} />
            <Route exact path="/cart" element={!loginTrue && loginTrue!=="" && RequireAuth ? <Login /> : <Cart />} />
            <Route exact path="/checkout" element={!loginTrue && loginTrue!=="" ? <Login /> :<CheckOut />} />
            <Route exact path="/my-profile" element={!loginTrue && loginTrue!=="" && RequireAuth ? <Login /> :<MyProfile />} />
            <Route exact path="/my-address" element={!loginTrue && loginTrue!=="" ? <Login /> :<MyAddress />} />
            <Route exact path="/add-address" element={!loginTrue && loginTrue!=="" ? <Login /> :<AddAddress />} />
            <Route exact path="/my-order" element={!loginTrue && loginTrue!=="" && RequireAuth ? <Login /> : <MyOrder />} />
            <Route exact path="/my-order/order/:id" element={!loginTrue && loginTrue!=="" && RequireAuth ? <Login /> : <SingleOrder />} />            
            <Route exact path="/edit-address" element={!loginTrue && loginTrue!=="" ? <Login /> :<EditAddress />} />
            <Route exact path="*" element={<NoPage />} />
          </Routes>
          <FooterMain />
        </Wrapper>
      </Router>
    </React.Fragment>
  );
};

export default Index;
