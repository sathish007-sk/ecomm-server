import React, { useEffect } from 'react';
import "./Assets/Scss/Fonts/Fonts.scss";
import "./Assets/Css/style.css";
import "./Assets/Css/t1.css";
import "./Assets/Scss/ecommerce.scss";
import "./Assets/Scss/Temp_1.scss";
import "./Assets/Scss/Temp_2.scss";
import "./Assets/Scss/Temp_3.scss";
import "./Assets/Scss/Temp_4.scss";
import "./Assets/Scss/Temp_6.scss";
import "./Assets/Scss/Temp_5.scss";
import SelectTemplate from './SelectTemplate'
import {setCompany, socialMediaLinks, setColor} from './Store/companyAction'
import API from './Api/ApiService'
import { useDispatch } from "react-redux";

function App() {

  const api = new API();
  const dispatch = useDispatch();
  useEffect(()=>{
    api.company().then((res)=>res.data)
    .then((data)=>{
      dispatch(
        setCompany({
          ...data,
          logo: data?.logo ? api.rootUrl + data.logo : "/blazon-logo.svg",
        })
      )
    }).catch((err)=>{});

    api.socialmedia().then((res)=>res.data)
    .then((data)=>{
      dispatch(socialMediaLinks(data))
    }).catch((err)=>{});

    
  
    api.themes().then((res)=>{
      let data = {
        color:res?.data?.color,
        fontfamily:res?.data?.fontfamily
      }
      dispatch(setColor(data))
    }).catch((err)=>{})


  },[])



  return (
    <React.Fragment>
      <SelectTemplate />
    </React.Fragment>
  );
}

export default App;
