import { ActionTypes } from "./ActionType"
export const setCartList = (data) =>{
    return {
        type:ActionTypes.SET_CART_LIST,
        payload:data
    }
}
