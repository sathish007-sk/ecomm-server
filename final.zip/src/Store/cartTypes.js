import API from "../Api/ApiService"
import { handleCartList } from "./handleCart";
import { setCartList } from "./cartAction";
export const getCartList= ()=>dispatch=>{
    let api=new API();
    api.cartList()
    .then(res=>dispatch(setCartList(handleCartList(res.data))));
}



