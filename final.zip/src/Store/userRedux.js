import { createSlice } from "@reduxjs/toolkit";

const userSlice = createSlice({
  name: "user",
  initialState: {
    currentUser: null,
    isFetching: false,
    error: false,
  },
  reducers: {
    loginStart: (state) => {
      state.isFetching = true;
    },
    loginSuccess: (state, action) => {
      state.isFetching = false;
      state.currentUser = action.payload;
    },
    loginFailure: (state) => {
      state.isFetching = false;
      state.error = true;
    },
    registerStart: (state) => {
      state.isFetching = true;
    },
    registerSuccess: (state, action) => {
      state.isFetching = false;
      state.currentUser = action.payload;
    },
    registerFailure: (state) => {
      state.isFetching = false;
      state.error = true;
    },
    forgotStart: (state) => {
      state.isFetching = true;
    },
    forgotSuccess: (state, action) => {
      state.isFetching = false;
      state.currentUser = action.payload;
    },
    forgotFailure: (state) => {
      state.isFetching = false;
      state.error = true;
    },
    loginOtpStart: (state) => {
      state.isFetching = true;
    },
    loginOtpSuccess: (state, action) => {
      state.isFetching = false;
      state.currentUser = action.payload;
    },
    loginOtpFailure: (state) => {
      state.isFetching = false;
      state.error = true;
    },
    logoutUser: (state) => {
      state.currentUser = null;
    },
  },
});

export const { loginStart, loginSuccess, loginFailure, registerStart, registerSuccess, registerFailure, forgotStart, forgotSuccess, forgotFailure, loginOtpStart, loginOtpSuccess, loginOtpFailure, logoutUser } = userSlice.actions;
export default userSlice.reducer;
