import { ActionTypes } from './ActionType';

const initialState={
  products:[],
}

export const cartReducer = (state=initialState,action)=>{
  switch (action.type) {
    case ActionTypes.SET_CART_LIST:
      return {...state,products:action.payload};
    default:
      return state;
  }
}
