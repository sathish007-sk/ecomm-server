import { ActionTypes } from '../Store/ActionType';

const initialState={
  value:{},
  socialMediaLinks:[],
}

const companyReducer = (state=initialState,action)=>{
  switch (action.type) {
    case ActionTypes.SET_COMPANY:
      return {...state,value:action.payload};
    case ActionTypes.SET_SOCIALMEDIA_LINK:
    return {...state,socialMediaLinks:action.payload};
    case ActionTypes.SET_CUSTOM:
    return {...state,setColor:action.payload};
    default:
      return state;
  }
}

export default companyReducer;