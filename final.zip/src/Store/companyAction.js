import { ActionTypes } from "./ActionType"
export const setCompany = (company) =>{
    return {
        type:ActionTypes.SET_COMPANY,
        payload:company
    }
}
export const socialMediaLinks = (data) =>{
    return {
        type:ActionTypes.SET_SOCIALMEDIA_LINK,
        payload:data
    }
}

export const setColor = (data) =>{
    return {
        type:ActionTypes.SET_CUSTOM,
        payload:data
    }
}