import API from "../Api/ApiService";

export const handleCartList = (input) => {
  const api = new API();
  return input.map((e) => {
    let last = e.product.category.slice(-1);
    let obj = {
      _id: e._id,
      category: e.product.category,
      quantity: e.quantity,
      sp: e.product.sp,
      mrp: e.product.mrp,
      product_id: e.product._id,
      description: e.product.description,
      sku: e.product.sku,
      delivery: e.delivery,
      packing_detail: e.product.packing_detail.weight,
      delivery_local: e.product.delivery_charge.local,
      delivery_zonal: e.product.delivery_charge.zonal,
      delivery_nation: e.product.delivery_charge.national,
      link: `${last[0]?.category_name.replace(
        " ",
        "-"
      )}/${e.product.description.replace(" ", "-")}?pid=${e.product._id}`,
    };
    if (e.product?.images?.length > 0) {
      obj.images = e.product.images[0];
    }
    return obj;
  });
};
