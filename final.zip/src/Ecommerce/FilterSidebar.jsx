import React, { useEffect, useState } from 'react'
import styled from 'styled-components';
import { Select } from "antd";
import { styles } from './../Api/Data';
const { Option } = Select;

const FilterSidebar = ({length}) => {
 

  return (
    <React.Fragment>
      <FilterSidebarSection>
        <FilterSidebarLeft>Showing of {length?.length} results</FilterSidebarLeft>
        <FilterSidebarRight>
          Sort By:{" "}
          <Select
          placeholder="Default Sort"
                        style={{ width: "150px" }}
                        size="small"
                        // onChange={sorting}
                      >
                        <Option value={1}>Price High to Low</Option>
                        <Option value={2}>Price Low to High</Option>
                        <Option value={3}>Rating</Option>
                        <Option value={4}>Discount</Option>
                      </Select>
        </FilterSidebarRight>
      </FilterSidebarSection>
    </React.Fragment>
  );
}

export default FilterSidebar;

const FilterSidebarSection = styled.div`
  border: 0px solid ${styles.light};
  padding: 0px 0px;
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: space-between;
  flex-wrap: wrap;
  background: #fff;
  border-radius: 5px;
  .ant-select-selection-placeholder {
    color: ${styles.color};
  }
`;
const FilterSidebarLeft = styled.div`
  color: ${styles.color};
  font-weight: 600;
  font-size: 15px;
`;
const FilterSidebarRight = styled.div`
  display: flex;
  align-items: center;
  gap: 10px;
  color: ${styles.color};
  font-weight: 600;
  font-size: 15px;
  .ant-select.ant-select-single.ant-select-show-arrow.ant-select-show-search,
  .ant-select:not(.ant-select-customize-input) .ant-select-selector {
    border: 0;
    border: 1px solid #f9f9f9;
  }
`;
