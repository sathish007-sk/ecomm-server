import React, { useEffect, useState } from "react";
import { Input, AutoComplete } from "antd";
import { useNavigate } from "react-router-dom";
import API from "../Api/ApiService";
import Default from '../Assets/Images/default.png'
import { createBrowserHistory } from 'history'
export default function SearchBoxComponent(props) {
  const api = new API();
  const history = createBrowserHistory();
  const [value, setValue] = useState("");
  const [options, setOptions] = useState([]);
  const onSearch = (searchText) => {
    if (searchText) {
      api.suggest(searchText).then((res) => {
        console.log(res)
        let sug = res.data?.map((e) => {
          return {
            label: <div style={{ display: "flex" }}>
              <img style={{ height: "30px", width: "30px" }} src={e.image ? api.rootUrl + e.image : Default} />
              <p style={{ padding: "0 0 0 10px", margin: "0" }}>{e.name}</p>
            </div>,
            value: e.name,
          };
        });
        var unique = sug.filter((value, index, self) => {
          let i = self.findIndex((e) => e.value == value.value);
          return i === index;
        });
        setOptions(unique);
      });
    } else setOptions([]);
  };
  const submit = (e) => {
    e.preventDefault();
    history.push(`/search?q=${value.toLowerCase().replace(/ /g, '-')
    .replace(/[^\w-]+/g, '')}`);
  };
  const onSelect = (data) => {
    setValue(data);
    history.push(`/search?q=${data.toLowerCase().replace(/ /g, '-')
    .replace(/[^\w-]+/g, '')}`);
    window.location.reload()
  };

  const onChange = (data) => {
    setValue(data);
  };
  useEffect(() => {}, [props]);
  return (
    <form onSubmit={submit} style={props.style}>
      <AutoComplete
        onSelect={onSelect}
        onSearch={onSearch}
        options={options}
        dropdownClassName="certain-category-search-dropdown"
        dropdownMatchSelectWidth={500}
        style={{ width: "100%" }}
      >
        <Input.Search size="medium" placeholder="Search Products" allowClear={true} />
      </AutoComplete>
    </form>
  );
}
