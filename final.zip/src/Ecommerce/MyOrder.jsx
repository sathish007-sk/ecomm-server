import React, { useState, useEffect } from "react";
import { List, Avatar, notification, message } from "antd";
import styled from 'styled-components';
import { styles } from '../Api/Data';
import OrderService from "../Api/OrderService";
import { Link, useLocation } from "react-router-dom";
import API from "../Api/ApiService";
import ProfileMenu from './ProfileMenu';
export default function MyOrder(props) {
  const api = new API();
  const [isLoading, setLoading] = useState(false);
  const [data, setData] = useState("");
  const [order, setOrder] = useState([]);
  const orderservice = new OrderService();
  const { path } = useLocation();
  const location = useLocation();
  useEffect(() => {
    let qParams = new URLSearchParams(location.search);
    let msg = qParams.get("msg");
    let status = qParams.get("status");
    if (msg) {
      notification["success"]({
        message: status,
        description: msg,
      });
    }
    list();
  }, [location]);

  function list() {
    setLoading(true);

    api.addressList().then((res) => {
      console.log()
      setData(res.data[0].buyer);
      getOrderList()
      setLoading(false);
    }).catch((err) => { setLoading(false) })
  }

  const getOrderList = (data) => {
    orderservice.retrieve(data).then((res) => {
      setOrder(res.data)
    })
  }





  return (
    <React.Fragment>
      <Section>
        <Wrapper>
          <Title>My Order</Title>
          <Align>
            <Left>
              <ProfileMenu />
            </Left>
            <Right>
              <section className="container" style={{ margin: "0px auto", width: "100%" }}>

                <List
                  loading={isLoading}
                  itemLayout="vertical"
                  size="small"
                  dataSource={order}
                  renderItem={(item) => (
                    <List.Item
                      key={item._id}
                      extra={
                        <div style={{ textAlign: "center" }}>
                          <p>{item.status}</p>
                          <h1>
                            {item.total.toLocaleString("en-IN", {
                              maximumFractionDigits: 2,
                              style: "currency",
                              currency: "INR",
                            })}
                          </h1>
                        </div>
                      }
                    >

                      <List.Item.Meta
                        // avatar={
                        //   <Avatar
                        //     size={80}
                        //     shape="square"
                        //     src={`${orderservice.rootUrl}${item.products[0]?.product?.images?.length > 0
                        //         ? item.products[0]?.product?.images[0]
                        //         : ""
                        //       }`}
                        //   />
                        // }
                        title={
                          <Link to={`order/${item._id}`}>
                            {item.products[0]?.description}&nbsp;
                            <br /> <small>SKU {item.products[0]?.product?.sku}</small>
                          </Link>
                        }
                        description={
                          <>
                            <p>
                              Order No:{item.order_no}
                              <br />
                              Date:{" "}
                              {new Date(item.date)?.toLocaleString("en-IN", {
                                dateStyle: "medium",
                              })}
                            </p>
                          </>
                        }
                      />
                    </List.Item>

                  )}
                />

              </section>
            </Right>
          </Align>
        </Wrapper>
      </Section>
    </React.Fragment>
  );
}

const Section = styled.section`
    margin: 60px 0 0 0;
    width: 100%;
    position: relative;
    display: inline-block;
`;
const Title = styled.h1`
    font-size: 30px;
    color: ${styles.color};
    margin: 0 0 25px;
`;
const Wrapper = styled.div`
max-width: 1200px;
padding: 0 10px;
margin: auto;
`;
const Align = styled.div`
display: flex;
justify-content: space-between;
position: relative;
flex-wrap: wrap;
`;
const Left = styled.div`
width: 25%;
display: inline-block;
border: 1px solid ${styles.light};
padding: 24px;
@media screen and (max-width:956px) {
    width: 100%;
    margin: 0 0 50px;
}
`;
const Right = styled.div`
width: 72%;
display: inline-block;
border: 1px solid ${styles.light};
padding: 24px;
@media screen and (max-width:956px) {
    width: 100%;
    
}
`;

const FormAlign = styled.div`
    width: 100%;
    display: flex;
    align-items: flex-start;
    flex-wrap: wrap;
`;
const FormLeft = styled.div`
width: 65%;
display: inline-block;
position: relative;
.ant-row {
    flex-wrap: wrap;
    flex-direction: column;
}
.ant-form-item-label {
    width: 100%;
    display: inline-block;
    text-align: left;
}
.ant-form-item {
    margin: 0 0 24px;
    display: inline-block;
    width: 100%;
}
.ant-form-item:nth-child(5) {
    width: 100%;
    display: inline-block;
}
.ant-form-item:nth-child(1), .ant-form-item:nth-child(3) {
    width: 48%;
    float: left;
}
.ant-form-item:nth-child(2), .ant-form-item:nth-child(4) {
    width: 48%;
    float: right;
}

@media screen and (max-width:768px) {
    width: 100%;
    .ant-form-item:nth-child(1), .ant-form-item:nth-child(3) {
    width: 100%;
    float: left;
}
.ant-form-item:nth-child(2), .ant-form-item:nth-child(4) {
    width: 100%;
    float: right;
}
}


`;
const FormRight = styled.div`
width: 30%;
display: inline-block;
position: relative;
`;