import {
    Col,
    Divider,
    Button,
    Image,
    message,
    Row,
    Timeline,
} from "antd";
import styled from 'styled-components';
import { styles } from '../Api/Data';
import ProfileMenu from './ProfileMenu';
import React, { useEffect, useState } from "react";
// import { useRouteMatch } from "react-router-dom";
import { useParams } from "react-router-dom";
import API from "../Api/ApiService";
import OrderService from "../Api/OrderService";
import errorImage from "./ErrorImage";
import { renderToString } from "react-dom/server";
import { useSelector } from "react-redux";
import moment from "moment";

import jsPDF from "jspdf";
export default function Order(props) {
    const api = new API();
    const [isLoading, setLoading] = useState(false);
    const [data, setData] = useState(null);
    const orderservice = new OrderService();
    const { id } = useParams();
    const company = useSelector((state) => {
        return state.company?.value;
    });
    //console.log(company);
    const fallback = errorImage;
    useEffect(() => {
        retrieve(id);
    }, [id]);
    // function printOrder(id) {
    //   setLoading(true);
    //   api.billPrint(id).then((response) => {
    //     let fileURL = URL.createObjectURL(response.data);
    //     window.open(fileURL, "Invoice Print", "popup");
    //     setLoading(false);
    //   });
    // }
    
    function retrieve(id) {
        setLoading(true);
        orderservice
            .retrieveSingle(id)
            .then((res) => {
                
                setData(res.data);
                setLoading(false);
            })
            .catch((error) => {
                
                message.error(error.res.data);
                setLoading(false);
            });
    }
    function status(val) {
        if (val === "Pending") return "Ordered";
        else return val;
    }

    const pdfGenerate = () => {
        let doc = new jsPDF("p", "pt", "a4");
        // let totalamt = Math.round(data.products[0]?.selling_price * 100)/100;
        // let totalamt = Math.round(data.products[0]?.selling_price * 100)/100;

        let htmlElement = (
            <>
                <div className="invoice">
                    <h1 style={{ textAlign: "left", fontSize: "30px" }}>Tax Invoice</h1>
                    <img src={company.logo} style={{ height: "85px" }} />
                    <div className="company_address">
                        <h4
                            style={{
                                textDecoration: "underline",
                                fontSize: "18px",
                            }}
                        >
                            Sold By
                        </h4>
                        <p>
                            {company.company_name} {company.address?.address_line1},
                        </p>
                        <p>
                            {company.address?.area}, {company.address?.district?.name},{" "}
                            {company.address?.state?.name}
                        </p>
                        <p>{company.address?.pincode}</p>
                        <p>GST: {company.gst_no}</p>
                    </div>
                    <div className="buyer_address">
                        <h4
                            style={{
                                textDecoration: "underline",
                                fontSize: "18px",
                            }}
                        >
                            Billing Address/Shipping Address
                        </h4>
                        <p>{data?.delivery_address.address_line_1}</p>
                        <p>{data?.delivery_address.address_line_2},</p>
                        <p>{data?.delivery_address.district},</p>
                        <p>{data?.delivery_address?.state?.name},</p>
                        <p>{data?.delivery_address?.country?.name},</p>
                        <p>{data?.delivery_address.pincode},</p>
                        <p>{data?.delivery_address.mobile_no}.</p>
                    </div>
                    <hr />

                    <div className="order_details">
                        <table
                            style={{
                                border: "1px solid #888",
                                borderCollapse: "collapse",
                            }}
                        >
                            <tr style={{ border: "1px solid #888" }}>
                                <td style={{ border: "1px solid #888", padding: "5px 7px" }}>
                                    Order No : {data.order_no}
                                </td>
                                <td style={{ border: "1px solid #888", padding: "5px 7px" }}>
                                    Order Date:{" "}
                                    {moment(data.order_status[0]?.updatedAt).format("DD/MM/YYYY")}
                                </td>
                            </tr>
                            <tr style={{ border: "1px solid #888" }}>
                                <td style={{ border: "1px solid #888", padding: "5px 7px" }}>
                                    Invoice No: {data.bill.invoice_no}
                                </td>
                                <td style={{ border: "1px solid #888", padding: "5px 7px" }}>
                                    Invoice Date : {moment(data.bill.date).format("DD/MM/YYYY")}
                                </td>
                            </tr>
                        </table>
                    </div>

                    <div className="order_summary">
                        <table
                            style={{
                                border: "1px solid #888",
                                borderCollapse: "collapse",
                            }}
                        >
                            <thead style={{ border: "1px solid #888" }}>
                                <tr style={{ border: "1px solid #888" }}>
                                    <th style={{ border: "1px solid #888", padding: "5px 7px" }}>
                                        Product
                                    </th>
                                    <th style={{ border: "1px solid #888", padding: "5px 7px" }}>
                                        Qty
                                    </th>
                                    <th style={{ border: "1px solid #888", padding: "5px 7px" }}>
                                        Taxable Value
                                    </th>
                                    <th
                                        colSpan="2"
                                        style={{ border: "1px solid #888", padding: "5px 7px" }}
                                    >
                                        CGST <br />
                                    </th>
                                    <th
                                        colSpan="2"
                                        style={{ border: "1px solid #888", padding: "5px 7px" }}
                                    >
                                        SGST{" "}
                                    </th>
                                    <th
                                        colSpan="2"
                                        style={{ border: "1px solid #888", padding: "5px 7px" }}
                                    >
                                        IGST
                                    </th>
                                    <th style={{ border: "1px solid #888", padding: "5px 7px" }}>
                                        Total Amount
                                    </th>
                                </tr>
                                <tr>
                                    <td style={{ border: "1px solid #888", padding: "5px 7px" }}>
                                        <b style={{ fontSize: "18px" }}>
                                            Single Photo Frames with Flower Design
                                        </b>
                                        <br />
                                        <br />
                                        HSN-Code3924,
                                        <br />
                                        SKUP0066
                                    </td>
                                    <td style={{ border: "1px solid #888", padding: "5px 7px" }}>
                                        {data?.bill.products[0].quantity}
                                    </td>
                                    <td style={{ border: "1px solid #888", padding: "5px 7px" }}>
                                        {(
                                            (data.products[0]?.selling_price).toFixed(2) *
                                            (100 / 118)
                                        ).toFixed(2)}
                                    </td>
                                    <td style={{ border: "1px solid #888", padding: "5px 7px" }}>
                                        {data?.delivery_address?.state?.name === "TAMILNADU"
                                            ? data.bill.products[0].tax_percentage / 2 + "%"
                                            : "-"}
                                    </td>
                                    <td style={{ border: "1px solid #888", padding: "5px 7px" }}>
                                        {data?.delivery_address?.state?.name === "TAMILNADU"
                                            ? (
                                                (
                                                    (data.products[0]?.selling_price).toFixed(2) *
                                                    (100 / 118)
                                                ).toFixed(2) *
                                                (data.bill.products[0].tax_percentage / 2 / 100)
                                            ).toFixed(2)
                                            : "-"}
                                    </td>
                                    <td style={{ border: "1px solid #888", padding: "5px 7px" }}>
                                        {data?.delivery_address?.state?.name === "TAMILNADU"
                                            ? data.bill.products[0]?.tax_percentage / 2 + "%"
                                            : "-"}
                                    </td>
                                    <td style={{ border: "1px solid #888", padding: "5px 7px" }}>
                                        {data?.delivery_address?.state?.name == "TAMILNADU"
                                            ? (
                                                (
                                                    (data.products[0]?.selling_price).toFixed(2) *
                                                    (100 / 118)
                                                ).toFixed(2) *
                                                (data.bill.products[0].tax_percentage / 2 / 100)
                                            ).toFixed(2)
                                            : "-"}
                                    </td>
                                    <td style={{ border: "1px solid #888", padding: "5px 7px" }}>
                                        {data?.delivery_address?.state?.name !== "TAMILNADU"
                                            ? data.bill.products[0].tax_percentage + "%"
                                            : "-"}
                                    </td>
                                    <td style={{ border: "1px solid #888", padding: "5px 7px" }}>
                                        {data?.delivery_address?.state?.name !== "TAMILNADU"
                                            ? (
                                                (
                                                    (data.products[0]?.selling_price).toFixed(2) *
                                                    (100 / 118)
                                                ).toFixed(2) *
                                                (data.bill.products[0].tax_percentage / 100)
                                            ).toFixed(2)
                                            : "-"}
                                    </td>
                                    <td
                                        style={{
                                            border: "1px solid #888",
                                            padding: "5px 7px",
                                            textAlign: "right",
                                        }}
                                    >
                                        {(data.products[0]?.selling_price).toFixed(2)}
                                    </td>
                                </tr>
                                <tr>
                                    <td style={{ border: "1px solid #888", padding: "5px 7px" }}>
                                        Delivery Charges
                                    </td>
                                    <td
                                        style={{ border: "1px solid #888", padding: "5px 7px" }}
                                    ></td>
                                    <td style={{ border: "1px solid #888", padding: "5px 7px" }}>
                                        {(
                                            (
                                                data.total -
                                                (data.products[0]?.selling_price).toFixed(2)
                                            ).toFixed(2) *
                                            (100 / 118)
                                        ).toFixed(2)}
                                    </td>
                                    <td style={{ border: "1px solid #888", padding: "5px 7px" }}>
                                        {data?.delivery_address?.state?.name === "TAMILNADU"
                                            ? data.bill.products[0].tax_percentage / 2 + "%"
                                            : "-"}
                                    </td>
                                    <td style={{ border: "1px solid #888", padding: "5px 7px" }}>
                                        {data?.delivery_address?.state?.name === "TAMILNADU"
                                            ? (
                                                (
                                                    (
                                                        data.total -
                                                        (data.products[0]?.selling_price).toFixed(2)
                                                    ).toFixed(2) *
                                                    (100 / 118)
                                                ).toFixed(2) *
                                                (data.bill.products[0].tax_percentage / 2 / 100)
                                            ).toFixed(2)
                                            : "-"}
                                    </td>
                                    <td style={{ border: "1px solid #888", padding: "5px 7px" }}>
                                        {data?.delivery_address?.state?.name === "TAMILNADU"
                                            ? data.bill.products[0].tax_percentage / 2 + "%"
                                            : "-"}
                                    </td>
                                    <td style={{ border: "1px solid #888", padding: "5px 7px" }}>
                                        {data?.delivery_address?.state?.name === "TAMILNADU"
                                            ? (
                                                (
                                                    (
                                                        data.total -
                                                        (data.products[0]?.selling_price).toFixed(2)
                                                    ).toFixed(2) *
                                                    (100 / 118)
                                                ).toFixed(2) *
                                                (data.bill.products[0].tax_percentage / 2 / 100)
                                            ).toFixed(2)
                                            : "-"}
                                    </td>
                                    <td style={{ border: "1px solid #888", padding: "5px 7px" }}>
                                        {data?.delivery_address?.state?.name !== "TAMILNADU"
                                            ? data.bill.products[0].tax_percentage + "%"
                                            : "-"}
                                    </td>
                                    <td style={{ border: "1px solid #888", padding: "5px 7px" }}>
                                        {data?.delivery_address?.state?.name !== "TAMILNADU"
                                            ? (
                                                (
                                                    (
                                                        data.total -
                                                        (data.products[0]?.selling_price).toFixed(2)
                                                    ).toFixed(2) *
                                                    (100 / 118)
                                                ).toFixed(2) *
                                                (data.bill.products[0].tax_percentage / 100)
                                            ).toFixed(2)
                                            : "-"}
                                    </td>
                                    <td
                                        style={{
                                            border: "1px solid #888",
                                            padding: "5px 7px",
                                            textAlign: "right",
                                        }}
                                    >
                                        {/* 0.70 */}
                                        {(
                                            data.total - (data.products[0]?.selling_price).toFixed(2)
                                        ).toFixed(2)}
                                    </td>
                                </tr>
                                <tr>
                                    <td
                                        colSpan="7"
                                        style={{ border: "1px solid #888", padding: "5px 7px" }}
                                    ></td>
                                    <td
                                        colSpan="2"
                                        style={{ border: "1px solid #888", padding: "5px 7px" }}
                                    >
                                        Grand Total:
                                    </td>
                                    <td
                                        colSpan="2"
                                        style={{
                                            border: "1px solid #888",
                                            padding: "5px 7px",
                                            textAlign: "right",
                                        }}
                                    >
                                        {data.total.toFixed(2)}
                                    </td>
                                </tr>
                            </thead>
                        </table>
                    </div>
                    <div className="condition">
                        <p>
                            This is System Generated Invoice, no requirement of stamp and
                            signature
                        </p>
                        <hr />
                        <b>Terms and Condition:</b>
                        <p>
                            1. All disputes are subject to the jurisdiction of Coimbatore.
                        </p>
                        <p>2. Our responsibility ceases after dispatch of the goods.</p>
                        <hr />
                        <b>Declaration:</b>
                        <p>
                            The goods sold are intended for end user consumption and not for
                            re-sale. If you have any questions, feel free to call us +91{" "}
                            {company.mobile_no} or log on to {company.website} / Contact Us
                        </p>
                    </div>
                </div>
            </>
        );
        let elementAsString = renderToString(htmlElement);

        doc.html(elementAsString, {
            callback: function (doc) {
                doc.save("order-invoice.pdf");
            },
            x: 10,
            y: 10,
        });
    };

    return (
        <React.Fragment>
            <Section>
                <Wrapper>
                    <Title>My Order</Title>
                    <Align>
                        <Left>
                            <ProfileMenu />
                        </Left>
                        <Right>
                            <section className="container">
                                {data && (
                                    <>
                                        <Row justify="space-between" gutter={[10, 10]} align="top">
                                            <Col lg={12} md={12} sm={24} xs={24}>
                                                Order No / Date : {data.order_no} /{" "}
                                                {new Date(data.date).toLocaleString("en-IN", {
                                                    dateStyle: "medium",
                                                })}
                                            </Col>
                                            <Col lg={6} md={6} sm={24} xs={24}>
                                                <h1>{data.status}</h1>
                                            </Col>
                                            <Col lg={6} md={6} sm={24} xs={24}>
                                                {data.bill?._id && (
                                                    <div>
                                                        <p> Bill No : {data.bill.bill_no}</p>
                                                        <Button onClick={pdfGenerate} type="primary">
                                                            Download Invoice
                                                        </Button>
                                                    </div>
                                                )}
                                            </Col>
                                        </Row>
                                        <br />
                                        <Row gutter={[10, 10]} align="top">
                                            <Col lg={4} md={4} sm={4} xs={4}>
                                                <Image
                                                    preview={false}
                                                    fallback={fallback}
                                                    width="100%"
                                                    src={`${orderservice.rootUrl}${data?.products[0]?.product?.images?.length > 0
                                                        ? data?.products[0]?.product?.images[0]
                                                        : ""
                                                        }`}
                                                    style={{ border: "1px solid #f2f2f2" }}
                                                />
                                            </Col>

                                            <Col lg={20} md={20} sm={20} xs={20}>
                                                <strong style={{ textAlign: "left" }}>{data?.products[0]?.description}</strong>
                                                <p style={{ textAlign: "left", fontSize: "11px", margin: "6px 0 0 0", fontStyle: "italic" }}>{data?.products[0]?.product.sku}</p>
                                            </Col>
                                        </Row>
                                        <Divider />
                                        <Row gutter={[10, 10]} align="stretch">
                                            <Col lg={12} md={12} sm={24} xs={24}>
                                                <br />
                                                <h1 style={{ marginBottom: "15px" }}>
                                                    {data?.products[0].selling_price.toLocaleString("en-IN", {
                                                        maximumFractionDigits: 2,
                                                        style: "currency",
                                                        currency: "INR",
                                                    })}{" "}
                                                    X {data.products[0].quantity} ={" "}
                                                    {data?.products[0].selling_price.toLocaleString("en-IN", {
                                                        maximumFractionDigits: 2,
                                                        style: "currency",
                                                        currency: "INR",
                                                    })}
                                                </h1>
                                                <p>(Excluding Delivery Charges.)</p>

                                                <strong>Delivery Address</strong>
                                                <p>
                                                    <strong>{data?.delivery_address.name}</strong>
                                                    <br />
                                                    {data?.delivery_address.address_line_1},{" "}
                                                    {data?.delivery_address.address_line_2},<br />{" "}
                                                    {data?.delivery_address.district} -{" "}
                                                    {data?.delivery_address.pincode},{" "}
                                                    {data?.delivery_address?.state?.name},{" "}
                                                    {data?.delivery_address?.country?.name}
                                                    <br />
                                                    Mobile No: {data?.delivery_address.mobile_no}
                                                    <br />
                                                    {data?.delivery_address.alternate_mobile_no
                                                        ? "Alternate No: " +
                                                        data?.delivery_address.alternate_mobile_no
                                                        : ""}
                                                </p>
                                            </Col>


                                            <Col lg={12} md={12} sm={24} xs={24}>
                                                <Timeline mode="left">
                                                    {data?.order_status?.map((e) => (
                                                        <Timeline.Item label={status(e.status)}>
                                                            {new Date(e.createdAt)?.toLocaleString("en-IN", {
                                                                dateStyle: "medium",
                                                                timeStyle: "medium",
                                                            })}
                                                        </Timeline.Item>
                                                    ))}
                                                </Timeline>
                                            </Col>
                                        </Row>
                                        <Divider />
                                    </>
                                )}
                            </section>
                        </Right>
                    </Align>
                </Wrapper>
            </Section>
        </React.Fragment>
    );
}
const Section = styled.section`
    margin: 60px 0 0 0;
    width: 100%;
    position: relative;
    display: inline-block;
`;
const Title = styled.h1`
    font-size: 30px;
    color: ${styles.color};
    margin: 0 0 25px;
`;
const Wrapper = styled.div`
max-width: 1200px;
padding: 0 10px;
margin: auto;
`;
const Align = styled.div`
display: flex;
justify-content: space-between;
position: relative;
flex-wrap: wrap;
`;
const Left = styled.div`
width: 25%;
display: inline-block;
border: 1px solid ${styles.light};
padding: 24px;
@media screen and (max-width:956px) {
    width: 100%;
    margin: 0 0 50px;
}
`;
const Right = styled.div`
width: 72%;
display: inline-block;
border: 1px solid ${styles.light};
padding: 24px;
@media screen and (max-width:956px) {
    width: 100%;
    
}
`;

const FormAlign = styled.div`
    width: 100%;
    display: flex;
    align-items: flex-start;
    flex-wrap: wrap;
`;
const FormLeft = styled.div`
width: 65%;
display: inline-block;
position: relative;
.ant-row {
    flex-wrap: wrap;
    flex-direction: column;
}
.ant-form-item-label {
    width: 100%;
    display: inline-block;
    text-align: left;
}
.ant-form-item {
    margin: 0 0 24px;
    display: inline-block;
    width: 100%;
}
.ant-form-item:nth-child(5) {
    width: 100%;
    display: inline-block;
}
.ant-form-item:nth-child(1), .ant-form-item:nth-child(3) {
    width: 48%;
    float: left;
}
.ant-form-item:nth-child(2), .ant-form-item:nth-child(4) {
    width: 48%;
    float: right;
}

@media screen and (max-width:768px) {
    width: 100%;
    .ant-form-item:nth-child(1), .ant-form-item:nth-child(3) {
    width: 100%;
    float: left;
}
.ant-form-item:nth-child(2), .ant-form-item:nth-child(4) {
    width: 100%;
    float: right;
}
}


`;
const FormRight = styled.div`
width: 30%;
display: inline-block;
position: relative;
`;