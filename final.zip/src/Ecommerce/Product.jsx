import React, { useEffect, useState } from "react";
import {
  Image,
  Breadcrumb,
  Button,
  Divider,
  Form,
  Rate,
  Input,
  Comment,
  message,
  List,
  Modal,
  Skeleton,
  Row,
  Col,
} from "antd";
import { HomeOutlined, ShoppingCartOutlined, ShoppingOutlined, EditOutlined } from "@ant-design/icons";
import { styles } from "../Api/Data";
import styled from "styled-components";
import { useNavigate, useLocation, Link } from 'react-router-dom'
import RelatedProduct from "./RelatedProduct";
import API from "../Api/ApiService";
import OrderService from "../Api/OrderService";
import Default from "../Assets/Images/default_img.png"
import { Swiper, SwiperSlide } from "swiper/react";
import { Navigation } from "swiper";
import moment from 'moment';
import { connect, useSelector } from "react-redux";
import { getCartList } from '../Store/cartTypes'
import { useParams } from "react-router-dom";
import { Helmet } from "react-helmet";
import AddAddressPopup from "../Ecommerce/AddAddressPopup"
const { TextArea } = Input;
const user = JSON.parse(localStorage.getItem("persist:root"))?.company;
const colorCustom = user && JSON.parse(user).setColor;










const Product = (props) => {
  const api = new API();
  const orderservice = new OrderService();
  const loginTrue = useSelector((state) => state.user.currentUser?.token);
  const company = useSelector((state) => state.company?.value);
  const location = useLocation();
  const params = useParams();
  const getParms = new URLSearchParams(location.search);
  let pid = getParms.get("pid");
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [product, setProduct] = useState([]);
  const [inCart, setInCart] = useState(false);
  const images = product.images;
  const [zoom, setZoom] = useState("");
  const [addToCartLoading, setAddToCartLoading] = useState(false)
  const [addressLength, setAddressLength] = useState("");
  const [delivery, setDelivery] = useState("");
  const [buyNowLoading, setBuyNowLoading] = useState(false)
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [profile, setProfile] = useState(false)
  const [form] = Form.useForm();
  const [form1] = Form.useForm();
  const [saving, setSaving] = useState(false)
  const [allReviews, setAllReviews] = useState([])
  const [dataReview, setDataReview] = useState([])
  const [exist, setExist] = useState("");
  const [reviewUpdateId, setReviewUpdateId] = useState("");
  const [reviewLoading, setReviewLoading] = useState(false)
  const [reviewRemove, setReviewRemove] = useState("")
  const [related, setRelated] = useState([])
  const [orderCount, setOrderCount] = useState("");


  const[refresh, setRefresh]= useState (false)
  const showModal = () => {
    setIsModalOpen(true);
  };


 

  const handleOk = () => {
    setIsModalOpen(false);
  };
  const handleCancel = () => {
    setRefresh(true)
    setIsModalOpen(false);
  
  };
  const reload=()=>{
    setRefresh(!refresh)
   
  }

  const [isModalOpen1, setIsModalOpen1] = useState(false);
  const showModal1 = () => {
    setIsModalOpen1(true);
  };
  const handleOk1 = () => {
    setIsModalOpen1(false);
  };
  const handleCancel1 = () => {
    setIsModalOpen1(false);
  };
  
  useEffect(() => {
    if (!pid) {
      navigate('/')
    } else {
      
    }
  }, [pid])





  var address;
  var district;
  var buyer_id;
  var buyer_address_id;
  var address_line_2;
  var weight;

  const addressList = () => {
    setLoading(true)
    api.addressList().then((res) => {
      setAddressLength(res.data.length);
      setDataReview(res.data)
      const trueadd = res.data?.find((item)=>{
        return item?.delivery===true;
    })
    console.log(trueadd)
      address = res.data;
      district = trueadd.district;
      address_line_2 = trueadd.city;
      buyer_id = trueadd.buyer;
      buyer_address_id = trueadd._id;
      dlchrg();
      setLoading(false)
    }).catch((err) => {
      setLoading(false)
    })
  }

  useEffect(() => {
    init()
   
  }, [pid,refresh])

  const init = async () => {
    setLoading(true)
    let res = await api.singleProduct(pid);
    console.log(res)
    let rid = res.data.category[0]?.parent;
    console.log(rid)
    relatedProduct(rid)
    addressList()
    loadAllReview()
    props.getCartList();
    setInCart(false)
    if (res.data.success != false) {
      setProduct(res.data);
      weight = res.data.packing_detail.weight;
      if (res.data.cart) {
        setInCart(true)
      }
    }
    setLoading(false)
  }

  const relatedProduct = (rid) => {
     setLoading(true)
    api.filter().then((res) => {
      let data = res.data;
      var responsefilter = 0;
      function filterByCategory(item) {
        if (item.category) {
          for (let i = 0; i < item.category.length; i++) {
            if (item.category[i]._id == rid && item.publish === true) {
              return true;
            }
          }
        }
        responsefilter++;
        return false;
      }
      const ress = data?.filter(filterByCategory)
      console.log(ress)
      setRelated(ress)
      setLoading(false)
    })
  }





  const dlchrg = () => {
    setLoading(true);
    let data = { address: address_line_2, weight: weight };
    console.log(data)
    api.singleProductDlchrg(data).then((res) => {
      console.log(res)
      setDelivery(res.data)
      getProDetails()
      setLoading(false)
    }).catch((err) => { setLoading(false) })
  }

  const getProDetails = () => {
    setLoading(true)
    api.getMyProfile().then((res) => {
      if (res.status === 200) {
        setProfile(res.data)
        loadAllReview()
        setLoading(false)
      }
    }).catch((err) => { })

  }

  const addToCart = () => {
    console.log(delivery)
    setAddToCartLoading(true)
    if(!loginTrue && loginTrue!=="") {
      message.warning("Please login your account")
      setAddToCartLoading(false)
    } else {
    
    if (addressLength < 1) {
      message.warning("Please add your delivery Address")
      setIsModalOpen1(true);
      setAddToCartLoading(false)
    } else {
      let data = { product: pid, delivery: delivery }
      api.addToCart(data).then((res) => {
        let data = res.data;
        if (data.success === true) {
          props.getCartList();
          setInCart(true)
          setAddToCartLoading(false)
          message.success("Successfully added")
        } else {
          message.warning("Product already in cart")
          setAddToCartLoading(false)
        }
      }).catch((err) => {setAddToCartLoading(false) })
    }
  }
  }

  const buyNow = () => {
    setBuyNowLoading(true);
    if(!loginTrue && loginTrue!=="") {
      message.warning("Please login your account")
      setBuyNowLoading(false)
    } else {
    if (addressLength < 1) {
      message.warning("Please add your delivery Address")
      setIsModalOpen1(true);
      setBuyNowLoading(false)
    } else {

      let data = { product: pid, delivery: delivery }
      api.addToCart(data).then((res) => {
        let data = res.data;
        if (data.success === true) {
          props.getCartList();
          setInCart(true)
          message.success("Successfully added")
          setBuyNowLoading(false)
          navigate("/cart")
        } else {
          message.warning("Product already in cart")
          setBuyNowLoading(false)
        }
      }).catch((err) => { setBuyNowLoading(false)})
    }
  }
  }

  const loadAllReview = () => {
    setReviewLoading(true)
    api.getAllProductReview(pid).then((res) => {
      if (res.status === 200) {
        setAllReviews((res.data).reverse())
        setReviewLoading(false)
      }
    }).catch((err) => {
      setReviewLoading(false)
    })
  }

  useEffect(() => {
    setReviewLoading(true)
    currentUserReviewLength()
    getOrderList()
    setReviewLoading(false)
  }, [allReviews])


  const getOrderList = () => {
    let id = profile?._id;
    orderservice.retrieve(id).then((res) => {
      // setOrder(res.data)
      let dataOrder = res.data;
      let rsOrder = dataOrder.filter((item)=>{
        return item.products[0]?.product?._id === pid;
      })

      setOrderCount(rsOrder.length)
    })
  }

  
  


  const currentUserReviewLength = () => {
    setReviewLoading(true)
    const result = allReviews.filter((item) => {
      return item.buyer_id === profile?._id;
    })
    const date1 = new Date(result[0]?.createdAt);
    const date2 = new Date();
    const diffTime = Math.abs(date2 - date1);
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    setReviewRemove(diffDays)
    form1.setFieldsValue(result[0])
    setReviewUpdateId(result[0]?._id)
    setExist(result.length)
    setReviewLoading(false)
  }
  const addReview = (values) => {
    setReviewLoading(true)
    if (!loginTrue && loginTrue !== "") {
      message.warning("Login and submit review!")
      setReviewLoading(false)
    } else {
      values["product_id"] = pid;
      values["buyer_id"] = profile?._id;
      values["buyer_name"] = profile?.first_name + " " + profile?.last_name;
      values["buyer_address_id"] = dataReview[0]?._id;
      if (exist > 0) {
        message.warning("You have already submitted!")
        setReviewLoading(false)
      } else {
        setSaving(true)
        
        if(orderCount===0) {
          message.warning("Review available only for Purchased Products.")
          setReviewLoading(false)
          setSaving(false)
        } else {
        api.addNewReview(values).then((res) => {
          if (res.data.success) {
            form.resetFields();
            message.success("Successfully Saved")
            loadAllReview()
            setSaving(false)
            setReviewLoading(false)
          } else {
            message.error("Something wend Wrong!")
            setSaving(false)
            setReviewLoading(false)
          }
        }).catch((err) => { setReviewLoading(false)})
      }
      }
    }
  }


  const updateReview = (values) => {
    setReviewLoading(true)
    let id = reviewUpdateId;
    api.updateReview(values, id).then((res) => {
      if (res.status === 200) {
        form.resetFields();
        setIsModalOpen(false);
        loadAllReview();
        message.success("Review updated successfully");
        setReviewLoading(false)
      } else {
        message.error("Something went wrong!")
        setReviewLoading(false)
      }
    }).catch((err) => {setReviewLoading(false) })
  }
  





  return (

    <React.Fragment>
      <Helmet>
        <title>{product?.description}</title>
        <meta
            name="description"
            content={product?.meta_desc || product?.description}
          />
          <meta name="keywords" content={product?.meta_key} />
          <meta property="og:locale" content="en_US" />
          <meta property="og:title" content={product?.description} />
          <meta property="og:url" content={window.location.href} />
          <meta
            property="og:description"
            content={product?.meta_desc || product?.description}
          />
          <meta name="twitter:title" content={product?.description} />
          <meta
            name="twitter:description"
            content={product?.meta_desc || product?.description}
          />
          <meta name="robots" content="index,follow" />
      </Helmet>
      <ProductSection>
        <Wrapper>
          {loading === true ?
            <Skeleton active />
            : <>

              <AlignRight>
                <Breadcrumb>
                  <Breadcrumb.Item key="bc0_0">
                    <Link to="/"><HomeOutlined /> </Link>
                  </Breadcrumb.Item>
                  {product?.category?.reverse().map((e, i) => (
                    <Breadcrumb.Item key={`bc_${i}`}>
                      <Link to={`/${e.category_name.toLowerCase().replace(/ /g, '-')
                        .replace(/[^\w-]+/g, '')}`}>
                        {e.category_name?.length < 25
                          ? e.category_name
                          : e.category_name?.substr(0, 22) + "..."}
                      </Link>
                    </Breadcrumb.Item>
                  ))}
                  <Breadcrumb.Item key="bc0_1">
                    <a>
                      {product?.description?.length < 25
                        ? product?.description
                        : product?.description}
                    </a>
                  </Breadcrumb.Item>
                </Breadcrumb>

              </AlignRight>
              <ProductAlign>
                <ProductLeft>
                  {images?.slice(0, 1).map((e) => {
                    return <Image key={zoom ? zoom : api.rootUrl + images[0].thumbnail} className="zooming" src={zoom ? zoom : api.rootUrl + images[0].thumbnail} />;
                  })}
                  <Swiper
                    slidesPerView={5}
                    spaceBetween={15}
                    slidesPerGroup={1}
                    loop={true}
                    loopFillGroupWithBlank={true}
                    navigation={{
                      nextEl: ".swiper-button-next",
                      prevEl: ".swiper-button-prev",
                    }}
                    modules={[Navigation]}
                    className="mySwiper"
                  >
                    {
                      images?.map((res) => {
                        return (
                          <SwiperSlide key={res._id}>
                            <img src={res.thumbnail ? api.rootUrl + res.thumbnail : Default} alt="Product" className="galleryImage" onClick={() => setZoom(api.rootUrl + res.thumbnail)} />
                          </SwiperSlide>
                        )
                      })
                    }
                  </Swiper>
                </ProductLeft>
                <ProductRight>
                  <ProductTitle>{product.description}</ProductTitle>
                  <ProductSku>
                    <B>SKU:</B> {product.sku}
                  </ProductSku>
                  <ProductPrice>
                    <Sp>{styles.currency}{(Number(product.sp).toFixed(0))}</Sp>
                    <Mrp>{styles.currency}{(Number(product.mrp).toFixed(0))}</Mrp>
                  </ProductPrice>
                  <ProductDescription>
                    {product.note && (
                      <div
                        dangerouslySetInnerHTML={{ __html: product.note }}
                      ></div>
                    )}
                  </ProductDescription>
                  <Divider />
                  {/* <ProductAttribute>
                    Size: <Button>S</Button>
                    <Button>M</Button>
                    <Button>XL</Button>
                    <Button>XXL</Button>
                  </ProductAttribute> */}
                  {product?.grouping?.map((e) => (
                    <Row gutter={[10, 10]} key={e.label}>
                      <Col sm={4}>
                        <strong>{e.label}</strong>
                      </Col>
                      <Col sm={20}>
                        <div className="product-grouping">
                          {e?.value?.map((f) => (
                            <Link
                              className={
                                String(f._id) === String(product._id)
                                  ? "active"
                                  : ""
                              }
                              to={{
                                pathname: location.pathname,
                                search: `?pid=${f._id}`,
                              }}
                              key={f._id}
                            >
                              {f.value}
                            </Link>
                          ))}
                        </div>
                      </Col>
                    </Row>
                    
                  ))}
                   <Divider />
                   <Modal title="Add Address" open={isModalOpen1} onOk={handleOk1} onCancel={handleCancel1} footer={null}>
                      <AddAddressPopup data={handleCancel1} data1={reload}/>
                    </Modal>
                   <p>
                        
                          *Delivery assurance is subject to our delivery
                          locations staying open as per govt. regulations.
                        
                      </p>
                  {/* {product.stock === 0 ? <ProductAction><Button
                    type="danger" ><ShoppingOutlined />Out of Stock</Button></ProductAction> : */}
                    <ProductAction>
                      {
                        inCart === false ?
                          <>
                            <AddToCart>
                              <Button
                                type="primary"
                                loading={addToCartLoading}
                                onClick={addToCart}
                              ><ShoppingCartOutlined />Add to Cart</Button>
                            </AddToCart>
                            <BuyNow>
                              <Button
                                type="danger"
                                loading={buyNowLoading}
                                onClick={buyNow}
                              ><ShoppingOutlined />Buy Now</Button>
                            </BuyNow>
                          </>

                          :
                          <AddToCart>
                            <Link to="/cart">
                              <Button
                                type="danger"
                              ><ShoppingCartOutlined />Go to Cart</Button>
                            </Link>
                          </AddToCart>

                      }


                    </ProductAction>
                  {/* } */}
                  <Divider />

                  <HighLight>
                    <B>Highlight:</B>
                    <ul className="highlight">
                      {product.highlight?.map((d, i) => {
                        return <li key={`h${i+1}`}>{d}</li>;
                      })}
                    </ul>
                  </HighLight>
                  <Divider />
                  <Specification>
                    <B>Specification:</B>
                    <table className="specificationTable">
                      <tbody>
                        {product.specification?.map((s) => {
                          if (s.value) {
                            return (
                              <tr key={`sp${s._id}`}>
                                <td> {s.title}</td>
                                <td>:</td>
                                <td>
                                  {s.value} {s.suffix}
                                </td>
                              </tr>
                            );
                          }
                        })}

                        {product.specification?.slice(5).map((s) => {
                          if (s.value) {
                            return (
                              <tr key={`mob${s._id}`}>
                                <td> {s.title}</td>
                                <td>:</td>
                                <td>
                                  {s.value} {s.suffix}
                                </td>
                              </tr>
                            );
                          }
                        })}
                      </tbody>
                    </table>
                  </Specification>
                </ProductRight>
              </ProductAlign>

              <ReviewSection>

                <ReviewLeft>
                  <AlignReview>
                    <H2>Review</H2>

                    {

                      exist >= 1 && reviewRemove < 7 && !loginTrue && loginTrue !== "" && orderCount>1 ? <Button type="primary" size="medium" onClick={showModal}><EditOutlined /> Edit My Review</Button> : ""
                    }


                    <Modal title={profile?.first_name ? profile?.first_name + " " + profile?.last_name : "Edit Review"} open={isModalOpen} onOk={handleOk} onCancel={handleCancel} footer={null}>
                      <Form
                        form={form1}
                        onFinish={updateReview}
                      >
                        <Form.Item
                          label="Your rating"
                          name="star"
                          rules={[
                            { required: true, message: "Please select your rating!" },
                          ]}
                        >
                          <Rate name="star" />
                        </Form.Item>
                        <Form.Item label="Your review" name="review" rules={[
                          { required: true, message: "Please write your review!" },
                        ]} >
                          <TextArea rows={4} maxLength={100} />
                        </Form.Item>
                        <Form.Item>
                          <Button htmlType="submit" type="danger" loading={saving}>Submit Review</Button>
                        </Form.Item>
                      </Form>
                    </Modal>
                  </AlignReview>

                  <List
                    className="comment-list"
                    header={`${allReviews.length > 1 ? allReviews.length - 1 : "0"} replies`}
                    itemLayout="horizontal"
                    dataSource={allReviews}
                    renderItem={(item) => (
                      <li>
                        <Comment
                          actions={item.actions}
                          author={item.buyer_name}
                          avatar={Default}
                          content={item.review}
                          datetime={moment.utc(item.createdAt).local().startOf('seconds').fromNow()}
                        />
                        <div className="rating_design"><Rate disabled defaultValue={item.star} /></div>
                      </li>
                    )}
                  />
                </ReviewLeft>

                <ReviewRight>
                  <H5>Write a review</H5>
                  <Form
                    form={form}
                    onFinish={addReview}
                  >
                    <Form.Item
                      label="Your rating"
                      name="star"
                      rules={[
                        { required: true, message: "Please select your rating!" },
                      ]}
                    >
                      <Rate name="star" />
                    </Form.Item>
                    <Form.Item label="Your review" name="review" rules={[
                      { required: true, message: "Please write your review!" },
                    ]} >
                      <TextArea rows={4} maxLength={100} />
                    </Form.Item>
                    <Form.Item>
                      <Button htmlType="submit" type="danger" loading={saving}>Submit Review</Button>
                    </Form.Item>
                  </Form>
                </ReviewRight>

              </ReviewSection>


              <RelatedProduct related={related} />
            </>
          }
        </Wrapper>
      </ProductSection>


    </React.Fragment>
  );
};

const mapStateToProps = (state) => ({
  products: state.cart.products,
});


export default connect(mapStateToProps, { getCartList })(Product);


const AlignReview = styled.div`
display:flex;
align-items:center;
justify-content: space-between;
  margin: 0 0 30px;
`;

const ProductSection = styled.section`
  margin: 60px 0 0 0;
  position: relative;
  width: 100%;
  display: inline-block;
  img.galleryImage {
    max-width: 100%;
    cursor: pointer;
    padding: 8px;
    border: 1px solid ${styles.light};
  }
  .zooming {
    width: 100%;
    margin: 0 0 30px;
    padding: 8px;
    border: 1px solid ${styles.light};
    display: inline-block;
  }
  .ant-image {
    width: 100%;
  }
  .specificationTable {
    margin: 10px 0 0 0;
  }
  .specificationTable td {
    padding: 3px 5px;
  }
  .rating_design {
    display: block;
    width: 100%;
    padding: 0 0 0 44px;
    margin: -10px 0 0 0px;
    position: relative;
    float: left;
  }
  .anticon svg {
    display: inline-block;
    font-size: 14px;
    line-height: 1;
}
.ant-list-items li {
  width: 100%;
  display: inline-block;
}
.ant-list-items li ul li {
  width: fit-content;
}
.ant-list-items li:first-child {
  display: none;
}
.ant-list-items li ul li:first-child {
display: inline-block;
}
.ant-btn-primary, .ant-btn-danger {
  display: flex;
  align-items: center;
}

.ant-breadcrumb a {
  line-height: 1.5;
  display: flex;
}
.ant-breadcrumb ol li{
display: flex;
    align-items: center;
}

`;

const HighLight = styled.div`
  ul {
    padding: 0;
    list-style-position: inside;
    margin: 10px 0 0 0;
  }
`;


const Wrapper = styled.div`
  max-width: 1200px;
  padding: 0 10px;
  margin: auto;
`;
const ProductAlign = styled.div`
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  margin: 45px 0 0 0;
  width: 100%;
  flex-wrap: wrap;
`;
const ProductLeft = styled.div`
  width: 47%;
  display: inline-block;
  position: relative;
  /* border: 1px solid ${styles.light}; */
  border-radius: 5px;
  overflow: hidden;
  @media screen and (max-width:768px) {
    width: 100%;
    margin: 0 0 55px;
  }
`;
const ProductRight = styled.div`
  width: 47%;
  display: flex;
  position: relative;
  flex-direction: column;
  gap: 10px;
  @media screen and (max-width:768px) {
    width: 100%;
  }
`;
const Span = styled.span``;
const AlignRight = styled.div`
  width: 100%;
  display: flex;
  
  text-align: end;
  padding: 0 0 12px 0;
  margin: 0 0 0px;
  border-bottom: 1px solid ${styles.light};
  border-radius: 5px;
`;
const ProductTitle = styled.h1`
  font-size: ${styles.h2};
  color: ${colorCustom?.color} !important;
  line-height: 1.5;
  font-weight: 600;
  margin: 0;
`;
const ProductPrice = styled.div`
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 10px;
`;
const Sp = styled.div`
  font-size: ${styles.h2};
  font-weight: 700;
  color: ${styles.color};
`;
const Mrp = styled.div`
  text-decoration: line-through;
  color: ${styles.gray};
`;
const ProductDescription = styled.div`
  font-size: 16px;
  line-height: 1.6;
  color: ${styles.gray};
`;
const ProductAttribute = styled.div`
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 10px;
  font-size: 16px;
  font-weight: 600;
  color: ${styles.color};
  margin: 25px 0;
`;
const ProductQuantity = styled.div`
  display: flex;
  margin: 8px 0;
`;
const ProductInput = styled.input`
  border: 0;
  border-top: 1px solid #d9d9d9;
  border-bottom: 1px solid #d9d9d9;
  text-align: center;
  outline: none;
  width: 60px;
`;
const ProductAction = styled.div`
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 15px;
  margin: 8px 0;
`;
const AddToCart = styled.div``;
const BuyNow = styled.div``;
const ProductSku = styled.div`
  line-height: 1.5;
  color: ${styles.color};
  margin: 0 0 0px;
`;
const ProductCategory = styled.div`
  line-height: 1.5;
  color: ${styles.color};
`;
const B = styled.b`
  font-weight: 600;
  color: ${styles.color};
  font-size: 18px;
  margin: 0 8px 0 0;
`;

const ReviewSection = styled.div`
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  position: relative;
  margin: 100px 0 0 0;
  flex-wrap: wrap;
`;
const H2 = styled.div`
  color: ${colorCustom?.color} !important;
  line-height: 1.5;
  margin: 0 0 0px;
  font-size: ${styles.h2};
  font-weight: 600;
`;

const Specification = styled.div``;

const ReviewLeft = styled.div`
  width: 60%;
  display: inline-block;
  position: relative;
  max-height: 400px;
  overflow: auto;
  padding: 0 30px 0 0;

  /* width */
  ::-webkit-scrollbar {
    width: 5px;
  }

  /* Track */
  ::-webkit-scrollbar-track {
    background: #f1f1f1;
  }

  /* Handle */
  ::-webkit-scrollbar-thumb {
    background: ${styles.background};
    border-radius: 5px;
  }

  /* Handle on hover */
  ::-webkit-scrollbar-thumb:hover {
    background: ${styles.background};
  }

  @media screen and (max-width:956px) {
    width: 55%;
  }
  @media screen and (max-width:768px) {
    width: 100%;
    margin: 0 0 40px;
  }

`;
const ReviewRight = styled.div`
  width: 35%;
  display: inline-block;
  position: relative;
  border: 1px solid ${styles.light};
  padding: 20px 25px;
  @media screen and (max-width:956px) {
    width: 43%;
  }
  @media screen and (max-width:768px) {
    width: 100%;
  }
`;

const H5 = styled.h5`
  font-size: 18px;
  font-weight: 600;
  color: ${styles.color};
`;