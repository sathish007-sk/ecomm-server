import React, { useState, useEffect } from "react";
import styled from "styled-components";
import { Checkbox, Input, List, message, Modal,Form,Select,Button,Divider } from "antd";
import { styles } from "./../Api/Data";
import API from "../Api/ApiService";
import { getCartList } from '../Store/cartTypes'
import AddAddressPopup from "../Ecommerce/AddAddressPopup"
import { connect, useSelector } from 'react-redux'
import { Link } from "react-router-dom"
import { PlusOutlined, EditOutlined } from '@ant-design/icons';
import EditAddress from "./EditAddressPopup";
const user = JSON.parse(localStorage.getItem("persist:root"))?.company;
const colorCustom = user && JSON.parse(user).setColor;
const { Option } = Select;
const BillingAddress = (props) => {

  const data = useSelector((state) => state.cart.products);
  const api = new API();
  const [addressList, setAddressList] = useState([])
  const [isLoading, setLoading] = useState(false);
  const [delivery, setdelivery] = useState([]);
  const [refresh, setRefresh] = useState(false)
  const [form] = Form.useForm();
  const [countryList, setCountryList] = useState([]);
  const [stateList, setStateList] = useState([]);
  const [cityListData, setCityListData] = useState([]);
  const [id,setId] = useState("")

  var timeOut;
  var address;
  var district;
  var address_line_2;
  let val2;

  const reload = () => {
    setRefresh(!refresh)

  }
  const [isModalOpen1, setIsModalOpen1] = useState(false);
  const showModal1 = (e) => {
    setId(e)
    api.getSingleAddress(e).then((res)=>{
      form.setFieldsValue(res.data);
   }).catch((err)=>{})
    setIsModalOpen1(true);
  };
  const handleOk1 = () => {
    setIsModalOpen1(false);
  };
  const handleCancel1 = () => {
    reload()
    setIsModalOpen1(false);
  };

  const [isModalOpen2, setIsModalOpen2] = useState(false);
  const showModal2 = () => {
    setIsModalOpen2(true);
  };
  const handleOk2 = () => {
    reload()
    setIsModalOpen2(false);
  };
  const handleCancel2 = () => {
    reload()
    getaddressList()
    setIsModalOpen2(false);
  };

  useEffect(()=>{

  
    api.countryList().then((res) => {
      setCountryList(res.data)
    }).catch((err) => {})
  },[])


  const updataAddressForm = (values) => {
    api.updateAddress(values,id).then((res)=>{
      if(res.data.success===true) {
        form.resetFields();
        setIsModalOpen1(false);
        getaddressList()
       
        message.success("Successfully Updated")
       } else {
        message.error("Something went wrong!")
      }
    }).catch((err)=>{
      message.error("Something went wrong!")
    })
  }



  const getState = (data) => {
    api.stateList(data).then((res) => {
      setStateList(res.data.data.states)
    }).catch((err) => {})
  }



  const getCity = (data) => {
    api.cityList(data).then((res) => {
      setCityListData(res.data.data)
    }).catch((err) => {})
  }








  useEffect(() => {
    getaddressList()
  }, [])

  const getaddressList = () => {
    setLoading(true)
    api.addressList().then((res) => {
      const trueadd = res.data?.find((item)=>{
       
        return item?.delivery===true;
    })
    
    address = res.data;
      district = trueadd.district;
      address_line_2 = trueadd.city;
      dlchrg()
      setAddressList(res.data)
      setLoading(false)
    }).catch((err) => { setLoading(false) })
  }
  const dlchrg = () => {
      
    setLoading(true);
    let data = { address: address_line_2, weight: val2 };
   
    api.singleProductDlchrg(data).then((res) => {
    
        setdelivery(res.data)
        setLoading(false);
      
    }).catch((err) => { setLoading(false) })
}



  function setDelivery(id) {
    setLoading(true);
    api.setDeliveryAddress(id)
      .then((res) => {
        if (res.data.success) {
          message.success(res.data.message);
          getaddressList()
          dlchrg()
          
          setLoading(false);
        } else {
          message.error(res.data.message);
          setLoading(false);
        }
      })
      .catch((error) => {
        setLoading(false);
        message.error(error.res.data);
      });
  }



  let tot = data.reduce(

    (carry, ele) => {
        val2 = carry.total_weight += ele.packing_detail * ele.quantity;
        ++carry.total_item;
        carry.total_mrp += ele.mrp * ele.quantity;
        carry.total_discount += (ele.mrp - ele.sp) * ele.quantity;
        carry.total_delivery += delivery * ele.quantity;
        carry.total_amount_t += ele.sp * ele.quantity;
        carry.total_amount += (ele.sp + delivery) * ele.quantity;
        return carry;
    },
    {
        total_item: 0,
        total_amount: 0,
        total_amount_t: 0,
        total_discount: 0,
        total_mrp: 0,
        total_delivery: 0,
        total_weight: 0,
    }
);

  return (
    <React.Fragment>
      <AddressForm>
      <Modal title="Add Address" open={isModalOpen2} onOk={handleOk2} onCancel={handleCancel2} footer={null}>
                      <AddAddressPopup data={handleCancel2} data1={reload}/>
                    </Modal>
        <Modal title="Edit Address" open={isModalOpen1} onOk={handleOk1} onCancel={handleCancel1} footer={null}>
          <div>
            <React.Fragment>
              <Section>
                <Wrapper>
                  <Align>
                    <Right>
                      <AddAddressSection>
                        <Form
                          name="basic"
                          form={form}
                          onFinish={updataAddressForm}
                          autoComplete="off"
                        >
                          <Form.Item
                            label="Name"
                            name="name"
                            rules={[
                              {
                                required: true,
                                message: "Please input your name!",
                              },
                            ]}
                          >
                            <Input />
                          </Form.Item>
                          <Form.Item
                            label="Mobile Number"
                            name="mobile_no"
                            rules={[
                              {
                                required: true,
                                message: "Please input your mobile number!",
                              },
                              {
                                min: 10,
                                max: 10,
                                message: "Phone number must be in 10 digits.",
                              },
                            ]}
                          >
                            <Input type="number" />
                          </Form.Item>
                          <Form.Item
                            label="Alternate Mobile Number"
                            name="alternate_mobile_no"
                          >
                            <Input />
                          </Form.Item>
                          <Form.Item
                            label="Address 1"
                            name="address_line_1"
                            rules={[
                              {
                                required: true,
                                message: "Please input your address",
                              },
                            ]}
                          >
                            <Input />
                          </Form.Item>
                          <Form.Item
                            label="Address 2"
                            name="address_line_2"
                            rules={[
                              {
                                required: true,
                                message: "Please input your address",
                              },
                            ]}
                          >
                            <Input />
                          </Form.Item>
                          <Form.Item
                            label="District"
                            name="district"
                            rules={[
                              {
                                required: true,
                                message: "Please input your district",
                              },
                            ]}
                          >
                            <Input />
                          </Form.Item>

                          <Form.Item
                            label="Pincode"
                            name="pincode"
                            rules={[
                              {
                                type: "regexp",
                                pattern: new RegExp("^d{4}$|^d{6}$"),
                                message: "Format is wrong",
                              },
                              {
                                required: true,
                                message: "Please input your pincode",
                              },
                              { min: 6, max: 6, message: "Pincode must be in 6 digits." },
                            ]}
                          >
                            <Input type="number" />
                          </Form.Item>
                          <Form.Item label="Country" name="country">
                            <Select showSearch allowClear onClick={getState} >
                              {countryList?.map((e) => (
                                <Option value={e._id} key={e._id}>
                                  {e.name}
                                </Option>
                              ))}
                            </Select>
                          </Form.Item>
                          <Form.Item
                            label="State"
                            name="states"
                            rules={[
                              {
                                required: true,
                                message: "Please select state",
                              },
                            ]}
                          >
                            <Select showSearch allowClear onChange={getCity}>
                              {stateList?.map((e) => (
                                <Option value={e.name} key={e.state_code}>
                                  {e.name}
                                </Option>
                              ))}
                            </Select>
                          </Form.Item>
                          <Form.Item
                            label="City"
                            name="city"
                            rules={[
                              {
                                required: true,
                                message: "Please select city",
                              },
                            ]}
                          >
                            <Select showSearch allowClear>
                              {cityListData?.map((e) => (
                                <Option value={e} key={e}>
                                  {e}
                                </Option>
                              ))}
                            </Select>
                          </Form.Item>



                          <Form.Item>
                            <Button type="primary" htmlType="submit">Update Address</Button>
                          </Form.Item>
                        </Form>
                      </AddAddressSection>
                    </Right>
                  </Align>
                </Wrapper>
              </Section>
            </React.Fragment>
          </div>
        </Modal>
        <Button type="primary" size="medium" className="d_add_new" onClick={showModal2}><PlusOutlined /> Add Address</Button>
        <Divider />
        <List
          className="edit-address"
          loading={isLoading}
          itemLayout="horizontal"
          dataSource={addressList}
          renderItem={(item) => (
            <List.Item
              actions={[
                // <Link to={`/edit-address?id=${item._id}`}>
                <div className="edit" onClick={() => showModal1(item._id)}>
                  <EditOutlined /> Edit</div>
                // </Link>
                ,
              ]}
            >
              <List.Item.Meta
                avatar={

                  <Checkbox
                    checked={item.delivery}
                    onChange={() => setDelivery(item._id)}
                  ></Checkbox>

                }
                title={`${item.name} - ${item.mobile_no}`}
                description={`${item.address_line_1}, ${item.address_line_2 == undefined ? "" : item.address_line_2
                  }, ${item.city},  ${item.district}, ${item.states}, ${item.country.name
                  }  - ${item.pincode}.  ${item.alternate_mobile_no
                    ? " Alternate Mobile :" + item.alternate_mobile_no
                    : ""
                  }`}
              />
            </List.Item>
          )}
        />
      </AddressForm>
    </React.Fragment>
  );
};
const mapStateToProps = (state) => ({
  products: state.cart.products,
})
export default connect(mapStateToProps, { getCartList })(BillingAddress);

const AddressForm = styled.section`
  margin: 40px 0 40px 0;
  padding: 24px;
  border: 1px solid #f5f5f5;
  width: 100%;
  position: relative;
  .edit {
    color: ${styles?.colorapi};
    display: flex;
    gap: 8px;
    align-items: center;
    cursor: pointer;
    font-weight: 600;
  }
  form {
    width: 100%;
    margin: auto auto 30px;
    padding: 40px 30px;
    border-radius: 5px;
    border: 1px solid ${styles.light};
  }
  .ant-row {
    flex-wrap: wrap;
    flex-flow: column;
  }
  .ant-col.ant-form-item-label {
    width: 100%;
    display: inline-block;
    label {
      width: 100%;
    }
  }
  .ant-col.ant-form-item-control {
    width: 100%;
  }

  .ant-checkbox-checked::after {
    border: 1px solid ${colorCustom?.color};
  }
  .ant-checkbox-checked .ant-checkbox-inner {
    background-color: ${colorCustom?.color};
    border-color: ${colorCustom?.color};
}
.d_add_new {
  display: flex;
  align-items: center;
  float: right;
  background: #1677ff !important;
  border-color: #1677ff !important;
  margin: 0 0 20px;
}


.ant-checkbox-checked:hover::after {
    border: 1px solid ${colorCustom?.color};
  }
  .ant-list-item-action>li a {
    color: ${colorCustom?.color};
    display: flex;
    align-items: center;
    gap: 6px;
  }
  .ant-btn-dashed:hover, .ant-btn-dashed:focus {
    border-color: ${colorCustom?.color};
    color: ${colorCustom?.color}
  }

`;
const GridAlign = styled.div`
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 0 40px;
  .ant-row {
    flex-wrap: wrap;
    flex-flow: column;
  }
  .ant-col.ant-form-item-label {
    width: 100%;
    display: inline-block;
    label {
      width: 100%;
    }
  }
`;
const H2 = styled.h2`
  font-size: 20;
  color: ${styles.color};
  font-weight: 600;
  margin: 0 0 20px;
`;
const Section = styled.section`
    margin: 0px 0 0 0;
    width: 100%;
    position: relative;
    display: inline-block;
`;
const Title = styled.h1`
    font-size: 30px;
    color: ${styles.color};
    margin: 0 0 25px;
`;
const Wrapper = styled.div`
max-width: 1200px;
padding: 0 0px;
margin: auto;
`;
const Align = styled.div`
display: flex;
justify-content: space-between;
position: relative;
flex-wrap: wrap;
`;
const Left = styled.div`
width: 25%;
display: inline-block;
border: 1px solid ${styles.light};
padding: 0px;
`;
const Right = styled.div`
width: 100%;
padding: 0px;
display: inline-block;
border: 0px solid ${styles.light};
`;


const AddAddressSection = styled.div`
width: 100%;
display: inline-block;
position: relative;

.ant-form-item:nth-child(odd){
  width: 48%;
  display: flex;
  flex-direction: column;
  float: left;
}
.ant-form-item:nth-child(even){
  width: 48%;
  display: flex;
  flex-direction: column;
  float: right;
}
.ant-form-item-label {
  width: 100%;
  display: inline-block;
  text-align: left;
}
.ant-row {
  flex-direction: column;
}


`;