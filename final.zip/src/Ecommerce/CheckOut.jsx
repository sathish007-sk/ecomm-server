import React,{useState, useEffect} from 'react'
import styled from 'styled-components';
import { useSelector } from 'react-redux'
import { Button, message, Steps, notification,Divider,Empty } from "antd";
import  { styles } from '../Api/Data';
import CartList from "./CartList";
import PriceList from "./PriceList";
import { createBrowserHistory } from 'history'
import BillingAddress from './BillingAddress';
import { useLocation, useNavigate  } from "react-router-dom";
import OrderService from '../Api/OrderService'
import API from "../Api/ApiService";
const { Step } = Steps;
const user = JSON.parse(localStorage.getItem("persist:root"))?.company;
const colorCustom = user && JSON.parse(user).setColor;




const CheckOut = () => {
  const [isLoading, setLoading] = useState(false);
  const [current, setCurrent] = useState(0);
  const history = createBrowserHistory();
  const location = useLocation();
  const data = useSelector((state) => state.cart.products);
  const orderService = new OrderService();
  const [length, setLength] = useState("");
  const api = new API();
  const [addressList, setAddressList] = useState([])
  

  
  useEffect(() => {
    let qParams = new URLSearchParams(location.search);
    let msg = qParams.get("msg");
    let status = qParams.get("status");
    if (msg) {
      notification["error"]({
        message: status,
        description: msg,
      });
    }
    let index = qParams.get("i");
    if (index) setCurrent(Number(index));
    calLength()
    getaddressList()
  }, [location]);


  const calLength = () => {
    setLength(data.length)
  }
  
  const orderPlace = () => {
    
    setLoading(true)
    if(addressList.length<1) {
      setCurrent(1);
      message.warning("Please add your delivery Addresss");
      setLoading(false)
    } else {
    orderService.placeOrder().then((res)=>{
      window.location = res.data.redirect;
      history.push("/my-order");
    }).catch((err)=>{
      setLoading(false);
      message.error(err.response.data);
    })
  }
  }

  const onChange = (c) => {
    setCurrent(c);
    getaddressList()

    if(c===2) {
      if(addressList.length<1) {
        setCurrent(1);
        message.warning("Please add your delivery Addresss");
      }
    }
  };

  
  

  const getaddressList = () => {
    setLoading(true)
    api.addressList().then((res) => {
      setAddressList(res.data)
      setLoading(false)
    }).catch((err) => { setLoading(false) })
  }



  const content = (index) => {
    switch (index) {
      case 1:
        return <BillingAddress order />;
        break;
      case 2:
        return <PriceList />;
        break;
      default:
        return <CartList />;
        break;
    }
  };

  const action = (index) => {
    switch (index) {
      case 0:
        return (
          <>
            <Button type="primary" onClick={() => onChange(1)}>
              Next
            </Button>
          </>
        );
        break;
      case 1:
        return (
          <>
          <div className='checkout_btn'>
            <Button type="dashed" onClick={() => onChange(0)}>
              Previous
            </Button>
            <Button type="primary" onClick={() => onChange(2)}>
              Next
            </Button>
            </div>
          </>
        );
        break;
      case 2:
        return (
          <>
          <div className='checkout_btn'>
            <Button type="dashed" onClick={() => onChange(1)}>
              Previous
            </Button>
            <Button
              isLoading={isLoading}
              type="primary"
              onClick={() => orderPlace()}
            >
              Pay now
            </Button>
            </div>
          </>
        );
        break;
      default:
        return <CartList />;
        break;
    }
  };

  

  return (
    <React.Fragment>
      <CheckOutPage>
        <Wrapper>
          <H2>Checkout</H2>
          <CheckOutAlign>
            {
              length===0 ? <Empty style={{margin:"100px 0"}} /> :

            
            <StepsAlign>
            <Steps
                size="small"
                current={current}
                onChange={onChange}
                responsive
                className='step_form'
              >
                <Step title="Item Summary" />
                <Step title="Delivery Address" />
                <Step title="Payment" />
              </Steps>
              
              {content(current)}
              <Divider />
              {action(current)}
              <p id="response"></p>
            </StepsAlign>
            }
          </CheckOutAlign>
        </Wrapper>
      </CheckOutPage>
    </React.Fragment>
  );
}



export default CheckOut;




const CheckOutPage = styled.section`
  margin: 60px 0 0 0;
  width: 100%;
  position: relative;
  .ant-steps-item-process .ant-steps-item-icon {
    background: ${styles.background};
    border-color: ${styles.background};
  }
  .ant-steps-item-finish
    > .ant-steps-item-container
    > .ant-steps-item-content
    > .ant-steps-item-title:after {
    background-color: ${styles.background};
  }
  .ant-steps-item-finish .ant-steps-item-icon {
    background-color: #fff;
    border-color: ${styles.background};
  }
  .anticon.anticon-check.ant-steps-finish-icon {
    color: ${styles.background};
  }
  .ant-btn.ant-btn-primary {
    border-color: ${styles.background};
    background: ${styles.background};
  }
  .step_form {
    padding: 0 200px;
  }
  .checkout_btn {
    display: flex;
    align-items: center;
    gap: 20px;
  }
  .ant-steps-item-process .ant-steps-item-icon {
    background: ${colorCustom?.color};
    border-color: ${colorCustom?.color};
}
.anticon.anticon-check.ant-steps-finish-icon {
  color: ${colorCustom?.color};
}
.ant-steps-item-finish .ant-steps-item-icon {
  border-color: ${colorCustom?.color};
}
.ant-steps-item-finish > .ant-steps-item-container > .ant-steps-item-content > .ant-steps-item-title:after {
  background-color: ${colorCustom?.color};
}

.ant-btn.ant-btn-primary {
  background: ${colorCustom?.color};
    border-color: ${colorCustom?.color};
}
.ant-steps-icon {
display: flex;
    align-items: center;
    justify-content: center;
    margin: auto;
    height: 100%;
}
  @media screen and (max-width:1200px) {
    .step_form {
    padding: 0 0px;
  }
  }


`;
const Wrapper = styled.div`
  max-width: 1200px;
  margin: auto;
  padding: 0 10px;
  position: relative;

`;
const H2 = styled.h2`
  font-size: ${styles.h2};
  color:${colorCustom?.color} !important;
  margin: 0 0 30px;
  font-weight: 600;
`;
const CheckOutAlign = styled.div`
padding: 0 0px;
`;
const StepsAlign = styled.div`
  width: 100%;
  display: inline-block;
  padding: 0 0px;
`;