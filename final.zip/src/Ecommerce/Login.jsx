import React, { useState, useEffect } from "react";
import { message, Button, Form, Input } from "antd";
import styled from "styled-components";
import { Link, useNavigate } from "react-router-dom";
import { styles } from "../Api/Data";
import API from "../Api/ApiService";
import { useDispatch, useSelector } from "react-redux";







const Login = () => {

  const [form] = Form.useForm();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [isSaving, setSaving] = useState(false);
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const loginTrue = useSelector((state) => state.user.currentUser?.token);


  useEffect(() => {
    if (!loginTrue && loginTrue != "") {
    } else {
      navigate('/')
    }
  }, [loginTrue])

  const loginForm = (values) => {
    setSaving(true);
    const api = new API();
    api.login(dispatch, {
      'user_name': username,
      'password': password,
    }, setSaving(false)).then((res) => {
      let data = res.data;
      if (data.success === true) {
        form.resetFields();
        message.success('Logged in successfully');
        navigate('/')
        window.location.reload(true)
      }
      else {
        message.error('Username or Password Mismatch!');
      }
    }).catch((error) => {

    })


  };


  return (
    <React.Fragment>
      <LoginSection>
        <LoginAlign>

          <LoginRight>
            <Title>Login</Title>
            <Form form={form} name="Login_Form" onFinish={loginForm}>
              <Form.Item
                label="Enter Mobile number"
                name="user_name"
                rules={[
                  {
                    required: true,
                    message: "Please enter your e-Mail/Mobile number!",
                  },
                ]}

              >
                <Input onChange={(e) => setUsername(e.target.value)} />
              </Form.Item>

              <Form.Item
                label="Enter Password"
                name="password"
                rules={[
                  { required: true, message: "Please enter your password!" },
                ]}

              >
                <Input.Password onChange={(e) => setPassword(e.target.value)} />
              </Form.Item>
              <Form.Item>
                <Button
                  type="primary"
                  htmlType="submit"
                  block
                  loading={isSaving}
                  className="primary_btn"
                >
                  Submit
                </Button>
              </Form.Item>
            </Form>
            <Or>
              or
            </Or>
            <LoginOtp>
              Login with OTP
              <Link to="/login-with-otp">
                Click Here
              </Link>
            </LoginOtp>

            <ForgetPassword>
            <Link to="/forgot-password">
              Forgot Password
              </Link>
            </ForgetPassword>
            <NewAccount>
              <Link to="/register">
                Click Here
              </Link>
              to Create an account
            </NewAccount>
          </LoginRight>
        </LoginAlign>
      </LoginSection>
    </React.Fragment>
  );

};

export default Login;
const LoginSection = styled.section`
  display: flex;
  width: 100%;
  position: relative;
  align-items: center;
  justify-content: center;
  @media screen and (max-width:580px) {
    padding: 0 20px;
  }
  .primary_btn {
    background: ${styles?.colorapi};
    border: 1px solid ${styles?.colorapi};
  }
`;
const LoginAlign = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 450px;
  flex-wrap: wrap;
  box-shadow: 0 0 40px rgb(0 0 0 / 9%);
  border-radius: 5px;
  margin: 70px 0;
  min-height: 300px;

  @media screen and (max-width:580px) {
    width: 100%;
    margin: 40px 0;
  }


`;

const LoginRight = styled.div`
  display: inline-block;
  width: 100%;
  position: relative;
  padding: 35px 35px;
  input {
    width: 100%;
    padding: 8px 14px;
  }
  input[type="password"] {
    width: 100%;
    padding: 4px 0px;
  }
  .ant-space {
    width: 100%;
    margin: 0 0 10px;
  }
  button {
    padding: 7px 20px;
    height: auto;
    font-size: 15px;
    background: ${styles.background};
    border: 1px solid ${styles.background};
  }

  .ant-row.ant-form-item-row {
    display: flex;
    flex-direction: column;
  }

  .ant-form label {
    width: 100%;
    display: inline-block;
    text-align: left;
  }

  @media screen and (max-width:580px) {
    padding: 30px 25px;
  }

`;


const Title = styled.div`
font-size: 25px;
color: #000;
font-weight: 700;
width: 100%;
margin: 0 0 20px;
text-transform: uppercase;
`;

const Or = styled.div`
width: 100%;
font-size: 15px;
text-align: center;
font-style: italic;
`;
const LoginOtp = styled.div`
font-size: 14px;
line-height: 1.5;
margin: 10px 0 0 0;
width: 100%;
display: flex;
text-align: center;
flex-wrap: wrap;
gap: 10px;
align-items: center;
justify-content: center;
`;
const ForgetPassword = styled.div`
  margin: 25px 0 0 0;
  text-align: center;
  width:100%;
  text-align: center;
`;
const NewAccount = styled.div`
margin: 8px 0 0 0;
  text-align: center;
  width:100%;
  text-align: center;
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
  align-items: center;
  justify-content: center;
`;