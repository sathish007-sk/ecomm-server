import React, { useEffect, useState } from 'react'
import styled from 'styled-components';
import API from '../Api/ApiService';
import { message, Form, Input, Select, Button } from 'antd'
import { styles } from '../Api/Data';
import { useNavigate, useLocation } from 'react-router-dom'
import ProfileMenu from './ProfileMenu';
const { Option } = Select;

const EditAddress = () => {
  const api = new API();
  const location = useLocation();
  const params = new URLSearchParams(location.search);
  const getParms = params.get("id");
  const navigate = useNavigate();
  const [form] = Form.useForm();
  const [countryList, setCountryList] = useState([]);
  const [stateList, setStateList] = useState([]);
  const [cityListData, setCityListData] = useState([]);

  

  useEffect(()=>{
    api.getSingleAddress(getParms).then((res)=>{
       form.setFieldsValue(res.data);
    }).catch((err)=>{})
  },[])


  useEffect(()=>{

  
    api.countryList().then((res) => {
      setCountryList(res.data)
    }).catch((err) => {})
  },[])


  const updataAddressForm = (values) => {
    let id = getParms;
    api.updateAddress(values, id).then((res)=>{
      if(res.data.success===true) {
        form.resetFields();
        message.success("Successfully Updated")
       } else {
        message.error("Something went wrong!")
      }
    }).catch((err)=>{
      message.error("Something went wrong!")
    })
  }


  const getState = (data) => {
    api.stateList(data).then((res) => {
      setStateList(res.data.data.states)
    }).catch((err) => {})
  }



  const getCity = (data) => {
    api.cityList(data).then((res) => {
      setCityListData(res.data.data)
    }).catch((err) => {})
  }









  return (
   <React.Fragment>
    test
   </React.Fragment>
  )
}

export default EditAddress


const Section = styled.section`
    margin: 0px 0 0 0;
    width: 100%;
    position: relative;
    display: inline-block;
`;
const Title = styled.h1`
    font-size: 30px;
    color: ${styles.color};
    margin: 0 0 25px;
`;
const Wrapper = styled.div`
max-width: 1200px;
padding: 0 0px;
margin: auto;
`;
const Align = styled.div`
display: flex;
justify-content: space-between;
position: relative;
flex-wrap: wrap;
`;
const Left = styled.div`
width: 25%;
display: inline-block;
border: 1px solid ${styles.light};
padding: 0px;
`;
const Right = styled.div`
width: 100%;
padding: 0px;
display: inline-block;
border: 0px solid ${styles.light};
`;


const AddAddressSection = styled.div`
width: 100%;
display: inline-block;
position: relative;

.ant-form-item:nth-child(odd){
  width: 48%;
  display: flex;
  flex-direction: column;
  float: left;
}
.ant-form-item:nth-child(even){
  width: 48%;
  display: flex;
  flex-direction: column;
  float: right;
}
.ant-form-item-label {
  width: 100%;
  display: inline-block;
  text-align: left;
}
.ant-row {
  flex-direction: column;
}


`;