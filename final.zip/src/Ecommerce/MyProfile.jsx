import React, { useEffect, useState } from 'react'
import styled from 'styled-components';
import { styles } from '../Api/Data';
import ProfileMenu from './ProfileMenu';
import {
    Button,
    Radio,
    message,
    Form,
    Input,
    Upload,
} from "antd";
import { LoadingOutlined, PlusOutlined } from '@ant-design/icons';
import API from '../Api/ApiService';


const getBase64 = (img, callback) => {
    const reader = new FileReader();
    reader.addEventListener('load', () => callback(reader.result));
    reader.readAsDataURL(img);
};
const beforeUpload = (file) => {
    const isJpgOrPng = file.type === 'image/jpeg' || file.type === 'image/png' || file.type === 'image/jpg' || file.type === 'image/webp';
    if (!isJpgOrPng) {
        message.error('You can only upload JPG/PNG/WEBP file!');
    }
    const isLt2M = file.size / 1024 / 1024 < 2;
    if (!isLt2M) {
        message.error('Image must smaller than 2MB!');
    }
    return isJpgOrPng && isLt2M;
};



const MyProfile = () => {
    const [imageUrl, setImageUrl] = useState("");
    const [isLoading, setLoading] = useState(false);
    const [buyerId, setBuyerId] = useState("");
    const [form] = Form.useForm();
    const api = new API();

    useEffect(() => {
        api.getMyProfile().then((res) => {
            setBuyerId(res.data._id);
            form.setFieldsValue(res.data);
        }).catch((error) => {})
    }, [])

    
    const myProfileForm = (values) => {
        setLoading(true);
        api.updateMyProfile(values).then((res) => {
            setLoading(false);
            let data = res.data;
            if (data.success === true) {
                message.success("Profile update successfully");
            } else {
                setLoading(false);
                message.error("Profile not Updated");
            }
        }).catch((err) => {
            setLoading(false);
            message.error("Something went wrong!");
        });
    }


    //Profile
    const upoad = (e) => {
        let id = buyerId;
        console.log(e.target.files[0])
    }

    const handleChange = (info) => {
        if (info.file.status === 'uploading') {
            setLoading(true);
            return;
        }
        if (info.file.status === 'done') {
            // Get this url from response in real world.
            getBase64(info.file.originFileObj, (url) => {
                setLoading(false);
                setImageUrl(url);
                let id = buyerId;
                // let link = Date.now();
                api.updateProfileImage(url, id).then((res) => {
                    console.log(res)
                }).catch((err) => {
                    message.error("Profile image not updated")
                })
            });
        }
    };
    const uploadButton = (
        <div>
            {isLoading ? <LoadingOutlined /> : <PlusOutlined />}
            <div
                style={{
                    marginTop: 8,
                }}
            >
                Upload
            </div>
        </div>
    );

    return (
        <React.Fragment>
            <Section>
                <Wrapper>
                    <Title>My Profile</Title>
                    <Align>
                        <Left>
                            <ProfileMenu />
                        </Left>
                        <Right>
                            <FormAlign>
                                <FormLeft>
                                    <Form
                                        name="basic"
                                        form={form}
                                        onFinish={myProfileForm}
                                        autoComplete="off"
                                    >
                                        <Form.Item
                                            label="First Name"
                                            name="first_name"
                                            rules={[
                                                {
                                                    required: true,
                                                    message: "Please input your First name!",
                                                },
                                            ]}
                                        >
                                            <Input />
                                        </Form.Item>

                                        <Form.Item
                                            label="Last Name"
                                            name="last_name"
                                            rules={[
                                                {
                                                    required: true,
                                                    message: "Please input your Last name!",
                                                },
                                            ]}
                                        >
                                            <Input />
                                        </Form.Item>
                                        <Form.Item
                                            label="e-Mail"
                                            name="email"
                                            rules={[
                                                {
                                                    type: "email",
                                                    required: true,
                                                    message: "Please input your valid email!",
                                                },
                                            ]}
                                        >
                                            <Input />
                                        </Form.Item>

                                        <Form.Item
                                            label="Mobile Number"
                                            name="mobile_no"
                                            readOnly
                                            rules={[
                                                {
                                                    required: true,
                                                    message: "Please input your mobile number!",
                                                },
                                            ]}
                                        >
                                            <Input />
                                        </Form.Item>

                                        <Form.Item
                                            name="gender"
                                            label="Gender"
                                            rules={[
                                                {
                                                    required: true,
                                                    message: "Please select gender!",
                                                },
                                            ]}
                                        >
                                            <Radio.Group>
                                                <Radio value="Male">Male</Radio>
                                                <Radio value="Female">Female</Radio>
                                                <Radio value="Transgender">Transgender</Radio>
                                            </Radio.Group>
                                        </Form.Item>

                                        <Form.Item>
                                            <Button loading={isLoading} type="primary" htmlType="submit">
                                                Save Profile
                                            </Button>
                                        </Form.Item>
                                    </Form>
                                </FormLeft>
                                <FormRight>
                                    {/* <Upload
                                        name="avatar"
                                        listType="picture-card"
                                        className="avatar-uploader"
                                        showUploadList={false}
                                        action="https://www.mocky.io/v2/5cc8019d300000980a055e76"
                                        beforeUpload={beforeUpload}
                                        onChange={handleChange}
                                    >
                                        {imageUrl ? (
                                            <img
                                                src={imageUrl}
                                                alt="avatar"
                                                style={{
                                                    width: '100%',
                                                }}
                                            />
                                        ) : (
                                            uploadButton
                                        )}
                                    </Upload> */}
                                    {/* <input type="file" onChange={upoad}/> */}
                                </FormRight>
                            </FormAlign>
                        </Right>
                    </Align>
                </Wrapper>
            </Section>
        </React.Fragment>
    )
}

export default MyProfile


const Section = styled.section`
    margin: 60px 0 0 0;
    width: 100%;
    position: relative;
    display: inline-block;
`;
const Title = styled.h1`
    font-size: 30px;
    color: ${styles.color};
    margin: 0 0 25px;
`;
const Wrapper = styled.div`
max-width: 1200px;
padding: 0 10px;
margin: auto;
`;
const Align = styled.div`
display: flex;
justify-content: space-between;
position: relative;
flex-wrap: wrap;
`;
const Left = styled.div`
width: 25%;
display: inline-block;
border: 1px solid ${styles.light};
padding: 24px;
@media screen and (max-width:956px) {
    width: 100%;
    margin: 0 0 50px;
}
`;
const Right = styled.div`
width: 72%;
display: inline-block;
border: 1px solid ${styles.light};
padding: 24px;
@media screen and (max-width:956px) {
    width: 100%;
    
}
`;

const FormAlign = styled.div`
    width: 100%;
    display: flex;
    align-items: flex-start;
    flex-wrap: wrap;
`;
const FormLeft = styled.div`
width: 65%;
display: inline-block;
position: relative;
.ant-row {
    flex-wrap: wrap;
    flex-direction: column;
}
.ant-form-item-label {
    width: 100%;
    display: inline-block;
    text-align: left;
}
.ant-form-item {
    margin: 0 0 24px;
    display: inline-block;
    width: 100%;
}
.ant-form-item:nth-child(5) {
    width: 100%;
    display: inline-block;
}
.ant-form-item:nth-child(1), .ant-form-item:nth-child(3) {
    width: 48%;
    float: left;
}
.ant-form-item:nth-child(2), .ant-form-item:nth-child(4) {
    width: 48%;
    float: right;
}

@media screen and (max-width:768px) {
    width: 100%;
    .ant-form-item:nth-child(1), .ant-form-item:nth-child(3) {
    width: 100%;
    float: left;
}
.ant-form-item:nth-child(2), .ant-form-item:nth-child(4) {
    width: 100%;
    float: right;
}
}


`;
const FormRight = styled.div`
width: 30%;
display: inline-block;
position: relative;
`;