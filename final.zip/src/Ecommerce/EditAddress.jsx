import React, { useEffect, useState } from 'react'
import styled from 'styled-components';
import API from '../Api/ApiService';
import { message, Form, Input, Select, Button } from 'antd'
import { styles } from '../Api/Data';
import { useNavigate, useLocation } from 'react-router-dom'
import ProfileMenu from './ProfileMenu';
const { Option } = Select;

const EditAddress = () => {
  const api = new API();
  const location = useLocation();
  const params = new URLSearchParams(location.search);
  const getParms = params.get("id");
  const navigate = useNavigate();
  const [form] = Form.useForm();
  const [countryList, setCountryList] = useState([]);
  const [stateList, setStateList] = useState([]);
  const [cityListData, setCityListData] = useState([]);

  

  useEffect(()=>{
    api.getSingleAddress(getParms).then((res)=>{
       form.setFieldsValue(res.data);
    }).catch((err)=>{})
  },[])


  useEffect(()=>{

  
    api.countryList().then((res) => {
      setCountryList(res.data)
    }).catch((err) => {})
  },[])


  const updataAddressForm = (values) => {
    let id = getParms;
    api.updateAddress(values, id).then((res)=>{
      if(res.data.success===true) {
        form.resetFields();
        message.success("Successfully Updated")
        navigate('/my-address')
      } else {
        message.error("Something went wrong!")
      }
    }).catch((err)=>{
      message.error("Something went wrong!")
    })
  }


  const getState = (data) => {
    api.stateList(data).then((res) => {
      setStateList(res.data.data.states)
    }).catch((err) => {})
  }



  const getCity = (data) => {
    api.cityList(data).then((res) => {
      setCityListData(res.data.data)
    }).catch((err) => {})
  }









  return (
    <React.Fragment>
      <Section>
        <Wrapper>
          <Title>Edit Address</Title>
          <Align>
            <Left>
              <ProfileMenu />
            </Left>
            <Right>
              <AddAddressSection>
                <Form
                  name="basic"
                  form={form}
                  onFinish={updataAddressForm}
                  autoComplete="off"
                >
                  <Form.Item
                    label="Name"
                    name="name"
                    rules={[
                      {
                        required: true,
                        message: "Please input your name!",
                      },
                    ]}
                  >
                    <Input />
                  </Form.Item>
                  <Form.Item
                    label="Mobile Number"
                    name="mobile_no"
                    rules={[
                      {
                        required: true,
                        message: "Please input your mobile number!",
                      },
                      {
                        min: 10,
                        max: 10,
                        message: "Phone number must be in 10 digits.",
                      },
                    ]}
                  >
                    <Input type="number" />
                  </Form.Item>
                  <Form.Item
                    label="Alternate Mobile Number"
                    name="alternate_mobile_no"
                  >
                    <Input />
                  </Form.Item>
                  <Form.Item
                    label="Address 1"
                    name="address_line_1"
                    rules={[
                      {
                        required: true,
                        message: "Please input your address",
                      },
                    ]}
                  >
                    <Input />
                  </Form.Item>
                  <Form.Item
                    label="Address 2"
                    name="address_line_2"
                    rules={[
                      {
                        required: true,
                        message: "Please input your address",
                      },
                    ]}
                  >
                    <Input />
                  </Form.Item>
                  <Form.Item
                    label="District"
                    name="district"
                    rules={[
                      {
                        required: true,
                        message: "Please input your district",
                      },
                    ]}
                  >
                    <Input />
                  </Form.Item>

                  <Form.Item
                    label="Pincode"
                    name="pincode"
                    rules={[
                      {
                        type: "regexp",
                      pattern: new RegExp("^d{4}$|^d{6}$"),
                        message: "Format is wrong",
                      },
                      {
                        required: true,
                        message: "Please input your pincode",
                      },
                      { min: 6, max: 6, message: "Pincode must be in 6 digits." },
                    ]}
                  >
                    <Input type="number" />
                  </Form.Item>
                  <Form.Item label="Country" name="country">
                    <Select showSearch allowClear  onClick={getState} >
                      {countryList?.map((e) => (
                        <Option value={e._id} key={e._id}>
                          {e.name}
                        </Option>
                      ))}
                    </Select>
                  </Form.Item>
                  <Form.Item
                    label="State"
                    name="states"
                    rules={[
                      {
                        required: true,
                        message: "Please select state",
                      },
                    ]}
                  >
                    <Select showSearch allowClear onChange={getCity}>
                      {stateList?.map((e) => (
                        <Option value={e.name} key={e.state_code}>
                          {e.name}
                        </Option>
                      ))}
                    </Select>
                  </Form.Item>
                  <Form.Item
                    label="City"
                    name="city"
                    rules={[
                      {
                        required: true,
                        message: "Please select city",
                      },
                    ]}
                  >
                    <Select showSearch allowClear>
                      {cityListData?.map((e) => (
                        <Option value={e} key={e}>
                          {e}
                        </Option>
                      ))}
                    </Select>
                  </Form.Item>



                  <Form.Item>
                    <Button type="primary" htmlType="submit">Update Address</Button>
                  </Form.Item>
                </Form>
              </AddAddressSection>
            </Right>
          </Align>
        </Wrapper>
      </Section>
    </React.Fragment>
  )
}

export default EditAddress


const Section = styled.section`
    margin: 60px 0 0 0;
    width: 100%;
    position: relative;
    display: inline-block;
`;
const Title = styled.h1`
    font-size: 30px;
    color: ${styles.color};
    margin: 0 0 25px;
`;
const Wrapper = styled.div`
max-width: 1200px;
padding: 0 10px;
margin: auto;
`;
const Align = styled.div`
display: flex;
justify-content: space-between;
position: relative;
flex-wrap: wrap;
`;
const Left = styled.div`
width: 25%;
display: inline-block;
border: 1px solid ${styles.light};
padding: 24px;
`;
const Right = styled.div`
width: 72%;
padding: 24px;
display: inline-block;
border: 1px solid ${styles.light};
`;


const AddAddressSection = styled.div`
width: 100%;
display: inline-block;
position: relative;

.ant-form-item:nth-child(odd){
  width: 48%;
  display: flex;
  flex-direction: column;
  float: left;
}
.ant-form-item:nth-child(even){
  width: 48%;
  display: flex;
  flex-direction: column;
  float: right;
}
.ant-form-item-label {
  width: 100%;
  display: inline-block;
  text-align: left;
}
.ant-row {
  flex-direction: column;
}


`;