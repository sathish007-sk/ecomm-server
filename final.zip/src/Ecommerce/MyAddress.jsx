import React, { useEffect, useState } from 'react'
import styled from 'styled-components';
import API from '../Api/ApiService';
import { message, Button, Popconfirm } from 'antd'
import { styles } from '../Api/Data';
import { Link } from 'react-router-dom'
import ProfileMenu from './ProfileMenu';
import { EditOutlined, DeleteOutlined, PlusOutlined } from '@ant-design/icons';

const MyAddress = () => {
  const [addressList, setAddressList] = useState([]);
  const [isLoading, setLoading] = useState(false);
  const api = new API();
  const getaddressList = () => {
    setLoading(true)
    api.addressList().then((res) => {
      setAddressList((res.data).reverse())
      setLoading(false)
    }).catch((err) => {setLoading(false)})
  }
  useEffect(() => {
    getaddressList()
  }, [])


  const confirm = (e) => {
    setLoading(true)
    api.deleteAddress(e).then((res)=>{
      let data = (res.data);
      if(data.success===true) {
        message.success("Successfully Deleted");
        getaddressList()
        setLoading(false)
      } else {
         message.error('Something went wrong!');
        setLoading(false)
      }
    }).catch((err)=>{
      message.error('Something went wrong!');
      setLoading(false)
    })
  };



  return (
    <React.Fragment>
      <Section>
        <Wrapper>
          <Title>My MyAddress</Title>
          <Align>
            <Left>
              <ProfileMenu />
            </Left>
            <Right>
              <AddressList>
                <Box>
                  <Add>
                    <Link to="/add-address">
                      <PlusOutlined /> Add New
                    </Link>
                  </Add>
                </Box>
                {
                  addressList?.map((data) => {
                    return (
                      <Box key={data._id}>
                        <BoxTitle>{data.name} - {data.mobile_no}</BoxTitle>
                        <Text>
                          {data.address_line_1}, {data.address_line_2}, {data.district}, {data.city}, {data.states}, {data.country.name}, {data.pincode}
                        </Text>
                        <Action>
                          <Edit><Link to={`/edit-address?id=${data._id}`}><Button type="primary" size="small"><EditOutlined /> Edit</Button></Link></Edit>
                          {
                            addressList?.length>1 ?<Delete><Popconfirm
                            title="Are you sure to delete this address?"
                            onConfirm={()=>confirm(data._id)}
                            loading={isLoading}
                            okText="Yes"
                            cancelText="No"
                          ><Button type="danger" size="small"><DeleteOutlined /> Delete</Button></Popconfirm></Delete> : ""
                          }
                          
                        </Action>
                      </Box>
                    )
                  })
                }

              </AddressList>
            </Right>
          </Align>
        </Wrapper>
      </Section>
    </React.Fragment>
  )
}

export default MyAddress

const Action = styled.div`
display: flex;
flex-wrap: wrap;
align-items: center;
gap: 12px;
margin: 15px 0 0 0;
`;
const Add = styled.div`
position: absolute;
height: 100%;
width: 100%;
cursor: pointer;
display: flex;
align-items: center;
justify-content: center;
top:0;
left:0;
color: ${styles.color} !important;
font-size: 16px;
font-weight: 600;

`;
const Edit = styled.div``;
const Delete = styled.div``;


const Section = styled.section`
    margin: 60px 0 0 0;
    width: 100%;
    position: relative;
    display: inline-block;
    .ant-btn-sm {
   display: flex;
    align-items: center;
}
`;
const Title = styled.h1`
    font-size: 30px;
    color: ${styles.color};
    margin: 0 0 25px;
`;
const Wrapper = styled.div`
max-width: 1200px;
padding: 0 10px;
margin: auto;
`;
const Align = styled.div`
display: flex;
justify-content: space-between;
position: relative;
flex-wrap: wrap;
`;
const Left = styled.div`
width: 25%;
display: inline-block;
border: 1px solid ${styles.light};
padding: 24px;
@media screen and (max-width:956px) {
  width: 100%;
  margin: 0 0 50px;
}



`;
const Right = styled.div`
width: 72%;
padding: 24px;
display: inline-block;
border: 1px solid ${styles.light};

@media screen and (max-width:956px) {
  width: 100%;
 
}

`;
const AddressList = styled.div`
display: grid;
grid-template-columns: repeat(3,1fr);
gap: 24px;

@media screen and (max-width:768px) {
  grid-template-columns: repeat(1,1fr);
}


`;
const Box = styled.div`
width: 100%;
padding: 25px 24px;
border: 1px solid ${styles.light};
box-shadow: 0 0 8px #000;
    box-shadow: 0 0 8px rgb(0 0 0 / 6%);
    border-radius: 4px;
    position: relative;
    min-height: 100px;
    display: flex;
    flex-direction: column;
    justify-content: space-between;

    a {
      display: flex;
    align-items: center;
    gap: 10px;
    }
`;
const BoxTitle = styled.div`
  font-size: 16px;
  font-weight: 600;
  color: ${styles.color};
  margin: 0 0 10px;
`;
const Text = styled.div``;