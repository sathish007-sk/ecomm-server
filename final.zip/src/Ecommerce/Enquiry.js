import React, { useState } from "react";
import { message, Alert, Row, Col, Input, Form, Button } from "antd";
import API from "../Api/ApiService";
export default function Enquiry() {
  const [response, setResponse] = useState(null);
  const [isSaving, setSaving] = useState(false);
  const [form] = Form.useForm();

  const api = new API();
  const onFinish = (values) => {
    setSaving(true);
    api
      .enquiry(values)
      .then((res) => {
        setResponse(null);
        let data = res.data;
        setSaving(false);
        if (data.success) {
          form.resetFields();
          setResponse("Submitted Successfully, thanks");
        } else message.error(data.message);
      })
      .catch((error) => {
        setSaving(false);
        message.error(error.message);
      });
  };

  return (
    <section className="container">
      <Row justify="center">
        <Col lg={12}>
          <h1 className="hometitle">Enquiry</h1>
          <Form
            size="middle"
            labelCol={{ span: 24 }}
            form={form}
            onFinish={onFinish}
          >
            <Form.Item
              label="Enter Your Name"
              name="name"
              rules={[{ required: true, message: "Please enter your name" }]}
            >
              <Input />
            </Form.Item>
            <Form.Item
              label="Enter Your Email"
              name="email"
              rules={[{ required: true, message: "Please enter e-Mail" }]}
            >
              <Input />
            </Form.Item>
            <Form.Item
              label="Enter Your Mobile Number"
              name="mobile_no"
              rules={[
                { required: true, message: "Please enter mobile number" },
              ]}
            >
              <Input />
            </Form.Item>
            <Form.Item
              label="Enter Subject"
              name="subject"
              rules={[{ required: true, message: "Please enter subject" }]}
            >
              <Input />
            </Form.Item>
            <Form.Item
              label="Enter Your Message"
              name="description"
              rules={[{ required: true, message: "Please enter Description!" }]}
            >
              <Input.TextArea />
            </Form.Item>

            <Row justify="center">
              <Col>
                <Form.Item>
                  <Button type="primary" htmlType="submit" loading={isSaving}>
                    Submit
                  </Button>
                </Form.Item>
              </Col>
            </Row>
          </Form>
          <br />
          {response && <Alert message={response} type="success" />}
        </Col>
      </Row>
    </section>
  );
}
