import React, { useEffect, useState } from "react";
import { message, Button, Form, Input, Radio } from "antd";
import styled from "styled-components";
import { Link, useNavigate } from "react-router-dom";
import { styles } from "../Api/Data";
import API from "../Api/ApiService";
import { useDispatch, useSelector } from "react-redux";

const Register = () => {
  const [form] = Form.useForm();
  const [form1] = Form.useForm();
  const [isSaving, setSaving] = useState(false);
  const [value, setValue] = useState(1);
  const [stage, setStage] = useState(1);
  const [mobileNo, setMobileNo] = useState('');
  const api = new API();
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const loginTrue = useSelector((state) => state.user.currentUser?.token);


  useEffect(() => {
    if (!loginTrue && loginTrue != "") {
    } else {
      navigate('/')
    }
  }, [loginTrue])

  const onChange = (e) => {
    setValue(e.target.value);
  };
  const registerMobile = (values) => {
    setSaving(true);
    setMobileNo(values.mobile_no);
    api.registerMobile(values.mobile_no).then((res) => {
      setSaving(false);
      let data = res.data;
      if (data.success === true) {
        setStage(2);
        message.success(data.message);

      } else {
        message.error("Account already exists");
        setSaving(false);
      }
    }).catch((error) => {
      setSaving(false);
      message.error('Something went wrong!');
    })
  };

  const registerForm = (values) => {
    setSaving(true);
    api.newRegister(dispatch, values, setSaving(false)).then((res) => {
      let data = res.data;
      setSaving(false);
      if (data.success === true) {
        form1.resetFields();
        message.success('Logged in successfully');
        navigate('/')
      } else {
        setSaving(false);
        message.error('Login Failed!');
      }
    }).catch((err) => {
      setSaving(false);
      message.error('Something went wrong!');
    })
  };

  const submitForm = () => {
    let mobile_no = mobileNo;
    registerMobile({ mobile_no: mobile_no });
  }

  return (
    <React.Fragment>
      <RegisterSection>
        <RegisterAlign>
          <RegisterRight>
            <Title>Registration</Title>
            {stage == 1 ? (
              <Form form={form} name="Register_Form" onFinish={registerMobile}>
                <Form.Item
                  label="Enter Mobile number"
                  name="mobile_no"

                  rules={[
                    {
                      required: true,
                      message: "Please enter your Mobile number!",
                    },
                  ]}
                >
                  <Input />
                </Form.Item>
                <Form.Item>
                  <Button
                    type="primary"
                    htmlType="submit"
                    block
                    loading={isSaving}
                    className="primary_btn"
                  >
                    Continue
                  </Button>
                </Form.Item>
              </Form>
            ) : (
              <Form
                form={form1}
                onFinish={registerForm}
                name="Reg_Form"
              >
                <Form.Item
                  label="Mobile number"
                  name="mobile_no"
                  value={mobileNo}
                  rules={[
                    {
                      required: true,
                      message: "Please enter your Mobile number!",
                    },
                  ]}
                >
                  <Input readOnly value={mobileNo} />
                  <Resend>
                    Didn't receive OTP?{" "}
                    <a onClick={() => submitForm()}>Click Here!</a>
                  </Resend>
                </Form.Item>

                <Form.Item
                  label="Enter code"
                  name="code"
                  rules={[
                    {
                      required: true,
                      message: "Please enter OTP sent to your mobile!",
                    },
                  ]}
                >
                  <Input style={{ width: "100%" }} />
                </Form.Item>
                <Form.Item
                  label="Enter Password"
                  name="password"
                  rules={[{ message: "Please enter your password!" }]}
                >
                  <Input.Password />
                </Form.Item>
                <Form.Item
                  name="interested"
                  rules={[
                    { required: true, message: "Please select any one!" },
                  ]}
                >
                  <Radio.Group onChange={onChange} value={value}>
                    <label>Are you interested in this product ?</label>
                    <Radio value={"yes"}>Yes</Radio>
                    <Radio value={"no"}>No</Radio>
                    <Radio value={"maybe"}>May be</Radio>
                  </Radio.Group>
                </Form.Item>
                <Form.Item>
                  <Button
                    type="primary"
                    htmlType="submit"
                    block
                    loading={isSaving}
                    className="primary_btn"
                  >
                    Submit
                  </Button>
                </Form.Item>
              </Form>
            )}
            <Or>
              or
            </Or>
            <LoginOtp>
              Already has an account ?
              <Link to="/login">
                Click Here
              </Link>
            </LoginOtp>
          </RegisterRight>
        </RegisterAlign>
      </RegisterSection>
    </React.Fragment>
  );
};

export default Register;

const RegisterSection = styled.section`
  display: flex;
  width: 100%;
  position: relative;
  align-items: center;
  justify-content: center;
  @media screen and (max-width:580px) {
    padding: 0 20px;
  }
  .primary_btn {
    background: ${styles?.colorapi};
    border: 1px solid ${styles?.colorapi};
  }
`;
const RegisterAlign = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 450px;
  flex-wrap: wrap;
  box-shadow: 0 0 40px rgb(0 0 0 / 9%);
  border-radius: 5px;
  margin: 70px 0;
  @media screen and (max-width:580px) {
    width: 100%;
    margin: 40px 0;
  }
`;

const RegisterRight = styled.div`
  display: inline-block;
  width: 100%;
  position: relative;
  padding: 40px 35px;
  input {
    width: 100%;
    padding: 8px 14px;
  }
  input[type="password"] {
    width: 100%;
    padding: 4px 0px;
  }
  .ant-space {
    width: 100%;
    margin: 0 0 10px;
  }
  button {
    padding: 7px 20px;
    height: auto;
    font-size:15px;
    background: ${styles.background};
    border: 1px solid ${styles.background};
  }
  .ant-row.ant-form-item-row {
    display: flex;
    flex-direction: column;
  }

  .ant-form label {
    width: 100%;
    display: inline-block;
    text-align: left;
    height:auto;
    margin:0 0 8px;
  }

  .ant-radio-wrapper.ant-radio-wrapper-in-form-item {
    display:flex;
    flex-wrap:wrap;
    gap:0px;
    float:left;
    width:fit-content;
    margin:0 10px 0 0;
  }

  @media screen and (max-width:580px) {
    padding: 30px 25px;
  }

`;

const Title = styled.div`
font-size: 25px;
color: #000;
font-weight: 700;
width: 100%;
margin: 0 0 20px;
text-transform: uppercase;
`;

const Resend = styled.div`
  display:inline-block;
  width:100%;
  position:relative;
  margin:8px 0 0 0;
`;

const Or = styled.div`
width: 100%;
font-size: 15px;
text-align: center;
font-style: italic;
`;
const LoginOtp = styled.div`
font-size: 14px;
line-height: 1.5;
margin: 10px 0 0 0;
width: 100%;
display: flex;
text-align: center;
flex-wrap: wrap;
gap: 10px;
align-items: center;
justify-content: center;
`;