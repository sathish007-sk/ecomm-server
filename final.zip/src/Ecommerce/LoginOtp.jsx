import React, { useEffect, useState } from "react";
import { message, Button, Form, Input } from "antd";
import styled from "styled-components";
import { Link, useNavigate } from "react-router-dom";
import { styles } from "../Api/Data";
import API from "../Api/ApiService";
import { useDispatch, useSelector } from "react-redux";

const Register = () => {
    const [form] = Form.useForm();
    const [form1] = Form.useForm();
    const [isSaving, setSaving] = useState(false);
    const [stage, setStage] = useState(1);
    const [mobileNo, setMobileNo] = useState("");
    const api = new API();
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const loginTrue = useSelector((state) => state.user.currentUser?.token);


    useEffect(() => {
      if (!loginTrue && loginTrue != "") {
      } else {
        navigate('/')
      }
    }, [loginTrue])

    const loginOtpMobile = (values) => {
        setSaving(true);
        setMobileNo(values.user_name);
        api.sentOtp(values).then((res) => {
            setSaving(false);
            let data = res.data;
            if (data.success === true) {
                setStage(2);
                message.success('OTP send successfully');

            } else {
                message.error(data.message);
                setSaving(false);
            }
        }).catch((error) => {
            setSaving(false);
            message.error('Something went wrong!');
        })
    };

    const otpForm = (values) => {
        values['mobile_no'] = mobileNo;
        setSaving(true);
        api.loginOtp(dispatch, values, setSaving(false)).then((res) => {
            let data = res.data;
            setSaving(false);
            if (data.success === true) {
                form1.resetFields();
                message.success(data.message);
                navigate('/')
            } else {
                setSaving(false);
                message.error(data.message);
            }
        }).catch((err) => {
            setSaving(false);
            message.error('Something went wrong!');
        })
    };

    const submitForm = () => {
        let mobile_no = mobileNo;
        loginOtpMobile({ user_name: mobile_no });
    }

    return (
        <React.Fragment>
            <RegisterSection>
                <RegisterAlign>
                    <RegisterRight>
                        <Title>Login with OTP</Title>
                        {stage == 1 ? (
                            <Form form={form} name="Forgot_Password" onFinish={loginOtpMobile}>
                                <Form.Item
                                    label="Enter Mobile number"
                                    name="user_name"

                                    rules={[
                                        {
                                            required: true,
                                            message: "Please enter your Mobile number!",
                                        },
                                    ]}
                                >
                                    <Input />
                                </Form.Item>
                                <Form.Item>
                                    <Button
                                        type="primary"
                                        htmlType="submit"
                                        block
                                        loading={isSaving}
                                        className="primary_btn"
                                    >
                                        Continue
                                    </Button>
                                </Form.Item>
                            </Form>
                        ) : (
                            <Form
                                form={form1}
                                onFinish={otpForm}
                                name="Forgot_Form"
                            >
                                <Form.Item
                                    label="Enter Mobile number"
                                    name="mobile_no"
                                    rules={[
                                        {
                                            message: "Please enter your Mobile number!",
                                        },
                                    ]}
                                >
                                    <Input readOnly value={mobileNo} />
                                    <Resend>
                                        Didn't receive OTP?{" "}
                                        <a onClick={() => submitForm()}>Click Here!</a>
                                    </Resend>
                                </Form.Item>

                                <Form.Item
                                    label="Enter code"
                                    name="code"
                                    rules={[
                                        {
                                            required: true,
                                            message: "Please enter OTP sent to your mobile!",
                                        },
                                    ]}
                                >
                                    <Input style={{ width: "100%" }} />
                                </Form.Item>
                                <br />
                                <Form.Item>
                                    <Button
                                        type="primary"
                                        htmlType="submit"
                                        block
                                        loading={isSaving}
                                    >
                                        Submit
                                    </Button>
                                </Form.Item>
                            </Form>

                        )}
                        <Or>
                            or
                        </Or>
                        <LoginOtp>
                            Back to Login
                            <Link to="/login">
                                Click Here
                            </Link>
                        </LoginOtp>
                    </RegisterRight>
                </RegisterAlign>
            </RegisterSection>
        </React.Fragment>
    );
};

export default Register;

const RegisterSection = styled.section`
  display: flex;
  width: 100%;
  position: relative;
  align-items: center;
  justify-content: center;
  @media screen and (max-width:580px) {
    padding: 0 20px;
  }
  .primary_btn {
    background: ${styles?.colorapi};
    border: 1px solid ${styles?.colorapi};
  }
`;
const RegisterAlign = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 450px;
  flex-wrap: wrap;
  box-shadow: 0 0 40px rgb(0 0 0 / 9%);
  border-radius: 5px;
  margin: 70px 0;

  @media screen and (max-width:580px) {
    width: 100%;
    margin: 40px 0;
  }

`;

const RegisterRight = styled.div`
  display: inline-block;
  width: 100%;
  position: relative;
  padding: 40px 35px;
  input {
    width: 100%;
    padding: 8px 14px;
  }
  input[type="password"] {
    width: 100%;
    padding: 4px 0px;
  }
  .ant-space {
    width: 100%;
    margin: 0 0 10px;
  }
  button {
    padding: 7px 20px;
    height: auto;
    font-size:15px;
    background: ${styles.background};
    border: 1px solid ${styles.background};
  }
  .ant-row.ant-form-item-row {
    display: flex;
    flex-direction: column;
  }

  .ant-form label {
    width: 100%;
    display: inline-block;
    text-align: left;
    height:auto;
    margin:0 0 8px;
  }

  .ant-radio-wrapper.ant-radio-wrapper-in-form-item {
    display:flex;
    flex-wrap:wrap;
    gap:0px;
    float:left;
    width:fit-content;
    margin:0 10px 0 0;
  }
  @media screen and (max-width:580px) {
    padding: 30px 25px;
  }

`;

const Title = styled.div`
font-size: 25px;
color: #000;
font-weight: 700;
width: 100%;
margin: 0 0 20px;
text-transform: uppercase;
`;

const Resend = styled.div`
  display:inline-block;
  width:100%;
  position:relative;
  margin:8px 0 0 0;
`;

const Or = styled.div`
width: 100%;
font-size: 15px;
text-align: center;
font-style: italic;
`;
const LoginOtp = styled.div`
font-size: 14px;
line-height: 1.5;
margin: 10px 0 0 0;
width: 100%;
display: flex;
text-align: center;
flex-wrap: wrap;
gap: 10px;
align-items: center;
justify-content: center;
`;