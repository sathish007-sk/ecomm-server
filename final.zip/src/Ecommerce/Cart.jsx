import React, { useState, useEffect } from 'react'
import { connect, useSelector } from 'react-redux'
import styled from "styled-components";
import { getCartList } from '../Store/cartTypes'
import API from "../Api/ApiService";
import { styles } from "./../Api/Data";
import { DeleteOutlined } from '@ant-design/icons';
import { Link, useLocation } from 'react-router-dom';
import { Button, Empty, message, Popconfirm, Skeleton } from "antd";
const user = JSON.parse(localStorage.getItem("persist:root"))?.company;
const colorCustom = user && JSON.parse(user).setColor;

const Cart = (props) => {
  const location = useLocation();
  const url = location.pathname.split("/")[1]
  const currentURL = window.location.toString().includes("cart");
  const api = new API();
  const data = useSelector((state) => state.cart.products);
  const [refresh, setRefresh] = useState(false);
  const [isLoading, setLoading] = useState(false);
  const [data1, setData] = useState([]);
  const [delivery, setdelivery] = useState([]);


  var timeOut;
  var address;
  var district;
  var address_line_2;
  let val2;


  useEffect(() => {
      props.getCartList();

  }, [refresh]);
  const reloadData = () => {
      setRefresh(!refresh);
  };

 
  const incre_ment = (ind) => {
     let obj = data[ind];
      obj.quantity += 1;
      update(ind, obj.quantity);
  };
  const dec_ment = (ind) => {
      let obj = data[ind];
      if (obj.quantity > 1) {
          obj.quantity -= 1;
      }
      update(ind, obj.quantity);
  };

  const update = (ind, quantity) => {
      let obj = data[ind];
      obj.quantity = quantity;
      if (timeOut) clearTimeout(timeOut);
      timeOut = setTimeout(() => {
          setLoading(true)
          api.updateCart(obj._id, quantity, delivery).then((res) => {
            
              let data = res.data;
              if (data.success === true) {
                  props.getCartList();
                  
              } else {
                  message.error("Something went wrong!")
              }
              setLoading(false)
          }).catch((err) => { setLoading(false) })
      }, 500);
  }
console.log(delivery)
  const deleteItem = (id) => {
      setLoading(true);
      api.deleteCart(id).then((res) => {
          let data = res.data;
          if (data.success === true) {
           
              reloadData();
              message.success("Successfully Deleted")
              setRefresh(!refresh);
          } else {
              message.error("Something went wrong!")
          }
          setLoading(false);
      }).catch((err) => { setLoading(false); })
  }

  useEffect(() => {
      addressList();

  }, [delivery]);

  const addressList = () => {
      setLoading(true);
      api.addressList().then((res) => {
        const trueadd = res.data?.find((item)=>{
            return item?.delivery===true;
        })
        address = res.data;
          district = trueadd.district;
          address_line_2 = trueadd.city;
            dlchrg()
          setLoading(false);
          setData(address)
      }).catch((err) => { setLoading(false) })
  }

  const dlchrg = () => {
      
      setLoading(true);
      let data = { address: address_line_2, weight: val2 };
      
      api.singleProductDlchrg(data).then((res) => {
          setdelivery(res.data)
         
          setLoading(false);
      }).catch((err) => { setLoading(false) })
  }

  
     
    let tot = data.reduce(

      (carry, ele) => {
          val2 = carry.total_weight += ele.packing_detail * ele.quantity;
          ++carry.total_item;
          carry.total_mrp += ele.mrp * ele.quantity;
          carry.total_discount += (ele.mrp - ele.sp) * ele.quantity;
          carry.total_delivery += delivery * ele.quantity;
          carry.total_amount_t += ele.sp * ele.quantity;
          carry.total_amount += (ele.sp + delivery) * ele.quantity;
          return carry;
      },
      {
          total_item: 0,
          total_amount: 0,
          total_amount_t: 0,
          total_discount: 0,
          total_mrp: 0,
          total_delivery: 0,
          total_weight: 0,
      }
  );

  const total = [
      {
          title: `Price (${tot.total_item} ${tot.total_item > 1 ? "items" : "item"
              })`,
          value: tot?.total_mrp.toLocaleString("en-IN", {
              maximumFractionDigits: 0,
              style: "currency",
              currency: "INR",
          }),
      },
      {
          title: "Discount",
          value: tot?.total_discount.toLocaleString("en-IN", {
              maximumFractionDigits: 0,
              style: "currency",
              currency: "INR",
          }),
      },
      // {
      //     title: "Delivery Charges",
      //     value: tot?.total_delivery.toLocaleString("en-IN", {
      //         maximumFractionDigits: 0,
      //         style: "currency",
      //         currency: "INR",
      //     }),
          
      // },
      
      {
          title: "Total Amount",
          value:
              currentURL == true
                  ? tot?.total_amount_t.toLocaleString("en-IN", {
                      maximumFractionDigits: 0,
                      style: "currency",
                      currency: "INR",
                  })
                  : tot?.total_amount.toLocaleString("en-IN", {
                      maximumFractionDigits: 0,
                      style: "currency",
                      currency: "INR",
                  }),
      },
  ];






  return (
    <React.Fragment>
      <CartSection>
        <Wrapper>
          {
            url === "checkout" ? "" :
              <H2>My Cart</H2>
          }

          <CartAlign>
          {data.length < 1 ?
                    <Empty className="empty_cart" />
                    :

                    <>
          <CartTop>
               
                        <CartList1>
                            <CartItems>
                                <CartTable>
                                    <CartThead>

                                        <Tr>
                                            <Th>S No</Th>
                                            <Th>Product Image</Th>
                                            <Th>Product Name</Th>
                                            <Th>Price</Th>
                                            <Th>Quantity</Th>
                                            {/* <Th>Sub Total</Th> */}
                                            <Th>Action</Th>
                                        </Tr>

                                        <tbody>
                                            {data?.map((item, index) => (
                                                <Tr key={item._id}>
                                                    <Td>{index + 1}</Td>
                                                    

                                                    <Td>
                                                        <Image
                                                            src={item.images ? api.rootUrl + item.images?.thumbnail : `${styles.default}`}
                                                        />
                                                    </Td>
                                                    <Td>{item.description}</Td>
                                                    <Td>
                                                        {styles.currency}
                                                        {Number(item.sp).toFixed(0)}
                                                    </Td>
                                                    <Td>
                                                        <ProductQuantity>
                                                            <Button onClick={() => dec_ment(index)}>-</Button>
                                                            <ProductInput
                                                                type="text"
                                                                value={item.quantity}
                                                                readOnly
                                                                min={1}
                                                                max={10}
                                                                onChange={(val) => update(index, val)}
                                                            />
                                                            <Button onClick={() => incre_ment(index)}>+</Button>
                                                        </ProductQuantity>
                                                    </Td>
                                                    {/* <Td>
                                                        <b>
                                                            {item.quantity * Number(item.sp).toFixed(0)}</b>
                                                    </Td> */}
                                                    <Td style={{ color: "red", cursor: "pointer", fontSize: "22px", fontWeight: "700" }}>
                                                        <Popconfirm
                                                            title="Are you sure to delete this product?"
                                                            onConfirm={() => {
                                                                deleteItem(item._id);
                                                            }}
                                                            okText="Delete"
                                                            cancelText="Cancel"
                                                        >
                                                            <DeleteOutlined />
                                                        </Popconfirm>
                                                    </Td>
                                                </Tr>
                                            ))}
                                        </tbody>
                                    </CartThead>
                                </CartTable>
                            </CartItems>
                        </CartList1>
                    
            </CartTop>
            <CartBottom 
            className={
                url==="checkout" ? "checkoutWidth" : ""
            }
            >
                <H2>Grand Totals</H2>
                <CartTable>
                    {
                        total?.map((item) => {
                            return (
                                <Tr key={item.title}>
                                    <Th>{item.title}</Th>
                                    <Td style={{ textAlign: "right" }}>{item.value}</Td>
                                </Tr>
                            )
                        })
                    }
                </CartTable>
                {
                    url==="checkout" ? "" : <Link to="/checkout"><CheckOut>Proceed to checkout</CheckOut></Link>
                }
                
            </CartBottom>
            </>
          }
            {/* <CartList />
            <PriceList /> */}
          </CartAlign>
        </Wrapper>
      </CartSection>
    </React.Fragment>
  );
};


const mapStateToProps = (state) => ({
  products: state.cart.products,
})
export default connect(mapStateToProps, { getCartList })(Cart);



const H2 = styled.div`
font-size: ${styles.h2};
 color: ${colorCustom?.color};
 margin: 0 0 30px;
 font-weight: 600;
 `
const CartSection = styled.section`
 margin: 60px 0 60px 0;
 width: 100%;
 position: relative;
 min-height: 350px;

 .empty_cart {
   border: 1px solid ${styles.light};
   padding: 60px 0;
 }
`;
const Wrapper = styled.div`
 max-width: 1200px;
 padding: 0 10px;
 margin: auto;
`;
const CartAlign = styled.div`
 width: 100%;
 display: inline-block;
 position: relative;
`;
const Tr = styled.tr`
 padding: 15px;
 border-bottom: 1px solid ${styles.light};
 &:last-child {
   border-bottom: 0;
 }
 @media screen and (max-width:768px) {
   padding: 10px;
   td:first-child, th:first-child {
     display: none;
   }
   td,th {
     padding: 8px;
     font-size: 14px;
   }
 }
 @media screen and (max-width:768px) {
   td,th {
     font-size: 12px;
   }
   td:last-child {
     font-size: 16px !important;
   }
 }
`;
const Th = styled.th`
 border-bottom: 1px solid ${styles.light};
 padding: 15px;
 font-size: 16px;
`;
const Td = styled.td`
 padding: 10px 10px;
 vertical-align: middle;
`;
const Image = styled.img`
 max-width: 100%;
 height: 50px;
 border: 1px solid ${styles.light};
 margin: auto;
`;


const ProductQuantity = styled.div`
 display: flex;
 margin: 8px auto;
 width: fit-content;
 button {
   font-size: 20px;
   font-weight: 700;
   display: flex;
   align-items: center;
   justify-content: center;
   height: 35px;
   padding: 0 9px;
 }
 @media screen and (max-width:768px) {
   button {
     height: 28px;
     font-size: 14px;
     padding: 0 5px;
   }
 }
`;
const ProductInput = styled.input`
 border: 0;
 border-top: 1px solid #d9d9d9;
 border-bottom: 1px solid #d9d9d9;
 text-align: center;
 outline: none;
 width: 40px;
 @media screen and (max-width:768px) {
     height: 28px;
     width: 28px;
 }
`;

const CartTop = styled.div`
 width: 100%;
 position: relative;
 display: inline-block;
`;

const CartList1 = styled.div`
 width: 100%;
 display: inline-block;
`;
const CartItems = styled.div`
 width: 100%;
 display: inline-block;
`;
const CartTable = styled.table`
 width: 100%;
 display: table;
 text-align: center;
 border: 1px solid ${styles.light};
 border-radius: 5px;
`;
const CartThead = styled.thead`
 width: 100%;
 display: table;
 text-align: center;
 border: 0px solid ${styles.light};
`;




const CartBottom = styled.div`
 margin: 55px 0 0 0;
 width: 35%;
 position: relative;
 display: block;
 float: right;
 table {
   text-align: left;
 }
 @media screen and (max-width:768px){
   width: 100%;
 }
 @media screen and (max-width:768px) {
   td:first-child, th:first-child {
     display: block;
   }
 }
`;

const CheckOut = styled.button`
 background: ${colorCustom?.color};
 width: 100%;
 margin: 18px 0 0 0;
 padding: 14px 15px;
 border-radius: 5px;
 outline: none;
 font-size: 18px;
 color: #fff;
 border: 0;
 font-weight: 600;
 cursor: pointer;
`;