import React,{useEffect, useState} from 'react'
import styled from 'styled-components';
import { styles } from './../Api/Data';
import { message } from 'antd';
import { connect, useSelector } from 'react-redux'
import { getCartList } from '../Store/cartTypes'
import {useLocation} from "react-router-dom"
import API from '../Api/ApiService';

const Payment = (props) => {
  const api = new API()
  const data = useSelector((state) => state.cart.products);
  const location = useLocation();
  const [refresh, setRefresh] = useState(false);
  const [isLoading, setLoading] = useState(false);
  const [delivery, setdelivery] = useState([]);
  const url = location.pathname.split("/")[1]

  var timeOut;
  var address;
  var district;
  var address_line_2;
  let val2;


  useEffect(() => {
    props.getCartList();

  }, [refresh]);
  const reloadData = () => {
    setRefresh(!refresh);
  };

  useEffect(() => {
    addressList();
  }, [delivery]);

  const addressList = () => {
    setLoading(true);
    api.addressList().then((res) => {
      address = res.data;
      district = address[0].district;
      address_line_2 = address[0].city;
      dlchrg()
      setLoading(false);
    }).catch((err) => { setLoading(false) })
  }

  const dlchrg = () => {
    setLoading(true);
    let data = { address_line_2: [address_line_2], weight: [val2] };
    api.singleProductDlchrg(data).then((res) => {
      setLoading(false)
      setdelivery(res.data)
    }).catch((err) => { setLoading(false) })
  }

  let tot = data.reduce(
    (carry, ele) => {
      val2 = carry.total_weight += ele.packing_detail * ele.quantity;
      carry.total_delivery += delivery;
      return carry;
    },
    { total_delivery: 0, total_weight: 0 }
  );

  let tot1 = data?.reduce(
    (carry, ele) => {
      val2 = carry.total_weight += ele.packing_detail * ele.quantity;
      ++carry.total_item;
      carry.total_mrp += ele.mrp * ele.quantity;
      carry.total_discount += (ele.mrp - ele.sp) * ele.quantity;
      carry.total_delivery += ele.delivery * ele.quantity;
      carry.total_amount_t += ele.sp * ele.quantity;
      carry.total_amount += (ele.sp + ele.delivery) * ele.quantity;
      return carry;
    },
    {
      total_item: 0,
      total_amount: 0,
      total_amount_t: 0,
      total_discount: 0,
      total_mrp: 0,
      total_delivery: 0,
      total_weight: 0,
    }
  );

  const total = [
    {
      title: `Price (${tot1.total_item} ${tot1.total_item > 1 ? "items" : "item"
        })`,
      value: tot1.total_mrp,
    },
    {
      title: "Discount",
      value: tot1.total_discount,
    },
    {
      title: "Delivery Charges",
      value: tot1.total_delivery,
    },
    {
      title: "Total Amount",
      value: tot1.total_amount_t+tot1.total_delivery,
    }
  ];



  return (
    <React.Fragment>
      <PaymentSection>
        <CartBottom>
          <CartTable>
            {
              total?.map((item)=>{
                return (
                  <Tr>
                    <Th>{item.title}</Th>
                    <Td style={{ textAlign: "right" }}>{styles.currency}{Number(item.value).toFixed(0)}</Td>
                  </Tr>
                )
              })
            }
            {/* <Tr>
              <Th>Test Product</Th>
              <Td>₹1,350</Td>
            </Tr>
            <Tr>
              <Th>Subtotal</Th>
              <Td>₹1,350</Td>
            </Tr>
            <Tr>
              <Th>Shipping</Th>
              <Td>Free shipping Shipping to Tamil Nadu.</Td>
            </Tr>
            <Tr>
              <Th>Total</Th>
              <Td>₹1,350</Td>
            </Tr> */}
            <Tr colspan="2">
              <Td className="Last" colSpan="2">
                Your personal data will be used to process your order, support
                your experience throughout this website, and for other purposes
                described in our privacy policy.
              </Td>
            </Tr>
          </CartTable>

          <CheckOut onClick={() => message.success("Processing complete!")}>
            Place Order
          </CheckOut>
        </CartBottom>
      </PaymentSection>
    </React.Fragment>
  );
}

const mapStateToProps = (state) => ({
  products: state.cart.products,
})

export default connect(mapStateToProps, { getCartList })(Payment);
 

const PaymentSection = styled.section`
width:100%;
display: inline-block;
margin: 10px 0 40px 0;
.Last {
  text-align: left;
}
`;
const CartTable = styled.table`
  width: 100%;
  display: table;
  text-align: center;
  border: 1px solid ${styles.light};
  border-radius: 5px;
`;
const H2 = styled.h2`
  font-size: 20;
  color: ${styles.color};
  font-weight: 600;
  margin: 0 0 20px;
`;
const Tr = styled.tr`
  padding: 15px;
  border-bottom: 1px solid ${styles.light};
`;
const Th = styled.th`
  border-bottom: 1px solid ${styles.light};
  padding: 15px;
  font-size: 16px;
`;
const Td = styled.td`
  padding: 15px;
  text-align: right;
`;
const CartBottom = styled.div`
  margin: 55px auto 0 auto;
  width: 55%;
  position: relative;
  display: block;
  table {
    text-align: left;
  }
`;

const CheckOut = styled.button`
  background: ${styles.background};
  width: 100%;
  margin: 18px 0 0 0;
  padding: 14px 15px;
  border-radius: 5px;
  outline: none;
  font-size: 18px;
  color: #fff;
  border: 0;
  font-weight: 600;
`;

const P = styled.p`
margin: 15px 0 0 0;
font-size: 14px;
`;