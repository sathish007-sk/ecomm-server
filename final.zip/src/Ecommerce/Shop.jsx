import React, { useEffect, useState } from "react";
import styled from "styled-components";
import { message, Breadcrumb, Pagination, Slider, Radio, Divider, Form, Select, Empty } from "antd";
import { HomeOutlined } from "@ant-design/icons";
import { styles } from "./../Api/Data";
import { Menu, Skeleton } from "antd"
import ProductGridView from "./ProductGridView";
import API from "../Api/ApiService";
import { CaretDownOutlined } from '@ant-design/icons';
import { Link, useLocation, useParams } from "react-router-dom";
import { Helmet } from "react-helmet";
import { useSelector } from "react-redux";
const user = JSON.parse(localStorage.getItem("persist:root"))?.company;
const colorCustom = user && JSON.parse(user).setColor;


const { Option } = Select;
const Shop = () => {
  const location = useLocation();
  const api = new API();
  const company = useSelector((state) => state.company?.value);
  const paramsUrl = useParams();
  const url = location.pathname.split("/")[1]
  const [loading, setLoading] = useState(false)
  const params = new URLSearchParams(location.search);
  const str = params.get("q");
  const [category, setCategory] = useState([]);
  const query = url.toLowerCase().replace(/ /g, '-').replace(/[^\w-]+/g, '');
  const [products, setProducts] = useState([]);
  const [filteredProduct, setFilterProduct] = useState([]);
  const [pageSize, setpageSize] = useState(8);
  const [currentPage, setCurrentPage] = useState(1);
  const [pagedList, setPagedList] = useState([]);
  const [cats, setCats] = useState([]);
  const [active, setActive] = useState([]);
  const [subCats, setSubCats] = useState([]);

  const curl = window.location.toString().includes("search")



  useEffect(() => {
    loadAllProduct();

  }, [paramsUrl, pageSize, currentPage])


  const loadAllProduct = () => {
    setLoading(true)
    api.filter().then((res) => {

      let arr = res.data;

      let result = arr.filter((value, index, self) =>
        index === self.findIndex((t) => (
          t.model === value.model && t.model === value.model
        ))
      )
      setProducts(result)
      loadAllCategory()
      setLoading(false)
    }).catch((err) => { setLoading(false) })
  }

  const loadAllCategory = () => {
    setLoading(true)
    api.allCategory().then((res) => {
      if (res.status === 200) {
        setCats(res.data)
        setCategory(
          res.data?.filter(e =>
            e.parent == null
          )
        )
        setLoading(false)
      }
    }).catch((err) => { setLoading(false) })
  }



  useEffect(() => {
    let limit = pageSize;
    let start = (currentPage - 1) * limit;
    let end = start + limit;
    let obj = filteredProduct?.slice(start, end);
    setPagedList(obj);
  }, [filteredProduct, pageSize, currentPage])




  const pageChange = (page) => {
    setCurrentPage(page);
  };
  const onPageSizeChange = (current, size) => {
    setpageSize(size);
  };





  var responsefilter = 0;
  function filterByCategory(item) {
    if (item.category) {
      for (let i = 0; i < item.category.length; i++) {
        if (item.category[i].category_name.toLowerCase().replace(/ /g, '-')
          .replace(/[^\w-]+/g, '') == query && item.publish === true && item.status === true) {
          return true;
        }
      }
    }
    responsefilter++;
    return false;
  }


  useEffect(() => {
    query &&
    

      setFilterProduct(
        products.filter(filterByCategory)
      )

    str &&
    serachResult()
  }, [products, query, str])


  

  const serachResult = () => {
    const res = products?.filter((item)=>{
      return item?.description?.toLowerCase().replace(/ /g, '-')
      .replace(/[^\w-]+/g, '') === str;
    })
    setFilterProduct(res)
  }





  const myRange = [...filteredProduct];
  const min = Math.min(...myRange.map((item) => item.sp));
  const max = Math.max(...myRange.map((item) => item.sp));


  const handleRange = (e) => {
    const myRangeFilter = [...filteredProduct];
    const currentRange = myRangeFilter.filter(function (res) {
      return res.sp >= e[0] && res.sp <= e[1];
    });
    setPagedList(currentRange)
  }


  const onChangeRating = () => {

  }

  function capitalizeFirstLetter(string) {
    return string.charAt(0).toUpperCase() + string.slice(1);
  }



  const sorting = (e) => {
    console.log(e)
    let pdt = [...filteredProduct];
    switch (e) {
      case 1:
        pdt.sort((a, b) => b.sp - a.sp);
        break;
      case 2:
        pdt.sort((a, b) => a.sp - b.sp);
        break;
      case 4:
        pdt.sort((a, b) => b.discount - a.discount);
        break;
      default:
        pdt.sort((a, b) => a.sp - b.sp);
        break;
    }
    setPagedList(pdt);
  }

  // console.log(subCats)
  const items = [
    ...category?.map((e) => {
      return (
        {
          label: (
            <Link to={"/" + e.category_name.toLowerCase().replace(/ /g, '-')
              .replace(/[^\w-]+/g, '')} >
              {e.category_name}
            </Link>
          ),
          key: e._id,
          children: [

            ...subCats.map((sub, key) => ({
              label: (
                <Link to={`/${sub.category_name.toLowerCase().replace(/ /g, '-')
                  .replace(/[^\w-]+/g, '')}`}>
                  {sub.category_name}
                </Link>
              ),
              key: sub._id + 2,
            })),

          ],


        }
      )
    })




  ];

  const mainCat1 = category;
  const resss1 = mainCat1?.slice(0, 1).map((e) => {
    return (
      e._id
    )
  })



  const [openKeys, setOpenKeys] = useState([]);
  // console.log(resss1)
  const onOpenChange = (keys) => {


    const tesProduct = category.filter((e) => e.category_name?.toLowerCase().replace(/ /g, '-')
      .replace(/[^\w-]+/g, '') === query)
    const lev = tesProduct[0]?._id;
    setActive(lev)
    const tesProduct1 = cats.filter((e) => e.parent === keys[keys.length - 1])
    setSubCats(tesProduct1)


    const latestOpenKey = keys.find((key) => openKeys.indexOf(key) === -1);
    if (rootSubmenuKeys.indexOf(latestOpenKey) === -1) {
      setOpenKeys(keys);
    } else {
      setOpenKeys(latestOpenKey ? [latestOpenKey] : []);
    }
  };
  // submenu keys of first level


  const mainCat = category;

  const resss = mainCat.map((e) => {
    return (
      e._id
    )
  })


  const rootSubmenuKeys = resss;





  return (
    <React.Fragment>
      <Helmet>
        <title>{capitalizeFirstLetter(capitalizeFirstLetter(url.replace("-", " ")).replace("-", " ").replace("-", " ").replace("-", " ").replace("-", " ").replace("-", " ").replace("-", " ").replace("-", " ").replace("-", " "))}  {company ? "| " + company?.company_name : ""}</title>
        <meta
          name="description"
          content={capitalizeFirstLetter(capitalizeFirstLetter(url.replace("-", " ")).replace("-", " ").replace("-", " ").replace("-", " ").replace("-", " ").replace("-", " ").replace("-", " ").replace("-", " ").replace("-", " "))}
        />
        <meta
          name="keywords"
          content={capitalizeFirstLetter(capitalizeFirstLetter(url.replace("-", " ")).replace("-", " ").replace("-", " ").replace("-", " ").replace("-", " ").replace("-", " ").replace("-", " ").replace("-", " ").replace("-", " "))}
        />
        <link
          rel="canonical"
          href={window.location.href}
        />
        <meta
          property="og:site_name"
          content={'"' + company ? company?.company_name : "" + '"'}
        />
        <meta property="og:locale" content="en_US" />
        <meta
          property="og:title"
          content={`${capitalizeFirstLetter(capitalizeFirstLetter(url.replace("-", " ")).replace("-", " ").replace("-", " ").replace("-", " ").replace("-", " ").replace("-", " ").replace("-", " ").replace("-", " ").replace("-", " "))}${company ? " | " + company?.company_name : ""}`}
        />
        <meta property="og:type" content="ecommerce" />
        <meta
          property="og:url"
          content={window.location.href}
        />
        <meta
          property="og:image"
          content={company ? company?.logo : ""}
        />
        <meta
          property="og:description"
          content={`${capitalizeFirstLetter(capitalizeFirstLetter(url.replace("-", " ")).replace("-", " ").replace("-", " ").replace("-", " ").replace("-", " ").replace("-", " ").replace("-", " ").replace("-", " ").replace("-", " "))}${company ? " | " + company?.company_name : ""}`}
        />
        <meta name="twitter:card" content="summary_large_image" />
        <meta
          name="twitter:site"
          content={'"' + company ? company?.website : "" + '"'}
        />
        <meta
          name="twitter:title"
          content={`${capitalizeFirstLetter(capitalizeFirstLetter(url.replace("-", " ")).replace("-", " ").replace("-", " ").replace("-", " ").replace("-", " ").replace("-", " ").replace("-", " ").replace("-", " ").replace("-", " "))}${company ? " | " + company?.company_name : ""}`}
        />
        <meta
          name="twitter:description"
          content={`${capitalizeFirstLetter(capitalizeFirstLetter(url.replace("-", " ")).replace("-", " ").replace("-", " ").replace("-", " ").replace("-", " ").replace("-", " ").replace("-", " ").replace("-", " ").replace("-", " "))}${company ? " | " + company?.company_name : ""}`}
        />
        <meta
          name="twitter:image"
          content={company ? company?.logo : ""}
        />
        <meta name="robots" content="index,follow" />
        <meta
          name="author"
          content={'"' + company ? company?.company_name : "" + '"'}
        />
      </Helmet>

      <ShopSection>
        <Wrapper>
          {loading === true ?
            <Skeleton active />
            : <>
              <ShopTop>
                <ShopTitle>{capitalizeFirstLetter(capitalizeFirstLetter(url.replace("-", " ")).replace("-", " ").replace("-", " ").replace("-", " ").replace("-", " ").replace("-", " ").replace("-", " ").replace("-", " ").replace("-", " "))}</ShopTitle>
                <Breadcrumb>
                  <Breadcrumb.Item>
                    <Link to="/">
                      <HomeOutlined />
                    </Link>
                  </Breadcrumb.Item>
                  <Breadcrumb.Item >
                    <Link to={`/${query}`}>
                      <Span>{capitalizeFirstLetter(capitalizeFirstLetter(url.replace("-", " ")).replace("-", " ").replace("-", " ").replace("-", " ").replace("-", " ").replace("-", " ").replace("-", " ").replace("-", " ").replace("-", " "))}</Span>
                    </Link>
                  </Breadcrumb.Item>
                  {/* <Breadcrumb.Item>Page Name</Breadcrumb.Item> */}
                </Breadcrumb>
              </ShopTop>
              <ShopAlign>
                <ShopLeft>
                  <SidebarSection>
                    <CategoryList>
                      <Title>Category</Title>
                      <Menu
                        mode="inline"
                        openKeys={openKeys}
                        onOpenChange={onOpenChange}
                        style={{
                          width: "100%",
                        }}
                        items={items}
                      />
                    </CategoryList>
                    <Divider />
                    <ProductFilter>
                      <Title>Filter by Price</Title>
                      <Slider
                        range
                        min={min}
                        max={max}
                        defaultValue={[min, max]}
                        onChange={handleRange}
                      />
                    </ProductFilter>

                    <Divider />
                    <ColorFilter>
                      <Title>Filter by Rating</Title>
                      <Radio.Group onChange={onChangeRating}>
                        <Radio value={1}>1 Star</Radio>
                        <Radio value={2}>2 Star</Radio>
                        <Radio value={3}>3 Star</Radio>
                        <Radio value={4}>4 Star</Radio>
                        <Radio value={5}>5 Star</Radio>
                      </Radio.Group>
                    </ColorFilter>
                  </SidebarSection>
                </ShopLeft>
                <ShopRight>
                  <FilterSidebarSection>
                    <FilterSidebarLeft>Showing of {filteredProduct?.length} results</FilterSidebarLeft>
                    <FilterSidebarRight>
                      Sort By:{" "}
                      <Select
                        placeholder="Default Sort"
                        style={{ width: "150px" }}
                        size="small"
                        onChange={sorting}
                      >
                        <Option value={1}>Price High to Low</Option>
                        <Option value={2}>Price Low to High</Option>
                        <Option value={3}>Rating</Option>
                        <Option value={4}>Discount</Option>
                      </Select>
                    </FilterSidebarRight>
                  </FilterSidebarSection>
                  <ProductListing>
                    <ProductGridView filteredProduct={pagedList} />
                  </ProductListing>
                  {filteredProduct.length > 0 ? (
                    <PageAlign>
                      <Pagination
                        total={filteredProduct?.length}
                        onChange={pageChange}
                        size="small"
                        current={currentPage}
                        pageSize={pageSize}
                        onShowSizeChange={onPageSizeChange}
                        responsive
                      />
                    </PageAlign>
                  ) : (
                    <Empty />
                  )}
                </ShopRight>
              </ShopAlign>
            </>
          }
        </Wrapper>
      </ShopSection>

    </React.Fragment>
  );
};

export default Shop;

const ShopSection = styled.section`
  width: 100%;
  display: inline-block;
  position: relative;
  margin: 60px 0 0 0;
  .ant-pagination-item-active {
    border-color: ${colorCustom?.color} !important;
  }
  .ant-pagination.ant-pagination-mini .ant-pagination-prev .ant-pagination-item-link, .ant-pagination.ant-pagination-mini .ant-pagination-next .ant-pagination-item-link {
    display: flex;
    align-items: center;
    justify-content: center;
}
.ant-breadcrumb a {
  line-height: 1.5;
  display: flex;
}
.ant-breadcrumb ol li:nth-child(1) {
display: flex;
    align-items: center;
}
`;
const Wrapper = styled.div`
  max-width: 1200px;
  margin: auto;
  padding: 0 10px;
`;
const ShopAlign = styled.div`
  display: flex;
  justify-content: space-between;
  width: 100%;
  flex-wrap: wrap;
  position: relative;
  
`;
const ShopLeft = styled.div`
  width: 23%;
  display: inline-block;
  padding: 25px 20px;
  border: 1px solid ${styles.light};
  /* background: ${styles.light}; */
  border-radius: 5px;
  @media screen and (max-width:1200px){
    width: 28%;
    margin: 0 0 50px;
  }
  @media screen and (max-width:768px){
    width: 100%;
  }
`;
const ShopRight = styled.div`
  width: 76%;
  display: inline-block;
  padding: 0 0 0 25px;
  border: 0px solid ${styles.light};
  @media screen and (max-width:1200px){
    width: 70%;
  }
  @media screen and (max-width:768px){
    width: 100%;
    padding: 0;
  }
`;
const ShopTop = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  flex-wrap: wrap;
  width: 100%;
  position: relative;
  margin: 0 0 30px;

 

`;
const ShopTitle = styled.h1`
  font-size: 25px;
  font-weight: 700;
  color: ${colorCustom?.color} !important;
  margin: 0;
  @media screen and (max-width:768px){
    width: 100%;
    margin: 0 0 25px;
    text-align: center;
  }
`;
const Span = styled.span``;

const ProductListing = styled.div`
  padding: 35px 0 0 0px;
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 20px 15px;

  @media screen and (max-width:1200px){
    grid-template-columns: repeat(3, 1fr);
  }
  @media screen and (max-width:956px){
    grid-template-columns: repeat(2, 1fr);
  }


`;

const PageAlign = styled.div`
  width: 100%;
  text-align: center;
  margin: 45px 0 15px 0;
`;

const SidebarSection = styled.section`
  display: inline-block;
  width: 100%;
  position: relative;

  ul.ant-menu.ant-menu-root.ant-menu-inline.ant-menu-light {
    border: 0;
    background: #fff;
  }
  ul li.ant-menu-item.ant-menu-item-only-child,
  ul li.ant-menu-item.ant-menu-item-active.ant-menu-item-only-child {
    padding-left: 50px !important;
  }
  .ant-slider-track,
  .ant-slider:hover .ant-slider-track {
    background: ${styles.background};
  }
  .ant-slider-handle,
  .ant-slider:hover .ant-slider-handle:not(.ant-tooltip-open) {
    border: solid 2px ${styles.background};
  }
  .ant-checkbox-checked::after {
    border: solid 1px ${styles.background};
  }
  .ant-checkbox-checked .ant-checkbox-inner {
    background-color: ${styles.background};
    border-color: ${styles.background};
  }
  .ant-radio-wrapper:hover .ant-radio,
  .ant-radio:hover .ant-radio-inner,
  .ant-radio-input:focus + .ant-radio-inner,
  .ant-radio-checked .ant-radio-inner {
    border-color: ${styles.background};
  }
  .ant-radio-inner::after {
    background-color: ${styles.background};
  }
  .ant-menu-inline.ant-menu-root .ant-menu-item,
  .ant-menu-inline.ant-menu-root .ant-menu-submenu-title,
  .bqSbPS ul li.ant-menu-item.ant-menu-item-only-child,
  .bqSbPS ul li.ant-menu-item.ant-menu-item-active.ant-menu-item-only-child {
    padding: 0 !important;
  }
  ul li.ant-menu-item.ant-menu-item-only-child,
  ul li.ant-menu-item.ant-menu-item-active.ant-menu-item-only-child {
    padding: 0 !important;
  }
  .ant-menu-sub.ant-menu-inline {
    background: #fff;
  }
  label.ant-checkbox-wrapper.ant-checkbox-group-item,
  .ant-radio-wrapper {
    margin: 0 10px 10px 0;
  }
  .ant-menu-light .ant-menu-item:hover,
  .ant-menu-light .ant-menu-item-active,
  .ant-menu-light .ant-menu:not(.ant-menu-inline) .ant-menu-submenu-open,
  .ant-menu-light .ant-menu-submenu-active,
  .ant-menu-light .ant-menu-submenu-title:hover,
  .ant-menu-submenu:hover
    > .ant-menu-submenu-title
    > .ant-menu-submenu-expand-icon,
  .ant-menu-submenu:hover > .ant-menu-submenu-title > .ant-menu-submenu-arrow {
    color: ${styles.background} !important;
  }
  .ant-menu-item.ant-menu-item-only-child span.ant-menu-title-content {
    padding: 10px 22px !important;
  }
  .ant-menu-item.ant-menu-item-only-child
    .ant-menu-submenu-title
    .ant-menu-title-content {
    padding: 10px 22px !important;
  }

  .ant-menu-title-content a {
    color: ${styles?.color};
  }

  .ant-slider-handle, .ant-slider:hover .ant-slider-handle:not(.ant-tooltip-open) {
    border: solid 2px ${colorCustom?.color};
  }

  .ant-slider-track, .ant-slider:hover .ant-slider-track {
    background: ${colorCustom?.color};
  }
  .ant-radio-checked::after {
    border: 1px solid ${colorCustom?.color};
  }
  .ant-radio-inner::after {
    background-color: ${colorCustom?.color};
  }
  .ant-radio-wrapper:hover .ant-radio, .ant-radio:hover .ant-radio-inner, .ant-radio-input:focus + .ant-radio-inner, .ant-radio-checked .ant-radio-inner, .ant-pagination-item-active:hover {
    border-color: ${colorCustom?.color};
  }

 
`;
const CategoryList = styled.div`
  width:100%;
  display: inline-block;
  position: relative;
`;
const Title = styled.div`
  font-size: 18px;
  color: ${styles?.color};
  margin: 0 0 20px;
  font-weight: 600;
  letter-spacing: 0.5px;
`;
const ProductFilter = styled.div`
  width: 100%;
  display: inline-block;
  position: relative;
`;
const ColorFilter = styled.div`
  width: 100%;
  display: inline-block;
  position: relative;
`;

const FilterSidebarSection = styled.div`
  border: 0px solid ${styles.light};
  padding: 0px 0px;
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: space-between;
  flex-wrap: wrap;
  background: #fff;
  border-radius: 5px;
  .ant-select-selection-placeholder {
    color: ${styles.color};
  }
  @media screen and (max-width:480px){
   flex-direction: column;
   justify-content: center;
   gap: 15px;
  }
`;
const FilterSidebarLeft = styled.div`
  color: ${styles.color};
  font-weight: 600;
  font-size: 15px;
`;
const FilterSidebarRight = styled.div`
  display: flex;
  align-items: center;
  gap: 10px;
  color: ${styles.color};
  font-weight: 600;
  font-size: 15px;
  .ant-select.ant-select-single.ant-select-show-arrow.ant-select-show-search,
  .ant-select:not(.ant-select-customize-input) .ant-select-selector {
    border: 0;
    border: 1px solid #f9f9f9;
  }
`;