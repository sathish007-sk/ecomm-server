import React, { useEffect, useState } from 'react'
import styled from 'styled-components';
import { styles } from "./../Api/Data";
import { Button } from "antd";
import { Link } from "react-router-dom";
import Default from '../Assets/Images/default.png'
import API from '../Api/ApiService';
const ProductGridView = ({filteredProduct}) => {
  const api = new API();


 return (
    <React.Fragment>
      {
        filteredProduct?.map((item)=>{
          return (
            <ProductBox key={item._id}>
               <ProductImage>
               <Link to={"/"+item.category[0]?.category_name.toLowerCase().replace(/ /g, '-')
                      .replace(/[^\w-]+/g, '') + "/" + item.description?.toLowerCase().replace(/ /g, '-')
                      .replace(/[^\w-]+/g, '') + "?pid=" + item._id}><Image src={item.images ? api.rootUrl + item.images[0] : Default} /></Link>
                </ProductImage>
                <Content>
                  <Title>{item.description?.substr(0, 40) + "..."}</Title>
                  <Price>
              <Sp>
                {styles.currency}
                {(Number(item.sp).toFixed(0))}
              </Sp>
              <Mrp>
                {styles.currency}
                {(Number(item.mrp).toFixed(0))}
              </Mrp>
            </Price>
            <Link to={"/"+item.category[0]?.category_name.toLowerCase().replace(/ /g, '-')
                      .replace(/[^\w-]+/g, '') + "/" + item.description?.toLowerCase().replace(/ /g, '-')
                      .replace(/[^\w-]+/g, '') + "?pid=" + item._id}>
              <Button>Buy Now</Button>
            </Link>
                </Content>
            </ProductBox>
          )
        })
      }
    </React.Fragment>
  );
}

export default ProductGridView

const ProductBox = styled.div`
  width:100%;
  position: relative;
  border: 1px solid ${styles.light};
  border-radius: 5px;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
`;
const ProductImage = styled.div``;
const Image = styled.img`
  max-width: 100%;
  width: 100%;
`;
const Content = styled.div`
  padding: 15px;
  width:100%;
  display: flex;
  flex-direction: column;
  gap: 12px;
  height: 100%;
  justify-content: space-between;
`;
const Title = styled.div`
  color: ${styles.color};
  font-size: 16px;
  font-weight: 600;
  line-height: 1.5;
  @media screen and (max-width:480px){
    font-size: 14px;
  }
`;
const Price = styled.div`
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 11px;
`;
const Sp = styled.div`
  font-size: 18px;
  color: ${styles.color};
  font-weight: 700;
`;
const Mrp = styled.div`
  font-size: 13px;
  color: ${styles.gray};
  text-decoration: line-through;
`;
