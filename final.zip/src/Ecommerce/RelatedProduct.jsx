import React, { useEffect, useState } from "react";
import styled from "styled-components";
import { styles } from "../Api/Data";
import { Button } from "antd";
import { Link } from "react-router-dom";
import API from "../Api/ApiService";
import Default from '../Assets/Images/default.png'
const user = JSON.parse(localStorage.getItem("persist:root"))?.company;
const colorCustom = user && JSON.parse(user).setColor;
const RelatedProduct = ({ related }) => {

  
  const element = related.sort(() => (Math.random() - Math.random()) * 4)
  .find(() => true);



  const api = new API();
  

  return (
    <React.Fragment>
      <RelatedProductSection>
        
          <HeadText>
            <H2>RelatedProduct</H2>
          </HeadText>
          <Ul>
            {related.length > 1 ? (
              related?.slice(0, 4).map((item) => (
                <Li key={item._id}>
                  <ImageAlign>
                  <Link to={"/"+item.category[0].category_name.toLowerCase().replace(/ /g, '-')
                      .replace(/[^\w-]+/g, '') + "/" + item.description.toLowerCase().replace(/ /g, '-')
                        .replace(/[^\w-]+/g, '') + "?pid=" + item._id}><Image
                      src={item.images ? api.rootUrl+item.images[0] : Default}
                      alt={item.title}
                    /></Link>
                  </ImageAlign>
                  <Content>
                    <Title>{item.description}</Title>
                    <Price>
                      <Sp>
                        {item.currency}
                        {(Number(item.sp).toFixed(0))}
                      </Sp>
                      <Mrp>
                        {item.currency}
                        {(Number(item.mrp).toFixed(0))}
                      </Mrp>
                    </Price>
                    <Link to={"/"+item.category[0].category_name.toLowerCase().replace(/ /g, '-')
                      .replace(/[^\w-]+/g, '') + "/" + item.description.toLowerCase().replace(/ /g, '-')
                        .replace(/[^\w-]+/g, '') + "?pid=" + item._id}>
                      <Button>Buy Now</Button>
                    </Link>
                  </Content>
                </Li>
              ))
            ) : (
              <p className="no_result_fount">No Relative Product yet</p>
            )}
          </Ul>
       
      </RelatedProductSection>
    </React.Fragment>
  );
};

export default RelatedProduct;

const RelatedProductSection = styled.section`
  display: inline-block;
  width: 100%;
  position: relative;
  margin: 60px 0;
  img {
    margin: auto;
  }
`;
const Wrapper = styled.div`
  max-width: 1200px;
  margin: auto;
`;
const HeadText = styled.div`
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: space-between;
  position: relative;
`;
const H2 = styled.h2`
  color: ${colorCustom?.color} !important;
  font-size: ${styles.h2};
`;
const Ul = styled.div`
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 30px 25px;
  margin: 20px 0 0 0;
  
  @media screen and (max-width: 768px) {
    grid-template-columns: repeat(2, 1fr);
  }

`;
const Li = styled.div`
  border: 1px solid ${styles.light};
  width: 100%;
  display: inline-block;
  border-radius: 5px;
`;
const ImageAlign = styled.div`
  width: 100%;
  background: transparent;
  width: 100%;
  position: relative;
`;
const Image = styled.img`
  max-width: 100%;
  display: block;
`;
const Content = styled.div`
  width: 100%;
  display: flex;
  flex-direction: column;
  gap: 15px;
  position: relative;
  padding: 25px;
  border-top: 0px solid ${styles.light};
`;
const Title = styled.div`
  color: ${styles.color};
  font-size: 18px;
  font-weight: 600;
  line-height: 1.5;

  @media screen and (max-width: 480px) {
    font-size: 14px;
  }
`;
const Price = styled.div`
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 15px;
`;
const Sp = styled.div`
  font-size: 20px;
  color: ${styles.color};
  font-weight: 700;
`;
const Mrp = styled.div`
  font-size: 14px;
  color: ${styles.gray};
  text-decoration: line-through;
`;
