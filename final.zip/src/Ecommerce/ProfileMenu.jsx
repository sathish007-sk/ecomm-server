import React from 'react'
import { Link } from 'react-router-dom'
import styled from 'styled-components'
import {Divider} from 'antd'
import { styles } from '../Api/Data'

const ProfileMenu = () => {
  return (
    <React.Fragment>
        <List>
            <Link to="/my-profile"><Item>My Profile</Item></Link>
            <Divider />
            <Link to="/my-address"><Item>Manage Address</Item></Link>
            <Divider />
            <Link to="/my-order"><Item>My Order</Item></Link>
        </List>
    </React.Fragment>
  )
}

export default ProfileMenu


const List = styled.div`
    color: ${styles.color};
    display: flex;
    flex-direction: column;
    gap: 0px;
`;
const Item = styled.div`
color: ${styles.color};
font-size: 17px;
font-weight: 600;
`;