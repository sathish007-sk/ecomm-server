import API from "./ApiService";
import { userRequest } from './Authentication'

class OrderService extends API {
    placeOrder = async () => {
        try {
            const res = await userRequest.post("api/order", {});
            return res;
        } catch (err) {}
    }
    addressList = async () => {
        try {
          const res = await userRequest.get("api/order");
          return res;
        } catch (err) {}
      };
      retrieve = async (id) => {
        let data = {buyer:id}
        try {
          const res = await userRequest.get(`api/order/`,data);
          return res;
        } catch (err) {}
      }
      retrieveSingle = async (id) => {
        // let id = {buyer:id}
        try {
          const res = await userRequest.get(`api/order/${id}`);
          return res;
        } catch (err) {}
      }
}   


export default OrderService;