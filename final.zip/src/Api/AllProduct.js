export const data = [
    {
        "packing_detail": {
            "weight": 2,
            "length": 40,
            "breadth": 25,
            "height": 40
        },
        "delivery_charge": {
            "local": 1,
            "zonal": 800,
            "national": 800
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "622341265507127df692c50f",
                "category_name": "Home Utilities",
                "specification": null,
                "createdAt": "2022-03-05T10:53:26.643Z",
                "updatedAt": "2022-03-17T08:17:50.624Z",
                "__v": 0,
                "images": "public/category/1664342495502.3452.webp"
            },
            {
                "parent": "622341265507127df692c50f",
                "status": true,
                "_id": "622ae8ea5507127df693035c",
                "category_name": "Chettinad Baskets",
                "specification": null,
                "createdAt": "2022-03-11T06:15:06.440Z",
                "updatedAt": "2022-10-19T09:12:02.077Z",
                "__v": 0,
                "images": "public/category/1666170722075.4104.webp"
            },
            {
                "parent": "622ae8ea5507127df693035c",
                "status": true,
                "_id": "622c34a08bc4af4c77b1fd17",
                "category_name": "Chettinad Basket set of 5 with Lids",
                "createdAt": "2022-03-12T05:50:24.289Z",
                "updatedAt": "2022-03-17T08:17:41.538Z",
                "__v": 0,
                "images": null,
                "specification": "62233e595507127df692c4db"
            }
        ],
        "pricestatus": true,
        "highlight": [
            "Easy mobility",
            "Sturdy to take with you anywhere"
        ],
        "key_words": [
            ""
        ],
        "status": true,
        "featured": true,
        "publish": true,
        "_id": "622341aa5507127df692c547",
        "meta_key": "Koodai",
        "images": [
            "public/product/1647332036070.4062.webp"
        ],
        "sku": "P001",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "specification": [
            {
                "_id": "62b6df302a62aa5591e4ccf5",
                "title": "Material",
                "value": "Plastic",
                "suffix": ""
            },
            {
                "_id": "62b6df302a62aa5591e4ccf6",
                "title": "Available Colours",
                "value": "Multi colors available",
                "suffix": ""
            },
            {
                "_id": "62b6df302a62aa5591e4ccf7",
                "title": "Types",
                "value": " Set of 5 Baskets/Koodai for all purposes with lids",
                "suffix": ""
            },
            {
                "_id": "62b6df302a62aa5591e4ccf8",
                "title": "Size-1 (INCHES)",
                "value": "Largest 12 X 8 X 11",
                "suffix": ""
            },
            {
                "_id": "62b6df302a62aa5591e4ccf9",
                "title": "Size-2",
                "value": "Large 11 X 7 X 11",
                "suffix": ""
            },
            {
                "_id": "62b6df302a62aa5591e4ccfa",
                "title": "Size-3",
                "value": "Medium 10 X 6 X 10",
                "suffix": ""
            },
            {
                "_id": "62b6df302a62aa5591e4ccfb",
                "title": "Size-4",
                "value": "Small 9 X 5 X 10",
                "suffix": ""
            },
            {
                "_id": "62b6df302a62aa5591e4ccfc",
                "title": "Size-5",
                "value": "Smallest 8 X 4 X 7",
                "suffix": ""
            }
        ],
        "createdAt": "2022-03-05T10:55:38.824Z",
        "updatedAt": "2022-11-03T05:37:53.122Z",
        "__v": 0,
        "description": "Chettinad Baskets set of 5 with lids",
        "display_date": null,
        "hsn_code": "3924",
        "min_order_qty": 1,
        "mrp": 40,
        "sp": 35,
        "stock": 52,
        "tax": {
            "status": true,
            "_id": "61f7dde28d37e6262ba17c80",
            "tax_name": "GST_18",
            "tax_percentage": 18,
            "__v": 0
        },
        "meta_desc": "Baskets",
        "note": "These baskets are usefull to carry anywhere at any time without spillage .The bottom of each basket is provided with bushes to make them stand sturdy and erect.",
        "delivery_days": 7,
        "price_id": "6348e914ce2b3a16aca44097"
    },
    {
        "packing_detail": {
            "weight": 0.2,
            "length": 10,
            "breadth": 5,
            "height": 6
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "622341265507127df692c50f",
                "category_name": "Home Utilities",
                "specification": null,
                "createdAt": "2022-03-05T10:53:26.643Z",
                "updatedAt": "2022-03-17T08:17:50.624Z",
                "__v": 0,
                "images": "public/category/1664342495502.3452.webp"
            },
            {
                "parent": "622341265507127df692c50f",
                "status": true,
                "_id": "622ae8ea5507127df693035c",
                "category_name": "Chettinad Baskets",
                "specification": null,
                "createdAt": "2022-03-11T06:15:06.440Z",
                "updatedAt": "2022-10-19T09:12:02.077Z",
                "__v": 0,
                "images": "public/category/1666170722075.4104.webp"
            },
            {
                "parent": "622ae8ea5507127df693035c",
                "status": true,
                "_id": "622c3ddd8bc4af4c77b201a6",
                "category_name": "Lunch Bags",
                "specification": "622ae9a55507127df69303d6",
                "createdAt": "2022-03-12T06:29:49.596Z",
                "updatedAt": "2022-03-12T06:29:49.596Z",
                "__v": 0
            }
        ],
        "pricestatus": true,
        "highlight": [
            "Store in your car space",
            "For your kids to take to school"
        ],
        "key_words": [
            ""
        ],
        "status": true,
        "featured": true,
        "publish": true,
        "_id": "6223472d5507127df692c621",
        "meta_key": "Koodai",
        "images": [
            "public/product/1647601397180.297.webp"
        ],
        "sku": "P002",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "specification": [
            {
                "_id": "62b6df552a62aa5591e4cd1b",
                "title": "Material",
                "value": "Plastic",
                "suffix": ""
            },
            {
                "_id": "62b6df552a62aa5591e4cd1c",
                "title": "Colour",
                "value": "Pink white and green designs",
                "suffix": ""
            },
            {
                "_id": "62b6df552a62aa5591e4cd1d",
                "title": "Size",
                "value": "8 X 5 X8 (In Inches)",
                "suffix": ""
            }
        ],
        "createdAt": "2022-03-05T11:19:09.582Z",
        "updatedAt": "2022-11-03T08:04:22.487Z",
        "__v": 0,
        "description": " Standard Lunch bags",
        "display_date": null,
        "hsn_code": "3924",
        "min_order_qty": 1,
        "mrp": 11,
        "sp": 11,
        "stock": 53,
        "tax": {
            "status": true,
            "_id": "61f7dde28d37e6262ba17c80",
            "tax_name": "GST_18",
            "tax_percentage": 18,
            "__v": 0
        },
        "meta_desc": "Small baskets",
        "note": "An comfortable size to hand carry anywhere&#160;",
        "delivery_days": 7,
        "price_id": "633bd331e936fa2c5cf94b6d"
    },
    {
        "packing_detail": {
            "weight": 0.25,
            "length": 10,
            "breadth": 7,
            "height": 1
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6225aa6c5507127df692d326",
                "category_name": "Wedding hand bags",
                "createdAt": "2022-03-07T06:47:08.299Z",
                "updatedAt": "2022-10-19T09:11:12.613Z",
                "__v": 0,
                "images": "public/category/1666170672612.1301.webp",
                "specification": null
            },
            {
                "parent": "6225aa6c5507127df692d326",
                "status": true,
                "_id": "62345cbc462a810f78226389",
                "category_name": "Clutch Hand Bags",
                "specification": "6227066b5507127df692d69c",
                "createdAt": "2022-03-18T10:19:40.691Z",
                "updatedAt": "2022-03-19T10:21:06.145Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Great Carry for weddings and parties"
        ],
        "key_words": [
            ""
        ],
        "status": true,
        "featured": true,
        "publish": false,
        "_id": "62270ca65507127df692d883",
        "meta_key": "bags, handbags",
        "images": [
            "public/product/1646726649642.7405.webp"
        ],
        "sku": "P0080",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "specification": [
            {
                "_id": "62b6df792a62aa5591e4cd3c",
                "title": "Material",
                "value": "Silk ",
                "suffix": ""
            },
            {
                "_id": "62b6df792a62aa5591e4cd3d",
                "title": "Colour",
                "value": "Dark Green",
                "suffix": ""
            },
            {
                "_id": "62b6df792a62aa5591e4cd3e",
                "title": "Size",
                "value": "10 X 6 X 2 (In Inches)",
                "suffix": ""
            }
        ],
        "createdAt": "2022-03-08T07:58:30.521Z",
        "updatedAt": "2022-10-12T03:56:07.270Z",
        "__v": 0,
        "description": "Green Clutch Bag",
        "display_date": null,
        "hsn_code": "6305",
        "min_order_qty": 1,
        "mrp": 123,
        "sp": 23,
        "stock": 0,
        "tax": {
            "status": true,
            "_id": "61f7dde28d37e6262ba17c80",
            "tax_name": "GST_18",
            "tax_percentage": 18,
            "__v": 0
        },
        "meta_desc": "Bags",
        "note": "&#160;Has an optional chain attached which can be used as a sling&#160; for the clutch if needed else it conveniently goes into the bag.",
        "delivery_days": 7,
        "price_id": [
            "63354270f912c525a4077d94"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.1,
            "length": 24,
            "breadth": 15,
            "height": 2
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6225aa6c5507127df692d326",
                "category_name": "Wedding hand bags",
                "createdAt": "2022-03-07T06:47:08.299Z",
                "updatedAt": "2022-10-19T09:11:12.613Z",
                "__v": 0,
                "images": "public/category/1666170672612.1301.webp",
                "specification": null
            },
            {
                "parent": "6225aa6c5507127df692d326",
                "status": true,
                "_id": "62345cbc462a810f78226389",
                "category_name": "Clutch Hand Bags",
                "specification": "6227066b5507127df692d69c",
                "createdAt": "2022-03-18T10:19:40.691Z",
                "updatedAt": "2022-03-19T10:21:06.145Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Party and Wedding Accessories",
            "The clutch can be slung on your shoulder with the chain provided if needed"
        ],
        "key_words": [
            ""
        ],
        "status": false,
        "featured": false,
        "publish": false,
        "_id": "62270e875507127df692d98c",
        "meta_key": "Sling pouch, pouches, clutches,",
        "images": [
            "public/product/1646727065277.5051.webp"
        ],
        "sku": "P009",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "specification": [
            {
                "_id": "62b6dfd62a62aa5591e4cd7f",
                "title": "Material",
                "value": "Silk",
                "suffix": ""
            },
            {
                "_id": "62b6dfd62a62aa5591e4cd80",
                "title": "Colour",
                "value": "Black",
                "suffix": ""
            },
            {
                "_id": "62b6dfd62a62aa5591e4cd81",
                "title": "Size",
                "value": "9 X 5 X 1 (In Inches) ",
                "suffix": ""
            }
        ],
        "createdAt": "2022-03-08T08:06:31.773Z",
        "updatedAt": "2022-07-27T08:27:11.832Z",
        "__v": 0,
        "description": "Black Ikkat Print clutch bag",
        "display_date": null,
        "hsn_code": "6305",
        "min_order_qty": 1,
        "mrp": 800,
        "sp": 790,
        "stock": 0,
        "tax": {
            "status": true,
            "_id": "61f7dde28d37e6262ba17c80",
            "tax_name": "GST_18",
            "tax_percentage": 18,
            "__v": 0
        },
        "meta_desc": "Purse",
        "note": "Has an optional chain attached that can be used to sling the clutch if needed else it conveniently goes into the cluch bag.",
        "delivery_days": 7
    },
    {
        "packing_detail": {
            "weight": 0.1,
            "length": 24,
            "breadth": 15,
            "height": 2
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6225aa6c5507127df692d326",
                "category_name": "Wedding hand bags",
                "createdAt": "2022-03-07T06:47:08.299Z",
                "updatedAt": "2022-10-19T09:11:12.613Z",
                "__v": 0,
                "images": "public/category/1666170672612.1301.webp",
                "specification": null
            },
            {
                "parent": "6225aa6c5507127df692d326",
                "status": true,
                "_id": "62345cbc462a810f78226389",
                "category_name": "Clutch Hand Bags",
                "specification": "6227066b5507127df692d69c",
                "createdAt": "2022-03-18T10:19:40.691Z",
                "updatedAt": "2022-03-19T10:21:06.145Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Accompanied by a chain attached to enable the bag to be used in a sling if needed."
        ],
        "key_words": [
            "Match with your wedding wear."
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "622710715507127df692da97",
        "meta_key": "Sling pouch",
        "images": [
            "public/product/1646727440581.0532.webp"
        ],
        "sku": "P010",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "specification": [
            {
                "_id": "62b6dffa2a62aa5591e4cda0",
                "title": "Material",
                "value": "Silk",
                "suffix": ""
            },
            {
                "_id": "62b6dffa2a62aa5591e4cda1",
                "title": "Colour",
                "value": "Baby pink",
                "suffix": ""
            },
            {
                "_id": "62b6dffa2a62aa5591e4cda2",
                "title": "Size",
                "value": "9 X 5 X 1 (In Inches)",
                "suffix": ""
            }
        ],
        "createdAt": "2022-03-08T08:14:41.027Z",
        "updatedAt": "2022-06-25T10:14:18.868Z",
        "__v": 0,
        "description": "Pink Clutch Bag",
        "display_date": null,
        "hsn_code": "6305",
        "min_order_qty": 1,
        "mrp": 800,
        "sp": 790,
        "stock": 0,
        "tax": {
            "status": true,
            "_id": "61f7dde28d37e6262ba17c80",
            "tax_name": "GST_18",
            "tax_percentage": 18,
            "__v": 0
        },
        "meta_desc": "Bag",
        "note": "",
        "delivery_days": 7
    },
    {
        "packing_detail": {
            "weight": 0.1,
            "length": 24,
            "breadth": 15,
            "height": 2
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6225aa6c5507127df692d326",
                "category_name": "Wedding hand bags",
                "createdAt": "2022-03-07T06:47:08.299Z",
                "updatedAt": "2022-10-19T09:11:12.613Z",
                "__v": 0,
                "images": "public/category/1666170672612.1301.webp",
                "specification": null
            },
            {
                "parent": "6225aa6c5507127df692d326",
                "status": true,
                "_id": "62345cbc462a810f78226389",
                "category_name": "Clutch Hand Bags",
                "specification": "6227066b5507127df692d69c",
                "createdAt": "2022-03-18T10:19:40.691Z",
                "updatedAt": "2022-03-19T10:21:06.145Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "For party and weddings",
            "Match with your sarees or outfits"
        ],
        "key_words": [
            ""
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "622711b25507127df692db8f",
        "meta_key": "Sling pouch",
        "images": [
            "public/product/1646727695916.724.webp"
        ],
        "sku": "P011",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "specification": [
            {
                "_id": "62b6e01c2a62aa5591e4cdc1",
                "title": "Material",
                "value": "Silk",
                "suffix": ""
            },
            {
                "_id": "62b6e01c2a62aa5591e4cdc2",
                "title": "Colour",
                "value": "Orange",
                "suffix": ""
            },
            {
                "_id": "62b6e01c2a62aa5591e4cdc3",
                "title": "Size",
                "value": "9 X 5 X 1 (In Inches)",
                "suffix": ""
            }
        ],
        "createdAt": "2022-03-08T08:20:02.541Z",
        "updatedAt": "2022-06-25T10:14:52.828Z",
        "__v": 0,
        "description": "Orange Ikkat Print Clutch Bag",
        "display_date": null,
        "hsn_code": "6305",
        "min_order_qty": 1,
        "mrp": 800,
        "sp": 790,
        "stock": 0,
        "tax": {
            "status": true,
            "_id": "61f7dde28d37e6262ba17c80",
            "tax_name": "GST_18",
            "tax_percentage": 18,
            "__v": 0
        },
        "meta_desc": "Bags ",
        "note": "Provided with optional chain to sling on shoulder.Press buttons and inner zip available.",
        "delivery_days": 7
    },
    {
        "packing_detail": {
            "weight": 0.5,
            "length": 20,
            "breadth": 10,
            "height": 1
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6225aa7f5507127df692d32f",
                "category_name": " Mobile or Cell phone Pouches ",
                "createdAt": "2022-03-07T06:47:27.047Z",
                "updatedAt": "2022-10-19T09:11:23.410Z",
                "__v": 0,
                "images": "public/category/1666170683409.058.webp",
                "specification": null
            },
            {
                "parent": "6225aa7f5507127df692d32f",
                "status": true,
                "_id": "62345e60462a810f782264ea",
                "category_name": "Saree Mobile phone pouches",
                "createdAt": "2022-03-18T10:26:40.949Z",
                "updatedAt": "2022-03-18T10:31:06.762Z",
                "__v": 0,
                "images": null,
                "specification": "62345ef7462a810f78226517"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Saree hook provided for the mobile to be hands free."
        ],
        "key_words": [
            "Match it with your fancy wear."
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "622713b25507127df692dbe5",
        "meta_key": "Saree compatible phone pouch",
        "images": [
            "public/product/1646728168767.5217.webp"
        ],
        "sku": "P012",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "specification": [
            {
                "_id": "62360b2a462a810f78226ede",
                "title": "Material",
                "value": "Silk",
                "suffix": ""
            },
            {
                "_id": "62360b2a462a810f78226edf",
                "title": "Colour",
                "value": "Orange",
                "suffix": ""
            },
            {
                "_id": "62360b2a462a810f78226ee0",
                "title": "Size",
                "value": "8\"*4\"(in inches)",
                "suffix": ""
            }
        ],
        "createdAt": "2022-03-08T08:28:34.147Z",
        "updatedAt": "2022-06-17T05:48:33.313Z",
        "__v": 0,
        "description": "Orange Mobile Phone Pouch",
        "display_date": null,
        "hsn_code": "6305",
        "min_order_qty": 1,
        "mrp": 350,
        "sp": 350,
        "stock": 0,
        "tax": {
            "status": true,
            "_id": "61f7dde28d37e6262ba17c80",
            "tax_name": "GST_18",
            "tax_percentage": 18,
            "__v": 0
        },
        "meta_desc": "Mobile Pouch",
        "note": "Silk with ikkat design",
        "delivery_days": 7
    },
    {
        "packing_detail": {
            "weight": 0.5,
            "length": 19,
            "breadth": 10,
            "height": 2
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6225aa7f5507127df692d32f",
                "category_name": " Mobile or Cell phone Pouches ",
                "createdAt": "2022-03-07T06:47:27.047Z",
                "updatedAt": "2022-10-19T09:11:23.410Z",
                "__v": 0,
                "images": "public/category/1666170683409.058.webp",
                "specification": null
            },
            {
                "parent": "6225aa7f5507127df692d32f",
                "status": true,
                "_id": "62345e60462a810f782264ea",
                "category_name": "Saree Mobile phone pouches",
                "createdAt": "2022-03-18T10:26:40.949Z",
                "updatedAt": "2022-03-18T10:31:06.762Z",
                "__v": 0,
                "images": null,
                "specification": "62345ef7462a810f78226517"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "With saree hooks to hang your mobile on your hip",
            "Match with your outfits"
        ],
        "key_words": [
            ""
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "622714a55507127df692dc21",
        "meta_key": "Saree phone pouch",
        "images": [
            "public/product/1646728410671.565.webp"
        ],
        "sku": "P013",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "specification": [
            {
                "_id": "62b6e0392a62aa5591e4cde2",
                "title": "Material",
                "value": "Silk",
                "suffix": ""
            },
            {
                "_id": "62b6e0392a62aa5591e4cde3",
                "title": "Colour",
                "value": "Baby pink",
                "suffix": ""
            },
            {
                "_id": "62b6e0392a62aa5591e4cde4",
                "title": "Size",
                "value": "8 X 4 (In Inches)",
                "suffix": ""
            }
        ],
        "createdAt": "2022-03-08T08:32:37.691Z",
        "updatedAt": "2022-06-25T10:15:21.348Z",
        "__v": 0,
        "meta_desc": "Mobile Phone Pouch",
        "note": "Grand to wear at your hip in a grand pattu saree",
        "description": "Pink Mobile Phone Pouch",
        "display_date": null,
        "hsn_code": "6305",
        "min_order_qty": 1,
        "mrp": 350,
        "sp": 350,
        "stock": 0,
        "tax": {
            "status": true,
            "_id": "61f7dde28d37e6262ba17c80",
            "tax_name": "GST_18",
            "tax_percentage": 18,
            "__v": 0
        },
        "delivery_days": 7
    },
    {
        "packing_detail": {
            "weight": 1,
            "length": 30.5,
            "breadth": 30.5,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6229fdc25507127df692f42c",
                "category_name": "Womans wear",
                "specification": "62ad9bc72a62aa5591e3ff4b",
                "createdAt": "2022-03-10T13:31:46.187Z",
                "updatedAt": "2022-10-19T09:11:36.730Z",
                "__v": 0,
                "images": "public/category/1666170696730.1174.webp"
            },
            {
                "parent": "6229fdc25507127df692f42c",
                "status": true,
                "_id": "622aebc45507127df69304a7",
                "category_name": "Ajrakh Printed Dress Material",
                "specification": "6226f1605507127df692d431",
                "createdAt": "2022-03-11T06:27:16.654Z",
                "updatedAt": "2022-06-20T09:03:30.883Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "For daily use and comfortable office wear"
        ],
        "key_words": [
            ""
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "6228541e5507127df692e53b",
        "meta_key": "suit material",
        "images": [
            "public/product/1646912128506.031.webp"
        ],
        "sku": "P014",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "specification": [
            {
                "_id": "623ac0471d83b224a04683ec",
                "title": "Material",
                "value": "Cotton",
                "suffix": ""
            },
            {
                "_id": "623ac0471d83b224a04683ed",
                "title": "Colour",
                "value": "Red",
                "suffix": ""
            }
        ],
        "createdAt": "2022-03-09T07:15:42.352Z",
        "updatedAt": "2022-06-17T06:16:28.872Z",
        "__v": 0,
        "description": "Ajrakh cotton printed dress material",
        "display_date": null,
        "hsn_code": "5208",
        "min_order_qty": 1,
        "mrp": 1800,
        "sp": 1500,
        "stock": 0,
        "tax": null,
        "meta_desc": " Fabric for Salwar top and bottom ",
        "note": "<div><br></div><div>Top Material is 2.5 meters with 44 inches width/bottom is 2.5 meters with cotton mulmul duppatta of 2 meters</div><div><br></div>Care instructions:<div>Kindly hand wash for first wash and iron for each use to get your best results</div>",
        "delivery_days": 7
    },
    {
        "packing_detail": {
            "weight": 1,
            "length": 30.5,
            "breadth": 30.5,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6229fdc25507127df692f42c",
                "category_name": "Womans wear",
                "specification": "62ad9bc72a62aa5591e3ff4b",
                "createdAt": "2022-03-10T13:31:46.187Z",
                "updatedAt": "2022-10-19T09:11:36.730Z",
                "__v": 0,
                "images": "public/category/1666170696730.1174.webp"
            },
            {
                "parent": "6229fdc25507127df692f42c",
                "status": true,
                "_id": "622aebc45507127df69304a7",
                "category_name": "Ajrakh Printed Dress Material",
                "specification": "6226f1605507127df692d431",
                "createdAt": "2022-03-11T06:27:16.654Z",
                "updatedAt": "2022-06-20T09:03:30.883Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Comfortable for all times and all places.",
            "Travel in great summer wear."
        ],
        "key_words": [
            ""
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "6229d4625507127df692efff",
        "meta_key": "Salwar top and bottom Fabric",
        "images": [
            "public/product/1646912068430.8584.webp"
        ],
        "sku": "P015",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "specification": [
            {
                "_id": "623acc461d83b224a0468816",
                "title": "Material",
                "value": "Cotton",
                "suffix": ""
            },
            {
                "_id": "623acc461d83b224a0468817",
                "title": "Colour",
                "value": "Yellow",
                "suffix": ""
            }
        ],
        "createdAt": "2022-03-10T10:35:14.640Z",
        "updatedAt": "2022-06-17T06:18:19.597Z",
        "__v": 0,
        "description": "Ajrakh cotton printed dress material",
        "display_date": null,
        "hsn_code": "5208",
        "min_order_qty": 1,
        "mrp": 1800,
        "sp": 1500,
        "stock": 0,
        "tax": null,
        "delivery_days": 7,
        "meta_desc": "Suit Material",
        "note": "First Wash to be Hand washed.Dry in shade and iron ."
    },
    {
        "packing_detail": {
            "weight": 0.75,
            "length": 30.5,
            "breadth": 30.5,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6229fdc25507127df692f42c",
                "category_name": "Womans wear",
                "specification": "62ad9bc72a62aa5591e3ff4b",
                "createdAt": "2022-03-10T13:31:46.187Z",
                "updatedAt": "2022-10-19T09:11:36.730Z",
                "__v": 0,
                "images": "public/category/1666170696730.1174.webp"
            },
            {
                "parent": "6229fdc25507127df692f42c",
                "status": true,
                "_id": "622aebc45507127df69304a7",
                "category_name": "Ajrakh Printed Dress Material",
                "specification": "6226f1605507127df692d431",
                "createdAt": "2022-03-11T06:27:16.654Z",
                "updatedAt": "2022-06-20T09:03:30.883Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "For daily use and comfortable office wear"
        ],
        "key_words": [
            ""
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "6229d83d5507127df692f0b3",
        "meta_key": "suit material",
        "images": [
            "public/product/1646909701465.0066.webp"
        ],
        "sku": "P016",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "specification": [
            {
                "_id": "622a32a25507127df692fb9d",
                "title": "Material",
                "value": "Cotton",
                "suffix": ""
            },
            {
                "_id": "622a32a25507127df692fb9e",
                "title": "Colour",
                "value": "Pink with printed flowers",
                "suffix": ""
            }
        ],
        "createdAt": "2022-03-10T10:51:41.530Z",
        "updatedAt": "2022-06-17T06:19:10.005Z",
        "__v": 0,
        "description": "Ajrakh Cotton Printed Dress Material",
        "display_date": null,
        "hsn_code": "5308",
        "min_order_qty": 1,
        "mrp": 1800,
        "sp": 1500,
        "stock": 0,
        "tax": null,
        "meta_desc": "Fabric for salwar top and bottam",
        "note": "Top Material 2.5 metres with 44&#34;width/Bottam 2.5 metres with cotton mulmul dupatta of 2 metres<div><br></div><div>Care instructions:</div><div>Kindly hand wash for first wash and iron for each use to get best results.</div><div><br></div>",
        "delivery_days": 7
    },
    {
        "packing_detail": {
            "weight": 0.75,
            "length": 30.5,
            "breadth": 30.5,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6229fdc25507127df692f42c",
                "category_name": "Womans wear",
                "specification": "62ad9bc72a62aa5591e3ff4b",
                "createdAt": "2022-03-10T13:31:46.187Z",
                "updatedAt": "2022-10-19T09:11:36.730Z",
                "__v": 0,
                "images": "public/category/1666170696730.1174.webp"
            },
            {
                "parent": "6229fdc25507127df692f42c",
                "status": true,
                "_id": "622aebc45507127df69304a7",
                "category_name": "Ajrakh Printed Dress Material",
                "specification": "6226f1605507127df692d431",
                "createdAt": "2022-03-11T06:27:16.654Z",
                "updatedAt": "2022-06-20T09:03:30.883Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "For daily use and comfortable office wear"
        ],
        "key_words": [
            ""
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "6229d92d5507127df692f0c3",
        "meta_key": "suit material",
        "images": [
            "public/product/1646909880754.2173.webp"
        ],
        "sku": "P017",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "specification": [
            {
                "_id": "62375969462a810f782271b1",
                "title": "Material",
                "value": "Cotton",
                "suffix": ""
            },
            {
                "_id": "62375969462a810f782271b2",
                "title": "Colour",
                "value": "Blue with red floral prints",
                "suffix": ""
            }
        ],
        "createdAt": "2022-03-10T10:55:41.724Z",
        "updatedAt": "2022-06-17T06:20:06.529Z",
        "__v": 0,
        "description": "Ajrakh Cotton Printed Dress Material",
        "display_date": null,
        "hsn_code": "5308",
        "min_order_qty": 1,
        "mrp": 1800,
        "sp": 1500,
        "stock": 0,
        "tax": null,
        "meta_desc": "Fabric for salwar top and bottom",
        "note": "Top material&#160; is 2.5 metres with 44&#34;width/Bottom is 2.5 metres with cotton mulmul dupatta of 2 metres.<div><br></div><div>Care Instructions:</div><div>Kindly hand wash for first was and iron for each use for best results.</div>",
        "delivery_days": 7
    },
    {
        "packing_detail": {
            "weight": 0.75,
            "length": 30.5,
            "breadth": 30.5,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6229fdc25507127df692f42c",
                "category_name": "Womans wear",
                "specification": "62ad9bc72a62aa5591e3ff4b",
                "createdAt": "2022-03-10T13:31:46.187Z",
                "updatedAt": "2022-10-19T09:11:36.730Z",
                "__v": 0,
                "images": "public/category/1666170696730.1174.webp"
            },
            {
                "parent": "6229fdc25507127df692f42c",
                "status": true,
                "_id": "622aebc45507127df69304a7",
                "category_name": "Ajrakh Printed Dress Material",
                "specification": "6226f1605507127df692d431",
                "createdAt": "2022-03-11T06:27:16.654Z",
                "updatedAt": "2022-06-20T09:03:30.883Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "For daily use and comfortable office wear."
        ],
        "key_words": [
            ""
        ],
        "status": true,
        "featured": true,
        "publish": true,
        "_id": "6229d9d45507127df692f0f4",
        "meta_key": "suit material",
        "images": [
            "public/product/1646934404930.3887.webp"
        ],
        "sku": "P018",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "specification": [
            {
                "_id": "623759a9462a810f782271cc",
                "title": "Material",
                "value": "Cotton",
                "suffix": ""
            },
            {
                "_id": "623759a9462a810f782271cd",
                "title": "Colour",
                "value": "Green with pink florals",
                "suffix": ""
            }
        ],
        "createdAt": "2022-03-10T10:58:28.622Z",
        "updatedAt": "2022-09-06T10:50:10.322Z",
        "__v": 0,
        "description": "Ajrakh Cotton  Printed Dress Material",
        "display_date": null,
        "hsn_code": "5308",
        "min_order_qty": 1,
        "mrp": 1800,
        "sp": 1500,
        "stock": 0,
        "tax": null,
        "meta_desc": "Fabric for salwar top and bottom",
        "note": "Top Material is 2.5 metres/Bottom is 2.5 metres with cotton mulmul dupatta of 2 metres.<div><br></div><div>Care Instructions:</div><div>Kindly hand wash for first wash and iron for each use to get best results.</div>",
        "delivery_days": 7
    },
    {
        "packing_detail": {
            "weight": 0.75,
            "length": 30.5,
            "breadth": 30.5,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6229fdc25507127df692f42c",
                "category_name": "Womans wear",
                "specification": "62ad9bc72a62aa5591e3ff4b",
                "createdAt": "2022-03-10T13:31:46.187Z",
                "updatedAt": "2022-10-19T09:11:36.730Z",
                "__v": 0,
                "images": "public/category/1666170696730.1174.webp"
            },
            {
                "parent": "6229fdc25507127df692f42c",
                "status": true,
                "_id": "622aebc45507127df69304a7",
                "category_name": "Ajrakh Printed Dress Material",
                "specification": "6226f1605507127df692d431",
                "createdAt": "2022-03-11T06:27:16.654Z",
                "updatedAt": "2022-06-20T09:03:30.883Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Comfortable for home and office wear"
        ],
        "key_words": [
            ""
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "6229da675507127df692f11a",
        "meta_key": "suit maerial",
        "images": [
            "public/product/1646910473062.4912.webp"
        ],
        "sku": "P019",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "specification": [
            {
                "_id": "62375834462a810f78227159",
                "title": "Material",
                "value": "Cotton",
                "suffix": ""
            },
            {
                "_id": "62375834462a810f7822715a",
                "title": "Colour",
                "value": "Yellow with pink and green florals",
                "suffix": ""
            }
        ],
        "createdAt": "2022-03-10T11:00:55.677Z",
        "updatedAt": "2022-06-17T06:21:55.582Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Yellow ajrakh print Dress Material",
        "display_date": null,
        "hsn_code": "5308",
        "min_order_qty": 1,
        "mrp": 1800,
        "sp": 1500,
        "stock": 0,
        "tax": null,
        "meta_desc": "Salwar material for top and bottom",
        "note": "First wash to be hand washed.Iron for best results.<div>Top is 2.5 metres with 2.5 metres bottom and 2 metre mulmul duppatta.</div>"
    },
    {
        "packing_detail": {
            "weight": 1,
            "length": 30.5,
            "breadth": 30.5,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6229fdc25507127df692f42c",
                "category_name": "Womans wear",
                "specification": "62ad9bc72a62aa5591e3ff4b",
                "createdAt": "2022-03-10T13:31:46.187Z",
                "updatedAt": "2022-10-19T09:11:36.730Z",
                "__v": 0,
                "images": "public/category/1666170696730.1174.webp"
            },
            {
                "parent": "6229fdc25507127df692f42c",
                "status": true,
                "_id": "622aebc45507127df69304a7",
                "category_name": "Ajrakh Printed Dress Material",
                "specification": "6226f1605507127df692d431",
                "createdAt": "2022-03-11T06:27:16.654Z",
                "updatedAt": "2022-06-20T09:03:30.883Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Comfortable to wear",
            "Great to beat the summer"
        ],
        "key_words": [
            ""
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "6229dc435507127df692f1ae",
        "meta_key": "suit material",
        "images": [
            "public/product/1646910998462.4446.webp"
        ],
        "sku": "P020",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "specification": [
            {
                "_id": "62375afc462a810f78227222",
                "title": "Material",
                "value": "Cotton",
                "suffix": ""
            },
            {
                "_id": "62375afc462a810f78227223",
                "title": "Colour",
                "value": "Dark Green",
                "suffix": ""
            }
        ],
        "createdAt": "2022-03-10T11:08:51.414Z",
        "updatedAt": "2022-06-17T06:22:58.139Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Dark Green Ajrakh Print Dress Material",
        "display_date": null,
        "hsn_code": "5308",
        "min_order_qty": 1,
        "mrp": 1800,
        "sp": 1500,
        "stock": 0,
        "tax": null,
        "meta_desc": "Salwar top and bottom fabric",
        "note": "Top is 2.5 metres with 44&#34;width,bottom is 2.5 metres and mulmul duppatta of 2 metres.<div>First wash to be hand washed.Starch and iron for best results</div>"
    },
    {
        "packing_detail": {
            "weight": 1,
            "length": 30.5,
            "breadth": 30.5,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6229fdc25507127df692f42c",
                "category_name": "Womans wear",
                "specification": "62ad9bc72a62aa5591e3ff4b",
                "createdAt": "2022-03-10T13:31:46.187Z",
                "updatedAt": "2022-10-19T09:11:36.730Z",
                "__v": 0,
                "images": "public/category/1666170696730.1174.webp"
            },
            {
                "parent": "6229fdc25507127df692f42c",
                "status": true,
                "_id": "622aebc45507127df69304a7",
                "category_name": "Ajrakh Printed Dress Material",
                "specification": "6226f1605507127df692d431",
                "createdAt": "2022-03-11T06:27:16.654Z",
                "updatedAt": "2022-06-20T09:03:30.883Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "comfortable for summer wear"
        ],
        "key_words": [
            ""
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "6229dfca5507127df692f1d8",
        "meta_key": "Suit dress material",
        "images": [
            "public/product/1646916464717.9407.webp"
        ],
        "sku": "P021",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "specification": [
            {
                "_id": "62375c4f462a810f78227242",
                "title": "Material",
                "value": "Cotton",
                "suffix": ""
            },
            {
                "_id": "62375c4f462a810f78227243",
                "title": "Colour",
                "value": "Green",
                "suffix": ""
            }
        ],
        "createdAt": "2022-03-10T11:23:54.556Z",
        "updatedAt": "2022-06-17T06:24:07.712Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Light Green Ajrakh Print Dress Material",
        "display_date": null,
        "hsn_code": "5308",
        "min_order_qty": 1,
        "mrp": 1800,
        "sp": 1500,
        "stock": 0,
        "tax": null,
        "meta_desc": "Salwar top and bottom material",
        "note": "First wash to be hand washed.Starch and iron.<div>Top is 2.5 metres with a width of 44&#34;,bottom is 2.5 m and a mulmul dupatta of 2 m</div>"
    },
    {
        "packing_detail": {
            "weight": 0.75,
            "length": 30.5,
            "breadth": 30.5,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6229fdc25507127df692f42c",
                "category_name": "Womans wear",
                "specification": "62ad9bc72a62aa5591e3ff4b",
                "createdAt": "2022-03-10T13:31:46.187Z",
                "updatedAt": "2022-10-19T09:11:36.730Z",
                "__v": 0,
                "images": "public/category/1666170696730.1174.webp"
            },
            {
                "parent": "6229fdc25507127df692f42c",
                "status": true,
                "_id": "622aebc45507127df69304a7",
                "category_name": "Ajrakh Printed Dress Material",
                "specification": "6226f1605507127df692d431",
                "createdAt": "2022-03-11T06:27:16.654Z",
                "updatedAt": "2022-06-20T09:03:30.883Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Comfortable and colourful to wear"
        ],
        "key_words": [
            ""
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "6229e18d5507127df692f1e8",
        "meta_key": "suit material",
        "images": [
            "public/product/1646916382161.3755.webp"
        ],
        "sku": "P022",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "specification": [
            {
                "_id": "62375d95462a810f78227268",
                "title": "Material",
                "value": "Cotton",
                "suffix": ""
            },
            {
                "_id": "62375d95462a810f78227269",
                "title": "Colour",
                "value": "Blue and Yellow",
                "suffix": ""
            }
        ],
        "createdAt": "2022-03-10T11:31:25.338Z",
        "updatedAt": "2022-06-17T06:26:11.049Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Ajrakh Dress Material In Blue And Yellow",
        "display_date": null,
        "hsn_code": "5208",
        "min_order_qty": 1,
        "mrp": 1800,
        "sp": 1500,
        "stock": 0,
        "tax": null,
        "meta_desc": "Salwar Top and bottom material",
        "note": "First wash hand wash .Starch and iron.<div>Top is 2.5 metres in 44&#34;width and bottom is 2.5 m with a mulmul dupatta of 2 m</div>"
    },
    {
        "packing_detail": {
            "weight": 0.75,
            "length": 30.5,
            "breadth": 30.5,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6229fdc25507127df692f42c",
                "category_name": "Womans wear",
                "specification": "62ad9bc72a62aa5591e3ff4b",
                "createdAt": "2022-03-10T13:31:46.187Z",
                "updatedAt": "2022-10-19T09:11:36.730Z",
                "__v": 0,
                "images": "public/category/1666170696730.1174.webp"
            },
            {
                "parent": "6229fdc25507127df692f42c",
                "status": true,
                "_id": "622aebc45507127df69304a7",
                "category_name": "Ajrakh Printed Dress Material",
                "specification": "6226f1605507127df692d431",
                "createdAt": "2022-03-11T06:27:16.654Z",
                "updatedAt": "2022-06-20T09:03:30.883Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Most comfotable for summer",
            "Lovely floral prints bright and eye catchy",
            "Grey bottam with zig zag lines to contrast the top"
        ],
        "key_words": [
            ""
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "6229ecb65507127df692f249",
        "meta_key": "Salwar suit material",
        "images": [
            "public/product/1646914924067.803.webp"
        ],
        "sku": "P023",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "specification": [
            {
                "_id": "62375faa462a810f7822728e",
                "title": "Material",
                "value": "Cotton",
                "suffix": ""
            },
            {
                "_id": "62375faa462a810f7822728f",
                "title": "Colour",
                "value": "Dark yellow with grey combination",
                "suffix": ""
            }
        ],
        "createdAt": "2022-03-10T12:19:02.503Z",
        "updatedAt": "2022-06-17T06:27:26.031Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Dark yellow and grey combined Ajrakh Print Dress Material",
        "display_date": null,
        "hsn_code": "5208",
        "min_order_qty": 1,
        "mrp": 1800,
        "sp": 1500,
        "stock": 0,
        "tax": null,
        "meta_desc": "Salwar top and bottom material",
        "note": "Top is 2.5 metres in a 44&#34;width,bottom is 2.5 m and accompanied by a 2 m mulmul dupatta.<div>Hand wash first wash,iron and get best results.</div>"
    },
    {
        "packing_detail": {
            "weight": 0.75,
            "length": 30.5,
            "breadth": 30.5,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6229fdc25507127df692f42c",
                "category_name": "Womans wear",
                "specification": "62ad9bc72a62aa5591e3ff4b",
                "createdAt": "2022-03-10T13:31:46.187Z",
                "updatedAt": "2022-10-19T09:11:36.730Z",
                "__v": 0,
                "images": "public/category/1666170696730.1174.webp"
            },
            {
                "parent": "6229fdc25507127df692f42c",
                "status": true,
                "_id": "622aebc45507127df69304a7",
                "category_name": "Ajrakh Printed Dress Material",
                "specification": "6226f1605507127df692d431",
                "createdAt": "2022-03-11T06:27:16.654Z",
                "updatedAt": "2022-06-20T09:03:30.883Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Comfortable for daily use.",
            "Blue floral top with yellow bottam with zig zag lines"
        ],
        "key_words": [
            ""
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "6229ee835507127df692f259",
        "meta_key": "Salwar suit material",
        "images": [
            "public/product/1646915511623.8005.webp"
        ],
        "sku": "P024",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "specification": [
            {
                "_id": "623acb1c1d83b224a0468750",
                "title": "Material",
                "value": "Cotton",
                "suffix": ""
            },
            {
                "_id": "623acb1c1d83b224a0468751",
                "title": "Colour",
                "value": "Navy blue and yellow",
                "suffix": ""
            }
        ],
        "createdAt": "2022-03-10T12:26:43.978Z",
        "updatedAt": "2022-06-17T06:28:19.343Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Navy Blue and Yellow combined Ajrakh Dress Material",
        "display_date": null,
        "hsn_code": "5208",
        "min_order_qty": 1,
        "mrp": 1800,
        "sp": 1500,
        "stock": 0,
        "tax": null,
        "meta_desc": "Salwar top and bottom material",
        "note": "Top material is 2.5 metres with 44&#34;width with bottam 2.5 m and a dupatta of mulmul material measuring 2 m.<div>Hand wash first wash and starch and iron for best results.</div>"
    },
    {
        "packing_detail": {
            "weight": 0.5,
            "length": 31,
            "breadth": 31,
            "height": 6
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6229fdc25507127df692f42c",
                "category_name": "Womans wear",
                "specification": "62ad9bc72a62aa5591e3ff4b",
                "createdAt": "2022-03-10T13:31:46.187Z",
                "updatedAt": "2022-10-19T09:11:36.730Z",
                "__v": 0,
                "images": "public/category/1666170696730.1174.webp"
            },
            {
                "parent": "6229fdc25507127df692f42c",
                "status": true,
                "_id": "622aead65507127df6930448",
                "category_name": "Sarees",
                "specification": "6226f3685507127df692d451",
                "createdAt": "2022-03-11T06:23:18.232Z",
                "updatedAt": "2022-06-20T09:03:24.617Z",
                "__v": 0,
                "images": null
            },
            {
                "parent": "622aead65507127df6930448",
                "status": true,
                "_id": "622c41d28bc4af4c77b203e9",
                "category_name": "Chettinad Cotton Sarees",
                "specification": "6226f3685507127df692d451",
                "createdAt": "2022-03-12T06:46:42.879Z",
                "updatedAt": "2022-03-12T06:46:42.879Z",
                "__v": 0
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Great Evening wear",
            " Temple wear ",
            "To give you a grand  and traditional look",
            "Light to wear",
            "Running blouse attached"
        ],
        "key_words": [
            "Cotton saress"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "622c42338bc4af4c77b20417",
        "images": [
            "public/product/1647067890041.4885.webp"
        ],
        "sku": "P028",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "specification": [
            {
                "_id": "622c43c58bc4af4c77b2046d",
                "title": "Material",
                "value": "Cotton and silk mixed",
                "suffix": ""
            },
            {
                "_id": "622c43c58bc4af4c77b2046e",
                "title": "Colour",
                "value": "Red",
                "suffix": ""
            },
            {
                "_id": "622c43c58bc4af4c77b2046f",
                "title": "Blouse",
                "value": "Orange and Yellow mixed",
                "suffix": ""
            }
        ],
        "createdAt": "2022-03-12T06:48:19.845Z",
        "updatedAt": "2022-06-17T06:51:08.716Z",
        "__v": 0,
        "description": "Chettinad Cotton Saree with golden zari border",
        "display_date": null,
        "hsn_code": "5208",
        "min_order_qty": 1,
        "mrp": 3000,
        "sp": 2500,
        "stock": 0,
        "tax": null,
        "meta_desc": "Cotton sarees",
        "note": "Care instructions:<div>Home /Hand wash with starch and iron for best results.</div><div>Dry in the shade</div>",
        "delivery_days": 7
    },
    {
        "packing_detail": {
            "weight": 0.6,
            "length": 31,
            "breadth": 31,
            "height": 6
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6229fdc25507127df692f42c",
                "category_name": "Womans wear",
                "specification": "62ad9bc72a62aa5591e3ff4b",
                "createdAt": "2022-03-10T13:31:46.187Z",
                "updatedAt": "2022-10-19T09:11:36.730Z",
                "__v": 0,
                "images": "public/category/1666170696730.1174.webp"
            },
            {
                "parent": "6229fdc25507127df692f42c",
                "status": true,
                "_id": "622aead65507127df6930448",
                "category_name": "Sarees",
                "specification": "6226f3685507127df692d451",
                "createdAt": "2022-03-11T06:23:18.232Z",
                "updatedAt": "2022-06-20T09:03:24.617Z",
                "__v": 0,
                "images": null
            },
            {
                "parent": "622aead65507127df6930448",
                "status": true,
                "_id": "622c41d28bc4af4c77b203e9",
                "category_name": "Chettinad Cotton Sarees",
                "specification": "6226f3685507127df692d451",
                "createdAt": "2022-03-12T06:46:42.879Z",
                "updatedAt": "2022-03-12T06:46:42.879Z",
                "__v": 0
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Stunning saree for any occassion",
            ""
        ],
        "key_words": [],
        "status": true,
        "featured": true,
        "publish": true,
        "_id": "622e09548bc4af4c77b20609",
        "images": [
            "public/product/1647184906966.9404.webp"
        ],
        "sku": "P029",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "specification": [
            {
                "_id": "622e12a68bc4af4c77b20643",
                "title": "Material",
                "value": "Cotton of highest count",
                "suffix": ""
            },
            {
                "_id": "622e12a68bc4af4c77b20644",
                "title": "Colour",
                "value": "Black and red",
                "suffix": ""
            },
            {
                "_id": "622e12a68bc4af4c77b20645",
                "title": "Blouse",
                "value": "Red With Stripes",
                "suffix": ""
            }
        ],
        "createdAt": "2022-03-13T15:10:12.551Z",
        "updatedAt": "2022-09-09T09:03:09.016Z",
        "__v": 0,
        "description": "Chettinad cotton saree in ikkat print",
        "display_date": null,
        "hsn_code": "5208",
        "min_order_qty": 1,
        "mrp": 7000,
        "sp": 6000,
        "stock": 0,
        "tax": null,
        "meta_desc": "Saree",
        "note": "<div>Saree with attached blouse</div>Care Instructions:<div>Dry wash first wash and then home wash with starch.</div>",
        "delivery_days": 7
    },
    {
        "packing_detail": {
            "weight": 0.6,
            "length": 31,
            "breadth": 31,
            "height": 6
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6229fdc25507127df692f42c",
                "category_name": "Womans wear",
                "specification": "62ad9bc72a62aa5591e3ff4b",
                "createdAt": "2022-03-10T13:31:46.187Z",
                "updatedAt": "2022-10-19T09:11:36.730Z",
                "__v": 0,
                "images": "public/category/1666170696730.1174.webp"
            },
            {
                "parent": "6229fdc25507127df692f42c",
                "status": true,
                "_id": "622aead65507127df6930448",
                "category_name": "Sarees",
                "specification": "6226f3685507127df692d451",
                "createdAt": "2022-03-11T06:23:18.232Z",
                "updatedAt": "2022-06-20T09:03:24.617Z",
                "__v": 0,
                "images": null
            },
            {
                "parent": "622aead65507127df6930448",
                "status": true,
                "_id": "622c41d28bc4af4c77b203e9",
                "category_name": "Chettinad Cotton Sarees",
                "specification": "6226f3685507127df692d451",
                "createdAt": "2022-03-12T06:46:42.879Z",
                "updatedAt": "2022-03-12T06:46:42.879Z",
                "__v": 0
            }
        ],
        "pricestatus": false,
        "highlight": [
            "For all occassions",
            "Light to wear",
            "Mix and match blouse"
        ],
        "key_words": [
            ""
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "622e1bc98bc4af4c77b20680",
        "meta_key": "chettinad cotton",
        "images": [
            "public/product/1647189172382.502.webp"
        ],
        "sku": "P030",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "specification": [
            {
                "_id": "622e203b8bc4af4c77b2069e",
                "title": "Material",
                "value": "Cotton",
                "suffix": ""
            },
            {
                "_id": "622e203b8bc4af4c77b2069f",
                "title": "Colour",
                "value": "Parrot green",
                "suffix": ""
            },
            {
                "_id": "622e203b8bc4af4c77b206a0",
                "title": "Blouse",
                "value": "Match your own blouse",
                "suffix": ""
            }
        ],
        "createdAt": "2022-03-13T16:28:57.235Z",
        "updatedAt": "2022-06-17T06:54:29.313Z",
        "__v": 0,
        "description": "Chettinad cotton saree ",
        "display_date": null,
        "hsn_code": "5208",
        "min_order_qty": 1,
        "mrp": 2500,
        "sp": 2000,
        "stock": 0,
        "tax": null,
        "meta_desc": "Saree",
        "note": "Lovely colour combination .<div>Care Instruction:</div><div>Home wash but starch and iron for best reults</div>",
        "delivery_days": 7
    },
    {
        "packing_detail": {
            "weight": 0.5,
            "length": 31,
            "breadth": 31,
            "height": 6
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6229fdc25507127df692f42c",
                "category_name": "Womans wear",
                "specification": "62ad9bc72a62aa5591e3ff4b",
                "createdAt": "2022-03-10T13:31:46.187Z",
                "updatedAt": "2022-10-19T09:11:36.730Z",
                "__v": 0,
                "images": "public/category/1666170696730.1174.webp"
            },
            {
                "parent": "6229fdc25507127df692f42c",
                "status": true,
                "_id": "622aead65507127df6930448",
                "category_name": "Sarees",
                "specification": "6226f3685507127df692d451",
                "createdAt": "2022-03-11T06:23:18.232Z",
                "updatedAt": "2022-06-20T09:03:24.617Z",
                "__v": 0,
                "images": null
            },
            {
                "parent": "622aead65507127df6930448",
                "status": true,
                "_id": "622c41d28bc4af4c77b203e9",
                "category_name": "Chettinad Cotton Sarees",
                "specification": "6226f3685507127df692d451",
                "createdAt": "2022-03-12T06:46:42.879Z",
                "updatedAt": "2022-03-12T06:46:42.879Z",
                "__v": 0
            }
        ],
        "pricestatus": false,
        "highlight": [
            "For all occassions casual or Trendy",
            "The traditional wear",
            "Light to wear"
        ],
        "key_words": [
            ""
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "622e213c8bc4af4c77b206b1",
        "meta_key": "chettinad cotton",
        "images": [
            "public/product/1647190502278.0605.webp"
        ],
        "sku": "P031",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "specification": [
            {
                "_id": "622e224e8bc4af4c77b206cf",
                "title": "Material",
                "value": "Cotton",
                "suffix": ""
            },
            {
                "_id": "622e224e8bc4af4c77b206d0",
                "title": "Colour",
                "value": "Green and yellow mixed",
                "suffix": ""
            },
            {
                "_id": "622e224e8bc4af4c77b206d1",
                "title": "Blouse",
                "value": "Match your own blouse",
                "suffix": ""
            }
        ],
        "createdAt": "2022-03-13T16:52:12.722Z",
        "updatedAt": "2022-06-17T06:55:18.907Z",
        "__v": 0,
        "description": "Chettinad Cotton Saree",
        "display_date": null,
        "hsn_code": "5208",
        "min_order_qty": 1,
        "mrp": 2500,
        "sp": 2000,
        "stock": 0,
        "tax": null,
        "meta_desc": "Saree",
        "note": "Care Instructions:<div>Home wash with starch and iron for best reults.</div>",
        "delivery_days": 7
    },
    {
        "packing_detail": {
            "weight": 0.5,
            "length": 31,
            "breadth": 31,
            "height": 6
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6229fdc25507127df692f42c",
                "category_name": "Womans wear",
                "specification": "62ad9bc72a62aa5591e3ff4b",
                "createdAt": "2022-03-10T13:31:46.187Z",
                "updatedAt": "2022-10-19T09:11:36.730Z",
                "__v": 0,
                "images": "public/category/1666170696730.1174.webp"
            },
            {
                "parent": "6229fdc25507127df692f42c",
                "status": true,
                "_id": "622aead65507127df6930448",
                "category_name": "Sarees",
                "specification": "6226f3685507127df692d451",
                "createdAt": "2022-03-11T06:23:18.232Z",
                "updatedAt": "2022-06-20T09:03:24.617Z",
                "__v": 0,
                "images": null
            },
            {
                "parent": "622aead65507127df6930448",
                "status": true,
                "_id": "622c41d28bc4af4c77b203e9",
                "category_name": "Chettinad Cotton Sarees",
                "specification": "6226f3685507127df692d451",
                "createdAt": "2022-03-12T06:46:42.879Z",
                "updatedAt": "2022-03-12T06:46:42.879Z",
                "__v": 0
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Ethnic to wear for all events",
            "Light Weight"
        ],
        "key_words": [],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "622e234b8bc4af4c77b206e2",
        "images": [
            "public/product/1647191194653.0493.webp"
        ],
        "sku": "P032",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "specification": [
            {
                "_id": "622e25698bc4af4c77b20700",
                "title": "Material",
                "value": "Cotton and silk mixed",
                "suffix": ""
            },
            {
                "_id": "622e25698bc4af4c77b20701",
                "title": "Colour",
                "value": "Baby pink",
                "suffix": ""
            },
            {
                "_id": "622e25698bc4af4c77b20702",
                "title": "Blouse",
                "value": " Attached blouse of Light sandal wood colour with mild checks and zari",
                "suffix": ""
            }
        ],
        "createdAt": "2022-03-13T17:00:59.862Z",
        "updatedAt": "2022-06-17T06:56:50.664Z",
        "__v": 0,
        "description": "Simple yet grand chettinad cotton saree",
        "display_date": null,
        "hsn_code": "5208",
        "min_order_qty": 1,
        "mrp": 2500,
        "sp": 2000,
        "stock": 0,
        "tax": null,
        "meta_desc": "Saree",
        "note": "Care Instructions:<div>Dry clean for the first wash and then home wash using starch and iron before use</div>",
        "delivery_days": 7
    },
    {
        "packing_detail": {
            "weight": 0.5,
            "length": 31,
            "breadth": 31,
            "height": 6
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6229fdc25507127df692f42c",
                "category_name": "Womans wear",
                "specification": "62ad9bc72a62aa5591e3ff4b",
                "createdAt": "2022-03-10T13:31:46.187Z",
                "updatedAt": "2022-10-19T09:11:36.730Z",
                "__v": 0,
                "images": "public/category/1666170696730.1174.webp"
            },
            {
                "parent": "6229fdc25507127df692f42c",
                "status": true,
                "_id": "622aead65507127df6930448",
                "category_name": "Sarees",
                "specification": "6226f3685507127df692d451",
                "createdAt": "2022-03-11T06:23:18.232Z",
                "updatedAt": "2022-06-20T09:03:24.617Z",
                "__v": 0,
                "images": null
            },
            {
                "parent": "622aead65507127df6930448",
                "status": true,
                "_id": "622c41d28bc4af4c77b203e9",
                "category_name": "Chettinad Cotton Sarees",
                "specification": "6226f3685507127df692d451",
                "createdAt": "2022-03-12T06:46:42.879Z",
                "updatedAt": "2022-03-12T06:46:42.879Z",
                "__v": 0
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Trendy and traditional",
            "The contrast bloue is appealing",
            "For all ages"
        ],
        "key_words": [
            ""
        ],
        "status": false,
        "featured": false,
        "publish": true,
        "_id": "622e26618bc4af4c77b20713",
        "meta_key": "chettinad cotton",
        "images": [
            "public/product/1647191810896.7922.webp"
        ],
        "sku": "P033",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "specification": [
            {
                "_id": "622e28258bc4af4c77b20731",
                "title": "Material",
                "value": "Cotton with mild silk mixed",
                "suffix": ""
            },
            {
                "_id": "622e28258bc4af4c77b20732",
                "title": "Colour",
                "value": "Parrot green",
                "suffix": ""
            },
            {
                "_id": "622e28258bc4af4c77b20733",
                "title": "Blouse",
                "value": "Attached contrast purple blouse",
                "suffix": ""
            }
        ],
        "createdAt": "2022-03-13T17:14:09.402Z",
        "updatedAt": "2022-07-27T08:27:43.044Z",
        "__v": 0,
        "description": "Chettinad cotton with mild zari",
        "display_date": null,
        "hsn_code": "5208",
        "min_order_qty": 1,
        "mrp": 3000,
        "sp": 2500,
        "stock": 0,
        "tax": null,
        "meta_desc": "Sarees",
        "note": "Care Instructions:<div>First wash to be dry cleaned followed by home washes wth starch and ironing for best results.</div>",
        "delivery_days": 7
    },
    {
        "packing_detail": {
            "weight": 0.5,
            "length": 31,
            "breadth": 31,
            "height": 6
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6229fdc25507127df692f42c",
                "category_name": "Womans wear",
                "specification": "62ad9bc72a62aa5591e3ff4b",
                "createdAt": "2022-03-10T13:31:46.187Z",
                "updatedAt": "2022-10-19T09:11:36.730Z",
                "__v": 0,
                "images": "public/category/1666170696730.1174.webp"
            },
            {
                "parent": "6229fdc25507127df692f42c",
                "status": true,
                "_id": "622aead65507127df6930448",
                "category_name": "Sarees",
                "specification": "6226f3685507127df692d451",
                "createdAt": "2022-03-11T06:23:18.232Z",
                "updatedAt": "2022-06-20T09:03:24.617Z",
                "__v": 0,
                "images": null
            },
            {
                "parent": "622aead65507127df6930448",
                "status": true,
                "_id": "622c41d28bc4af4c77b203e9",
                "category_name": "Chettinad Cotton Sarees",
                "specification": "6226f3685507127df692d451",
                "createdAt": "2022-03-12T06:46:42.879Z",
                "updatedAt": "2022-03-12T06:46:42.879Z",
                "__v": 0
            }
        ],
        "pricestatus": false,
        "highlight": [
            "All age groups can carry it",
            "Traditional "
        ],
        "key_words": [
            ""
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "622e29498bc4af4c77b20744",
        "meta_key": "chettinad cotton",
        "images": [
            "public/product/1647192474162.6873.webp"
        ],
        "sku": "P034",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "specification": [
            {
                "_id": "623b1a671d83b224a0469453",
                "title": "Material",
                "value": "Pure Handloom cotton",
                "suffix": ""
            },
            {
                "_id": "623b1a671d83b224a0469454",
                "title": "Colour",
                "value": "Black",
                "suffix": ""
            },
            {
                "_id": "623b1a671d83b224a0469455",
                "title": "Blouse",
                "value": "Mix and match any blouse",
                "suffix": ""
            }
        ],
        "createdAt": "2022-03-13T17:26:33.153Z",
        "updatedAt": "2022-06-17T07:04:16.153Z",
        "__v": 0,
        "description": "Traditional chettinad cotton saree",
        "display_date": null,
        "hsn_code": "5208",
        "min_order_qty": 1,
        "mrp": 2000,
        "sp": 1800,
        "stock": 0,
        "tax": null,
        "meta_desc": "Saree",
        "note": "Care instructions:<div>Home wash and starch and iron before use</div>",
        "delivery_days": 7
    },
    {
        "packing_detail": {
            "weight": 0.5,
            "length": 31,
            "breadth": 31,
            "height": 6
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6229fdc25507127df692f42c",
                "category_name": "Womans wear",
                "specification": "62ad9bc72a62aa5591e3ff4b",
                "createdAt": "2022-03-10T13:31:46.187Z",
                "updatedAt": "2022-10-19T09:11:36.730Z",
                "__v": 0,
                "images": "public/category/1666170696730.1174.webp"
            },
            {
                "parent": "6229fdc25507127df692f42c",
                "status": true,
                "_id": "622aead65507127df6930448",
                "category_name": "Sarees",
                "specification": "6226f3685507127df692d451",
                "createdAt": "2022-03-11T06:23:18.232Z",
                "updatedAt": "2022-06-20T09:03:24.617Z",
                "__v": 0,
                "images": null
            },
            {
                "parent": "622aead65507127df6930448",
                "status": true,
                "_id": "622c41d28bc4af4c77b203e9",
                "category_name": "Chettinad Cotton Sarees",
                "specification": "6226f3685507127df692d451",
                "createdAt": "2022-03-12T06:46:42.879Z",
                "updatedAt": "2022-03-12T06:46:42.879Z",
                "__v": 0
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Prefferred by the older generation for daily use",
            "Great summer wear",
            ""
        ],
        "key_words": [
            ""
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "622e2b128bc4af4c77b207b0",
        "meta_key": "chettinad cotton",
        "images": [
            "public/product/1647193015267.939.webp"
        ],
        "sku": "P035",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "specification": [
            {
                "_id": "622e2c338bc4af4c77b207ce",
                "title": "Material",
                "value": "Pure cotton",
                "suffix": ""
            },
            {
                "_id": "622e2c338bc4af4c77b207cf",
                "title": "Colour",
                "value": "Grey and mild pink combination",
                "suffix": ""
            },
            {
                "_id": "622e2c338bc4af4c77b207d0",
                "title": "Blouse",
                "value": "Mix and match any blouse of your choice",
                "suffix": ""
            }
        ],
        "createdAt": "2022-03-13T17:34:10.817Z",
        "updatedAt": "2022-06-17T07:05:06.774Z",
        "__v": 0,
        "description": "Chettinad Cotton",
        "display_date": null,
        "hsn_code": "5208",
        "min_order_qty": 1,
        "mrp": 1700,
        "sp": 1500,
        "stock": 0,
        "tax": null,
        "meta_desc": "Saree",
        "note": "Care Instructions:<div>Home wash /starch and iron</div>",
        "delivery_days": 7
    },
    {
        "packing_detail": {
            "weight": 0.5,
            "length": 31,
            "breadth": 31,
            "height": 5
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6229fdc25507127df692f42c",
                "category_name": "Womans wear",
                "specification": "62ad9bc72a62aa5591e3ff4b",
                "createdAt": "2022-03-10T13:31:46.187Z",
                "updatedAt": "2022-10-19T09:11:36.730Z",
                "__v": 0,
                "images": "public/category/1666170696730.1174.webp"
            },
            {
                "parent": "6229fdc25507127df692f42c",
                "status": true,
                "_id": "622aead65507127df6930448",
                "category_name": "Sarees",
                "specification": "6226f3685507127df692d451",
                "createdAt": "2022-03-11T06:23:18.232Z",
                "updatedAt": "2022-06-20T09:03:24.617Z",
                "__v": 0,
                "images": null
            },
            {
                "parent": "622aead65507127df6930448",
                "status": true,
                "_id": "622c41d28bc4af4c77b203e9",
                "category_name": "Chettinad Cotton Sarees",
                "specification": "6226f3685507127df692d451",
                "createdAt": "2022-03-12T06:46:42.879Z",
                "updatedAt": "2022-03-12T06:46:42.879Z",
                "__v": 0
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Great for summer",
            "Traditional look"
        ],
        "key_words": [
            ""
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "6232000d434e6366c9fdab98",
        "meta_key": "Chettinad Cotton",
        "images": [
            "public/product/1647444585402.354.webp"
        ],
        "sku": "P042",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "specification": [
            {
                "_id": "62320303434e6366c9fdabbd",
                "title": "Material",
                "value": "Cotton and silk mixed",
                "suffix": ""
            },
            {
                "_id": "62320303434e6366c9fdabbe",
                "title": "Colour",
                "value": "Red",
                "suffix": ""
            },
            {
                "_id": "62320303434e6366c9fdabbf",
                "title": "Blouse",
                "value": "Orange contrast with zari",
                "suffix": ""
            }
        ],
        "createdAt": "2022-03-16T15:19:41.788Z",
        "updatedAt": "2022-06-17T06:48:51.873Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Chettinad cotton with silk mixed and zari border",
        "display_date": null,
        "hsn_code": "5208",
        "min_order_qty": 1,
        "mrp": 2500,
        "sp": 2300,
        "stock": 0,
        "tax": null,
        "meta_desc": "Sarees",
        "note": "Care Instructions:<div>First wash to be dry cleaned and then home wash ,starch and iron for best results.</div>"
    },
    {
        "packing_detail": {
            "weight": 0.25,
            "length": 31,
            "breadth": 31,
            "height": 2
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 100,
            "national": 100
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6225aa6c5507127df692d326",
                "category_name": "Wedding hand bags",
                "createdAt": "2022-03-07T06:47:08.299Z",
                "updatedAt": "2022-10-19T09:11:12.613Z",
                "__v": 0,
                "images": "public/category/1666170672612.1301.webp",
                "specification": null
            },
            {
                "parent": "6225aa6c5507127df692d326",
                "status": true,
                "_id": "6225aa0b5507127df692d314",
                "category_name": "Surukku Bags",
                "createdAt": "2022-03-07T06:45:31.847Z",
                "updatedAt": "2022-10-19T09:11:03.348Z",
                "__v": 0,
                "images": "public/category/1666170663347.396.webp",
                "specification": "6226f5ec5507127df692d460"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Trendy to carry to weddings and temples.",
            "Can hold your mobile,cash and other personal accessories",
            "9\"*8*(in inches when open)"
        ],
        "key_words": [
            ""
        ],
        "status": false,
        "featured": false,
        "publish": true,
        "_id": "62346215462a810f78226675",
        "images": [
            "public/product/1647711116783.954.webp"
        ],
        "sku": "P045",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "specification": [
            {
                "_id": "62b6e3482a62aa5591e4cf5a",
                "title": "Material",
                "value": "Silk",
                "suffix": ""
            },
            {
                "_id": "62b6e3482a62aa5591e4cf5b",
                "title": "Colour",
                "value": "Off White",
                "suffix": ""
            },
            {
                "_id": "62b6e3482a62aa5591e4cf5c",
                "title": "Size",
                "value": "8.5 X 8.5 (In Inches)",
                "suffix": ""
            }
        ],
        "createdAt": "2022-03-18T10:42:29.517Z",
        "updatedAt": "2022-06-29T10:29:12.277Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Embroided Surukku Bag",
        "display_date": null,
        "hsn_code": "6305",
        "min_order_qty": 1,
        "mrp": 800,
        "sp": 750,
        "stock": 0,
        "tax": {
            "status": true,
            "_id": "61f7dde28d37e6262ba17c80",
            "tax_name": "GST_18",
            "tax_percentage": 18,
            "__v": 0
        },
        "meta_desc": "surukku bag",
        "note": "Wash with Care."
    },
    {
        "packing_detail": {
            "weight": 0.25,
            "length": 26,
            "breadth": 15,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6225aa6c5507127df692d326",
                "category_name": "Wedding hand bags",
                "createdAt": "2022-03-07T06:47:08.299Z",
                "updatedAt": "2022-10-19T09:11:12.613Z",
                "__v": 0,
                "images": "public/category/1666170672612.1301.webp",
                "specification": null
            },
            {
                "parent": "6225aa6c5507127df692d326",
                "status": true,
                "_id": "62345cbc462a810f78226389",
                "category_name": "Clutch Hand Bags",
                "specification": "6227066b5507127df692d69c",
                "createdAt": "2022-03-18T10:19:40.691Z",
                "updatedAt": "2022-03-19T10:21:06.145Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Carry with your Grand wear"
        ],
        "key_words": [
            ""
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "6234b3cb462a810f78226b10",
        "meta_key": "Clutch bag",
        "images": [
            "public/product/1647621453439.912.webp"
        ],
        "sku": "P046",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "specification": [
            {
                "_id": "62b6e0912a62aa5591e4ce1a",
                "title": "Material",
                "value": "Silk",
                "suffix": ""
            },
            {
                "_id": "62b6e0912a62aa5591e4ce1b",
                "title": "Colour",
                "value": "Black",
                "suffix": ""
            },
            {
                "_id": "62b6e0912a62aa5591e4ce1c",
                "title": "Size",
                "value": "10 X 6 X 2 (In Inches)",
                "suffix": ""
            }
        ],
        "createdAt": "2022-03-18T16:31:07.295Z",
        "updatedAt": "2022-06-25T10:16:49.309Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Black Clutch Bag",
        "display_date": null,
        "hsn_code": "6305",
        "min_order_qty": 1,
        "mrp": 800,
        "sp": 790,
        "stock": 0,
        "tax": {
            "status": true,
            "_id": "61f7dde28d37e6262ba17c80",
            "tax_name": "GST_18",
            "tax_percentage": 18,
            "__v": 0
        },
        "meta_desc": "Purse",
        "note": "Provided with a an optional chain to sling on shoulder if needed."
    },
    {
        "packing_detail": {
            "weight": 0.25,
            "length": 30.5,
            "breadth": 30.5,
            "height": 2
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 100,
            "national": 100
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6225aa6c5507127df692d326",
                "category_name": "Wedding hand bags",
                "createdAt": "2022-03-07T06:47:08.299Z",
                "updatedAt": "2022-10-19T09:11:12.613Z",
                "__v": 0,
                "images": "public/category/1666170672612.1301.webp",
                "specification": null
            },
            {
                "parent": "6225aa6c5507127df692d326",
                "status": true,
                "_id": "62345cbc462a810f78226389",
                "category_name": "Clutch Hand Bags",
                "specification": "6227066b5507127df692d69c",
                "createdAt": "2022-03-18T10:19:40.691Z",
                "updatedAt": "2022-03-19T10:21:06.145Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Carry your accessories at parties and weddings"
        ],
        "key_words": [
            ""
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "6234b5a9462a810f78226b8b",
        "meta_key": "Clutch purse",
        "images": [
            "public/product/1647621747953.4285.webp"
        ],
        "sku": "P047",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "specification": [
            {
                "_id": "62b6e0bd2a62aa5591e4ce3b",
                "title": "Material",
                "value": "Silk",
                "suffix": ""
            },
            {
                "_id": "62b6e0bd2a62aa5591e4ce3c",
                "title": "Colour",
                "value": "Orange",
                "suffix": ""
            },
            {
                "_id": "62b6e0bd2a62aa5591e4ce3d",
                "title": "Size",
                "value": "10 X 6 X 2 (In Inches)",
                "suffix": ""
            }
        ],
        "createdAt": "2022-03-18T16:39:05.714Z",
        "updatedAt": "2022-06-25T10:17:33.829Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Orange Clutch Bag",
        "display_date": null,
        "hsn_code": "1234",
        "min_order_qty": 1,
        "mrp": 800,
        "sp": 790,
        "stock": 0,
        "tax": {
            "status": true,
            "_id": "6223313e5507127df692c355",
            "tax_name": "GST_0",
            "tax_percentage": 0,
            "description": "",
            "createdAt": "2022-03-05T09:45:34.291Z",
            "updatedAt": "2022-03-05T09:45:34.291Z",
            "__v": 0
        },
        "meta_desc": "Sling pouch",
        "note": "Provided with a chain to sling on to shoulder if needed."
    },
    {
        "packing_detail": {
            "weight": 0.2,
            "length": 31,
            "breadth": 31,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6225aa6c5507127df692d326",
                "category_name": "Wedding hand bags",
                "createdAt": "2022-03-07T06:47:08.299Z",
                "updatedAt": "2022-10-19T09:11:12.613Z",
                "__v": 0,
                "images": "public/category/1666170672612.1301.webp",
                "specification": null
            },
            {
                "parent": "6225aa6c5507127df692d326",
                "status": true,
                "_id": "62345cbc462a810f78226389",
                "category_name": "Clutch Hand Bags",
                "specification": "6227066b5507127df692d69c",
                "createdAt": "2022-03-18T10:19:40.691Z",
                "updatedAt": "2022-03-19T10:21:06.145Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "For weddings and parties",
            "Fancy chain with pearls",
            "Matches all outfits traditional or western"
        ],
        "key_words": [
            ""
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62360f47462a810f78226faf",
        "images": [
            "public/product/1647710201486.4988.webp"
        ],
        "sku": "P048",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "specification": [
            {
                "_id": "62b6e0dc2a62aa5591e4ce5c",
                "title": "Material",
                "value": "Silk with embroidery",
                "suffix": ""
            },
            {
                "_id": "62b6e0dc2a62aa5591e4ce5d",
                "title": "Colour",
                "value": "Off White",
                "suffix": ""
            },
            {
                "_id": "62b6e0dc2a62aa5591e4ce5e",
                "title": "Size",
                "value": "10 X 6 X 2 (In Inches)",
                "suffix": ""
            }
        ],
        "createdAt": "2022-03-19T17:13:43.376Z",
        "updatedAt": "2022-06-25T10:18:04.621Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Embroided White clutch with sling",
        "display_date": null,
        "hsn_code": "6305",
        "min_order_qty": 1,
        "mrp": 1500,
        "sp": 1350,
        "stock": 0,
        "tax": null,
        "meta_desc": "clutch bag",
        "note": ""
    },
    {
        "packing_detail": {
            "weight": 0.1,
            "length": 31,
            "breadth": 31,
            "height": 3
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6225aa7f5507127df692d32f",
                "category_name": " Mobile or Cell phone Pouches ",
                "createdAt": "2022-03-07T06:47:27.047Z",
                "updatedAt": "2022-10-19T09:11:23.410Z",
                "__v": 0,
                "images": "public/category/1666170683409.058.webp",
                "specification": null
            },
            {
                "parent": "6225aa7f5507127df692d32f",
                "status": true,
                "_id": "62345e60462a810f782264ea",
                "category_name": "Saree Mobile phone pouches",
                "createdAt": "2022-03-18T10:26:40.949Z",
                "updatedAt": "2022-03-18T10:31:06.762Z",
                "__v": 0,
                "images": null,
                "specification": "62345ef7462a810f78226517"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Ethnic to wear on your saree hip to be hands free"
        ],
        "key_words": [
            "Saree phone holder, mobile phone pouch"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "623c1f4a1d83b224a0469a19",
        "images": [
            "public/product/1656131911921.9868.webp"
        ],
        "sku": "P050",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "specification": [
            {
                "_id": "62b56c752a62aa5591e499bf",
                "title": "Material",
                "value": "Silk",
                "suffix": ""
            },
            {
                "_id": "62b56c752a62aa5591e499c0",
                "title": "Colour",
                "value": "Black",
                "suffix": ""
            },
            {
                "_id": "62b56c752a62aa5591e499c1",
                "title": "Size",
                "value": "7 X 4. 5 (In Inches)",
                "suffix": ""
            }
        ],
        "createdAt": "2022-03-24T07:35:38.623Z",
        "updatedAt": "2022-06-27T04:58:02.766Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Floral silk saree mobile pouch",
        "display_date": null,
        "hsn_code": "6305",
        "min_order_qty": 1,
        "mrp": 650,
        "sp": 600,
        "stock": 0,
        "tax": {
            "status": true,
            "_id": "61f7dde28d37e6262ba17c80",
            "tax_name": "GST_18",
            "tax_percentage": 18,
            "__v": 0
        },
        "meta_desc": "Saree phone holder, mobile phone pouch",
        "meta_key": "mobile phone pouch, Saree phone holder",
        "note": "Saree hook provided to hold yor mobile safely"
    },
    {
        "packing_detail": {
            "weight": 0.1,
            "length": 31,
            "breadth": 31,
            "height": 3
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6225aa7f5507127df692d32f",
                "category_name": " Mobile or Cell phone Pouches ",
                "createdAt": "2022-03-07T06:47:27.047Z",
                "updatedAt": "2022-10-19T09:11:23.410Z",
                "__v": 0,
                "images": "public/category/1666170683409.058.webp",
                "specification": null
            },
            {
                "parent": "6225aa7f5507127df692d32f",
                "status": true,
                "_id": "62345e60462a810f782264ea",
                "category_name": "Saree Mobile phone pouches",
                "createdAt": "2022-03-18T10:26:40.949Z",
                "updatedAt": "2022-03-18T10:31:06.762Z",
                "__v": 0,
                "images": null,
                "specification": "62345ef7462a810f78226517"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "For regular use.",
            "Hang it on your hip to carry your mobile and be hands free."
        ],
        "key_words": [
            ""
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "623c221b1d83b224a0469a73",
        "images": [
            "public/product/1648108452371.075.webp"
        ],
        "sku": "P051",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "specification": [
            {
                "_id": "623c230b1d83b224a0469a8f",
                "title": "Material",
                "value": "Cotton",
                "suffix": ""
            },
            {
                "_id": "623c230b1d83b224a0469a90",
                "title": "Colour",
                "value": "Black",
                "suffix": ""
            },
            {
                "_id": "623c230b1d83b224a0469a91",
                "title": "Size",
                "value": "6.5\"*4\"(in inches)",
                "suffix": ""
            }
        ],
        "createdAt": "2022-03-24T07:47:39.855Z",
        "updatedAt": "2022-06-17T06:00:25.555Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Black Saree mobile phone pouch with goddess face",
        "display_date": null,
        "hsn_code": "6305",
        "min_order_qty": 1,
        "mrp": 650,
        "sp": 600,
        "stock": 0,
        "tax": {
            "status": true,
            "_id": "61f7dde28d37e6262ba17c80",
            "tax_name": "GST_18",
            "tax_percentage": 18,
            "__v": 0
        },
        "meta_desc": "Saree phone pouch",
        "meta_key": "Mobile phone pouch",
        "note": ""
    },
    {
        "packing_detail": {
            "weight": 0.3,
            "length": 31,
            "breadth": 31,
            "height": 10
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6234634f462a810f782266a6",
                "category_name": "Paper Craft",
                "createdAt": "2022-03-18T10:47:43.637Z",
                "updatedAt": "2022-10-19T09:12:36.034Z",
                "__v": 0,
                "images": "public/category/1666170756033.8086.webp",
                "specification": null
            },
            {
                "parent": "6234634f462a810f782266a6",
                "status": true,
                "_id": "623c257c1d83b224a0469ae9",
                "category_name": "Desk top Holders",
                "createdAt": "2022-03-24T08:02:04.087Z",
                "updatedAt": "2022-03-24T10:31:44.555Z",
                "__v": 0,
                "images": null,
                "specification": "62321c97434e6366c9fdac36"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Great utility on on your desk.",
            "Best organiser."
        ],
        "key_words": [
            ""
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "623c3e641d83b224a0469e5a",
        "images": [
            "public/product/1648117471330.898.webp"
        ],
        "sku": "P052",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "specification": [
            {
                "_id": "62b6e1142a62aa5591e4ce8e",
                "title": "Material",
                "value": "Paper",
                "suffix": ""
            },
            {
                "_id": "62b6e1142a62aa5591e4ce8f",
                "title": "Colour",
                "value": "Blue marble painting",
                "suffix": ""
            },
            {
                "_id": "62b6e1142a62aa5591e4ce90",
                "title": "Size",
                "value": "5 X 5 X 4 (In Inches)",
                "suffix": ""
            }
        ],
        "createdAt": "2022-03-24T09:48:20.149Z",
        "updatedAt": "2022-06-25T10:19:00.326Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Blue Desk Top Holders",
        "display_date": null,
        "hsn_code": "3924",
        "min_order_qty": 1,
        "mrp": 800,
        "sp": 750,
        "stock": 0,
        "tax": {
            "status": true,
            "_id": "61f7dde28d37e6262ba17c80",
            "tax_name": "GST_18",
            "tax_percentage": 18,
            "__v": 0
        },
        "meta_desc": "Paper made products",
        "meta_key": "Hand made products",
        "note": "Marble Painted kraft paper used and desk top holder is wholly hand made.<div>Lovely and fancy handles for the miniature draws.</div>"
    },
    {
        "packing_detail": {
            "weight": 0.5,
            "length": 31,
            "breadth": 31,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6225aa6c5507127df692d326",
                "category_name": "Wedding hand bags",
                "createdAt": "2022-03-07T06:47:08.299Z",
                "updatedAt": "2022-10-19T09:11:12.613Z",
                "__v": 0,
                "images": "public/category/1666170672612.1301.webp",
                "specification": null
            },
            {
                "parent": "6225aa6c5507127df692d326",
                "status": true,
                "_id": "6225aa0b5507127df692d314",
                "category_name": "Surukku Bags",
                "createdAt": "2022-03-07T06:45:31.847Z",
                "updatedAt": "2022-10-19T09:11:03.348Z",
                "__v": 0,
                "images": "public/category/1666170663347.396.webp",
                "specification": "6226f5ec5507127df692d460"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Great Give aways at weddings and any ceremonies tucked with sweets"
        ],
        "key_words": [
            ""
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "623c4bdf1d83b224a046a785",
        "images": [
            "public/product/1648118822159.0352.webp"
        ],
        "sku": "P054",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "specification": [
            {
                "_id": "62b6e3902a62aa5591e4cf8c",
                "title": "Material",
                "value": "Silk with zari",
                "suffix": ""
            },
            {
                "_id": "62b6e3902a62aa5591e4cf8d",
                "title": "Colour",
                "value": "Gold and Red",
                "suffix": ""
            },
            {
                "_id": "62b6e3902a62aa5591e4cf8e",
                "title": "Size",
                "value": "8.5 X 8.5 (In Inches)",
                "suffix": ""
            }
        ],
        "createdAt": "2022-03-24T10:45:51.755Z",
        "updatedAt": "2022-06-25T10:29:36.654Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Zari Potli Bags",
        "display_date": null,
        "hsn_code": "6305",
        "min_order_qty": 1,
        "mrp": 800,
        "sp": 650,
        "stock": 0,
        "tax": {
            "status": true,
            "_id": "61f7dde28d37e6262ba17c80",
            "tax_name": "GST_18",
            "tax_percentage": 18,
            "__v": 0
        },
        "meta_desc": "Surukku bags",
        "meta_key": "Potli bags",
        "note": "Potli bags for take aways at any occassion.<div>Beaded with embroidery.</div>"
    },
    {
        "packing_detail": {
            "weight": 0.5,
            "length": 31,
            "breadth": 31,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6225aa6c5507127df692d326",
                "category_name": "Wedding hand bags",
                "createdAt": "2022-03-07T06:47:08.299Z",
                "updatedAt": "2022-10-19T09:11:12.613Z",
                "__v": 0,
                "images": "public/category/1666170672612.1301.webp",
                "specification": null
            },
            {
                "parent": "6225aa6c5507127df692d326",
                "status": true,
                "_id": "6225aa0b5507127df692d314",
                "category_name": "Surukku Bags",
                "createdAt": "2022-03-07T06:45:31.847Z",
                "updatedAt": "2022-10-19T09:11:03.348Z",
                "__v": 0,
                "images": "public/category/1666170663347.396.webp",
                "specification": "6226f5ec5507127df692d460"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Flashy take aways at all occassions.",
            "Fill them with memories"
        ],
        "key_words": [
            ""
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "623c4e031d83b224a046a8f0",
        "images": [
            "public/product/1648119329621.1426.webp"
        ],
        "sku": "P055",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "specification": [
            {
                "_id": "62b6e3af2a62aa5591e4cfad",
                "title": "Material",
                "value": "Silk with zari",
                "suffix": ""
            },
            {
                "_id": "62b6e3af2a62aa5591e4cfae",
                "title": "Colour",
                "value": "White and Gold",
                "suffix": ""
            },
            {
                "_id": "62b6e3af2a62aa5591e4cfaf",
                "title": "Size",
                "value": "8.5 X 8.5 (In Inches)",
                "suffix": ""
            }
        ],
        "createdAt": "2022-03-24T10:54:59.926Z",
        "updatedAt": "2022-06-25T10:30:07.502Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "White and gold Potli Bag",
        "display_date": null,
        "hsn_code": "6305",
        "min_order_qty": 1,
        "mrp": 800,
        "sp": 650,
        "stock": 0,
        "tax": {
            "status": true,
            "_id": "61f7dde28d37e6262ba17c80",
            "tax_name": "GST_18",
            "tax_percentage": 18,
            "__v": 0
        },
        "meta_desc": "Surukku bag",
        "meta_key": "Potli bag",
        "note": "Beaded to give it a traditional look"
    },
    {
        "packing_detail": {
            "weight": 0.25,
            "length": 31,
            "breadth": 31,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6225aa6c5507127df692d326",
                "category_name": "Wedding hand bags",
                "createdAt": "2022-03-07T06:47:08.299Z",
                "updatedAt": "2022-10-19T09:11:12.613Z",
                "__v": 0,
                "images": "public/category/1666170672612.1301.webp",
                "specification": null
            },
            {
                "parent": "6225aa6c5507127df692d326",
                "status": true,
                "_id": "62345cbc462a810f78226389",
                "category_name": "Clutch Hand Bags",
                "specification": "6227066b5507127df692d69c",
                "createdAt": "2022-03-18T10:19:40.691Z",
                "updatedAt": "2022-03-19T10:21:06.145Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Carry your personals at weddings and parties."
        ],
        "key_words": [
            ""
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "623c4fa61d83b224a046a951",
        "images": [
            "public/product/1648119758532.7495.webp"
        ],
        "sku": "P056",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "specification": [
            {
                "_id": "62b44e6c2a62aa5591e4893e",
                "title": "Material",
                "value": "Silk with ikkat print",
                "suffix": ""
            },
            {
                "_id": "62b44e6c2a62aa5591e4893f",
                "title": "Colour",
                "value": "Orange",
                "suffix": ""
            },
            {
                "_id": "62b44e6c2a62aa5591e48940",
                "title": "Size",
                "value": "10 X 7 (in inches)",
                "suffix": ""
            }
        ],
        "createdAt": "2022-03-24T11:01:58.302Z",
        "updatedAt": "2022-06-23T11:35:56.810Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Ikkat Hand bags",
        "display_date": null,
        "hsn_code": "6305",
        "min_order_qty": 1,
        "mrp": 1500,
        "sp": 1200,
        "stock": 0,
        "tax": {
            "status": true,
            "_id": "61f7dde28d37e6262ba17c80",
            "tax_name": "GST_18",
            "tax_percentage": 18,
            "__v": 0
        },
        "meta_desc": "Hand bag",
        "meta_key": "Bag",
        "note": ""
    },
    {
        "packing_detail": {
            "weight": 0.15,
            "length": 31,
            "breadth": 31,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6234634f462a810f782266a6",
                "category_name": "Paper Craft",
                "createdAt": "2022-03-18T10:47:43.637Z",
                "updatedAt": "2022-10-19T09:12:36.034Z",
                "__v": 0,
                "images": "public/category/1666170756033.8086.webp",
                "specification": null
            },
            {
                "parent": "6234634f462a810f782266a6",
                "status": true,
                "_id": "62346405462a810f782266de",
                "category_name": "Photo Frame",
                "createdAt": "2022-03-18T10:50:45.256Z",
                "updatedAt": "2022-06-23T12:33:45.449Z",
                "__v": 0,
                "images": null,
                "specification": "62321be0434e6366c9fdac28"
            },
            {
                "parent": "62346405462a810f782266de",
                "status": true,
                "_id": "62b40ea82a62aa5591e47486",
                "category_name": "Single photo frames",
                "specification": "62321be0434e6366c9fdac28",
                "createdAt": "2022-06-23T06:56:40.678Z",
                "updatedAt": "2022-06-23T12:35:21.122Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Nice to gift to your loved ones.",
            "An easy gift to buy ,store and gift at any time with memories to hold."
        ],
        "key_words": [
            ""
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "623c52b91d83b224a046a9a4",
        "images": [
            "public/product/1655986683020.426.webp"
        ],
        "sku": "P057",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "specification": [
            {
                "_id": "62b459cc2a62aa5591e48b30",
                "title": "Material",
                "value": "Paper",
                "suffix": ""
            },
            {
                "_id": "62b459cc2a62aa5591e48b31",
                "title": "Colour",
                "value": "Available colors blue,green,pink",
                "suffix": ""
            },
            {
                "_id": "62b459cc2a62aa5591e48b32",
                "title": "Size",
                "value": "8.5\"*6.5\"(in inches)",
                "suffix": ""
            },
            {
                "_id": "62b459cc2a62aa5591e48b33",
                "title": "Available Colours",
                "value": "",
                "suffix": "Red"
            }
        ],
        "createdAt": "2022-03-24T11:15:05.476Z",
        "updatedAt": "2022-06-23T12:51:56.633Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Paper board photo frames - Red Colour",
        "display_date": null,
        "hsn_code": "3924",
        "min_order_qty": 1,
        "mrp": 350,
        "sp": 300,
        "stock": 0,
        "tax": {
            "status": true,
            "_id": "61f7dde28d37e6262ba17c80",
            "tax_name": "GST_18",
            "tax_percentage": 18,
            "__v": 0
        },
        "meta_desc": "Photo frame",
        "meta_key": "Paper craft",
        "note": "",
        "model": "PF"
    },
    {
        "packing_detail": {
            "weight": 0.25,
            "length": 30.5,
            "breadth": 30.5,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "62a9d1d22a62aa5591e39c3a",
                "category_name": "Girls Ethnic Wear",
                "specification": "62ad8d1c2a62aa5591e3f721",
                "createdAt": "2022-06-15T12:34:26.450Z",
                "updatedAt": "2022-10-19T09:13:06.445Z",
                "__v": 0,
                "images": "public/category/1666170786445.4958.webp"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Great Combination with mild embroidery"
        ],
        "key_words": [
            "Eye catching "
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62a9da482a62aa5591e3a03b",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P003A",
        "model": "PB1",
        "specification": [
            {
                "_id": "62b03d982a62aa5591e42cfb",
                "title": "AVAILABLE SIZE",
                "value": "",
                "suffix": "6 Months"
            },
            {
                "_id": "62b03d982a62aa5591e42cfc",
                "title": "Material",
                "value": "Cotton ",
                "suffix": ""
            },
            {
                "_id": "62b03d982a62aa5591e42cfd",
                "title": "Colour",
                "value": "Red Blouse with navy Blue pavadai",
                "suffix": ""
            },
            {
                "_id": "62b03d982a62aa5591e42cfe",
                "title": "Model",
                "value": "Pavadai full length with short sleeve blouse with mild embroidery and stunning border/pavadai attached with petticoat",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-15T13:10:32.721Z",
        "updatedAt": "2022-06-25T09:04:22.860Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Pavadai  and Blouse Age 6 months ",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 1800,
        "sp": 1500,
        "stock": 0,
        "tax": null,
        "meta_desc": "Girls Traditional Wear",
        "meta_key": "Pavadai and Top",
        "note": "Wash&#160; instructions hand wash and dry in shade,Iron for Best result",
        "images": [
            "public/product/1655299695164.9392.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.25,
            "length": 30.5,
            "breadth": 30.5,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "62a9d1d22a62aa5591e39c3a",
                "category_name": "Girls Ethnic Wear",
                "specification": "62ad8d1c2a62aa5591e3f721",
                "createdAt": "2022-06-15T12:34:26.450Z",
                "updatedAt": "2022-10-19T09:13:06.445Z",
                "__v": 0,
                "images": "public/category/1666170786445.4958.webp"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Great Combination with Mild Embroidery "
        ],
        "key_words": [
            "Eye Catching "
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62aacd612a62aa5591e3a296",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P003B",
        "model": "PB1",
        "specification": [
            {
                "_id": "62b03dd32a62aa5591e42d22",
                "title": "AVAILABLE SIZE",
                "value": "",
                "suffix": "1 Year"
            },
            {
                "_id": "62b03dd32a62aa5591e42d23",
                "title": "Material",
                "value": "Cotton ",
                "suffix": ""
            },
            {
                "_id": "62b03dd32a62aa5591e42d24",
                "title": "Colour",
                "value": "Red Blouse with navy Blue Pavadai",
                "suffix": ""
            },
            {
                "_id": "62b03dd32a62aa5591e42d25",
                "title": "Model",
                "value": "Pavadai full length with short sleeve blouse with mild embroidery and stunning border/pavadai attached with petticoat",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-16T06:27:45.093Z",
        "updatedAt": "2022-06-25T09:04:49.230Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Pavadai and Blouse  Age 1year",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 1800,
        "sp": 1500,
        "stock": 0,
        "tax": null,
        "meta_desc": "Girls traditional Wear ",
        "meta_key": "Pavadai and top",
        "note": "Wash Instructions :Hand wash and dry in shade .Iron for best Results.",
        "images": [
            "public/product/1655701855882.3274.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.25,
            "length": 30.5,
            "breadth": 30.5,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "62a9d1d22a62aa5591e39c3a",
                "category_name": "Girls Ethnic Wear",
                "specification": "62ad8d1c2a62aa5591e3f721",
                "createdAt": "2022-06-15T12:34:26.450Z",
                "updatedAt": "2022-10-19T09:13:06.445Z",
                "__v": 0,
                "images": "public/category/1666170786445.4958.webp"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Great combination with Mild Embroidery "
        ],
        "key_words": [
            "Eye Catching "
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62aae1fb2a62aa5591e3a9a3",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P003C",
        "model": "PB1",
        "specification": [
            {
                "_id": "62b03df92a62aa5591e42d44",
                "title": "AVAILABLE SIZE",
                "value": "",
                "suffix": "1.5 Years"
            },
            {
                "_id": "62b03df92a62aa5591e42d45",
                "title": "Material",
                "value": "Cotton",
                "suffix": ""
            },
            {
                "_id": "62b03df92a62aa5591e42d46",
                "title": "Colour",
                "value": "Red blouse with navy blue pavadai",
                "suffix": ""
            },
            {
                "_id": "62b03df92a62aa5591e42d47",
                "title": "Model",
                "value": "Pavadai full length with short sleeve blouse with mild embroidery and stunning border/pavadai attached with petticoat",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-16T07:55:39.453Z",
        "updatedAt": "2022-06-25T09:05:08.701Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Pavadai and Blouse Age 1.5 years ",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 1800,
        "sp": 1500,
        "stock": 0,
        "tax": null,
        "meta_desc": "Girls Traditional Wear ",
        "meta_key": "pavadai and top ",
        "note": "Wash Instructions: Hand&#160; Wash&#160; and dry in shade .iron for Best result&#160;",
        "images": [
            "public/product/1655701956187.3105.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.25,
            "length": 30.5,
            "breadth": 30.5,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "62a9d1d22a62aa5591e39c3a",
                "category_name": "Girls Ethnic Wear",
                "specification": "62ad8d1c2a62aa5591e3f721",
                "createdAt": "2022-06-15T12:34:26.450Z",
                "updatedAt": "2022-10-19T09:13:06.445Z",
                "__v": 0,
                "images": "public/category/1666170786445.4958.webp"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Great combination with mild embroidery "
        ],
        "key_words": [
            "Eye catching "
        ],
        "status": true,
        "featured": true,
        "publish": true,
        "_id": "62aaec892a62aa5591e3ab59",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P003D",
        "model": "PB1",
        "specification": [
            {
                "_id": "62b03e262a62aa5591e42d66",
                "title": "AVAILABLE SIZE",
                "value": "",
                "suffix": "2 Years"
            },
            {
                "_id": "62b03e262a62aa5591e42d67",
                "title": "Material",
                "value": "Cotton ",
                "suffix": ""
            },
            {
                "_id": "62b03e262a62aa5591e42d68",
                "title": "Colour",
                "value": "Red blouse with navy Blue pavadai",
                "suffix": ""
            },
            {
                "_id": "62b03e262a62aa5591e42d69",
                "title": "Model",
                "value": "Pavadai full length with short sleeve blouse with mild embroidery and stunning border/pavadai attached with petticoat",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-16T08:40:41.454Z",
        "updatedAt": "2022-09-09T09:03:19.119Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Pavadai and Blouse Age 2 year",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 1800,
        "sp": 1500,
        "stock": 0,
        "tax": null,
        "meta_desc": "Girls traditionall Wear ",
        "meta_key": "Pavadai and top ",
        "note": "wash Instruction :Hand wash and dry in shade .Iron for Best Result&#160;",
        "images": [
            "public/product/1655702051108.913.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.25,
            "length": 30.5,
            "breadth": 30.5,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "62a9d1d22a62aa5591e39c3a",
                "category_name": "Girls Ethnic Wear",
                "specification": "62ad8d1c2a62aa5591e3f721",
                "createdAt": "2022-06-15T12:34:26.450Z",
                "updatedAt": "2022-10-19T09:13:06.445Z",
                "__v": 0,
                "images": "public/category/1666170786445.4958.webp"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Great Combination with mild embroidery "
        ],
        "key_words": [
            "Eye Catching "
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62aaf4d92a62aa5591e3af19",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P003E",
        "model": "PB1",
        "specification": [
            {
                "_id": "62b03e512a62aa5591e42d88",
                "title": "AVAILABLE SIZE",
                "value": "",
                "suffix": "4 Years"
            },
            {
                "_id": "62b03e512a62aa5591e42d89",
                "title": "Material",
                "value": "cotton ",
                "suffix": ""
            },
            {
                "_id": "62b03e512a62aa5591e42d8a",
                "title": "Colour",
                "value": "Red blouse with navy Blue Pavadai ",
                "suffix": ""
            },
            {
                "_id": "62b03e512a62aa5591e42d8b",
                "title": "Model",
                "value": "Pavadai full length with short sleeve blouse with mild embroidery and stunning border/pavadai attached with petticoat",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-16T09:16:09.222Z",
        "updatedAt": "2022-06-25T09:05:48.774Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Pavadai and Blouse Age 4 Years",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 1800,
        "sp": 1500,
        "stock": 0,
        "tax": null,
        "meta_desc": "Girls Traditional wear",
        "meta_key": "Pavadai and top ",
        "note": "Wash Instruction : Hand Wash and dry in shade .Iron for Best Results.",
        "images": [
            "public/product/1655371295250.5764.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.25,
            "length": 30.5,
            "breadth": 30.5,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "62a9d1d22a62aa5591e39c3a",
                "category_name": "Girls Ethnic Wear",
                "specification": "62ad8d1c2a62aa5591e3f721",
                "createdAt": "2022-06-15T12:34:26.450Z",
                "updatedAt": "2022-10-19T09:13:06.445Z",
                "__v": 0,
                "images": "public/category/1666170786445.4958.webp"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Hand Embroidery top"
        ],
        "key_words": [
            "Skirt and top, Pavadai and Blouse "
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62ab03bb2a62aa5591e3b2e6",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P005A",
        "model": "PB3",
        "specification": [
            {
                "_id": "62b0416f2a62aa5591e43023",
                "title": "AVAILABLE SIZE",
                "value": "",
                "suffix": "6 Months"
            },
            {
                "_id": "62b0416f2a62aa5591e43024",
                "title": "Material",
                "value": "cotton",
                "suffix": ""
            },
            {
                "_id": "62b0416f2a62aa5591e43025",
                "title": "Colour",
                "value": "Navy blue blouse pink ajrakh print skirt",
                "suffix": ""
            },
            {
                "_id": "62b0416f2a62aa5591e43026",
                "title": "Model",
                "value": "Flare skirt with puffed sleeves and hand embroidery on the blouse",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-16T10:19:39.467Z",
        "updatedAt": "2022-06-27T05:08:28.280Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "skirt and top Age 6 months",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 1800,
        "sp": 1500,
        "stock": 0,
        "tax": null,
        "meta_desc": "Girls Traditional Wear  , Skirt and top, Pavadai and Blouse ",
        "meta_key": "Skirt and top, Pavadai and Blouse ",
        "note": "Hand wash&#160; and Dry in Shade . Iron for Best result .",
        "images": [
            "public/product/1655375250211.2205.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.25,
            "length": 30.5,
            "breadth": 30.5,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "62a9d1d22a62aa5591e39c3a",
                "category_name": "Girls Ethnic Wear",
                "specification": "62ad8d1c2a62aa5591e3f721",
                "createdAt": "2022-06-15T12:34:26.450Z",
                "updatedAt": "2022-10-19T09:13:06.445Z",
                "__v": 0,
                "images": "public/category/1666170786445.4958.webp"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Hand Embroided top",
            "Great Summer wear "
        ],
        "key_words": [
            "Skirt and top  Pavadai  and blouse "
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62ab0b112a62aa5591e3b3b5",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P005B",
        "model": "PB3",
        "specification": [
            {
                "_id": "62b041902a62aa5591e43045",
                "title": "AVAILABLE SIZE",
                "value": "",
                "suffix": "1 Year"
            },
            {
                "_id": "62b041902a62aa5591e43046",
                "title": "Material",
                "value": "cotton",
                "suffix": ""
            },
            {
                "_id": "62b041902a62aa5591e43047",
                "title": "Colour",
                "value": "Navy blue blouse pink ajrakh print skirt",
                "suffix": ""
            },
            {
                "_id": "62b041902a62aa5591e43048",
                "title": "Model",
                "value": "Flare skirt with puffed sleeves and hand embroidery on the blouse",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-16T10:50:57.856Z",
        "updatedAt": "2022-06-27T05:08:49.302Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Skirt and Top Age 1 Year ",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 1800,
        "sp": 1500,
        "stock": 0,
        "tax": null,
        "meta_desc": "Girls traditional Wear ,Skirt and top  Pavadai  and blouse ",
        "meta_key": "Skirt and top  Pavadai  and blouse ",
        "note": "Hand Wash and dry in shade . Iron For Best Results.",
        "images": [
            "public/product/1655705442681.0083.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.25,
            "length": 30.5,
            "breadth": 30.5,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "62a9d1d22a62aa5591e39c3a",
                "category_name": "Girls Ethnic Wear",
                "specification": "62ad8d1c2a62aa5591e3f721",
                "createdAt": "2022-06-15T12:34:26.450Z",
                "updatedAt": "2022-10-19T09:13:06.445Z",
                "__v": 0,
                "images": "public/category/1666170786445.4958.webp"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Hand Embroided top ",
            "Great Summer Wear "
        ],
        "key_words": [
            "Skirt and top pavadai and blouse "
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62ab0cca2a62aa5591e3b413",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P005C",
        "model": "PB3",
        "specification": [
            {
                "_id": "62b041af2a62aa5591e43067",
                "title": "AVAILABLE SIZE",
                "value": "",
                "suffix": "1.5 Years"
            },
            {
                "_id": "62b041af2a62aa5591e43068",
                "title": "Material",
                "value": "cotton",
                "suffix": ""
            },
            {
                "_id": "62b041af2a62aa5591e43069",
                "title": "Colour",
                "value": "Navy blue blouse pink ajrakh print skirt",
                "suffix": ""
            },
            {
                "_id": "62b041af2a62aa5591e4306a",
                "title": "Model",
                "value": "Flare skirt with puffed sleeves and hand embroidery on the blouse",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-16T10:58:18.382Z",
        "updatedAt": "2022-06-27T05:09:09.382Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Skirt and top Age 1.5 years",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 1800,
        "sp": 1500,
        "stock": 0,
        "tax": null,
        "meta_desc": "Girls Traditional wear ,Skirt and top pavadai and blouse ",
        "meta_key": "Skirt and top pavadai and blouse ",
        "note": "Hand Wash and Dry in shade . Iron for best Result&#160;",
        "images": [
            "public/product/1655705693658.5818.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.25,
            "length": 30.5,
            "breadth": 30.5,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "62a9d1d22a62aa5591e39c3a",
                "category_name": "Girls Ethnic Wear",
                "specification": "62ad8d1c2a62aa5591e3f721",
                "createdAt": "2022-06-15T12:34:26.450Z",
                "updatedAt": "2022-10-19T09:13:06.445Z",
                "__v": 0,
                "images": "public/category/1666170786445.4958.webp"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Hand Embroided top ",
            " Great Summer Wear "
        ],
        "key_words": [
            "Skirt and top pavadai and blouse "
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62ab1a132a62aa5591e3bde8",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P005D",
        "model": "PB3",
        "specification": [
            {
                "_id": "62b041d32a62aa5591e43089",
                "title": "AVAILABLE SIZE",
                "value": "",
                "suffix": "2 Years"
            },
            {
                "_id": "62b041d32a62aa5591e4308a",
                "title": "Material",
                "value": "cotton",
                "suffix": ""
            },
            {
                "_id": "62b041d32a62aa5591e4308b",
                "title": "Colour",
                "value": "Navy blue blouse pink ajrakh print skirt",
                "suffix": ""
            },
            {
                "_id": "62b041d32a62aa5591e4308c",
                "title": "Model",
                "value": "Flare skirt with puffed sleeves and hand embroidery on the blouse",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-16T11:54:59.464Z",
        "updatedAt": "2022-06-27T05:09:28.256Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Skirt and top Age 2 years ",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 1800,
        "sp": 1500,
        "stock": 0,
        "tax": null,
        "meta_desc": "Girls Traditional wear ,Skirt and top pavadai and blouse ",
        "meta_key": "Skirt and top pavadai and blouse ",
        "note": "Hand Wash and Dry in shade .Iron For Best result&#160;",
        "images": [
            "public/product/1655380729905.2715.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.25,
            "length": 30.5,
            "breadth": 30.5,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "62a9d1d22a62aa5591e39c3a",
                "category_name": "Girls Ethnic Wear",
                "specification": "62ad8d1c2a62aa5591e3f721",
                "createdAt": "2022-06-15T12:34:26.450Z",
                "updatedAt": "2022-10-19T09:13:06.445Z",
                "__v": 0,
                "images": "public/category/1666170786445.4958.webp"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Hand Embroided top ",
            "Great Summer Wear "
        ],
        "key_words": [
            "Skirt and top pavadai and blouse "
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62ab1b982a62aa5591e3be63",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P005E",
        "model": "PB3",
        "specification": [
            {
                "_id": "62b0420e2a62aa5591e430c2",
                "title": "AVAILABLE SIZE",
                "value": "",
                "suffix": "4 Years"
            },
            {
                "_id": "62b0420e2a62aa5591e430c3",
                "title": "Material",
                "value": "cotton",
                "suffix": ""
            },
            {
                "_id": "62b0420e2a62aa5591e430c4",
                "title": "Colour",
                "value": "Navy blue blouse pink ajrakh print skirt",
                "suffix": ""
            },
            {
                "_id": "62b0420e2a62aa5591e430c5",
                "title": "Model",
                "value": "Flare skirt with puffed sleeves and hand embroidery on the blouse",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-16T12:01:28.519Z",
        "updatedAt": "2022-06-27T05:09:47.559Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Skirt and top Age 4 Years ",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 1800,
        "sp": 1500,
        "stock": 0,
        "tax": null,
        "meta_desc": "\nGirls Traditional wear ,Skirt and top pavadai and blouse \n",
        "meta_key": "Skirt and top pavadai and blouse ",
        "note": "Hand Wash and Dry shade . Iron for Better Result&#160;",
        "images": [
            "public/product/1655706152836.1052.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.5,
            "length": 30.5,
            "breadth": 30.5,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "62a9d1d22a62aa5591e39c3a",
                "category_name": "Girls Ethnic Wear",
                "specification": "62ad8d1c2a62aa5591e3f721",
                "createdAt": "2022-06-15T12:34:26.450Z",
                "updatedAt": "2022-10-19T09:13:06.445Z",
                "__v": 0,
                "images": "public/category/1666170786445.4958.webp"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Contrast blouse  a frill frock"
        ],
        "key_words": [
            "Frock and top  Pavadai and top"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62ac01812a62aa5591e3bfe2",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P006A",
        "model": "PB5",
        "specification": [
            {
                "_id": "62b03feb2a62aa5591e42f06",
                "title": "AVAILABLE SIZE",
                "value": "",
                "suffix": "6 Months"
            },
            {
                "_id": "62b03feb2a62aa5591e42f07",
                "title": "Material",
                "value": "Ajrakh cotton",
                "suffix": ""
            },
            {
                "_id": "62b03feb2a62aa5591e42f08",
                "title": "Colour",
                "value": "Yellow top with dark blue skirt",
                "suffix": ""
            },
            {
                "_id": "62b03feb2a62aa5591e42f09",
                "title": "Model",
                "value": "Frock skirt with top",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-17T04:22:25.228Z",
        "updatedAt": "2022-06-27T05:10:16.078Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Frock skirt with top Age 6 Months ",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 1800,
        "sp": 1500,
        "stock": 0,
        "tax": null,
        "meta_desc": "Girls traditional wear,Frock and top  Pavadai and top\n",
        "meta_key": "Frock and top  Pavadai and top",
        "note": "<div>Hand wash and dry in shade.Iron for best results.</div><div><br></div>",
        "images": [
            "public/product/1655440090111.6663.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.5,
            "length": 30.5,
            "breadth": 30.5,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "62a9d1d22a62aa5591e39c3a",
                "category_name": "Girls Ethnic Wear",
                "specification": "62ad8d1c2a62aa5591e3f721",
                "createdAt": "2022-06-15T12:34:26.450Z",
                "updatedAt": "2022-10-19T09:13:06.445Z",
                "__v": 0,
                "images": "public/category/1666170786445.4958.webp"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Contrast blouse  a frill frock"
        ],
        "key_words": [
            "Frock and top  Pavadai and top"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62ac036a2a62aa5591e3c085",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P006B",
        "model": "PB5",
        "specification": [
            {
                "_id": "62b0401a2a62aa5591e42f39",
                "title": "AVAILABLE SIZE",
                "value": "",
                "suffix": "1 Year"
            },
            {
                "_id": "62b0401a2a62aa5591e42f3a",
                "title": "Material",
                "value": "Ajrakh cotton",
                "suffix": ""
            },
            {
                "_id": "62b0401a2a62aa5591e42f3b",
                "title": "Colour",
                "value": "Yellow top with dark blue skirt",
                "suffix": ""
            },
            {
                "_id": "62b0401a2a62aa5591e42f3c",
                "title": "Model",
                "value": "Frock skirt with top",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-17T04:30:34.421Z",
        "updatedAt": "2022-06-27T05:10:39.144Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Frock skirt with top Age 1Year ",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 1800,
        "sp": 1500,
        "stock": 0,
        "tax": null,
        "meta_desc": "Girls tradiional wear,Frock and top  Pavadai and top\n",
        "meta_key": "Frock and top  Pavadai and top",
        "note": "<div>Hand wash and dry in shade.Iron for best results.</div><div><br></div>",
        "images": [
            "public/product/1655708040496.4578.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.5,
            "length": 30.5,
            "breadth": 30.5,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "62a9d1d22a62aa5591e39c3a",
                "category_name": "Girls Ethnic Wear",
                "specification": "62ad8d1c2a62aa5591e3f721",
                "createdAt": "2022-06-15T12:34:26.450Z",
                "updatedAt": "2022-10-19T09:13:06.445Z",
                "__v": 0,
                "images": "public/category/1666170786445.4958.webp"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Contrast blouse  a frill frock"
        ],
        "key_words": [
            "Frock and top  Pavadai and top"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62ac054f2a62aa5591e3c180",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P006C",
        "model": "PB5",
        "specification": [
            {
                "_id": "62b040412a62aa5591e42f5b",
                "title": "AVAILABLE SIZE",
                "value": "",
                "suffix": "1.5 Years"
            },
            {
                "_id": "62b040412a62aa5591e42f5c",
                "title": "Material",
                "value": "Ajrakh cotton",
                "suffix": ""
            },
            {
                "_id": "62b040412a62aa5591e42f5d",
                "title": "Colour",
                "value": "Yellow top with dark blue skirt",
                "suffix": ""
            },
            {
                "_id": "62b040412a62aa5591e42f5e",
                "title": "Model",
                "value": "6 months to 4 years",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-17T04:38:39.219Z",
        "updatedAt": "2022-06-27T05:11:09.494Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Frock skirt with top Age 1.5 Years",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 1800,
        "sp": 1500,
        "stock": 0,
        "tax": null,
        "meta_desc": "Girls traditional wear,Frock and top  Pavadai and top",
        "meta_key": "Frock and top  Pavadai and top",
        "note": "<div>Hand wash and dry in shade.Iron for best results.</div><div><br></div>",
        "images": [
            "public/product/1655708174157.9387.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.5,
            "length": 30.5,
            "breadth": 30.5,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "62a9d1d22a62aa5591e39c3a",
                "category_name": "Girls Ethnic Wear",
                "specification": "62ad8d1c2a62aa5591e3f721",
                "createdAt": "2022-06-15T12:34:26.450Z",
                "updatedAt": "2022-10-19T09:13:06.445Z",
                "__v": 0,
                "images": "public/category/1666170786445.4958.webp"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Contrast blouse  a frill frock"
        ],
        "key_words": [
            "Frock and top  Pavadai and top"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62ac06362a62aa5591e3c1d6",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P006D",
        "model": "PB5",
        "specification": [
            {
                "_id": "62b0405e2a62aa5591e42f7d",
                "title": "AVAILABLE SIZE",
                "value": "",
                "suffix": "2 Years"
            },
            {
                "_id": "62b0405e2a62aa5591e42f7e",
                "title": "Material",
                "value": "Ajrakh cotton",
                "suffix": ""
            },
            {
                "_id": "62b0405e2a62aa5591e42f7f",
                "title": "Colour",
                "value": "Yellow top with dark blue skirt",
                "suffix": ""
            },
            {
                "_id": "62b0405e2a62aa5591e42f80",
                "title": "Model",
                "value": "6 months to 4 years",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-17T04:42:30.742Z",
        "updatedAt": "2022-06-27T05:11:30.442Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Frock skirt with top Age 2 Years",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 1800,
        "sp": 1500,
        "stock": 0,
        "tax": null,
        "meta_desc": "Girls traditional wear,Frock and top  Pavadai and top\n",
        "meta_key": "Frock and top  Pavadai and top",
        "note": "<div>Hand wash and dry in shade.Iron for best results.</div><div><br></div>",
        "images": [
            "public/product/1655708283971.5132.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.5,
            "length": 30.5,
            "breadth": 30.5,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "62a9d1d22a62aa5591e39c3a",
                "category_name": "Girls Ethnic Wear",
                "specification": "62ad8d1c2a62aa5591e3f721",
                "createdAt": "2022-06-15T12:34:26.450Z",
                "updatedAt": "2022-10-19T09:13:06.445Z",
                "__v": 0,
                "images": "public/category/1666170786445.4958.webp"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Contrast blouse  a frill frock"
        ],
        "key_words": [
            "Frock and top  Pavadai and top"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62ac06e62a62aa5591e3c22c",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P006E",
        "model": "PB5",
        "specification": [
            {
                "_id": "62b0408e2a62aa5591e42fb0",
                "title": "AVAILABLE SIZE",
                "value": "",
                "suffix": "4 Years"
            },
            {
                "_id": "62b0408e2a62aa5591e42fb1",
                "title": "Material",
                "value": "Ajrakh cotton",
                "suffix": ""
            },
            {
                "_id": "62b0408e2a62aa5591e42fb2",
                "title": "Colour",
                "value": "Yellow top with dark blue skirt",
                "suffix": ""
            },
            {
                "_id": "62b0408e2a62aa5591e42fb3",
                "title": "Model",
                "value": "Frock skirt with top",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-17T04:45:26.717Z",
        "updatedAt": "2022-06-27T05:11:53.006Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Frock skirt with top Age 4 Years",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 1800,
        "sp": 1500,
        "stock": 0,
        "tax": null,
        "meta_desc": "Girls traditional wear,Frock and top  Pavadai and top\n",
        "meta_key": "Frock and top  Pavadai and top",
        "note": "<div>Hand wash and dry in shade.Iron for best results.</div><div><br></div>",
        "images": [
            "public/product/1655441232275.4248.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.35,
            "length": 30.5,
            "breadth": 30.5,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "62a9d1d22a62aa5591e39c3a",
                "category_name": "Girls Ethnic Wear",
                "specification": "62ad8d1c2a62aa5591e3f721",
                "createdAt": "2022-06-15T12:34:26.450Z",
                "updatedAt": "2022-10-19T09:13:06.445Z",
                "__v": 0,
                "images": "public/category/1666170786445.4958.webp"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Contrast pavadai and top with embroidery."
        ],
        "key_words": [
            "Sleeveless to beat the heat."
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62ac08902a62aa5591e3c302",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P007A",
        "model": "PB6",
        "specification": [
            {
                "_id": "62b042db2a62aa5591e4314e",
                "title": "AVAILABLE SIZE",
                "value": "",
                "suffix": "6 Months"
            },
            {
                "_id": "62b042db2a62aa5591e4314f",
                "title": "Material",
                "value": "Handloom cotton",
                "suffix": ""
            },
            {
                "_id": "62b042db2a62aa5591e43150",
                "title": "Colour",
                "value": " Purple top and sky blue pavadai",
                "suffix": ""
            },
            {
                "_id": "62b042db2a62aa5591e43151",
                "title": "Model",
                "value": "Plain colours with matching border and fancy strings/sleeve less top with hand embroidery for the top with elastic waist pavadai for quick and easy fit",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-17T04:52:32.812Z",
        "updatedAt": "2022-06-25T09:09:46.201Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Pavadai and blouse Age 6 Months ",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 1800,
        "sp": 1500,
        "stock": 0,
        "tax": null,
        "meta_desc": "Girls traditional wear \n",
        "meta_key": "Pavadai and blouse   skirt and top",
        "note": "<div>Hand wash with care and dry in shade.Iron for best results.</div><div><br></div>",
        "images": [
            "public/product/1655441843964.8882.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.35,
            "length": 30.5,
            "breadth": 30.5,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "62a9d1d22a62aa5591e39c3a",
                "category_name": "Girls Ethnic Wear",
                "specification": "62ad8d1c2a62aa5591e3f721",
                "createdAt": "2022-06-15T12:34:26.450Z",
                "updatedAt": "2022-10-19T09:13:06.445Z",
                "__v": 0,
                "images": "public/category/1666170786445.4958.webp"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Contrast pavadai and top with embroidery."
        ],
        "key_words": [
            "Sleeveless to beat the heat."
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62ac0aeb2a62aa5591e3c38b",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P007B",
        "model": "PB6",
        "specification": [
            {
                "_id": "62b042f62a62aa5591e43170",
                "title": "AVAILABLE SIZE",
                "value": "",
                "suffix": "1 Year"
            },
            {
                "_id": "62b042f62a62aa5591e43171",
                "title": "Material",
                "value": "Handloom cotton",
                "suffix": ""
            },
            {
                "_id": "62b042f62a62aa5591e43172",
                "title": "Colour",
                "value": " Purple top and sky blue pavadai",
                "suffix": ""
            },
            {
                "_id": "62b042f62a62aa5591e43173",
                "title": "Model",
                "value": "Plain colours with matching border and fancy strings/sleeve less top with hand embroidery for the top with elastic waist pavadai for quick and easy fit",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-17T05:02:35.368Z",
        "updatedAt": "2022-06-25T09:10:09.232Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Pavadai and blouse Age 1Year",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 1800,
        "sp": 1500,
        "stock": 0,
        "tax": null,
        "meta_desc": "Girls traditional wear \n",
        "meta_key": "Pavadai and blouse   skirt and top",
        "note": "<div>Hand wash with care and dry in shade.Iron for best results.</div><div><br></div>",
        "images": [
            "public/product/1655706915162.2468.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.35,
            "length": 30.5,
            "breadth": 30.5,
            "height": 30.5
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "62a9d1d22a62aa5591e39c3a",
                "category_name": "Girls Ethnic Wear",
                "specification": "62ad8d1c2a62aa5591e3f721",
                "createdAt": "2022-06-15T12:34:26.450Z",
                "updatedAt": "2022-10-19T09:13:06.445Z",
                "__v": 0,
                "images": "public/category/1666170786445.4958.webp"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Contrast pavadai and top with embroidery."
        ],
        "key_words": [
            "Sleeveless to beat the heat."
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62ac0bc22a62aa5591e3c3e5",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P007C",
        "model": "PB6",
        "specification": [
            {
                "_id": "62b043122a62aa5591e43192",
                "title": "AVAILABLE SIZE",
                "value": "",
                "suffix": "1.5 Years"
            },
            {
                "_id": "62b043122a62aa5591e43193",
                "title": "Material",
                "value": "Handloom cotton",
                "suffix": ""
            },
            {
                "_id": "62b043122a62aa5591e43194",
                "title": "Colour",
                "value": " Purple top and sky blue pavadai",
                "suffix": ""
            },
            {
                "_id": "62b043122a62aa5591e43195",
                "title": "Model",
                "value": "Plain colours with matching border and fancy strings/sleeve less top with hand embroidery for the top with elastic waist pavadai for quick and easy fit",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-17T05:06:10.844Z",
        "updatedAt": "2022-06-25T09:10:27.592Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Pavadai and blouse Age 1.5Years ",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 1800,
        "sp": 1500,
        "stock": 0,
        "tax": null,
        "meta_desc": "Girls traditional wear ",
        "meta_key": "Pavadai and blouse   skirt and top",
        "note": "<div>Hand wash with care and dry in shade.Iron for best results.</div><div><br></div>",
        "images": [
            "public/product/1655707007639.9653.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.35,
            "length": 30.5,
            "breadth": 30.5,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "62a9d1d22a62aa5591e39c3a",
                "category_name": "Girls Ethnic Wear",
                "specification": "62ad8d1c2a62aa5591e3f721",
                "createdAt": "2022-06-15T12:34:26.450Z",
                "updatedAt": "2022-10-19T09:13:06.445Z",
                "__v": 0,
                "images": "public/category/1666170786445.4958.webp"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Contrast pavadai and top with embroidery."
        ],
        "key_words": [
            "Sleeveless to beat the heat."
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62ac0c8a2a62aa5591e3c448",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P007D",
        "model": "PB6",
        "specification": [
            {
                "_id": "62b0432d2a62aa5591e431b4",
                "title": "AVAILABLE SIZE",
                "value": "",
                "suffix": "2 Years"
            },
            {
                "_id": "62b0432d2a62aa5591e431b5",
                "title": "Material",
                "value": "Handloom cotton",
                "suffix": ""
            },
            {
                "_id": "62b0432d2a62aa5591e431b6",
                "title": "Colour",
                "value": " Purple top and sky blue pavadai",
                "suffix": ""
            },
            {
                "_id": "62b0432d2a62aa5591e431b7",
                "title": "Model",
                "value": "Plain colours with matching border and fancy strings/sleeve less top with hand embroidery for the top with elastic waist pavadai for quick and easy fit",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-17T05:09:30.148Z",
        "updatedAt": "2022-06-25T09:10:43.144Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Pavadai and blouse Age 2 Years ",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 1800,
        "sp": 1500,
        "stock": 0,
        "tax": null,
        "meta_desc": "Girls traditional wear ",
        "meta_key": "Pavadai and blouse   skirt and top",
        "note": "<div>Hand wash with care and dry in shade.Iron for best results.</div><div><br></div>",
        "images": [
            "public/product/1655707073152.8396.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.35,
            "length": 30.5,
            "breadth": 30.5,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "62a9d1d22a62aa5591e39c3a",
                "category_name": "Girls Ethnic Wear",
                "specification": "62ad8d1c2a62aa5591e3f721",
                "createdAt": "2022-06-15T12:34:26.450Z",
                "updatedAt": "2022-10-19T09:13:06.445Z",
                "__v": 0,
                "images": "public/category/1666170786445.4958.webp"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Contrast pavadai and top with embroidery."
        ],
        "key_words": [
            "Sleeveless to beat the heat"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62ac0d422a62aa5591e3c4a2",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P007E",
        "model": "PB6",
        "specification": [
            {
                "_id": "62b043502a62aa5591e431d6",
                "title": "AVAILABLE SIZE",
                "value": "",
                "suffix": "4 Years"
            },
            {
                "_id": "62b043502a62aa5591e431d7",
                "title": "Material",
                "value": "Handloom cotton",
                "suffix": ""
            },
            {
                "_id": "62b043502a62aa5591e431d8",
                "title": "Colour",
                "value": " Purple top and sky blue pavadai",
                "suffix": ""
            },
            {
                "_id": "62b043502a62aa5591e431d9",
                "title": "Model",
                "value": "Plain colours with matching border and fancy strings/sleeve less top with hand embroidery for the top with elastic waist pavadai for quick and easy fit",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-17T05:12:34.111Z",
        "updatedAt": "2022-06-25T09:10:56.963Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Pavadai and blouse Age 4 Years ",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 1800,
        "sp": 1500,
        "stock": 0,
        "tax": null,
        "meta_desc": "Girls traditional wear ",
        "meta_key": "Pavadai and blouse   skirt and top",
        "note": "<div>Hand wash with care and dry in shade. Iron for best results.</div><div><br></div>",
        "images": [
            "public/product/1655442878325.649.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.25,
            "length": 30.5,
            "breadth": 30.5,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "62a9d1d22a62aa5591e39c3a",
                "category_name": "Girls Ethnic Wear",
                "specification": "62ad8d1c2a62aa5591e3f721",
                "createdAt": "2022-06-15T12:34:26.450Z",
                "updatedAt": "2022-10-19T09:13:06.445Z",
                "__v": 0,
                "images": "public/category/1666170786445.4958.webp"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Great summer wear for occassions",
            "Contrast colours to entice kids",
            "Jazzy borders to uplift the outfit"
        ],
        "key_words": [
            "Girls ethic wear"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62ac13662a62aa5591e3c7e4",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P043A",
        "model": "PB7",
        "specification": [
            {
                "_id": "62b043d92a62aa5591e43235",
                "title": "AVAILABLE SIZE",
                "value": "",
                "suffix": "6 Months"
            },
            {
                "_id": "62b043d92a62aa5591e43236",
                "title": "Material",
                "value": "Handloom Cotton",
                "suffix": ""
            },
            {
                "_id": "62b043d92a62aa5591e43237",
                "title": "Colour",
                "value": "Parrot green pavadai with Dark pink top",
                "suffix": ""
            },
            {
                "_id": "62b043d92a62aa5591e43238",
                "title": "Model",
                "value": "Sleeveless top with pavadai",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-17T05:38:46.640Z",
        "updatedAt": "2022-06-27T05:07:42.919Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Green and pink Pavadai and top Age 6 Months ",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 1800,
        "sp": 1500,
        "stock": 0,
        "tax": null,
        "meta_desc": "Pavadai and blouse ,Girls ethic wear\n",
        "meta_key": "Girls ethic wear",
        "note": "<div>Hand wash and dry in shade,</div><div><br></div>",
        "images": [
            "public/product/1655444505413.0005.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.25,
            "length": 30.5,
            "breadth": 30.5,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "62a9d1d22a62aa5591e39c3a",
                "category_name": "Girls Ethnic Wear",
                "specification": "62ad8d1c2a62aa5591e3f721",
                "createdAt": "2022-06-15T12:34:26.450Z",
                "updatedAt": "2022-10-19T09:13:06.445Z",
                "__v": 0,
                "images": "public/category/1666170786445.4958.webp"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Great summer wear for occassions",
            "Contrast colours to entice kids",
            "Jazzy borders to uplift the outfit"
        ],
        "key_words": [
            "Girls ethic wear"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62ac14732a62aa5591e3c851",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P043B",
        "model": "PB7",
        "specification": [
            {
                "_id": "62b043f42a62aa5591e43257",
                "title": "AVAILABLE SIZE",
                "value": "",
                "suffix": "1 Year"
            },
            {
                "_id": "62b043f42a62aa5591e43258",
                "title": "Material",
                "value": "Handloom Cotton",
                "suffix": ""
            },
            {
                "_id": "62b043f42a62aa5591e43259",
                "title": "Colour",
                "value": "Parrot green pavadai with Dark pink top",
                "suffix": ""
            },
            {
                "_id": "62b043f42a62aa5591e4325a",
                "title": "Model",
                "value": "Sleeveless top with pavadai",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-17T05:43:15.644Z",
        "updatedAt": "2022-06-25T09:15:43.142Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Green and pink Pavadai and top Age 1 Year ",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 1800,
        "sp": 1500,
        "stock": 0,
        "tax": null,
        "meta_desc": "Pavadai and blouse ,Girls ethic wear\n",
        "meta_key": "Girls ethic wear",
        "note": "<div>Hand wash and dry in shade.</div><div><br></div>",
        "images": [
            "public/product/1655707629656.7407.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.25,
            "length": 30.5,
            "breadth": 30.5,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "62a9d1d22a62aa5591e39c3a",
                "category_name": "Girls Ethnic Wear",
                "specification": "62ad8d1c2a62aa5591e3f721",
                "createdAt": "2022-06-15T12:34:26.450Z",
                "updatedAt": "2022-10-19T09:13:06.445Z",
                "__v": 0,
                "images": "public/category/1666170786445.4958.webp"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Great summer wear for occassions",
            "Contrast colours to entice kids",
            "Jazzy borders to uplift the outfit"
        ],
        "key_words": [
            ""
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62ac15682a62aa5591e3c93c",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P043C",
        "model": "PB7",
        "specification": [
            {
                "_id": "62b044122a62aa5591e43279",
                "title": "AVAILABLE SIZE",
                "value": "",
                "suffix": "1.5 Years"
            },
            {
                "_id": "62b044122a62aa5591e4327a",
                "title": "Material",
                "value": "Handloom Cotton",
                "suffix": ""
            },
            {
                "_id": "62b044122a62aa5591e4327b",
                "title": "Colour",
                "value": "Parrot green pavadai with Dark pink top",
                "suffix": ""
            },
            {
                "_id": "62b044122a62aa5591e4327c",
                "title": "Model",
                "value": "Sleeveless top with pavadai",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-17T05:47:20.456Z",
        "updatedAt": "2022-06-25T09:11:43.857Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Green and pink Pavadai and top Age 1.5 Years",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 1800,
        "sp": 1500,
        "stock": 0,
        "tax": null,
        "meta_desc": "Pavadai and blouse",
        "meta_key": "Girls ethic wear",
        "note": "<div>Hand wash and dry in shade,</div><div><br></div>",
        "images": [
            "public/product/1655707729159.769.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.25,
            "length": 30.5,
            "breadth": 30.5,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "62a9d1d22a62aa5591e39c3a",
                "category_name": "Girls Ethnic Wear",
                "specification": "62ad8d1c2a62aa5591e3f721",
                "createdAt": "2022-06-15T12:34:26.450Z",
                "updatedAt": "2022-10-19T09:13:06.445Z",
                "__v": 0,
                "images": "public/category/1666170786445.4958.webp"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Great summer wear for occassions",
            "Contrast colours to entice kids",
            "Jazzy borders to uplift the outfit"
        ],
        "key_words": [
            ""
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62ac164c2a62aa5591e3c9d9",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P043D",
        "model": "PB7",
        "specification": [
            {
                "_id": "62b0469a2a62aa5591e435be",
                "title": "AVAILABLE SIZE",
                "value": "",
                "suffix": "2 Years"
            },
            {
                "_id": "62b0469a2a62aa5591e435bf",
                "title": "Material",
                "value": "Handloom Cotton",
                "suffix": ""
            },
            {
                "_id": "62b0469a2a62aa5591e435c0",
                "title": "Colour",
                "value": "Parrot Green Pavadai With Dark Pink Top",
                "suffix": ""
            },
            {
                "_id": "62b0469a2a62aa5591e435c1",
                "title": "Model",
                "value": "Sleeveless Top With Pavadai",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-17T05:51:08.991Z",
        "updatedAt": "2022-06-25T09:12:02.530Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Green and pink Pavadai and top Age 2 Years ",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 1800,
        "sp": 1500,
        "stock": 0,
        "tax": null,
        "meta_desc": "Pavadai and blouse\n",
        "meta_key": "Girls ethic wear",
        "note": "Hand wash and dry in shade,",
        "images": [
            "public/product/1655446924967.0552.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.25,
            "length": 30.5,
            "breadth": 30.5,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "62a9d1d22a62aa5591e39c3a",
                "category_name": "Girls Ethnic Wear",
                "specification": "62ad8d1c2a62aa5591e3f721",
                "createdAt": "2022-06-15T12:34:26.450Z",
                "updatedAt": "2022-10-19T09:13:06.445Z",
                "__v": 0,
                "images": "public/category/1666170786445.4958.webp"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Great summer wear for occassions",
            "Contrast colours to entice kids",
            "Jazzy borders to uplift the outfit"
        ],
        "key_words": [
            ""
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62ac1e0e2a62aa5591e3cca0",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P043E",
        "model": "PB7",
        "specification": [
            {
                "_id": "62b044362a62aa5591e4329b",
                "title": "AVAILABLE SIZE",
                "value": "",
                "suffix": "4 Years"
            },
            {
                "_id": "62b044362a62aa5591e4329c",
                "title": "Material",
                "value": "Handloom Cotton",
                "suffix": ""
            },
            {
                "_id": "62b044362a62aa5591e4329d",
                "title": "Colour",
                "value": "Parrot green pavadai with Dark pink top",
                "suffix": ""
            },
            {
                "_id": "62b044362a62aa5591e4329e",
                "title": "Model",
                "value": "Sleeveless top with pavadai",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-17T06:24:14.203Z",
        "updatedAt": "2022-06-25T09:12:20.777Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Green and pink Pavadai and top Age 4 Years ",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 1800,
        "sp": 1500,
        "stock": 0,
        "tax": null,
        "meta_desc": "Pavadai and blouse\n",
        "meta_key": "Girls ethic wear",
        "note": "<div>Hand wash and dry in shade,</div><div><br></div>",
        "images": [
            "public/product/1655707869095.2112.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.5,
            "length": 31,
            "breadth": 31,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "62a9d1d22a62aa5591e39c3a",
                "category_name": "Girls Ethnic Wear",
                "specification": "62ad8d1c2a62aa5591e3f721",
                "createdAt": "2022-06-15T12:34:26.450Z",
                "updatedAt": "2022-10-19T09:13:06.445Z",
                "__v": 0,
                "images": "public/category/1666170786445.4958.webp"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Great for summer",
            "Both outdoor and indoor"
        ],
        "key_words": [
            ""
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62ac23592a62aa5591e3ced4",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P004A",
        "model": "PB8",
        "specification": [
            {
                "_id": "62b044942a62aa5591e432f0",
                "title": "AVAILABLE SIZE",
                "value": "",
                "suffix": "6 Months"
            },
            {
                "_id": "62b044942a62aa5591e432f1",
                "title": "Material",
                "value": "Handloom cotton",
                "suffix": ""
            },
            {
                "_id": "62b044942a62aa5591e432f2",
                "title": "Colour",
                "value": "Magenta red",
                "suffix": ""
            },
            {
                "_id": "62b044942a62aa5591e432f3",
                "title": "Model",
                "value": "One piece set with sleeveless top and pavadai attached",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-17T06:46:49.391Z",
        "updatedAt": "2022-06-25T09:12:50.747Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Pavadai and Blouse in a one piece set Age 6 Months ",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 1800,
        "sp": 1500,
        "stock": 0,
        "tax": null,
        "meta_desc": "Pavadai and blouse\n",
        "meta_key": "skirt and top",
        "note": "<div>Care instructions:</div><div>Home wash but hand wash and dry in shade.</div><div><br></div>",
        "images": [
            "public/product/1655706715391.4578.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.5,
            "length": 31,
            "breadth": 31,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "62a9d1d22a62aa5591e39c3a",
                "category_name": "Girls Ethnic Wear",
                "specification": "62ad8d1c2a62aa5591e3f721",
                "createdAt": "2022-06-15T12:34:26.450Z",
                "updatedAt": "2022-10-19T09:13:06.445Z",
                "__v": 0,
                "images": "public/category/1666170786445.4958.webp"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Great for summer",
            "Both outdoor and indoor",
            "Pavadai and blouse"
        ],
        "key_words": [
            ""
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62ac24632a62aa5591e3cf5c",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P044B",
        "model": "PB8",
        "specification": [
            {
                "_id": "62b044b02a62aa5591e43312",
                "title": "AVAILABLE SIZE",
                "value": "",
                "suffix": "1 Year"
            },
            {
                "_id": "62b044b02a62aa5591e43313",
                "title": "Material",
                "value": "Handloom cotton",
                "suffix": ""
            },
            {
                "_id": "62b044b02a62aa5591e43314",
                "title": "Colour",
                "value": "Magenta red",
                "suffix": ""
            },
            {
                "_id": "62b044b02a62aa5591e43315",
                "title": "Model",
                "value": "One piece set with sleeveless top and pavadai attached",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-17T06:51:15.489Z",
        "updatedAt": "2022-06-20T09:58:08.555Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Pavadai and Blouse in a one piece set  Age 1 Year ",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 1800,
        "sp": 1200,
        "stock": 0,
        "tax": null,
        "meta_desc": "Pavadai and blouse\t",
        "meta_key": "skirt and top",
        "note": "<div>Care instructions:</div><div>Home wash but hand wash and dry in shade.</div><div><br></div>",
        "images": [
            "public/product/1655448830191.3699.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.5,
            "length": 31,
            "breadth": 31,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "62a9d1d22a62aa5591e39c3a",
                "category_name": "Girls Ethnic Wear",
                "specification": "62ad8d1c2a62aa5591e3f721",
                "createdAt": "2022-06-15T12:34:26.450Z",
                "updatedAt": "2022-10-19T09:13:06.445Z",
                "__v": 0,
                "images": "public/category/1666170786445.4958.webp"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Great for summer",
            "Both outdoor and indoor",
            ""
        ],
        "key_words": [
            ""
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62ac256e2a62aa5591e3d038",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P044C",
        "model": "PB8",
        "specification": [
            {
                "_id": "62b044c52a62aa5591e43334",
                "title": "AVAILABLE SIZE",
                "value": "",
                "suffix": "1.5 Years"
            },
            {
                "_id": "62b044c52a62aa5591e43335",
                "title": "Material",
                "value": "Handloom cotton",
                "suffix": ""
            },
            {
                "_id": "62b044c52a62aa5591e43336",
                "title": "Colour",
                "value": "Magenta red",
                "suffix": ""
            },
            {
                "_id": "62b044c52a62aa5591e43337",
                "title": "Model",
                "value": "One piece set with sleeveless top and pavadai attached",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-17T06:55:42.069Z",
        "updatedAt": "2022-06-20T09:58:29.809Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Pavadai and Blouse in a one piece set Age 1.5 years ",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 1800,
        "sp": 1500,
        "stock": 0,
        "tax": null,
        "meta_desc": "Pavadai and blouse",
        "meta_key": "skirt and top",
        "note": "<div>Care instructions:</div><div>Home wash but hand wash and dry in shade.</div><div><br></div>",
        "images": [
            "public/product/1655706597308.9478.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.5,
            "length": 31,
            "breadth": 31,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "62a9d1d22a62aa5591e39c3a",
                "category_name": "Girls Ethnic Wear",
                "specification": "62ad8d1c2a62aa5591e3f721",
                "createdAt": "2022-06-15T12:34:26.450Z",
                "updatedAt": "2022-10-19T09:13:06.445Z",
                "__v": 0,
                "images": "public/category/1666170786445.4958.webp"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Great for summer",
            "Both outdoor and indoor"
        ],
        "key_words": [
            ""
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62ac26882a62aa5591e3d0d3",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P044D",
        "model": "PB8",
        "specification": [
            {
                "_id": "62b044de2a62aa5591e43356",
                "title": "AVAILABLE SIZE",
                "value": "",
                "suffix": "2 Years"
            },
            {
                "_id": "62b044de2a62aa5591e43357",
                "title": "Material",
                "value": "Handloom cotton",
                "suffix": ""
            },
            {
                "_id": "62b044de2a62aa5591e43358",
                "title": "Colour",
                "value": "Magenta red",
                "suffix": ""
            },
            {
                "_id": "62b044de2a62aa5591e43359",
                "title": "Model",
                "value": "One piece set with sleeveless top and pavadai attached",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-17T07:00:24.070Z",
        "updatedAt": "2022-06-20T09:58:54.532Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Pavadai and Blouse in a one piece set Age 2 years ",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 1800,
        "sp": 1500,
        "stock": 0,
        "tax": null,
        "meta_desc": "Pavadai and blouse\t\n",
        "meta_key": "skirt and top",
        "note": "<div>Care instructions:</div><div>Home wash but hand wash and dry in shade.</div><div><br></div>",
        "images": [
            "public/product/1655706462895.0654.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.5,
            "length": 31,
            "breadth": 31,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "62a9d1d22a62aa5591e39c3a",
                "category_name": "Girls Ethnic Wear",
                "specification": "62ad8d1c2a62aa5591e3f721",
                "createdAt": "2022-06-15T12:34:26.450Z",
                "updatedAt": "2022-10-19T09:13:06.445Z",
                "__v": 0,
                "images": "public/category/1666170786445.4958.webp"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Great for summer",
            "Both outdoor and indoor"
        ],
        "key_words": [
            ""
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62ac27332a62aa5591e3d130",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P044E",
        "model": "PB8",
        "specification": [
            {
                "_id": "62b044fe2a62aa5591e4337d",
                "title": "AVAILABLE SIZE",
                "value": "",
                "suffix": "4 Years"
            },
            {
                "_id": "62b044fe2a62aa5591e4337e",
                "title": "Material",
                "value": "Handloom cotton",
                "suffix": ""
            },
            {
                "_id": "62b044fe2a62aa5591e4337f",
                "title": "Colour",
                "value": "Magenta red",
                "suffix": ""
            },
            {
                "_id": "62b044fe2a62aa5591e43380",
                "title": "Model",
                "value": "One piece set with sleeveless top and pavadai attached",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-17T07:03:15.516Z",
        "updatedAt": "2022-06-20T09:59:26.794Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Pavadai and Blouse in a one piece set Age 4 Years ",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 1800,
        "sp": 1500,
        "stock": 0,
        "tax": null,
        "meta_desc": "Pavadai and blouse\t\n",
        "meta_key": "skirt and top",
        "note": "<div><br></div><div>Care instructions:</div><div>Home wash but hand wash and dry in shade.</div><div><br></div>",
        "images": [
            "public/product/1655449518609.5474.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.3,
            "length": 31,
            "breadth": 31,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "62a9d1d22a62aa5591e39c3a",
                "category_name": "Girls Ethnic Wear",
                "specification": "62ad8d1c2a62aa5591e3f721",
                "createdAt": "2022-06-15T12:34:26.450Z",
                "updatedAt": "2022-10-19T09:13:06.445Z",
                "__v": 0,
                "images": "public/category/1666170786445.4958.webp"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Traditional Pavadai with fancy top"
        ],
        "key_words": [
            "Sleeveless to beat the heat."
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62ac50562a62aa5591e3df53",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P049A",
        "model": "PB9",
        "specification": [
            {
                "_id": "62b045612a62aa5591e433b0",
                "title": "AVAILABLE SIZE",
                "value": "",
                "suffix": "6 Months"
            },
            {
                "_id": "62b045612a62aa5591e433b1",
                "title": "Material",
                "value": "Cotton",
                "suffix": ""
            },
            {
                "_id": "62b045612a62aa5591e433b2",
                "title": "Colour",
                "value": "Parrot green with Blue",
                "suffix": ""
            },
            {
                "_id": "62b045612a62aa5591e433b3",
                "title": "Model",
                "value": "Top with pavadai and petticoat attached",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-17T09:58:46.950Z",
        "updatedAt": "2022-06-25T09:17:13.192Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Ajrakh Pavadai  and top Age 6 Months",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 1800,
        "sp": 1500,
        "stock": 0,
        "tax": null,
        "meta_desc": "Pavadai and blouse , skirt and top\n ",
        "meta_key": " skirt and top",
        "note": "<div>Hand wash and dry in shade.Iron for best results.</div><div><br></div>",
        "images": [
            "public/product/1655460057855.7622.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.3,
            "length": 31,
            "breadth": 31,
            "height": 31
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "62a9d1d22a62aa5591e39c3a",
                "category_name": "Girls Ethnic Wear",
                "specification": "62ad8d1c2a62aa5591e3f721",
                "createdAt": "2022-06-15T12:34:26.450Z",
                "updatedAt": "2022-10-19T09:13:06.445Z",
                "__v": 0,
                "images": "public/category/1666170786445.4958.webp"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Traditional Pavadai with fancy top"
        ],
        "key_words": [
            "Skirt and Top "
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62ac51232a62aa5591e3df9f",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P049B",
        "model": "PB9",
        "specification": [
            {
                "_id": "62b0457a2a62aa5591e433d2",
                "title": "AVAILABLE SIZE",
                "value": "",
                "suffix": "1 Year"
            },
            {
                "_id": "62b0457a2a62aa5591e433d3",
                "title": "Material",
                "value": "Cotton",
                "suffix": ""
            },
            {
                "_id": "62b0457a2a62aa5591e433d4",
                "title": "Colour",
                "value": "Parrot green with Blue",
                "suffix": ""
            },
            {
                "_id": "62b0457a2a62aa5591e433d5",
                "title": "Model",
                "value": "Top with pavadai and petticoat attached",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-17T10:02:11.690Z",
        "updatedAt": "2022-06-25T09:17:56.735Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Ajrakh Pavadai  and top Age  1 Year ",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 1800,
        "sp": 1500,
        "stock": 0,
        "tax": null,
        "meta_desc": "Pavadai and blouse ,Skirt and Top \n",
        "meta_key": "Skirt and Top ",
        "note": "&#160;<span>Hand wash and dry in shade.Iron for best results.</span><div><span><br></span></div>",
        "images": [
            "public/product/1655702821351.2583.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.3,
            "length": 31,
            "breadth": 31,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "62a9d1d22a62aa5591e39c3a",
                "category_name": "Girls Ethnic Wear",
                "specification": "62ad8d1c2a62aa5591e3f721",
                "createdAt": "2022-06-15T12:34:26.450Z",
                "updatedAt": "2022-10-19T09:13:06.445Z",
                "__v": 0,
                "images": "public/category/1666170786445.4958.webp"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Traditional Pavadai with fancy top"
        ],
        "key_words": [
            "Skirt and Top "
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62ac51e82a62aa5591e3dff7",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P0049C",
        "model": "PB9",
        "specification": [
            {
                "_id": "62b045972a62aa5591e433f4",
                "title": "AVAILABLE SIZE",
                "value": "",
                "suffix": "1.5 Years"
            },
            {
                "_id": "62b045972a62aa5591e433f5",
                "title": "Material",
                "value": "Cotton",
                "suffix": ""
            },
            {
                "_id": "62b045972a62aa5591e433f6",
                "title": "Colour",
                "value": "Parrot green with Blue",
                "suffix": ""
            },
            {
                "_id": "62b045972a62aa5591e433f7",
                "title": "Model",
                "value": " Cotton Parrot green with Blue Top with pavadai and petticoat attached",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-17T10:05:28.782Z",
        "updatedAt": "2022-06-25T09:18:39.707Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Ajrakh Pavadai  and top Age  1.5years ",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 1800,
        "sp": 1500,
        "stock": 0,
        "tax": null,
        "meta_desc": "Pavadai and blouse ,Skirt and Top \n",
        "meta_key": "Skirt and Top ",
        "note": "<div>Hand wash and dry in shade.Iron for best results.</div><div><br></div>",
        "images": [
            "public/product/1655702895665.706.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.3,
            "length": 31,
            "breadth": 31,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "62a9d1d22a62aa5591e39c3a",
                "category_name": "Girls Ethnic Wear",
                "specification": "62ad8d1c2a62aa5591e3f721",
                "createdAt": "2022-06-15T12:34:26.450Z",
                "updatedAt": "2022-10-19T09:13:06.445Z",
                "__v": 0,
                "images": "public/category/1666170786445.4958.webp"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Traditional Pavadai with fancy top"
        ],
        "key_words": [
            "Skirt and Top "
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62ac529d2a62aa5591e3e047",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P0049D",
        "model": "PB9",
        "specification": [
            {
                "_id": "62b045b62a62aa5591e43416",
                "title": "AVAILABLE SIZE",
                "value": "",
                "suffix": "2 Years"
            },
            {
                "_id": "62b045b62a62aa5591e43417",
                "title": "Material",
                "value": "Cotton",
                "suffix": ""
            },
            {
                "_id": "62b045b62a62aa5591e43418",
                "title": "Colour",
                "value": "Parrot green with Blue",
                "suffix": ""
            },
            {
                "_id": "62b045b62a62aa5591e43419",
                "title": "Model",
                "value": "Cotton Parrot green with Blue Top with pavadai and petticoat attached",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-17T10:08:29.153Z",
        "updatedAt": "2022-06-25T09:19:07.033Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Ajrakh Pavadai  and top Age  Age 2 Years ",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 1800,
        "sp": 1500,
        "stock": 0,
        "tax": null,
        "meta_desc": "Pavadai and blouse ,Skirt and Top \n",
        "meta_key": "Skirt and Top ",
        "note": "<div>Hand wash and dry in shade.Iron for best results.</div><div><br></div>",
        "images": [
            "public/product/1655702959018.9834.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.3,
            "length": 31,
            "breadth": 31,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "62a9d1d22a62aa5591e39c3a",
                "category_name": "Girls Ethnic Wear",
                "specification": "62ad8d1c2a62aa5591e3f721",
                "createdAt": "2022-06-15T12:34:26.450Z",
                "updatedAt": "2022-10-19T09:13:06.445Z",
                "__v": 0,
                "images": "public/category/1666170786445.4958.webp"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Traditional Pavadai with fancy top"
        ],
        "key_words": [
            "Skirt and Top "
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62ac534b2a62aa5591e3e093",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P049E",
        "model": "PB9",
        "specification": [
            {
                "_id": "62b045ce2a62aa5591e43438",
                "title": "AVAILABLE SIZE",
                "value": "",
                "suffix": "4 Years"
            },
            {
                "_id": "62b045ce2a62aa5591e43439",
                "title": "Material",
                "value": "Cotton",
                "suffix": ""
            },
            {
                "_id": "62b045ce2a62aa5591e4343a",
                "title": "Colour",
                "value": "Parrot green with Blue",
                "suffix": ""
            },
            {
                "_id": "62b045ce2a62aa5591e4343b",
                "title": "Model",
                "value": "Top with pavadai and petticoat attached",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-17T10:11:23.267Z",
        "updatedAt": "2022-06-25T09:19:34.783Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Ajrakh Pavadai  and top Age  4 years",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 1800,
        "sp": 1500,
        "stock": 0,
        "tax": null,
        "meta_desc": "Pavadai and blouse ,Skirt and Top \n",
        "meta_key": "Skirt and Top ",
        "note": "<div>Hand wash and dry in shade.Iron for best results.</div><div><br></div>",
        "images": [
            "public/product/1655703069027.7512.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.3,
            "length": 30.5,
            "breadth": 30.5,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "62a9d1d22a62aa5591e39c3a",
                "category_name": "Girls Ethnic Wear",
                "specification": "62ad8d1c2a62aa5591e3f721",
                "createdAt": "2022-06-15T12:34:26.450Z",
                "updatedAt": "2022-10-19T09:13:06.445Z",
                "__v": 0,
                "images": "public/category/1666170786445.4958.webp"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Catchy colors with embroidery"
        ],
        "key_words": [
            "skirt and top"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b048292a62aa5591e43675",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P004 A",
        "model": "PB2",
        "specification": [
            {
                "_id": "62b048892a62aa5591e4368d",
                "title": "AVAILABLE SIZE",
                "value": "",
                "suffix": "6 Months"
            },
            {
                "_id": "62b048892a62aa5591e4368e",
                "title": "Material",
                "value": "cotton",
                "suffix": ""
            },
            {
                "_id": "62b048892a62aa5591e4368f",
                "title": "Colour",
                "value": "Blue blouse with pink pavadai",
                "suffix": ""
            },
            {
                "_id": "62b048892a62aa5591e43690",
                "title": "Model",
                "value": "pavadai attached with petticoat and elastic waist and with a short sleeve blouse",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-20T10:12:57.732Z",
        "updatedAt": "2022-06-25T09:20:40.692Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Pink Pavadai with Blue Blouse Age6 Months ",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 1800,
        "sp": 1500,
        "stock": 0,
        "tax": null,
        "meta_desc": "Pavadai and blouse ,skirt and top\n",
        "meta_key": "skirt and top",
        "note": "<div>Hand wash and dry in shade.Iron for better results.</div><div><br></div>",
        "images": [
            "public/product/1655720120871.1128.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.3,
            "length": 30.5,
            "breadth": 30.5,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "62a9d1d22a62aa5591e39c3a",
                "category_name": "Girls Ethnic Wear",
                "specification": "62ad8d1c2a62aa5591e3f721",
                "createdAt": "2022-06-15T12:34:26.450Z",
                "updatedAt": "2022-10-19T09:13:06.445Z",
                "__v": 0,
                "images": "public/category/1666170786445.4958.webp"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Catchy colors with embroidery"
        ],
        "key_words": [
            "skirt and top"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b048f72a62aa5591e436c1",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P004 B",
        "model": "PB2",
        "specification": [
            {
                "_id": "62b0493a2a62aa5591e436d9",
                "title": "AVAILABLE SIZE",
                "value": "",
                "suffix": "1 Year"
            },
            {
                "_id": "62b0493a2a62aa5591e436da",
                "title": "Material",
                "value": "cotton",
                "suffix": ""
            },
            {
                "_id": "62b0493a2a62aa5591e436db",
                "title": "Colour",
                "value": "Blue blouse with pink pavadai",
                "suffix": ""
            },
            {
                "_id": "62b0493a2a62aa5591e436dc",
                "title": "Model",
                "value": "pavadai attached with petticoat and elastic waist and with a short sleeve blouse",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-20T10:16:23.673Z",
        "updatedAt": "2022-06-25T09:20:16.944Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Pink Pavadai with Blue Blouse  Age 1 Year",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 1800,
        "sp": 1500,
        "stock": 0,
        "tax": null,
        "meta_desc": "Pavadai and blouse  ,skirt and top",
        "meta_key": "skirt and top",
        "note": "<div>Hand wash and dry in shade.Iron for better results.</div><div><br></div>",
        "images": [
            "public/product/1655720294908.2144.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.3,
            "length": 30.5,
            "breadth": 30.5,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "62a9d1d22a62aa5591e39c3a",
                "category_name": "Girls Ethnic Wear",
                "specification": "62ad8d1c2a62aa5591e3f721",
                "createdAt": "2022-06-15T12:34:26.450Z",
                "updatedAt": "2022-10-19T09:13:06.445Z",
                "__v": 0,
                "images": "public/category/1666170786445.4958.webp"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Catchy colors with embroidery"
        ],
        "key_words": [
            "skirt and top"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b049b12a62aa5591e43717",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P004 C",
        "model": "PB2",
        "specification": [
            {
                "_id": "62b049ee2a62aa5591e43733",
                "title": "AVAILABLE SIZE",
                "value": "",
                "suffix": "1.5 Years"
            },
            {
                "_id": "62b049ee2a62aa5591e43734",
                "title": "Material",
                "value": "cotton",
                "suffix": ""
            },
            {
                "_id": "62b049ee2a62aa5591e43735",
                "title": "Colour",
                "value": "Blue blouse with pink pavadai",
                "suffix": ""
            },
            {
                "_id": "62b049ee2a62aa5591e43736",
                "title": "Model",
                "value": "pavadai attached with petticoat and elastic waist and with a short sleeve blouse",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-20T10:19:29.838Z",
        "updatedAt": "2022-06-25T09:21:07.879Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Pink Pavadai with Blue Blouse  Age1.5 Years",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 1800,
        "sp": 1500,
        "stock": 0,
        "tax": null,
        "meta_desc": "Pavadai and blouse ,skirt and top",
        "meta_key": "skirt and top",
        "note": "<div>Hand wash and dry in shade.Iron for better results.</div><div><br></div>",
        "images": [
            "public/product/1655813774474.513.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.3,
            "length": 30.5,
            "breadth": 30.5,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "62a9d1d22a62aa5591e39c3a",
                "category_name": "Girls Ethnic Wear",
                "specification": "62ad8d1c2a62aa5591e3f721",
                "createdAt": "2022-06-15T12:34:26.450Z",
                "updatedAt": "2022-10-19T09:13:06.445Z",
                "__v": 0,
                "images": "public/category/1666170786445.4958.webp"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Catchy colors with embroidery"
        ],
        "key_words": [
            "skirt and top"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b04a622a62aa5591e43771",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P004 D",
        "model": "PB2",
        "specification": [
            {
                "_id": "62b04d2f2a62aa5591e43b22",
                "title": "AVAILABLE SIZE",
                "value": "",
                "suffix": "2 Years"
            },
            {
                "_id": "62b04d2f2a62aa5591e43b23",
                "title": "Material",
                "value": "cotton",
                "suffix": ""
            },
            {
                "_id": "62b04d2f2a62aa5591e43b24",
                "title": "Colour",
                "value": "Blue blouse with pink pavadai",
                "suffix": ""
            },
            {
                "_id": "62b04d2f2a62aa5591e43b25",
                "title": "Model",
                "value": "pavadai attached with petticoat and elastic waist and with a short sleeve blouse",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-20T10:22:26.115Z",
        "updatedAt": "2022-06-25T09:21:33.007Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Pink Pavadai with Blue Blouse  Age 2 Years ",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 1800,
        "sp": 1500,
        "stock": 0,
        "tax": null,
        "meta_desc": "Pavadai and blouse  ,skirt and top",
        "meta_key": "skirt and top",
        "note": "<div>Hand wash and dry in shade.Iron for better results.</div><div><br></div>",
        "images": [
            "public/product/1655720646913.9658.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.3,
            "length": 30.5,
            "breadth": 30.5,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 100,
            "national": 100
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "62a9d1d22a62aa5591e39c3a",
                "category_name": "Girls Ethnic Wear",
                "specification": "62ad8d1c2a62aa5591e3f721",
                "createdAt": "2022-06-15T12:34:26.450Z",
                "updatedAt": "2022-10-19T09:13:06.445Z",
                "__v": 0,
                "images": "public/category/1666170786445.4958.webp"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Catchy colors with embroidery"
        ],
        "key_words": [
            "skirt and top"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b04ba32a62aa5591e438a0",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P004 E",
        "model": "PB2",
        "specification": [
            {
                "_id": "62b04cd42a62aa5591e43ab5",
                "title": "AVAILABLE SIZE",
                "value": "",
                "suffix": "4 Years"
            },
            {
                "_id": "62b04cd42a62aa5591e43ab6",
                "title": "Material",
                "value": "cotton",
                "suffix": ""
            },
            {
                "_id": "62b04cd42a62aa5591e43ab7",
                "title": "Colour",
                "value": "Blue blouse with pink pavadai",
                "suffix": ""
            },
            {
                "_id": "62b04cd42a62aa5591e43ab8",
                "title": "Model",
                "value": "pavadai attached with petticoat and elastic waist and with a short sleeve blouse",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-20T10:27:47.327Z",
        "updatedAt": "2022-06-25T09:21:48.962Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Pink Pavadai with Blue Blouse Age 4 Years ",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 1800,
        "sp": 1500,
        "stock": 0,
        "tax": null,
        "meta_desc": "Pavadai and blouse ,skirt and top",
        "meta_key": "skirt and top",
        "note": "<div>Hand wash and dry in shade.Iron for better results.</div><div><br></div>",
        "images": [
            "public/product/1655720965894.1628.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.4,
            "length": 30.5,
            "breadth": 30.5,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6229fdc25507127df692f42c",
                "category_name": "Womans wear",
                "specification": "62ad9bc72a62aa5591e3ff4b",
                "createdAt": "2022-03-10T13:31:46.187Z",
                "updatedAt": "2022-10-19T09:11:36.730Z",
                "__v": 0,
                "images": "public/category/1666170696730.1174.webp"
            },
            {
                "parent": "6229fdc25507127df692f42c",
                "status": true,
                "_id": "622aec725507127df69304f4",
                "category_name": "Kurthis",
                "specification": "622aebec5507127df69304d3",
                "createdAt": "2022-03-11T06:30:10.094Z",
                "updatedAt": "2022-06-20T09:03:37.611Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "For casual wear",
            "Umbrella cut top"
        ],
        "key_words": [
            "Tops ,Umbrella cut top"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b04fc92a62aa5591e43b9b",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P025 A",
        "model": "K1",
        "specification": [
            {
                "_id": "62b952e62a62aa5591e4e5c6",
                "title": "Material",
                "value": "Cotton",
                "suffix": ""
            },
            {
                "_id": "62b952e62a62aa5591e4e5c7",
                "title": "Colour",
                "value": "Blue",
                "suffix": ""
            },
            {
                "_id": "62b952e62a62aa5591e4e5c8",
                "title": "Model",
                "value": "Flare cut",
                "suffix": ""
            },
            {
                "_id": "62b952e62a62aa5591e4e5c9",
                "title": "Size",
                "value": "",
                "suffix": "XS"
            }
        ],
        "createdAt": "2022-06-20T10:45:29.175Z",
        "updatedAt": "2022-06-27T06:49:10.751Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Kurthis - XS Size",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 2000,
        "sp": 1800,
        "stock": 0,
        "tax": null,
        "meta_desc": "Kurthis ,Tops\n",
        "meta_key": "Tops",
        "note": "<div>Kindly hand wash the first wash and iron for best result</div><div><br></div>",
        "images": [
            "public/product/1656145638315.4333.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.4,
            "length": 30.5,
            "breadth": 30.5,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6229fdc25507127df692f42c",
                "category_name": "Womans wear",
                "specification": "62ad9bc72a62aa5591e3ff4b",
                "createdAt": "2022-03-10T13:31:46.187Z",
                "updatedAt": "2022-10-19T09:11:36.730Z",
                "__v": 0,
                "images": "public/category/1666170696730.1174.webp"
            },
            {
                "parent": "6229fdc25507127df692f42c",
                "status": true,
                "_id": "622aec725507127df69304f4",
                "category_name": "Kurthis",
                "specification": "622aebec5507127df69304d3",
                "createdAt": "2022-03-11T06:30:10.094Z",
                "updatedAt": "2022-06-20T09:03:37.611Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "For casual wear",
            "Umbrella cut top"
        ],
        "key_words": [
            "Tops ,Umbrella cut top"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b054fd2a62aa5591e43c6c",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P025 B",
        "model": "K1",
        "specification": [
            {
                "_id": "62b952d52a62aa5591e4e5a4",
                "title": "Material",
                "value": "Cotton",
                "suffix": ""
            },
            {
                "_id": "62b952d52a62aa5591e4e5a5",
                "title": "Colour",
                "value": "Blue",
                "suffix": ""
            },
            {
                "_id": "62b952d52a62aa5591e4e5a6",
                "title": "Model",
                "value": "Flare cut",
                "suffix": ""
            },
            {
                "_id": "62b952d52a62aa5591e4e5a7",
                "title": "Size",
                "value": "",
                "suffix": "S"
            }
        ],
        "createdAt": "2022-06-20T11:07:41.582Z",
        "updatedAt": "2022-06-27T06:48:53.167Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "kurthis -S Size",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 2000,
        "sp": 1800,
        "stock": 0,
        "tax": null,
        "meta_desc": "Kurthis ,Tops",
        "meta_key": "Tops",
        "note": "<div>Kindly hand wash the first wash and iron for best result</div><div><br></div>",
        "images": [
            "public/product/1655723502241.7568.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.4,
            "length": 30.5,
            "breadth": 30.5,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6229fdc25507127df692f42c",
                "category_name": "Womans wear",
                "specification": "62ad9bc72a62aa5591e3ff4b",
                "createdAt": "2022-03-10T13:31:46.187Z",
                "updatedAt": "2022-10-19T09:11:36.730Z",
                "__v": 0,
                "images": "public/category/1666170696730.1174.webp"
            },
            {
                "parent": "6229fdc25507127df692f42c",
                "status": true,
                "_id": "622aec725507127df69304f4",
                "category_name": "Kurthis",
                "specification": "622aebec5507127df69304d3",
                "createdAt": "2022-03-11T06:30:10.094Z",
                "updatedAt": "2022-06-20T09:03:37.611Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "For casual wear"
        ],
        "key_words": [
            " Tops,Umbrella cut top"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b0562f2a62aa5591e43cbc",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P025 C",
        "model": "K1",
        "specification": [
            {
                "_id": "62b953172a62aa5591e4e61c",
                "title": "Material",
                "value": "Cotton",
                "suffix": ""
            },
            {
                "_id": "62b953172a62aa5591e4e61d",
                "title": "Colour",
                "value": "Blue",
                "suffix": ""
            },
            {
                "_id": "62b953172a62aa5591e4e61e",
                "title": "Model",
                "value": "Flare cut",
                "suffix": ""
            },
            {
                "_id": "62b953172a62aa5591e4e61f",
                "title": "Size",
                "value": "",
                "suffix": "M"
            }
        ],
        "createdAt": "2022-06-20T11:12:47.394Z",
        "updatedAt": "2022-06-27T06:49:59.508Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Kurthis- M Size",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 2000,
        "sp": 1800,
        "stock": 0,
        "tax": null,
        "meta_desc": "Kurthis ,Tops",
        "meta_key": "Tops",
        "note": "<div>Kindly hand wash the first wash and iron for best result</div><div><br></div>",
        "images": [
            "public/product/1655723699856.7463.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.4,
            "length": 30.5,
            "breadth": 30.5,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6229fdc25507127df692f42c",
                "category_name": "Womans wear",
                "specification": "62ad9bc72a62aa5591e3ff4b",
                "createdAt": "2022-03-10T13:31:46.187Z",
                "updatedAt": "2022-10-19T09:11:36.730Z",
                "__v": 0,
                "images": "public/category/1666170696730.1174.webp"
            },
            {
                "parent": "6229fdc25507127df692f42c",
                "status": true,
                "_id": "622aec725507127df69304f4",
                "category_name": "Kurthis",
                "specification": "622aebec5507127df69304d3",
                "createdAt": "2022-03-11T06:30:10.094Z",
                "updatedAt": "2022-06-20T09:03:37.611Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "For casual wear"
        ],
        "key_words": [
            "Tops ,Umbrella cut top"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b058472a62aa5591e43d21",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P025 D",
        "model": "K1",
        "specification": [
            {
                "_id": "62b9535b2a62aa5591e4e64c",
                "title": "Material",
                "value": "Cotton",
                "suffix": ""
            },
            {
                "_id": "62b9535b2a62aa5591e4e64d",
                "title": "Colour",
                "value": "Bllue",
                "suffix": ""
            },
            {
                "_id": "62b9535b2a62aa5591e4e64e",
                "title": "Model",
                "value": "Flare cut",
                "suffix": ""
            },
            {
                "_id": "62b9535b2a62aa5591e4e64f",
                "title": "Size",
                "value": "",
                "suffix": "L"
            }
        ],
        "createdAt": "2022-06-20T11:21:43.330Z",
        "updatedAt": "2022-06-27T06:51:07.827Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Kurthis - L Size",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 2000,
        "sp": 1800,
        "stock": 0,
        "tax": null,
        "meta_desc": "Kurthis ,Tops\n",
        "meta_key": "Tops",
        "note": "<div>Kindly hand wash the first wash and iron for best result</div><div><br></div>",
        "images": [
            "public/product/1655724231106.521.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.25,
            "length": 30.5,
            "breadth": 30.5,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6229fdc25507127df692f42c",
                "category_name": "Womans wear",
                "specification": "62ad9bc72a62aa5591e3ff4b",
                "createdAt": "2022-03-10T13:31:46.187Z",
                "updatedAt": "2022-10-19T09:11:36.730Z",
                "__v": 0,
                "images": "public/category/1666170696730.1174.webp"
            },
            {
                "parent": "6229fdc25507127df692f42c",
                "status": true,
                "_id": "622aec725507127df69304f4",
                "category_name": "Kurthis",
                "specification": "622aebec5507127df69304d3",
                "createdAt": "2022-03-11T06:30:10.094Z",
                "updatedAt": "2022-06-20T09:03:37.611Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Delicate hand embroidery",
            "For casual wear",
            "To wear with jeans or leggings"
        ],
        "key_words": [
            "Kurthi"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b05bae2a62aa5591e43e18",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P026 A",
        "model": "K2",
        "specification": [
            {
                "_id": "62b953f22a62aa5591e4e75f",
                "title": "Material",
                "value": "Cotton",
                "suffix": ""
            },
            {
                "_id": "62b953f22a62aa5591e4e760",
                "title": "Colour",
                "value": "Yellow Printed",
                "suffix": ""
            },
            {
                "_id": "62b953f22a62aa5591e4e761",
                "title": "Model",
                "value": "Straight Cut ",
                "suffix": ""
            },
            {
                "_id": "62b953f22a62aa5591e4e762",
                "title": "Size",
                "value": "",
                "suffix": "XS"
            }
        ],
        "createdAt": "2022-06-20T11:36:14.131Z",
        "updatedAt": "2022-06-27T06:53:38.007Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Yellow  printed Kurthi - XS Size",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 2000,
        "sp": 1800,
        "stock": 0,
        "tax": null,
        "meta_desc": "Tops, Kurthi",
        "meta_key": "Kurthi",
        "note": "<div>Kindly hand wash</div><div><br></div>",
        "images": [
            "public/product/1655725188496.5232.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.25,
            "length": 30.5,
            "breadth": 30.5,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6229fdc25507127df692f42c",
                "category_name": "Womans wear",
                "specification": "62ad9bc72a62aa5591e3ff4b",
                "createdAt": "2022-03-10T13:31:46.187Z",
                "updatedAt": "2022-10-19T09:11:36.730Z",
                "__v": 0,
                "images": "public/category/1666170696730.1174.webp"
            },
            {
                "parent": "6229fdc25507127df692f42c",
                "status": true,
                "_id": "622aec725507127df69304f4",
                "category_name": "Kurthis",
                "specification": "622aebec5507127df69304d3",
                "createdAt": "2022-03-11T06:30:10.094Z",
                "updatedAt": "2022-06-20T09:03:37.611Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Delicate hand embroidery",
            "For casual wear",
            "To wear with jeans or leggings"
        ],
        "key_words": [
            "Kurthi"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b05cbd2a62aa5591e43e70",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P026 B",
        "model": "K2",
        "specification": [
            {
                "_id": "62b954212a62aa5591e4e78f",
                "title": "Material",
                "value": "Cotton",
                "suffix": ""
            },
            {
                "_id": "62b954212a62aa5591e4e790",
                "title": "Colour",
                "value": "Yellow Printed",
                "suffix": ""
            },
            {
                "_id": "62b954212a62aa5591e4e791",
                "title": "Model",
                "value": "Straight Cut",
                "suffix": ""
            },
            {
                "_id": "62b954212a62aa5591e4e792",
                "title": "Size",
                "value": "",
                "suffix": "S"
            }
        ],
        "createdAt": "2022-06-20T11:40:45.107Z",
        "updatedAt": "2022-06-27T06:54:25.199Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Yellow Printed Kurthi - S Size",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 2000,
        "sp": 1800,
        "stock": 0,
        "tax": null,
        "meta_desc": "Tops ,Kurthi",
        "meta_key": "Kurthi",
        "note": "<div>Kindly hand wash</div><div><br></div>",
        "images": [
            "public/product/1655725414980.0989.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.25,
            "length": 30.5,
            "breadth": 30.5,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6229fdc25507127df692f42c",
                "category_name": "Womans wear",
                "specification": "62ad9bc72a62aa5591e3ff4b",
                "createdAt": "2022-03-10T13:31:46.187Z",
                "updatedAt": "2022-10-19T09:11:36.730Z",
                "__v": 0,
                "images": "public/category/1666170696730.1174.webp"
            },
            {
                "parent": "6229fdc25507127df692f42c",
                "status": true,
                "_id": "622aec725507127df69304f4",
                "category_name": "Kurthis",
                "specification": "622aebec5507127df69304d3",
                "createdAt": "2022-03-11T06:30:10.094Z",
                "updatedAt": "2022-06-20T09:03:37.611Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Delicate hand embroidery",
            "For casual wear",
            "To wear with jeans or leggings"
        ],
        "key_words": [
            "Kurthi"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b05da32a62aa5591e43ec6",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P026 C",
        "model": "K2",
        "specification": [
            {
                "_id": "62b954442a62aa5591e4e7bf",
                "title": "Material",
                "value": "Cotton",
                "suffix": ""
            },
            {
                "_id": "62b954442a62aa5591e4e7c0",
                "title": "Colour",
                "value": "Yellow Printed",
                "suffix": ""
            },
            {
                "_id": "62b954442a62aa5591e4e7c1",
                "title": "Model",
                "value": "Straight cut",
                "suffix": ""
            },
            {
                "_id": "62b954442a62aa5591e4e7c2",
                "title": "Size",
                "value": "",
                "suffix": "M"
            }
        ],
        "createdAt": "2022-06-20T11:44:35.520Z",
        "updatedAt": "2022-06-27T06:56:50.976Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Yellow  Printed Kurthi - M Size",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 2000,
        "sp": 1800,
        "stock": 0,
        "tax": null,
        "meta_desc": "Tops ,Kurthi",
        "meta_key": "Kurthi",
        "note": "",
        "images": [
            "public/product/1655725564079.2048.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.4,
            "length": 30.5,
            "breadth": 30.5,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6229fdc25507127df692f42c",
                "category_name": "Womans wear",
                "specification": "62ad9bc72a62aa5591e3ff4b",
                "createdAt": "2022-03-10T13:31:46.187Z",
                "updatedAt": "2022-10-19T09:11:36.730Z",
                "__v": 0,
                "images": "public/category/1666170696730.1174.webp"
            },
            {
                "parent": "6229fdc25507127df692f42c",
                "status": true,
                "_id": "622aec725507127df69304f4",
                "category_name": "Kurthis",
                "specification": "622aebec5507127df69304d3",
                "createdAt": "2022-03-11T06:30:10.094Z",
                "updatedAt": "2022-06-20T09:03:37.611Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Delicate hand embroidery",
            "For casual wear",
            "To wear with jeans or leggings"
        ],
        "key_words": [
            "Kurthi"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b05e322a62aa5591e43f08",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P026 D",
        "model": "K2",
        "specification": [
            {
                "_id": "62b954c82a62aa5591e4e844",
                "title": "Material",
                "value": "Cotton",
                "suffix": ""
            },
            {
                "_id": "62b954c82a62aa5591e4e845",
                "title": "Colour",
                "value": "Yellow Printed",
                "suffix": ""
            },
            {
                "_id": "62b954c82a62aa5591e4e846",
                "title": "Model",
                "value": "Straight Cut ",
                "suffix": ""
            },
            {
                "_id": "62b954c82a62aa5591e4e847",
                "title": "Size",
                "value": "",
                "suffix": "L"
            }
        ],
        "createdAt": "2022-06-20T11:46:58.329Z",
        "updatedAt": "2022-06-27T06:57:12.332Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Yellow Printed Kurthi - L Size",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 2000,
        "sp": 1800,
        "stock": 0,
        "tax": null,
        "meta_desc": "Tops , Kurthi",
        "meta_key": "Kurthi",
        "note": "",
        "images": [
            "public/product/1655725714480.6663.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.5,
            "length": 31,
            "breadth": 31,
            "height": 2
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6229fdc25507127df692f42c",
                "category_name": "Womans wear",
                "specification": "62ad9bc72a62aa5591e3ff4b",
                "createdAt": "2022-03-10T13:31:46.187Z",
                "updatedAt": "2022-10-19T09:11:36.730Z",
                "__v": 0,
                "images": "public/category/1666170696730.1174.webp"
            },
            {
                "parent": "6229fdc25507127df692f42c",
                "status": true,
                "_id": "622aec725507127df69304f4",
                "category_name": "Kurthis",
                "specification": "622aebec5507127df69304d3",
                "createdAt": "2022-03-11T06:30:10.094Z",
                "updatedAt": "2022-06-20T09:03:37.611Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Cool and Casual wear",
            "Goes well with leggings and jeans\t\t",
            "Can be mix matched with any salwar bottom  "
        ],
        "key_words": [
            "Kurthi"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b061682a62aa5591e4419c",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P037 A",
        "model": "K3",
        "specification": [
            {
                "_id": "62b9553e2a62aa5591e4e924",
                "title": "Material",
                "value": "Cotton ",
                "suffix": ""
            },
            {
                "_id": "62b9553e2a62aa5591e4e925",
                "title": "Colour",
                "value": "Black ",
                "suffix": ""
            },
            {
                "_id": "62b9553e2a62aa5591e4e926",
                "title": "Model",
                "value": "Straight cut",
                "suffix": ""
            },
            {
                "_id": "62b9553e2a62aa5591e4e927",
                "title": "Size",
                "value": "",
                "suffix": "XS"
            }
        ],
        "createdAt": "2022-06-20T12:00:40.933Z",
        "updatedAt": "2022-06-27T06:59:10.828Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Ajrakh Print Black Kurthi - XS Size",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 2000,
        "sp": 1800,
        "stock": 0,
        "tax": null,
        "meta_desc": "Tops, Kurthi\n",
        "meta_key": "Kurthi",
        "note": "<div>Care Instructions:</div><div>Hand wash and dry in shade.</div><div>Starch and iron for best results</div>",
        "images": [
            "public/product/1655726615421.1018.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.5,
            "length": 31,
            "breadth": 31,
            "height": 2
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6229fdc25507127df692f42c",
                "category_name": "Womans wear",
                "specification": "62ad9bc72a62aa5591e3ff4b",
                "createdAt": "2022-03-10T13:31:46.187Z",
                "updatedAt": "2022-10-19T09:11:36.730Z",
                "__v": 0,
                "images": "public/category/1666170696730.1174.webp"
            },
            {
                "parent": "6229fdc25507127df692f42c",
                "status": true,
                "_id": "622aec725507127df69304f4",
                "category_name": "Kurthis",
                "specification": "622aebec5507127df69304d3",
                "createdAt": "2022-03-11T06:30:10.094Z",
                "updatedAt": "2022-06-20T09:03:37.611Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Cool and Casual wear",
            "Goes well with leggings and jeans",
            "Can be mix matched with any salwar bottom  "
        ],
        "key_words": [
            "Kurthi"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b0628f2a62aa5591e441f0",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P037 B",
        "model": "K3",
        "specification": [
            {
                "_id": "62b9556c2a62aa5591e4e954",
                "title": "Material",
                "value": "Cotton ",
                "suffix": ""
            },
            {
                "_id": "62b9556c2a62aa5591e4e955",
                "title": "Colour",
                "value": "Black ",
                "suffix": ""
            },
            {
                "_id": "62b9556c2a62aa5591e4e956",
                "title": "Model",
                "value": "Straight Cut ",
                "suffix": ""
            },
            {
                "_id": "62b9556c2a62aa5591e4e957",
                "title": "Size",
                "value": "",
                "suffix": "S"
            }
        ],
        "createdAt": "2022-06-20T12:05:35.423Z",
        "updatedAt": "2022-06-27T06:59:56.107Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Ajrakh Print Black Kurthi - S Size",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 2000,
        "sp": 1800,
        "stock": 0,
        "tax": null,
        "meta_desc": "Tops ,Kurthi\n",
        "meta_key": "Kurthi",
        "note": "<div>Care Instructions:</div><div>Hand wash and dry in shade.</div><div>Starch and iron for best results</div><div><br></div>",
        "images": [
            "public/product/1655726883855.991.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.4,
            "length": 31,
            "breadth": 31,
            "height": 2
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6229fdc25507127df692f42c",
                "category_name": "Womans wear",
                "specification": "62ad9bc72a62aa5591e3ff4b",
                "createdAt": "2022-03-10T13:31:46.187Z",
                "updatedAt": "2022-10-19T09:11:36.730Z",
                "__v": 0,
                "images": "public/category/1666170696730.1174.webp"
            },
            {
                "parent": "6229fdc25507127df692f42c",
                "status": true,
                "_id": "622aec725507127df69304f4",
                "category_name": "Kurthis",
                "specification": "622aebec5507127df69304d3",
                "createdAt": "2022-03-11T06:30:10.094Z",
                "updatedAt": "2022-06-20T09:03:37.611Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Cool and Casual wear",
            "Goes well with leggings and jeans\t\t",
            "Can be mix matched with any salwar bottom  "
        ],
        "key_words": [
            "Kurthi"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b063652a62aa5591e4423c",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P037 C",
        "model": "K3",
        "specification": [
            {
                "_id": "62b955952a62aa5591e4e984",
                "title": "Material",
                "value": "Cotton",
                "suffix": ""
            },
            {
                "_id": "62b955952a62aa5591e4e985",
                "title": "Colour",
                "value": "Black",
                "suffix": ""
            },
            {
                "_id": "62b955952a62aa5591e4e986",
                "title": "Model",
                "value": "Straight Cut ",
                "suffix": ""
            },
            {
                "_id": "62b955952a62aa5591e4e987",
                "title": "Size",
                "value": "",
                "suffix": "M"
            }
        ],
        "createdAt": "2022-06-20T12:09:09.654Z",
        "updatedAt": "2022-06-27T07:00:37.538Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Ajrakh Print Black Kurthi - M Size",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 2000,
        "sp": 1800,
        "stock": 0,
        "tax": null,
        "meta_desc": "Tops, Kurthi",
        "meta_key": "Kurthi",
        "note": "<div>Care Instructions:</div><div>Hand wash and dry in shade.</div><div>Starch and iron for best results</div><div><br></div>",
        "images": [
            "public/product/1655727086906.5059.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.4,
            "length": 31,
            "breadth": 31,
            "height": 2
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6229fdc25507127df692f42c",
                "category_name": "Womans wear",
                "specification": "62ad9bc72a62aa5591e3ff4b",
                "createdAt": "2022-03-10T13:31:46.187Z",
                "updatedAt": "2022-10-19T09:11:36.730Z",
                "__v": 0,
                "images": "public/category/1666170696730.1174.webp"
            },
            {
                "parent": "6229fdc25507127df692f42c",
                "status": true,
                "_id": "622aec725507127df69304f4",
                "category_name": "Kurthis",
                "specification": "622aebec5507127df69304d3",
                "createdAt": "2022-03-11T06:30:10.094Z",
                "updatedAt": "2022-06-20T09:03:37.611Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Cool and Casual wear",
            "Goes well with leggings and jeans",
            "Can be mix matched with any salwar bottom  "
        ],
        "key_words": [
            "Kurthi"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b0643c2a62aa5591e44288",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P037 D",
        "model": "K3",
        "specification": [
            {
                "_id": "62b955b82a62aa5591e4e9b4",
                "title": "Material",
                "value": "Cotton",
                "suffix": ""
            },
            {
                "_id": "62b955b82a62aa5591e4e9b5",
                "title": "Colour",
                "value": "Black",
                "suffix": ""
            },
            {
                "_id": "62b955b82a62aa5591e4e9b6",
                "title": "Model",
                "value": "Straight Cut",
                "suffix": ""
            },
            {
                "_id": "62b955b82a62aa5591e4e9b7",
                "title": "Size",
                "value": "",
                "suffix": "L"
            }
        ],
        "createdAt": "2022-06-20T12:12:44.077Z",
        "updatedAt": "2022-06-27T07:01:12.832Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Ajrakh Print Black Kurthi - L Size",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 2000,
        "sp": 1800,
        "stock": 0,
        "tax": null,
        "meta_desc": "Tops ,Kurthi",
        "meta_key": "Kurthi",
        "note": "<div>Care Instructions:</div><div>Hand wash and dry in shade.</div><div>Starch and iron for best results</div><div><br></div>",
        "images": [
            "public/product/1655727300670.2551.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.25,
            "length": 12,
            "breadth": 12,
            "height": 2
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6229fdc25507127df692f42c",
                "category_name": "Womans wear",
                "specification": "62ad9bc72a62aa5591e3ff4b",
                "createdAt": "2022-03-10T13:31:46.187Z",
                "updatedAt": "2022-10-19T09:11:36.730Z",
                "__v": 0,
                "images": "public/category/1666170696730.1174.webp"
            },
            {
                "parent": "6229fdc25507127df692f42c",
                "status": true,
                "_id": "622aec725507127df69304f4",
                "category_name": "Kurthis",
                "specification": "622aebec5507127df69304d3",
                "createdAt": "2022-03-11T06:30:10.094Z",
                "updatedAt": "2022-06-20T09:03:37.611Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Comfortable for daily wear"
        ],
        "key_words": [
            ""
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b067692a62aa5591e44395",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P038 A",
        "model": "K4",
        "specification": [
            {
                "_id": "62b955f02a62aa5591e4e9e4",
                "title": "Material",
                "value": "Cotton",
                "suffix": ""
            },
            {
                "_id": "62b955f02a62aa5591e4e9e5",
                "title": "Colour",
                "value": "Red With Traditional Print",
                "suffix": ""
            },
            {
                "_id": "62b955f02a62aa5591e4e9e6",
                "title": "Model",
                "value": "Straight cut with mild flair",
                "suffix": ""
            },
            {
                "_id": "62b955f02a62aa5591e4e9e7",
                "title": "Size",
                "value": "",
                "suffix": "XS"
            }
        ],
        "createdAt": "2022-06-20T12:26:17.210Z",
        "updatedAt": "2022-06-27T07:02:08.272Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Ajrakh Print Cotton Kurthi - XS Size",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 2000,
        "sp": 1800,
        "stock": 0,
        "tax": null,
        "meta_desc": "Tops\n",
        "meta_key": "Kurthis",
        "note": "<div><b>Care Instructions:</b></div><div><b>Hand wash and dry in shade.</b></div><div><b>Starch and iron for best results.</b></div><div><br></div>",
        "images": [
            "public/product/1655728146062.0913.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.4,
            "length": 12,
            "breadth": 12,
            "height": 2
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6229fdc25507127df692f42c",
                "category_name": "Womans wear",
                "specification": "62ad9bc72a62aa5591e3ff4b",
                "createdAt": "2022-03-10T13:31:46.187Z",
                "updatedAt": "2022-10-19T09:11:36.730Z",
                "__v": 0,
                "images": "public/category/1666170696730.1174.webp"
            },
            {
                "parent": "6229fdc25507127df692f42c",
                "status": true,
                "_id": "622aec725507127df69304f4",
                "category_name": "Kurthis",
                "specification": "622aebec5507127df69304d3",
                "createdAt": "2022-03-11T06:30:10.094Z",
                "updatedAt": "2022-06-20T09:03:37.611Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Comfortable for daily wear"
        ],
        "key_words": [
            "Kurthis"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b068492a62aa5591e443e1",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P038 B",
        "model": "K4",
        "specification": [
            {
                "_id": "62b9560f2a62aa5591e4ea14",
                "title": "Material",
                "value": "Cotton",
                "suffix": ""
            },
            {
                "_id": "62b9560f2a62aa5591e4ea15",
                "title": "Colour",
                "value": "Red With Traditional Print",
                "suffix": ""
            },
            {
                "_id": "62b9560f2a62aa5591e4ea16",
                "title": "Model",
                "value": "Straight cut with mild flair",
                "suffix": ""
            },
            {
                "_id": "62b9560f2a62aa5591e4ea17",
                "title": "Size",
                "value": "",
                "suffix": "S"
            }
        ],
        "createdAt": "2022-06-20T12:30:01.828Z",
        "updatedAt": "2022-06-27T07:02:39.004Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Ajrakh Print Cotton Kurthi  - S Size",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 2000,
        "sp": 1800,
        "stock": 0,
        "tax": null,
        "meta_desc": "Tops,Kurthis\n",
        "meta_key": "Kurthis",
        "note": "<div>Hand wash and dry in shade.</div><div>Starch and iron for best results.</div><div><br></div>",
        "images": [
            "public/product/1655728317963.25.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.4,
            "length": 12,
            "breadth": 12,
            "height": 2
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6229fdc25507127df692f42c",
                "category_name": "Womans wear",
                "specification": "62ad9bc72a62aa5591e3ff4b",
                "createdAt": "2022-03-10T13:31:46.187Z",
                "updatedAt": "2022-10-19T09:11:36.730Z",
                "__v": 0,
                "images": "public/category/1666170696730.1174.webp"
            },
            {
                "parent": "6229fdc25507127df692f42c",
                "status": true,
                "_id": "622aec725507127df69304f4",
                "category_name": "Kurthis",
                "specification": "622aebec5507127df69304d3",
                "createdAt": "2022-03-11T06:30:10.094Z",
                "updatedAt": "2022-06-20T09:03:37.611Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Comfortable for daily wear"
        ],
        "key_words": [
            "Kurthis"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b069052a62aa5591e44437",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P038 C",
        "model": "K4",
        "specification": [
            {
                "_id": "62b9562f2a62aa5591e4ea44",
                "title": "Material",
                "value": "Cotton",
                "suffix": ""
            },
            {
                "_id": "62b9562f2a62aa5591e4ea45",
                "title": "Colour",
                "value": "Red With Traditional Print",
                "suffix": ""
            },
            {
                "_id": "62b9562f2a62aa5591e4ea46",
                "title": "Model",
                "value": "Straight cut with mild flair",
                "suffix": ""
            },
            {
                "_id": "62b9562f2a62aa5591e4ea47",
                "title": "Size",
                "value": "",
                "suffix": "M"
            }
        ],
        "createdAt": "2022-06-20T12:33:09.488Z",
        "updatedAt": "2022-06-27T07:03:11.705Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Ajrakh Print Cotton Kurthi - M Size",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 2000,
        "sp": 1800,
        "stock": 0,
        "tax": null,
        "meta_desc": "Tops,Kurthi\n",
        "meta_key": "Kurthis",
        "note": "<div>Care Instructions:</div><div>Hand wash and dry in shade.</div><div>Starch and iron for best results.</div><div><br></div>",
        "images": [
            "public/product/1655728493410.4436.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.4,
            "length": 12,
            "breadth": 12,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6229fdc25507127df692f42c",
                "category_name": "Womans wear",
                "specification": "62ad9bc72a62aa5591e3ff4b",
                "createdAt": "2022-03-10T13:31:46.187Z",
                "updatedAt": "2022-10-19T09:11:36.730Z",
                "__v": 0,
                "images": "public/category/1666170696730.1174.webp"
            },
            {
                "parent": "6229fdc25507127df692f42c",
                "status": true,
                "_id": "622aec725507127df69304f4",
                "category_name": "Kurthis",
                "specification": "622aebec5507127df69304d3",
                "createdAt": "2022-03-11T06:30:10.094Z",
                "updatedAt": "2022-06-20T09:03:37.611Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Comfortable for daily wear"
        ],
        "key_words": [
            "Kurthis"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b069ad2a62aa5591e44487",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P038 D",
        "model": "K4",
        "specification": [
            {
                "_id": "62b9565f2a62aa5591e4ea8a",
                "title": "Material",
                "value": "Cotton",
                "suffix": ""
            },
            {
                "_id": "62b9565f2a62aa5591e4ea8b",
                "title": "Colour",
                "value": "Red With Traditional Print",
                "suffix": ""
            },
            {
                "_id": "62b9565f2a62aa5591e4ea8c",
                "title": "Model",
                "value": "Straight cut with mild flair",
                "suffix": ""
            },
            {
                "_id": "62b9565f2a62aa5591e4ea8d",
                "title": "Size",
                "value": "",
                "suffix": "L"
            }
        ],
        "createdAt": "2022-06-20T12:35:57.924Z",
        "updatedAt": "2022-06-27T07:03:58.999Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Ajrakh Print Cotton Kurthi  - L Size",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 2000,
        "sp": 1800,
        "stock": 0,
        "tax": null,
        "meta_desc": "Tops,Kurthis\n",
        "meta_key": "Kurthis",
        "note": "<div>Care Instructions:</div><div>Hand wash and dry in shade.</div><div>Starch and iron for best results.</div><div><br></div>",
        "images": [
            "public/product/1655728675457.3838.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.25,
            "length": 31,
            "breadth": 31,
            "height": 2
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6229fdc25507127df692f42c",
                "category_name": "Womans wear",
                "specification": "62ad9bc72a62aa5591e3ff4b",
                "createdAt": "2022-03-10T13:31:46.187Z",
                "updatedAt": "2022-10-19T09:11:36.730Z",
                "__v": 0,
                "images": "public/category/1666170696730.1174.webp"
            },
            {
                "parent": "6229fdc25507127df692f42c",
                "status": true,
                "_id": "622aec725507127df69304f4",
                "category_name": "Kurthis",
                "specification": "622aebec5507127df69304d3",
                "createdAt": "2022-03-11T06:30:10.094Z",
                "updatedAt": "2022-06-20T09:03:37.611Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Casual summer wear",
            "Beat the heat with this light wear"
        ],
        "key_words": [
            "Kurthi"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b06baf2a62aa5591e4454e",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P039 A",
        "model": "K5",
        "specification": [
            {
                "_id": "62b9569a2a62aa5591e4ead6",
                "title": "Material",
                "value": "Cotton",
                "suffix": ""
            },
            {
                "_id": "62b9569a2a62aa5591e4ead7",
                "title": "Colour",
                "value": "Light Blue",
                "suffix": ""
            },
            {
                "_id": "62b9569a2a62aa5591e4ead8",
                "title": "Model",
                "value": "Straight cut with mild flair",
                "suffix": ""
            },
            {
                "_id": "62b9569a2a62aa5591e4ead9",
                "title": "Size",
                "value": "",
                "suffix": "XS"
            }
        ],
        "createdAt": "2022-06-20T12:44:31.035Z",
        "updatedAt": "2022-06-27T07:04:58.568Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Sky blue Ajrakh Print Kurthi - XS Size",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 1600,
        "sp": 1400,
        "stock": 0,
        "tax": null,
        "meta_desc": "Tops,Kurthi",
        "meta_key": "Kurthi",
        "note": "<div>Care Instructions:</div><div>Hand wash and dry in shade.</div><div>Starch and iron for best reults.</div><div><br></div>",
        "images": [
            "public/product/1656145696186.7883.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.25,
            "length": 31,
            "breadth": 31,
            "height": 2
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6229fdc25507127df692f42c",
                "category_name": "Womans wear",
                "specification": "62ad9bc72a62aa5591e3ff4b",
                "createdAt": "2022-03-10T13:31:46.187Z",
                "updatedAt": "2022-10-19T09:11:36.730Z",
                "__v": 0,
                "images": "public/category/1666170696730.1174.webp"
            },
            {
                "parent": "6229fdc25507127df692f42c",
                "status": true,
                "_id": "622aec725507127df69304f4",
                "category_name": "Kurthis",
                "specification": "622aebec5507127df69304d3",
                "createdAt": "2022-03-11T06:30:10.094Z",
                "updatedAt": "2022-06-20T09:03:37.611Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Casual summer wear",
            "Beat the heat with this light wear"
        ],
        "key_words": [
            "Kurthi"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b06c702a62aa5591e4459a",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P039 B",
        "model": "K5",
        "specification": [
            {
                "_id": "62b956c12a62aa5591e4eb06",
                "title": "Material",
                "value": "Cotton",
                "suffix": ""
            },
            {
                "_id": "62b956c12a62aa5591e4eb07",
                "title": "Colour",
                "value": "Light Blue",
                "suffix": ""
            },
            {
                "_id": "62b956c12a62aa5591e4eb08",
                "title": "Model",
                "value": "Straight cut with mild flair",
                "suffix": ""
            },
            {
                "_id": "62b956c12a62aa5591e4eb09",
                "title": "Size",
                "value": "",
                "suffix": "S"
            }
        ],
        "createdAt": "2022-06-20T12:47:44.854Z",
        "updatedAt": "2022-06-27T07:05:37.040Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Sky blue Ajrakh Print Kurthi - S Size",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 1600,
        "sp": 1400,
        "stock": 0,
        "tax": null,
        "meta_desc": "Tops ,Kurthi",
        "meta_key": "Kurthi",
        "note": "<div>Care Instructions:</div><div>Hand wash and dry in shade.</div><div>Starch and iron for best reults.</div><div><br></div>",
        "images": [
            "public/product/1655729374085.0317.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.25,
            "length": 31,
            "breadth": 31,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6229fdc25507127df692f42c",
                "category_name": "Womans wear",
                "specification": "62ad9bc72a62aa5591e3ff4b",
                "createdAt": "2022-03-10T13:31:46.187Z",
                "updatedAt": "2022-10-19T09:11:36.730Z",
                "__v": 0,
                "images": "public/category/1666170696730.1174.webp"
            },
            {
                "parent": "6229fdc25507127df692f42c",
                "status": true,
                "_id": "622aec725507127df69304f4",
                "category_name": "Kurthis",
                "specification": "622aebec5507127df69304d3",
                "createdAt": "2022-03-11T06:30:10.094Z",
                "updatedAt": "2022-06-20T09:03:37.611Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Casual summer wear",
            "Beat the heat with this light wear"
        ],
        "key_words": [
            "Kurthi"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b06d112a62aa5591e445e6",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P039 C",
        "model": "K5",
        "specification": [
            {
                "_id": "62b956e22a62aa5591e4eb36",
                "title": "Material",
                "value": "Cotton",
                "suffix": ""
            },
            {
                "_id": "62b956e22a62aa5591e4eb37",
                "title": "Colour",
                "value": "Light Blue",
                "suffix": ""
            },
            {
                "_id": "62b956e22a62aa5591e4eb38",
                "title": "Model",
                "value": "Straight cut with mild flair",
                "suffix": ""
            },
            {
                "_id": "62b956e22a62aa5591e4eb39",
                "title": "Size",
                "value": "",
                "suffix": "M"
            }
        ],
        "createdAt": "2022-06-20T12:50:25.958Z",
        "updatedAt": "2022-06-27T07:06:10.326Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Sky blue Ajrakh Print Kurthi - M Size",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 1600,
        "sp": 1400,
        "stock": 0,
        "tax": null,
        "meta_desc": "Tops ,Kurthi",
        "meta_key": "Kurthi",
        "note": "<div>Care Instructions:</div><div>Hand wash and dry in shade.</div><div>Starch and iron for best reults.</div><div><br></div>",
        "images": [
            "public/product/1655729533595.533.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.25,
            "length": 31,
            "breadth": 31,
            "height": 2
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6229fdc25507127df692f42c",
                "category_name": "Womans wear",
                "specification": "62ad9bc72a62aa5591e3ff4b",
                "createdAt": "2022-03-10T13:31:46.187Z",
                "updatedAt": "2022-10-19T09:11:36.730Z",
                "__v": 0,
                "images": "public/category/1666170696730.1174.webp"
            },
            {
                "parent": "6229fdc25507127df692f42c",
                "status": true,
                "_id": "622aec725507127df69304f4",
                "category_name": "Kurthis",
                "specification": "622aebec5507127df69304d3",
                "createdAt": "2022-03-11T06:30:10.094Z",
                "updatedAt": "2022-06-20T09:03:37.611Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Casual summer wear",
            "Beat the heat with this light wear"
        ],
        "key_words": [
            "Kurthi"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b06da92a62aa5591e44632",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P039 D",
        "model": "K5",
        "specification": [
            {
                "_id": "62b957092a62aa5591e4eb66",
                "title": "Material",
                "value": "Cotton",
                "suffix": ""
            },
            {
                "_id": "62b957092a62aa5591e4eb67",
                "title": "Colour",
                "value": "Light Blue",
                "suffix": ""
            },
            {
                "_id": "62b957092a62aa5591e4eb68",
                "title": "Model",
                "value": "Straight cut with mild flair",
                "suffix": ""
            },
            {
                "_id": "62b957092a62aa5591e4eb69",
                "title": "Size",
                "value": "",
                "suffix": "L"
            }
        ],
        "createdAt": "2022-06-20T12:52:57.469Z",
        "updatedAt": "2022-06-27T07:06:49.709Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Sky blue Ajrakh Print Kurthi- L Size",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 1600,
        "sp": 1400,
        "stock": 0,
        "tax": null,
        "meta_desc": "Tops , Kurthi",
        "meta_key": "Kurthi",
        "note": "<div>Care Instructions:</div><div>Hand wash and dry in shade.</div><div>Starch and iron for best reults.</div><div><br></div>",
        "images": [
            "public/product/1655729676993.5493.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.3,
            "length": 31,
            "breadth": 31,
            "height": 2
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6229fdc25507127df692f42c",
                "category_name": "Womans wear",
                "specification": "62ad9bc72a62aa5591e3ff4b",
                "createdAt": "2022-03-10T13:31:46.187Z",
                "updatedAt": "2022-10-19T09:11:36.730Z",
                "__v": 0,
                "images": "public/category/1666170696730.1174.webp"
            },
            {
                "parent": "6229fdc25507127df692f42c",
                "status": true,
                "_id": "622aec725507127df69304f4",
                "category_name": "Kurthis",
                "specification": "622aebec5507127df69304d3",
                "createdAt": "2022-03-11T06:30:10.094Z",
                "updatedAt": "2022-06-20T09:03:37.611Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Light summer wear for young and old"
        ],
        "key_words": [
            "Kurthi"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b144ce2a62aa5591e44871",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P040 A",
        "model": "K6",
        "specification": [
            {
                "_id": "62b957742a62aa5591e4ebb3",
                "title": "Material",
                "value": "Light Weight cotton with Ajrack ",
                "suffix": ""
            },
            {
                "_id": "62b957742a62aa5591e4ebb4",
                "title": "Colour",
                "value": "Blue",
                "suffix": ""
            },
            {
                "_id": "62b957742a62aa5591e4ebb5",
                "title": "Model",
                "value": "Kurthi with chinese collar,mild embroidery at the yoke and straight cut kurthi",
                "suffix": ""
            },
            {
                "_id": "62b957742a62aa5591e4ebb6",
                "title": "Size",
                "value": "",
                "suffix": "XS"
            }
        ],
        "createdAt": "2022-06-21T04:10:54.700Z",
        "updatedAt": "2022-06-27T07:08:36.873Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Blue Printed Kurthi - XS Size",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 2000,
        "sp": 1800,
        "stock": 0,
        "tax": null,
        "meta_desc": "Salwar top ,Kurthi\n ",
        "meta_key": "Kurthi",
        "note": "<div>Care instructions:</div><div>Home wash and mild ironing&#160;</div><div><br></div>",
        "images": [
            "public/product/1655784779886.883.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.3,
            "length": 31,
            "breadth": 31,
            "height": 2
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6229fdc25507127df692f42c",
                "category_name": "Womans wear",
                "specification": "62ad9bc72a62aa5591e3ff4b",
                "createdAt": "2022-03-10T13:31:46.187Z",
                "updatedAt": "2022-10-19T09:11:36.730Z",
                "__v": 0,
                "images": "public/category/1666170696730.1174.webp"
            },
            {
                "parent": "6229fdc25507127df692f42c",
                "status": true,
                "_id": "622aec725507127df69304f4",
                "category_name": "Kurthis",
                "specification": "622aebec5507127df69304d3",
                "createdAt": "2022-03-11T06:30:10.094Z",
                "updatedAt": "2022-06-20T09:03:37.611Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Light summer wear for young and old"
        ],
        "key_words": [
            "Kurthi"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b145962a62aa5591e448c7",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P040 B",
        "model": "K6",
        "specification": [
            {
                "_id": "62b957c62a62aa5591e4ec0b",
                "title": "Material",
                "value": "Light Weight cotton with Ajrack Print",
                "suffix": ""
            },
            {
                "_id": "62b957c62a62aa5591e4ec0c",
                "title": "Colour",
                "value": "Blue",
                "suffix": ""
            },
            {
                "_id": "62b957c62a62aa5591e4ec0d",
                "title": "Model",
                "value": "Kurthi with chinese collar,mild embroidery at the yoke and straight cut kurthi",
                "suffix": ""
            },
            {
                "_id": "62b957c62a62aa5591e4ec0e",
                "title": "Size",
                "value": "",
                "suffix": "S"
            }
        ],
        "createdAt": "2022-06-21T04:14:14.557Z",
        "updatedAt": "2022-06-27T07:09:58.989Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Blue Printed Kurthi - S Size",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 2000,
        "sp": 1800,
        "stock": 0,
        "tax": null,
        "meta_desc": "Salwar top , Kurthi\n",
        "meta_key": "Kurthi",
        "note": "<div>Care instructions:</div><div>Home wash and mild ironing&#160;</div><div><br></div>",
        "images": [
            "public/product/1655784974476.6514.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.3,
            "length": 31,
            "breadth": 31,
            "height": 2
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6229fdc25507127df692f42c",
                "category_name": "Womans wear",
                "specification": "62ad9bc72a62aa5591e3ff4b",
                "createdAt": "2022-03-10T13:31:46.187Z",
                "updatedAt": "2022-10-19T09:11:36.730Z",
                "__v": 0,
                "images": "public/category/1666170696730.1174.webp"
            },
            {
                "parent": "6229fdc25507127df692f42c",
                "status": true,
                "_id": "622aec725507127df69304f4",
                "category_name": "Kurthis",
                "specification": "622aebec5507127df69304d3",
                "createdAt": "2022-03-11T06:30:10.094Z",
                "updatedAt": "2022-06-20T09:03:37.611Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Light summer wear for young and old"
        ],
        "key_words": [
            "Kurthi"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b1464b2a62aa5591e44917",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P040 C",
        "model": "K6",
        "specification": [
            {
                "_id": "62b957eb2a62aa5591e4ec3b",
                "title": "Material",
                "value": "Light Weight cotton with Ajrack Print",
                "suffix": ""
            },
            {
                "_id": "62b957eb2a62aa5591e4ec3c",
                "title": "Colour",
                "value": "Blue",
                "suffix": ""
            },
            {
                "_id": "62b957eb2a62aa5591e4ec3d",
                "title": "Model",
                "value": "Kurthi with chinese collar,mild embroidery at the yoke and straight cut kurthi",
                "suffix": ""
            },
            {
                "_id": "62b957eb2a62aa5591e4ec3e",
                "title": "Size",
                "value": "",
                "suffix": "M"
            }
        ],
        "createdAt": "2022-06-21T04:17:15.446Z",
        "updatedAt": "2022-06-27T07:10:35.821Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Blue Printed Kurthi - M Size",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 2000,
        "sp": 1800,
        "stock": 0,
        "tax": null,
        "meta_desc": "Salwar top, Kurthi\n",
        "meta_key": "Kurthi",
        "note": "<div>Care instructions:</div><div>Home wash and mild ironing&#160;</div><div><br></div>",
        "images": [
            "public/product/1655785190534.9502.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.3,
            "length": 31,
            "breadth": 31,
            "height": 2
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6229fdc25507127df692f42c",
                "category_name": "Womans wear",
                "specification": "62ad9bc72a62aa5591e3ff4b",
                "createdAt": "2022-03-10T13:31:46.187Z",
                "updatedAt": "2022-10-19T09:11:36.730Z",
                "__v": 0,
                "images": "public/category/1666170696730.1174.webp"
            },
            {
                "parent": "6229fdc25507127df692f42c",
                "status": true,
                "_id": "622aec725507127df69304f4",
                "category_name": "Kurthis",
                "specification": "622aebec5507127df69304d3",
                "createdAt": "2022-03-11T06:30:10.094Z",
                "updatedAt": "2022-06-20T09:03:37.611Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Light summer wear for young and old"
        ],
        "key_words": [
            "Kurthi"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b147792a62aa5591e44963",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P040 D",
        "model": "K6",
        "specification": [
            {
                "_id": "62b958142a62aa5591e4ec6b",
                "title": "Material",
                "value": "Light Weight cotton with Ajrack Print",
                "suffix": ""
            },
            {
                "_id": "62b958142a62aa5591e4ec6c",
                "title": "Colour",
                "value": "Blue",
                "suffix": ""
            },
            {
                "_id": "62b958142a62aa5591e4ec6d",
                "title": "Model",
                "value": "Kurthi with chinese collar,mild embroidery at the yoke and straight cut kurthi",
                "suffix": ""
            },
            {
                "_id": "62b958142a62aa5591e4ec6e",
                "title": "Size",
                "value": "",
                "suffix": "L"
            }
        ],
        "createdAt": "2022-06-21T04:22:17.289Z",
        "updatedAt": "2022-06-27T07:11:16.004Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Blue Printed Kurthi - L Size",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 2000,
        "sp": 1800,
        "stock": 0,
        "tax": null,
        "meta_desc": "Salwar top, Kurthi\n",
        "meta_key": "Kurthi",
        "note": "<div>Care instructions:</div><div>Home wash and mild ironing&#160;</div><div><br></div>",
        "images": [
            "public/product/1655785474594.6965.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.1,
            "length": 31,
            "breadth": 31,
            "height": 2
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6229fdc25507127df692f42c",
                "category_name": "Womans wear",
                "specification": "62ad9bc72a62aa5591e3ff4b",
                "createdAt": "2022-03-10T13:31:46.187Z",
                "updatedAt": "2022-10-19T09:11:36.730Z",
                "__v": 0,
                "images": "public/category/1666170696730.1174.webp"
            },
            {
                "parent": "6229fdc25507127df692f42c",
                "status": true,
                "_id": "622aec725507127df69304f4",
                "category_name": "Kurthis",
                "specification": "622aebec5507127df69304d3",
                "createdAt": "2022-03-11T06:30:10.094Z",
                "updatedAt": "2022-06-20T09:03:37.611Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "So light and smart to wear ",
            "Great summer outfit for outdoor activities"
        ],
        "key_words": [
            "Shirt kurthi"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b14a2b2a62aa5591e44a3e",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P041 A",
        "model": "K7",
        "specification": [
            {
                "_id": "62b958402a62aa5591e4ec9b",
                "title": "Material",
                "value": "Cotton",
                "suffix": ""
            },
            {
                "_id": "62b958402a62aa5591e4ec9c",
                "title": "Colour",
                "value": "Green",
                "suffix": ""
            },
            {
                "_id": "62b958402a62aa5591e4ec9d",
                "title": "Model",
                "value": "Kurthi Thigh Length with flap model three fourth sleeves",
                "suffix": ""
            },
            {
                "_id": "62b958402a62aa5591e4ec9e",
                "title": "Size",
                "value": "",
                "suffix": "XS"
            }
        ],
        "createdAt": "2022-06-21T04:33:47.141Z",
        "updatedAt": "2022-06-27T07:12:00.370Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Shirt Type Kurthi - XS Size",
        "display_date": null,
        "hsn_code": "610.4",
        "min_order_qty": 1,
        "mrp": 2000,
        "sp": 1800,
        "stock": 0,
        "tax": null,
        "meta_desc": "Salwar top , Shirt kurthi\n ",
        "meta_key": "Shirt kurthi",
        "note": "<div>Care Instructions:</div><div>Home wash and mild ironing.</div><div><br></div>",
        "images": [
            "public/product/1655786200404.2812.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.1,
            "length": 31,
            "breadth": 31,
            "height": 2
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6229fdc25507127df692f42c",
                "category_name": "Womans wear",
                "specification": "62ad9bc72a62aa5591e3ff4b",
                "createdAt": "2022-03-10T13:31:46.187Z",
                "updatedAt": "2022-10-19T09:11:36.730Z",
                "__v": 0,
                "images": "public/category/1666170696730.1174.webp"
            },
            {
                "parent": "6229fdc25507127df692f42c",
                "status": true,
                "_id": "622aec725507127df69304f4",
                "category_name": "Kurthis",
                "specification": "622aebec5507127df69304d3",
                "createdAt": "2022-03-11T06:30:10.094Z",
                "updatedAt": "2022-06-20T09:03:37.611Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "So light and smart to wear ",
            "Great summer outfit for outdoor activities"
        ],
        "key_words": [
            "Shirt kurthi"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b14b182a62aa5591e44a8a",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P041 B",
        "model": "K7",
        "specification": [
            {
                "_id": "62b958642a62aa5591e4eccb",
                "title": "Material",
                "value": "Cotton",
                "suffix": ""
            },
            {
                "_id": "62b958642a62aa5591e4eccc",
                "title": "Colour",
                "value": "Green",
                "suffix": ""
            },
            {
                "_id": "62b958642a62aa5591e4eccd",
                "title": "Model",
                "value": "Kurthi Thigh Length with flap model three fourth sleeves",
                "suffix": ""
            },
            {
                "_id": "62b958642a62aa5591e4ecce",
                "title": "Size",
                "value": "",
                "suffix": "S"
            }
        ],
        "createdAt": "2022-06-21T04:37:44.412Z",
        "updatedAt": "2022-06-27T07:12:36.332Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Shirt Type Kurthi - S Size",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 2000,
        "sp": 1800,
        "stock": 0,
        "tax": null,
        "meta_desc": "Salwar top ,Shirt kurthi\n",
        "meta_key": "Shirt kurthi",
        "note": "<div>Care Instructions:</div><div>Home wash and mild ironing.</div><div><br></div>",
        "images": [
            "public/product/1655786387904.09.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.1,
            "length": 31,
            "breadth": 31,
            "height": 2
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6229fdc25507127df692f42c",
                "category_name": "Womans wear",
                "specification": "62ad9bc72a62aa5591e3ff4b",
                "createdAt": "2022-03-10T13:31:46.187Z",
                "updatedAt": "2022-10-19T09:11:36.730Z",
                "__v": 0,
                "images": "public/category/1666170696730.1174.webp"
            },
            {
                "parent": "6229fdc25507127df692f42c",
                "status": true,
                "_id": "622aec725507127df69304f4",
                "category_name": "Kurthis",
                "specification": "622aebec5507127df69304d3",
                "createdAt": "2022-03-11T06:30:10.094Z",
                "updatedAt": "2022-06-20T09:03:37.611Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "So light and smart to wear ",
            "Great summer outfit for outdoor activities"
        ],
        "key_words": [
            "Shirt kurthi"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b14bcb2a62aa5591e44adc",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P041 C",
        "model": "K7",
        "specification": [
            {
                "_id": "62b9589c2a62aa5591e4ed01",
                "title": "Material",
                "value": "Cotton",
                "suffix": ""
            },
            {
                "_id": "62b9589c2a62aa5591e4ed02",
                "title": "Colour",
                "value": "Green",
                "suffix": ""
            },
            {
                "_id": "62b9589c2a62aa5591e4ed03",
                "title": "Model",
                "value": "Kurthi Thigh Length with flap model three fourth sleeves",
                "suffix": ""
            },
            {
                "_id": "62b9589c2a62aa5591e4ed04",
                "title": "Size",
                "value": "",
                "suffix": "M"
            }
        ],
        "createdAt": "2022-06-21T04:40:43.739Z",
        "updatedAt": "2022-06-27T07:13:32.218Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Shirt Type kurthi - M Size",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 2000,
        "sp": 1800,
        "stock": 0,
        "tax": null,
        "meta_desc": "Salwar top ,Shirt kurthi\n",
        "meta_key": "Shirt kurthi",
        "note": "<div>Care Instructions:</div><div>Home wash and mild ironing.</div><div><br></div>",
        "images": [
            "public/product/1655786550452.9182.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.1,
            "length": 31,
            "breadth": 31,
            "height": 2
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6229fdc25507127df692f42c",
                "category_name": "Womans wear",
                "specification": "62ad9bc72a62aa5591e3ff4b",
                "createdAt": "2022-03-10T13:31:46.187Z",
                "updatedAt": "2022-10-19T09:11:36.730Z",
                "__v": 0,
                "images": "public/category/1666170696730.1174.webp"
            },
            {
                "parent": "6229fdc25507127df692f42c",
                "status": true,
                "_id": "622aec725507127df69304f4",
                "category_name": "Kurthis",
                "specification": "622aebec5507127df69304d3",
                "createdAt": "2022-03-11T06:30:10.094Z",
                "updatedAt": "2022-06-20T09:03:37.611Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "So light and smart to wear ",
            "Great summer outfit for outdoor activities"
        ],
        "key_words": [
            "Shirt kurthi"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b14c6e2a62aa5591e44b28",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P041 D",
        "model": "K7",
        "specification": [
            {
                "_id": "62b958fc2a62aa5591e4ed31",
                "title": "Material",
                "value": "Cotton",
                "suffix": ""
            },
            {
                "_id": "62b958fc2a62aa5591e4ed32",
                "title": "Colour",
                "value": "Green",
                "suffix": ""
            },
            {
                "_id": "62b958fc2a62aa5591e4ed33",
                "title": "Model",
                "value": "Kurthi Thigh Length with flap model three fourth sleeves",
                "suffix": ""
            },
            {
                "_id": "62b958fc2a62aa5591e4ed34",
                "title": "Size",
                "value": "",
                "suffix": "L"
            }
        ],
        "createdAt": "2022-06-21T04:43:26.165Z",
        "updatedAt": "2022-06-27T07:15:08.280Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Shirt Type Kurthi -L Size",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 2000,
        "sp": 1800,
        "stock": 0,
        "tax": null,
        "meta_desc": "Salwar top , Shirt kurthi\n",
        "meta_key": "Shirt kurthi",
        "note": "<div>Care Instructions:</div><div>Home wash and mild ironing.</div><div><br></div>",
        "images": [
            "public/product/1655786704346.2507.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 2.7,
            "length": 40,
            "breadth": 25,
            "height": 40
        },
        "delivery_charge": {
            "local": 500,
            "zonal": 800,
            "national": 800
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "622341265507127df692c50f",
                "category_name": "Home Utilities",
                "specification": null,
                "createdAt": "2022-03-05T10:53:26.643Z",
                "updatedAt": "2022-03-17T08:17:50.624Z",
                "__v": 0,
                "images": "public/category/1664342495502.3452.webp"
            },
            {
                "parent": "622341265507127df692c50f",
                "status": true,
                "_id": "622ae8ea5507127df693035c",
                "category_name": "Chettinad Baskets",
                "specification": null,
                "createdAt": "2022-03-11T06:15:06.440Z",
                "updatedAt": "2022-10-19T09:12:02.077Z",
                "__v": 0,
                "images": "public/category/1666170722075.4104.webp"
            },
            {
                "parent": "622ae8ea5507127df693035c",
                "status": true,
                "_id": "622c34a08bc4af4c77b1fd17",
                "category_name": "Chettinad Basket set of 5 with Lids",
                "createdAt": "2022-03-12T05:50:24.289Z",
                "updatedAt": "2022-03-17T08:17:41.538Z",
                "__v": 0,
                "images": null,
                "specification": "62233e595507127df692c4db"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Easy mobility",
            "Sturdy to take with you anywhere"
        ],
        "key_words": [
            ""
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b19a682a62aa5591e44d9e",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P001A",
        "model": "BWL 1",
        "specification": [
            {
                "_id": "62b59c222a62aa5591e4a126",
                "title": "Material",
                "value": "Plastic",
                "suffix": ""
            },
            {
                "_id": "62b59c222a62aa5591e4a127",
                "title": "Available Colours",
                "value": "Multi colors available",
                "suffix": ""
            },
            {
                "_id": "62b59c222a62aa5591e4a128",
                "title": "Types",
                "value": "Set of 5 Baskets/Koodai for all purposes with lids",
                "suffix": ""
            },
            {
                "_id": "62b59c222a62aa5591e4a129",
                "title": "Size-1 (INCHES)",
                "value": "Largest 11.5 X 7.5 X 11",
                "suffix": ""
            },
            {
                "_id": "62b59c222a62aa5591e4a12a",
                "title": "Size-2",
                "value": "Large 11 X 6.5 X 10",
                "suffix": ""
            },
            {
                "_id": "62b59c222a62aa5591e4a12b",
                "title": "Size-3",
                "value": "Medium 10 X 6 X 9",
                "suffix": ""
            },
            {
                "_id": "62b59c222a62aa5591e4a12c",
                "title": "Size-4",
                "value": "Small  9 X 5 X 8",
                "suffix": ""
            },
            {
                "_id": "62b59c222a62aa5591e4a12d",
                "title": "Size-5",
                "value": "Smallest 7.5 X 4.5 X 6.5 ",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-21T10:16:08.576Z",
        "updatedAt": "2022-06-24T11:12:34.009Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Chettinadu Baskets Set of 5  with lids ",
        "display_date": null,
        "hsn_code": "3924",
        "min_order_qty": 1,
        "mrp": 2200,
        "sp": 1900,
        "stock": 0,
        "tax": {
            "status": true,
            "_id": "61f7dde28d37e6262ba17c80",
            "tax_name": "GST_18",
            "tax_percentage": 18,
            "__v": 0
        },
        "meta_desc": "Baskets",
        "meta_key": "Koodai",
        "note": "These baskets are usefull to carry anywhere at any time without spillage .The bottom of each basket is provided with bushes to make them stand sturdy and erect.",
        "images": [
            "public/product/1655807748740.7827.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 2,
            "length": 40,
            "breadth": 25,
            "height": 40
        },
        "delivery_charge": {
            "local": 500,
            "zonal": 800,
            "national": 800
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "622341265507127df692c50f",
                "category_name": "Home Utilities",
                "specification": null,
                "createdAt": "2022-03-05T10:53:26.643Z",
                "updatedAt": "2022-03-17T08:17:50.624Z",
                "__v": 0,
                "images": "public/category/1664342495502.3452.webp"
            },
            {
                "parent": "622341265507127df692c50f",
                "status": true,
                "_id": "622ae8ea5507127df693035c",
                "category_name": "Chettinad Baskets",
                "specification": null,
                "createdAt": "2022-03-11T06:15:06.440Z",
                "updatedAt": "2022-10-19T09:12:02.077Z",
                "__v": 0,
                "images": "public/category/1666170722075.4104.webp"
            },
            {
                "parent": "622ae8ea5507127df693035c",
                "status": true,
                "_id": "622c3ed38bc4af4c77b20255",
                "category_name": "Chettinad Baskets set of 5 without lids",
                "specification": "62233e595507127df692c4db",
                "createdAt": "2022-03-12T06:33:55.857Z",
                "updatedAt": "2022-03-12T06:33:55.857Z",
                "__v": 0
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Easy mobility",
            "Sturdy to take with you anywhere"
        ],
        "key_words": [
            ""
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b1a02b2a62aa5591e44eb2",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P001B",
        "model": "BWOL",
        "specification": [
            {
                "_id": "62b59cf42a62aa5591e4a172",
                "title": "Material",
                "value": "Plastic",
                "suffix": ""
            },
            {
                "_id": "62b59cf42a62aa5591e4a173",
                "title": "Available Colours",
                "value": "Multi colors available",
                "suffix": ""
            },
            {
                "_id": "62b59cf42a62aa5591e4a174",
                "title": "Types",
                "value": "Set of 5 Baskets/Koodai for all purposes without lids",
                "suffix": ""
            },
            {
                "_id": "62b59cf42a62aa5591e4a175",
                "title": "Size-1 (INCHES)",
                "value": "Largest 13 X 9 X 9",
                "suffix": ""
            },
            {
                "_id": "62b59cf42a62aa5591e4a176",
                "title": "Size-2",
                "value": " Large 12.5 X 8 X 8",
                "suffix": ""
            },
            {
                "_id": "62b59cf42a62aa5591e4a177",
                "title": "Size-3",
                "value": "Medium 11.5 X 7 X 7",
                "suffix": ""
            },
            {
                "_id": "62b59cf42a62aa5591e4a178",
                "title": "Size-4",
                "value": "Small 10.5 X 6.5 X 6",
                "suffix": ""
            },
            {
                "_id": "62b59cf42a62aa5591e4a179",
                "title": "Size-5",
                "value": "Smallest 9.5 X 5.5 X 5",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-21T10:40:43.784Z",
        "updatedAt": "2022-06-24T11:16:04.680Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Chettinadu Baskets Set of 5  without lids ",
        "display_date": null,
        "hsn_code": "3924",
        "min_order_qty": 1,
        "mrp": 1800,
        "sp": 1500,
        "stock": 0,
        "tax": {
            "status": true,
            "_id": "61f7dde28d37e6262ba17c80",
            "tax_name": "GST_18",
            "tax_percentage": 18,
            "__v": 0
        },
        "meta_desc": "Baskets\n",
        "meta_key": "Koodai",
        "note": "<div>These baskets are usefull to carry anywhere at any time without spillage .The bottom of each basket is provided with bushes to make them stand sturdy and erect.</div><div><br></div>",
        "images": [
            "public/product/1655813533502.8196.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 2,
            "length": 40,
            "breadth": 25,
            "height": 40
        },
        "delivery_charge": {
            "local": 500,
            "zonal": 800,
            "national": 800
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "622341265507127df692c50f",
                "category_name": "Home Utilities",
                "specification": null,
                "createdAt": "2022-03-05T10:53:26.643Z",
                "updatedAt": "2022-03-17T08:17:50.624Z",
                "__v": 0,
                "images": "public/category/1664342495502.3452.webp"
            },
            {
                "parent": "622341265507127df692c50f",
                "status": true,
                "_id": "622ae8ea5507127df693035c",
                "category_name": "Chettinad Baskets",
                "specification": null,
                "createdAt": "2022-03-11T06:15:06.440Z",
                "updatedAt": "2022-10-19T09:12:02.077Z",
                "__v": 0,
                "images": "public/category/1666170722075.4104.webp"
            },
            {
                "parent": "622ae8ea5507127df693035c",
                "status": true,
                "_id": "622c3ed38bc4af4c77b20255",
                "category_name": "Chettinad Baskets set of 5 without lids",
                "specification": "62233e595507127df692c4db",
                "createdAt": "2022-03-12T06:33:55.857Z",
                "updatedAt": "2022-03-12T06:33:55.857Z",
                "__v": 0
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Easy mobility",
            "Sturdy to take with you anywhere"
        ],
        "key_words": [
            ""
        ],
        "status": true,
        "featured": true,
        "publish": true,
        "_id": "62b1a2372a62aa5591e44f46",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P001C",
        "model": "BWOL",
        "specification": [
            {
                "_id": "62b59d972a62aa5591e4a1bc",
                "title": "Material",
                "value": "Plastic",
                "suffix": ""
            },
            {
                "_id": "62b59d972a62aa5591e4a1bd",
                "title": "Available Colours",
                "value": "Multi colors available",
                "suffix": ""
            },
            {
                "_id": "62b59d972a62aa5591e4a1be",
                "title": "Types",
                "value": "Set of 5 Baskets/Koodai for all purposes without lids",
                "suffix": ""
            },
            {
                "_id": "62b59d972a62aa5591e4a1bf",
                "title": "Size-1 (INCHES)",
                "value": "Largest  12 X 7 X 11",
                "suffix": ""
            },
            {
                "_id": "62b59d972a62aa5591e4a1c0",
                "title": "Size-2",
                "value": "Large 11.5 X 6 X 10",
                "suffix": ""
            },
            {
                "_id": "62b59d972a62aa5591e4a1c1",
                "title": "Size-3",
                "value": "Medium 10.5 X 5.5 X 9",
                "suffix": ""
            },
            {
                "_id": "62b59d972a62aa5591e4a1c2",
                "title": "Size-4",
                "value": "Small  9.5 X 4.5 X 8 ",
                "suffix": ""
            },
            {
                "_id": "62b59d972a62aa5591e4a1c3",
                "title": "Size-5",
                "value": "Smallest 7.5 X 4.5 X 6.5",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-21T10:49:27.694Z",
        "updatedAt": "2022-09-09T09:04:32.321Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Chettinadu Basket Set of 5 Without lid ",
        "display_date": null,
        "hsn_code": "3924",
        "min_order_qty": 1,
        "mrp": 1800,
        "sp": 1500,
        "stock": 0,
        "tax": {
            "status": true,
            "_id": "61f7dde28d37e6262ba17c80",
            "tax_name": "GST_18",
            "tax_percentage": 18,
            "__v": 0
        },
        "meta_desc": "Baskets\n",
        "meta_key": "Koodai",
        "note": "These baskets are usefull to carry anywhere at any time without spillage .The bottom of each basket is provided with bushes to make them stand sturdy and erect.",
        "images": [
            "public/product/1655813386443.2654.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 2,
            "length": 40,
            "breadth": 25,
            "height": 40
        },
        "delivery_charge": {
            "local": 500,
            "zonal": 800,
            "national": 800
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "622341265507127df692c50f",
                "category_name": "Home Utilities",
                "specification": null,
                "createdAt": "2022-03-05T10:53:26.643Z",
                "updatedAt": "2022-03-17T08:17:50.624Z",
                "__v": 0,
                "images": "public/category/1664342495502.3452.webp"
            },
            {
                "parent": "622341265507127df692c50f",
                "status": true,
                "_id": "622ae8ea5507127df693035c",
                "category_name": "Chettinad Baskets",
                "specification": null,
                "createdAt": "2022-03-11T06:15:06.440Z",
                "updatedAt": "2022-10-19T09:12:02.077Z",
                "__v": 0,
                "images": "public/category/1666170722075.4104.webp"
            },
            {
                "parent": "622ae8ea5507127df693035c",
                "status": true,
                "_id": "622c3ed38bc4af4c77b20255",
                "category_name": "Chettinad Baskets set of 5 without lids",
                "specification": "62233e595507127df692c4db",
                "createdAt": "2022-03-12T06:33:55.857Z",
                "updatedAt": "2022-03-12T06:33:55.857Z",
                "__v": 0
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Easy mobility",
            "Sturdy to take with you anywhere"
        ],
        "key_words": [
            ""
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b1a4dd2a62aa5591e45004",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P001D",
        "model": "BWOL",
        "specification": [
            {
                "_id": "62b59e012a62aa5591e4a1ee",
                "title": "Material",
                "value": "Plastic",
                "suffix": ""
            },
            {
                "_id": "62b59e012a62aa5591e4a1ef",
                "title": "Available Colours",
                "value": "Multi colors available",
                "suffix": ""
            },
            {
                "_id": "62b59e012a62aa5591e4a1f0",
                "title": "Types",
                "value": "Set of 5 Baskets/Koodai for all purposes without lids",
                "suffix": ""
            },
            {
                "_id": "62b59e012a62aa5591e4a1f1",
                "title": "Size-1 (INCHES)",
                "value": "Largest  12 X 7 X 12 ",
                "suffix": ""
            },
            {
                "_id": "62b59e012a62aa5591e4a1f2",
                "title": "Size-2",
                "value": "Large 10.5 X 6.5 X 10.5 ",
                "suffix": ""
            },
            {
                "_id": "62b59e012a62aa5591e4a1f3",
                "title": "Size-3",
                "value": "Medium 10.5 X 5.5 X 9.5",
                "suffix": ""
            },
            {
                "_id": "62b59e012a62aa5591e4a1f4",
                "title": "Size-4",
                "value": "Small  9.5 X 4.5 X 8.5 ",
                "suffix": ""
            },
            {
                "_id": "62b59e012a62aa5591e4a1f5",
                "title": "Size-5",
                "value": "Smallest 7.5 X 4.5 X 6.5",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-21T11:00:45.338Z",
        "updatedAt": "2022-06-24T11:20:33.054Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Chettinadu Basket Set of 5 Without lid ",
        "display_date": null,
        "hsn_code": "3924",
        "min_order_qty": 1,
        "mrp": 1800,
        "sp": 1500,
        "stock": 0,
        "tax": {
            "status": true,
            "_id": "61f7dde28d37e6262ba17c80",
            "tax_name": "GST_18",
            "tax_percentage": 18,
            "__v": 0
        },
        "meta_desc": "Baskets\n",
        "meta_key": "Koodai",
        "note": "<div>These baskets are usefull to carry anywhere at any time without spillage .The bottom of each basket is provided with bushes to make them stand sturdy and erect.</div><div><br></div>",
        "images": [
            "public/product/1655813296011.1858.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 2,
            "length": 40,
            "breadth": 25,
            "height": 40
        },
        "delivery_charge": {
            "local": 500,
            "zonal": 800,
            "national": 800
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "622341265507127df692c50f",
                "category_name": "Home Utilities",
                "specification": null,
                "createdAt": "2022-03-05T10:53:26.643Z",
                "updatedAt": "2022-03-17T08:17:50.624Z",
                "__v": 0,
                "images": "public/category/1664342495502.3452.webp"
            },
            {
                "parent": "622341265507127df692c50f",
                "status": true,
                "_id": "622ae8ea5507127df693035c",
                "category_name": "Chettinad Baskets",
                "specification": null,
                "createdAt": "2022-03-11T06:15:06.440Z",
                "updatedAt": "2022-10-19T09:12:02.077Z",
                "__v": 0,
                "images": "public/category/1666170722075.4104.webp"
            },
            {
                "parent": "622ae8ea5507127df693035c",
                "status": true,
                "_id": "622c3ed38bc4af4c77b20255",
                "category_name": "Chettinad Baskets set of 5 without lids",
                "specification": "62233e595507127df692c4db",
                "createdAt": "2022-03-12T06:33:55.857Z",
                "updatedAt": "2022-03-12T06:33:55.857Z",
                "__v": 0
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Easy mobility"
        ],
        "key_words": [
            "Sturdy to take with you anywhere"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b1aaab2a62aa5591e450c4",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P001 E",
        "model": "BWOL",
        "specification": [
            {
                "_id": "62b59e562a62aa5591e4a220",
                "title": "Material",
                "value": "Plastic",
                "suffix": ""
            },
            {
                "_id": "62b59e562a62aa5591e4a221",
                "title": "Available Colours",
                "value": "Multi colors available",
                "suffix": ""
            },
            {
                "_id": "62b59e562a62aa5591e4a222",
                "title": "Types",
                "value": "Set of 5 Baskets/Koodai for all purposes without lids",
                "suffix": ""
            },
            {
                "_id": "62b59e562a62aa5591e4a223",
                "title": "Size-1 (INCHES)",
                "value": "Largest 12 X 7 X 11 ",
                "suffix": ""
            },
            {
                "_id": "62b59e562a62aa5591e4a224",
                "title": "Size-2",
                "value": "Large 11.5 X 6.5 X 10 ",
                "suffix": ""
            },
            {
                "_id": "62b59e562a62aa5591e4a225",
                "title": "Size-3",
                "value": "Medium 10.5 X 5.5 X 9 ",
                "suffix": ""
            },
            {
                "_id": "62b59e562a62aa5591e4a226",
                "title": "Size-4",
                "value": "Small  9.5 X 4.5 X 8 ",
                "suffix": ""
            },
            {
                "_id": "62b59e562a62aa5591e4a227",
                "title": "Size-5",
                "value": "Smallest 8 X 4.3 X 6.5",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-21T11:25:31.738Z",
        "updatedAt": "2022-06-24T11:21:58.884Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Chettinadu Basket Set of 5 Without lid ",
        "display_date": null,
        "hsn_code": "3924",
        "min_order_qty": 1,
        "mrp": 1800,
        "sp": 1500,
        "stock": 0,
        "tax": {
            "status": true,
            "_id": "61f7dde28d37e6262ba17c80",
            "tax_name": "GST_18",
            "tax_percentage": 18,
            "__v": 0
        },
        "meta_desc": "Baskets\n",
        "meta_key": "Koodai",
        "note": "<div>These baskets are usefull to carry anywhere at any time without spillage .The bottom of each basket is provided with bushes to make them stand sturdy and erect.</div><div><br></div>",
        "images": [
            "public/product/1655813189188.2522.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 2,
            "length": 40,
            "breadth": 25,
            "height": 40
        },
        "delivery_charge": {
            "local": 500,
            "zonal": 800,
            "national": 800
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "622341265507127df692c50f",
                "category_name": "Home Utilities",
                "specification": null,
                "createdAt": "2022-03-05T10:53:26.643Z",
                "updatedAt": "2022-03-17T08:17:50.624Z",
                "__v": 0,
                "images": "public/category/1664342495502.3452.webp"
            },
            {
                "parent": "622341265507127df692c50f",
                "status": true,
                "_id": "622ae8ea5507127df693035c",
                "category_name": "Chettinad Baskets",
                "specification": null,
                "createdAt": "2022-03-11T06:15:06.440Z",
                "updatedAt": "2022-10-19T09:12:02.077Z",
                "__v": 0,
                "images": "public/category/1666170722075.4104.webp"
            },
            {
                "parent": "622ae8ea5507127df693035c",
                "status": true,
                "_id": "622c3ed38bc4af4c77b20255",
                "category_name": "Chettinad Baskets set of 5 without lids",
                "specification": "62233e595507127df692c4db",
                "createdAt": "2022-03-12T06:33:55.857Z",
                "updatedAt": "2022-03-12T06:33:55.857Z",
                "__v": 0
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Easy mobility",
            "Sturdy to take with you anywhere"
        ],
        "key_words": [
            ""
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b1ac922a62aa5591e452ec",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P001F",
        "model": "BWOL",
        "specification": [
            {
                "_id": "62b59ed02a62aa5591e4a252",
                "title": "Material",
                "value": "Plastic",
                "suffix": ""
            },
            {
                "_id": "62b59ed02a62aa5591e4a253",
                "title": "Available Colours",
                "value": "Multi colors available",
                "suffix": ""
            },
            {
                "_id": "62b59ed02a62aa5591e4a254",
                "title": "Types",
                "value": "Set of 5 Baskets/Koodai for all purposes without lids",
                "suffix": ""
            },
            {
                "_id": "62b59ed02a62aa5591e4a255",
                "title": "Size-1 (INCHES)",
                "value": "Largest  11.5 X 7.5 X 11",
                "suffix": ""
            },
            {
                "_id": "62b59ed02a62aa5591e4a256",
                "title": "Size-2",
                "value": "Large 10.5 X 6.5 X 10",
                "suffix": ""
            },
            {
                "_id": "62b59ed02a62aa5591e4a257",
                "title": "Size-3",
                "value": "Medium 9.5 X 5.5 X 9 ",
                "suffix": ""
            },
            {
                "_id": "62b59ed02a62aa5591e4a258",
                "title": "Size-4",
                "value": "Small  9 X 5 X 8",
                "suffix": ""
            },
            {
                "_id": "62b59ed02a62aa5591e4a259",
                "title": "Size-5",
                "value": "Smallest  7 X  4.5  X 6",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-21T11:33:38.402Z",
        "updatedAt": "2022-06-24T11:24:00.451Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Chettinadu Basket Set of 5 Without lid ",
        "display_date": null,
        "hsn_code": "3924",
        "min_order_qty": 1,
        "mrp": 1800,
        "sp": 1500,
        "stock": 0,
        "tax": {
            "status": true,
            "_id": "61f7dde28d37e6262ba17c80",
            "tax_name": "GST_18",
            "tax_percentage": 18,
            "__v": 0
        },
        "meta_desc": "Baskets\n",
        "meta_key": "Koodai",
        "note": "<div>These baskets are usefull to carry anywhere at any time without spillage .The bottom of each basket is provided with bushes to make them stand sturdy and erect.</div><div><br></div>",
        "images": [
            "public/product/1655813081421.3176.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 2,
            "length": 40,
            "breadth": 25,
            "height": 40
        },
        "delivery_charge": {
            "local": 500,
            "zonal": 800,
            "national": 800
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "622341265507127df692c50f",
                "category_name": "Home Utilities",
                "specification": null,
                "createdAt": "2022-03-05T10:53:26.643Z",
                "updatedAt": "2022-03-17T08:17:50.624Z",
                "__v": 0,
                "images": "public/category/1664342495502.3452.webp"
            },
            {
                "parent": "622341265507127df692c50f",
                "status": true,
                "_id": "622ae8ea5507127df693035c",
                "category_name": "Chettinad Baskets",
                "specification": null,
                "createdAt": "2022-03-11T06:15:06.440Z",
                "updatedAt": "2022-10-19T09:12:02.077Z",
                "__v": 0,
                "images": "public/category/1666170722075.4104.webp"
            },
            {
                "parent": "622ae8ea5507127df693035c",
                "status": true,
                "_id": "622c3ed38bc4af4c77b20255",
                "category_name": "Chettinad Baskets set of 5 without lids",
                "specification": "62233e595507127df692c4db",
                "createdAt": "2022-03-12T06:33:55.857Z",
                "updatedAt": "2022-03-12T06:33:55.857Z",
                "__v": 0
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Easy mobility",
            "Sturdy to take with you anywhere"
        ],
        "key_words": [
            ""
        ],
        "status": true,
        "featured": true,
        "publish": true,
        "_id": "62b1af362a62aa5591e455ee",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P001 G",
        "model": "BWOL",
        "specification": [
            {
                "_id": "62b59f362a62aa5591e4a27f",
                "title": "Material",
                "value": "Plastic",
                "suffix": ""
            },
            {
                "_id": "62b59f362a62aa5591e4a280",
                "title": "Available Colours",
                "value": "Multi colors available",
                "suffix": ""
            },
            {
                "_id": "62b59f362a62aa5591e4a281",
                "title": "Types",
                "value": "Set of 5 Baskets/Koodai for all purposes without lids",
                "suffix": ""
            },
            {
                "_id": "62b59f362a62aa5591e4a282",
                "title": "Size-1 (INCHES)",
                "value": "Largest 11.5 X 7.5 X 9",
                "suffix": ""
            },
            {
                "_id": "62b59f362a62aa5591e4a283",
                "title": "Size-2",
                "value": "Large  10.5 X 7 X 8",
                "suffix": ""
            },
            {
                "_id": "62b59f362a62aa5591e4a284",
                "title": "Size-3",
                "value": "Medium 10 X 6 X  7",
                "suffix": ""
            },
            {
                "_id": "62b59f362a62aa5591e4a285",
                "title": "Size-4",
                "value": "Small  9 X 5 X 6",
                "suffix": ""
            },
            {
                "_id": "62b59f362a62aa5591e4a286",
                "title": "Size-5",
                "value": "Smallest  8 X 4.5 X 5.5",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-21T11:44:54.778Z",
        "updatedAt": "2022-09-09T09:04:20.391Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Chettinadu Basket Set of 5 Without lid ",
        "display_date": null,
        "hsn_code": "3924",
        "min_order_qty": 1,
        "mrp": 1800,
        "sp": 1500,
        "stock": 0,
        "tax": {
            "status": true,
            "_id": "61f7dde28d37e6262ba17c80",
            "tax_name": "GST_18",
            "tax_percentage": 18,
            "__v": 0
        },
        "meta_desc": "Baskets\n",
        "meta_key": "Koodai",
        "note": "<div>These baskets are usefull to carry anywhere at any time without spillage .The bottom of each basket is provided with bushes to make them stand sturdy and erect.</div><div><br></div>",
        "images": [
            "public/product/1655812042747.3425.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.4,
            "length": 30.5,
            "breadth": 30.5,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6229fdc25507127df692f42c",
                "category_name": "Womans wear",
                "specification": "62ad9bc72a62aa5591e3ff4b",
                "createdAt": "2022-03-10T13:31:46.187Z",
                "updatedAt": "2022-10-19T09:11:36.730Z",
                "__v": 0,
                "images": "public/category/1666170696730.1174.webp"
            },
            {
                "parent": "6229fdc25507127df692f42c",
                "status": true,
                "_id": "622aec725507127df69304f4",
                "category_name": "Kurthis",
                "specification": "622aebec5507127df69304d3",
                "createdAt": "2022-03-11T06:30:10.094Z",
                "updatedAt": "2022-06-20T09:03:37.611Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "For casual wear and goes well with contrast leggings and jeans",
            "Umbrella cut top"
        ],
        "key_words": [
            "Tops"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b2a6b92a62aa5591e45fe1",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P058A",
        "model": "K8",
        "specification": [
            {
                "_id": "62b95a272a62aa5591e4ee04",
                "title": "Material",
                "value": "Cotton",
                "suffix": ""
            },
            {
                "_id": "62b95a272a62aa5591e4ee05",
                "title": "Colour",
                "value": "Yellow with Green Kurthi",
                "suffix": ""
            },
            {
                "_id": "62b95a272a62aa5591e4ee06",
                "title": "Model",
                "value": "Kurthi Knee Length with umbrella cut and  three fourth sleeves",
                "suffix": ""
            },
            {
                "_id": "62b95a272a62aa5591e4ee07",
                "title": "Size",
                "value": "",
                "suffix": "XS"
            }
        ],
        "createdAt": "2022-06-22T05:20:57.875Z",
        "updatedAt": "2022-06-27T07:20:07.559Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Yellow &  Green Ajrakh Print Kurthi -XS Size ",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 2000,
        "sp": 1800,
        "stock": 0,
        "tax": null,
        "meta_desc": "Kurthis ,Tops\n ",
        "meta_key": "Tops",
        "note": "<div>Kindly hand wash the first wash and iron for best result</div><div><br></div>",
        "images": [
            "public/product/1655875514237.8582.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.4,
            "length": 30.5,
            "breadth": 30.5,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6229fdc25507127df692f42c",
                "category_name": "Womans wear",
                "specification": "62ad9bc72a62aa5591e3ff4b",
                "createdAt": "2022-03-10T13:31:46.187Z",
                "updatedAt": "2022-10-19T09:11:36.730Z",
                "__v": 0,
                "images": "public/category/1666170696730.1174.webp"
            },
            {
                "parent": "6229fdc25507127df692f42c",
                "status": true,
                "_id": "622aec725507127df69304f4",
                "category_name": "Kurthis",
                "specification": "622aebec5507127df69304d3",
                "createdAt": "2022-03-11T06:30:10.094Z",
                "updatedAt": "2022-06-20T09:03:37.611Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "For casual wear and goes well with contrast leggings and jeans",
            "Umbrella cut top"
        ],
        "key_words": [
            "Tops"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b2a8752a62aa5591e46062",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P058B",
        "model": "K8",
        "specification": [
            {
                "_id": "62b95a4e2a62aa5591e4ee39",
                "title": "Material",
                "value": "Cotton",
                "suffix": ""
            },
            {
                "_id": "62b95a4e2a62aa5591e4ee3a",
                "title": "Colour",
                "value": "Yellow with Green Kurthi",
                "suffix": ""
            },
            {
                "_id": "62b95a4e2a62aa5591e4ee3b",
                "title": "Model",
                "value": "Kurthi Knee Length with umbrella cut and  three fourth sleeves",
                "suffix": ""
            },
            {
                "_id": "62b95a4e2a62aa5591e4ee3c",
                "title": "Size",
                "value": "",
                "suffix": "S"
            }
        ],
        "createdAt": "2022-06-22T05:28:21.993Z",
        "updatedAt": "2022-06-27T07:20:46.517Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Yellow &  Green Ajrakh Print Kurthi -S Size ",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 2000,
        "sp": 1800,
        "stock": 0,
        "tax": null,
        "meta_desc": "Kurthis , Tops\n",
        "meta_key": "Tops",
        "note": "<div>Kindly hand wash the first wash and iron for best result</div><div><br></div>",
        "images": [
            "public/product/1655875921079.3838.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.4,
            "length": 30.5,
            "breadth": 30.5,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6229fdc25507127df692f42c",
                "category_name": "Womans wear",
                "specification": "62ad9bc72a62aa5591e3ff4b",
                "createdAt": "2022-03-10T13:31:46.187Z",
                "updatedAt": "2022-10-19T09:11:36.730Z",
                "__v": 0,
                "images": "public/category/1666170696730.1174.webp"
            },
            {
                "parent": "6229fdc25507127df692f42c",
                "status": true,
                "_id": "622aec725507127df69304f4",
                "category_name": "Kurthis",
                "specification": "622aebec5507127df69304d3",
                "createdAt": "2022-03-11T06:30:10.094Z",
                "updatedAt": "2022-06-20T09:03:37.611Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "For casual wear and goes well with contrast leggings and jeans",
            "Umbrella cut top"
        ],
        "key_words": [
            "Tops"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b2a99a2a62aa5591e460cd",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P058C",
        "model": "K8",
        "specification": [
            {
                "_id": "62b95a6e2a62aa5591e4ee69",
                "title": "Material",
                "value": "Cotton",
                "suffix": ""
            },
            {
                "_id": "62b95a6e2a62aa5591e4ee6a",
                "title": "Colour",
                "value": "Yellow with Green Kurthi",
                "suffix": ""
            },
            {
                "_id": "62b95a6e2a62aa5591e4ee6b",
                "title": "Model",
                "value": "Kurthi Knee Length with umbrella cut and  three fourth sleeves",
                "suffix": ""
            },
            {
                "_id": "62b95a6e2a62aa5591e4ee6c",
                "title": "Size",
                "value": "",
                "suffix": "M"
            }
        ],
        "createdAt": "2022-06-22T05:33:14.186Z",
        "updatedAt": "2022-06-27T07:21:18.005Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Yellow &  Green Ajrakh Print Kurthi -M Size ",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 2000,
        "sp": 1800,
        "stock": 0,
        "tax": null,
        "meta_desc": "Kurthis , Tops",
        "meta_key": "Tops",
        "note": "<div>Kindly hand wash the first wash and iron for best result</div><div><br></div>",
        "images": [
            "public/product/1655876144639.5298.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.4,
            "length": 30.5,
            "breadth": 30.5,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6229fdc25507127df692f42c",
                "category_name": "Womans wear",
                "specification": "62ad9bc72a62aa5591e3ff4b",
                "createdAt": "2022-03-10T13:31:46.187Z",
                "updatedAt": "2022-10-19T09:11:36.730Z",
                "__v": 0,
                "images": "public/category/1666170696730.1174.webp"
            },
            {
                "parent": "6229fdc25507127df692f42c",
                "status": true,
                "_id": "622aec725507127df69304f4",
                "category_name": "Kurthis",
                "specification": "622aebec5507127df69304d3",
                "createdAt": "2022-03-11T06:30:10.094Z",
                "updatedAt": "2022-06-20T09:03:37.611Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "For casual wear and goes well with contrast leggings and jeans",
            "Umbrella cut top"
        ],
        "key_words": [
            "Tops"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b2aa742a62aa5591e46137",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P058D",
        "model": "K8",
        "specification": [
            {
                "_id": "62b95a962a62aa5591e4ee99",
                "title": "Material",
                "value": "Cotton",
                "suffix": ""
            },
            {
                "_id": "62b95a962a62aa5591e4ee9a",
                "title": "Colour",
                "value": "Yellow with Green Kurthi",
                "suffix": ""
            },
            {
                "_id": "62b95a962a62aa5591e4ee9b",
                "title": "Model",
                "value": "Kurthi Thigh Length with flap model three fourth sleeves",
                "suffix": ""
            },
            {
                "_id": "62b95a962a62aa5591e4ee9c",
                "title": "Size",
                "value": "",
                "suffix": "L"
            }
        ],
        "createdAt": "2022-06-22T05:36:52.180Z",
        "updatedAt": "2022-06-27T07:21:58.921Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Yellow &  Green Ajrakh Print Kurthi -L Size ",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 2000,
        "sp": 1800,
        "stock": 0,
        "tax": null,
        "meta_desc": "Kurthis Tops",
        "meta_key": "Tops",
        "note": "Kindly hand wash the first wash and iron for best result",
        "images": [
            "public/product/1655876303874.0278.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.4,
            "length": 30.5,
            "breadth": 30.5,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6229fdc25507127df692f42c",
                "category_name": "Womans wear",
                "specification": "62ad9bc72a62aa5591e3ff4b",
                "createdAt": "2022-03-10T13:31:46.187Z",
                "updatedAt": "2022-10-19T09:11:36.730Z",
                "__v": 0,
                "images": "public/category/1666170696730.1174.webp"
            },
            {
                "parent": "6229fdc25507127df692f42c",
                "status": true,
                "_id": "622aec725507127df69304f4",
                "category_name": "Kurthis",
                "specification": "622aebec5507127df69304d3",
                "createdAt": "2022-03-11T06:30:10.094Z",
                "updatedAt": "2022-06-20T09:03:37.611Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "For casual wear",
            "Umbrella cut top"
        ],
        "key_words": [
            "Tops"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b2ae522a62aa5591e46263",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P059A",
        "model": "K9",
        "specification": [
            {
                "_id": "62b95af62a62aa5591e4eeda",
                "title": "Material",
                "value": "Cotton",
                "suffix": ""
            },
            {
                "_id": "62b95af62a62aa5591e4eedb",
                "title": "Colour",
                "value": "Red Kurthi",
                "suffix": ""
            },
            {
                "_id": "62b95af62a62aa5591e4eedc",
                "title": "Model",
                "value": " Calf Length Kurthi  with umbrella cut and three fourth sleeves",
                "suffix": ""
            },
            {
                "_id": "62b95af62a62aa5591e4eedd",
                "title": "Size",
                "value": "",
                "suffix": "XS"
            }
        ],
        "createdAt": "2022-06-22T05:53:22.478Z",
        "updatedAt": "2022-06-27T07:23:34.495Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Red Ajrakh Print Kurthi with hand embroidery- XS Size",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 2000,
        "sp": 1800,
        "stock": 0,
        "tax": null,
        "meta_desc": "Kurthis , Tops\n",
        "meta_key": "Tops",
        "note": "<div>Kindly hand wash the first wash and iron for best result</div><div><br></div>",
        "images": [
            "public/product/1655877376178.7944.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.4,
            "length": 30.5,
            "breadth": 30.5,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6229fdc25507127df692f42c",
                "category_name": "Womans wear",
                "specification": "62ad9bc72a62aa5591e3ff4b",
                "createdAt": "2022-03-10T13:31:46.187Z",
                "updatedAt": "2022-10-19T09:11:36.730Z",
                "__v": 0,
                "images": "public/category/1666170696730.1174.webp"
            },
            {
                "parent": "6229fdc25507127df692f42c",
                "status": true,
                "_id": "622aec725507127df69304f4",
                "category_name": "Kurthis",
                "specification": "622aebec5507127df69304d3",
                "createdAt": "2022-03-11T06:30:10.094Z",
                "updatedAt": "2022-06-20T09:03:37.611Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "For casual wear",
            "Umbrella cut top"
        ],
        "key_words": [
            "Tops"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b2af3f2a62aa5591e462b3",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P059B",
        "model": "K9",
        "specification": [
            {
                "_id": "62b95b202a62aa5591e4ef0a",
                "title": "Material",
                "value": "Cotton",
                "suffix": ""
            },
            {
                "_id": "62b95b202a62aa5591e4ef0b",
                "title": "Colour",
                "value": "Red Kurthi",
                "suffix": ""
            },
            {
                "_id": "62b95b202a62aa5591e4ef0c",
                "title": "Model",
                "value": " Calf Length Kurthi  with umbrella cut and three fourth sleeves",
                "suffix": ""
            },
            {
                "_id": "62b95b202a62aa5591e4ef0d",
                "title": "Size",
                "value": "",
                "suffix": "S"
            }
        ],
        "createdAt": "2022-06-22T05:57:19.373Z",
        "updatedAt": "2022-06-27T07:24:16.183Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Red Ajrakh Print Kurthi with hand embroidery- S Size",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 2000,
        "sp": 1800,
        "stock": 0,
        "tax": null,
        "meta_desc": "Kurthis ,Tops\n",
        "meta_key": "Tops",
        "note": "<div>Kindly hand wash the first wash and iron for best result</div><div><br></div>",
        "images": [
            "public/product/1655877552812.5085.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.4,
            "length": 30.5,
            "breadth": 30.5,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6229fdc25507127df692f42c",
                "category_name": "Womans wear",
                "specification": "62ad9bc72a62aa5591e3ff4b",
                "createdAt": "2022-03-10T13:31:46.187Z",
                "updatedAt": "2022-10-19T09:11:36.730Z",
                "__v": 0,
                "images": "public/category/1666170696730.1174.webp"
            },
            {
                "parent": "6229fdc25507127df692f42c",
                "status": true,
                "_id": "622aec725507127df69304f4",
                "category_name": "Kurthis",
                "specification": "622aebec5507127df69304d3",
                "createdAt": "2022-03-11T06:30:10.094Z",
                "updatedAt": "2022-06-20T09:03:37.611Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "For casual wear",
            "Umbrella cut top"
        ],
        "key_words": [
            ""
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b2afea2a62aa5591e46302",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P059C",
        "model": "K9",
        "specification": [
            {
                "_id": "62b95b442a62aa5591e4ef3a",
                "title": "Material",
                "value": "Cotton",
                "suffix": ""
            },
            {
                "_id": "62b95b442a62aa5591e4ef3b",
                "title": "Colour",
                "value": "Red Kurthi",
                "suffix": ""
            },
            {
                "_id": "62b95b442a62aa5591e4ef3c",
                "title": "Model",
                "value": " Calf Length Kurthi  with umbrella cut and three fourth sleeves",
                "suffix": ""
            },
            {
                "_id": "62b95b442a62aa5591e4ef3d",
                "title": "Size",
                "value": "",
                "suffix": "M"
            }
        ],
        "createdAt": "2022-06-22T06:00:10.201Z",
        "updatedAt": "2022-06-27T07:24:52.506Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Red Ajrakh Print Kurthi with hand embroidery - M Size",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 2000,
        "sp": 1800,
        "stock": 0,
        "tax": null,
        "meta_desc": "Kurthis\n",
        "meta_key": "Tops",
        "note": "<div>Kindly hand wash the first wash and iron for best result</div><div><br></div>",
        "images": [
            "public/product/1655877730569.3699.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.4,
            "length": 30.5,
            "breadth": 30.5,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6229fdc25507127df692f42c",
                "category_name": "Womans wear",
                "specification": "62ad9bc72a62aa5591e3ff4b",
                "createdAt": "2022-03-10T13:31:46.187Z",
                "updatedAt": "2022-10-19T09:11:36.730Z",
                "__v": 0,
                "images": "public/category/1666170696730.1174.webp"
            },
            {
                "parent": "6229fdc25507127df692f42c",
                "status": true,
                "_id": "622aec725507127df69304f4",
                "category_name": "Kurthis",
                "specification": "622aebec5507127df69304d3",
                "createdAt": "2022-03-11T06:30:10.094Z",
                "updatedAt": "2022-06-20T09:03:37.611Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "For casual wear",
            "Umbrella cut top"
        ],
        "key_words": [
            "Tops"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b2b09d2a62aa5591e46354",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P059D",
        "model": "K9",
        "specification": [
            {
                "_id": "62b95b612a62aa5591e4ef6a",
                "title": "Material",
                "value": "Cotton",
                "suffix": ""
            },
            {
                "_id": "62b95b612a62aa5591e4ef6b",
                "title": "Colour",
                "value": "Red Kurthi",
                "suffix": ""
            },
            {
                "_id": "62b95b612a62aa5591e4ef6c",
                "title": "Model",
                "value": " Calf Length Kurthi  with umbrella cut and three fourth sleeves",
                "suffix": ""
            },
            {
                "_id": "62b95b612a62aa5591e4ef6d",
                "title": "Size",
                "value": "",
                "suffix": "L"
            }
        ],
        "createdAt": "2022-06-22T06:03:09.381Z",
        "updatedAt": "2022-06-27T07:25:21.274Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Red Ajrakh Print Kurthi with hand embroidery - L Size ",
        "display_date": null,
        "hsn_code": "6104",
        "min_order_qty": 1,
        "mrp": 2000,
        "sp": 1800,
        "stock": 0,
        "tax": null,
        "meta_desc": "Kurthis ,Tops\n",
        "meta_key": "Tops",
        "note": "<div>Kindly hand wash the first wash and iron for best result</div><div><br></div>",
        "images": [
            "public/product/1655877939779.4758.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.15,
            "length": 10,
            "breadth": 5,
            "height": 6
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "622341265507127df692c50f",
                "category_name": "Home Utilities",
                "specification": null,
                "createdAt": "2022-03-05T10:53:26.643Z",
                "updatedAt": "2022-03-17T08:17:50.624Z",
                "__v": 0,
                "images": "public/category/1664342495502.3452.webp"
            },
            {
                "parent": "622341265507127df692c50f",
                "status": true,
                "_id": "622ae8ea5507127df693035c",
                "category_name": "Chettinad Baskets",
                "specification": null,
                "createdAt": "2022-03-11T06:15:06.440Z",
                "updatedAt": "2022-10-19T09:12:02.077Z",
                "__v": 0,
                "images": "public/category/1666170722075.4104.webp"
            },
            {
                "parent": "622ae8ea5507127df693035c",
                "status": true,
                "_id": "62b304112a62aa5591e469b9",
                "category_name": "Chettinadu Pookoodai",
                "specification": "62b306422a62aa5591e46a67",
                "createdAt": "2022-06-22T11:59:13.958Z",
                "updatedAt": "2022-06-22T12:10:01.782Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Lovely handy basket to carry for all your temple functions",
            "Fill them with goodies for function takeaways"
        ],
        "key_words": [
            ""
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b304c12a62aa5591e46a16",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P0059",
        "model": "PK",
        "specification": [
            {
                "_id": "62b5a0952a62aa5591e4a33a",
                "title": "Material",
                "value": "Plastic",
                "suffix": ""
            },
            {
                "_id": "62b5a0952a62aa5591e4a33b",
                "title": "Colour",
                "value": "Pink with Green ",
                "suffix": ""
            },
            {
                "_id": "62b5a0952a62aa5591e4a33c",
                "title": "Size",
                "value": "6 X 5 X 4 (In Inches)",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-22T12:02:09.308Z",
        "updatedAt": "2022-06-24T11:31:33.618Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Chettinadu Pookoodai Pink With Green Combination ",
        "display_date": null,
        "hsn_code": "3924",
        "min_order_qty": 1,
        "mrp": 800,
        "sp": 500,
        "stock": 0,
        "tax": {
            "status": true,
            "_id": "61f7dde28d37e6262ba17c80",
            "tax_name": "GST_18",
            "tax_percentage": 18,
            "__v": 0
        },
        "meta_desc": "Small Basket ",
        "meta_key": "Koodai",
        "note": "<div>Carry flowers and garlands to the temple<br></div>",
        "images": [
            "public/product/1655978860182.4.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.2,
            "length": 10,
            "breadth": 5,
            "height": 6
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "622341265507127df692c50f",
                "category_name": "Home Utilities",
                "specification": null,
                "createdAt": "2022-03-05T10:53:26.643Z",
                "updatedAt": "2022-03-17T08:17:50.624Z",
                "__v": 0,
                "images": "public/category/1664342495502.3452.webp"
            },
            {
                "parent": "622341265507127df692c50f",
                "status": true,
                "_id": "622ae8ea5507127df693035c",
                "category_name": "Chettinad Baskets",
                "specification": null,
                "createdAt": "2022-03-11T06:15:06.440Z",
                "updatedAt": "2022-10-19T09:12:02.077Z",
                "__v": 0,
                "images": "public/category/1666170722075.4104.webp"
            },
            {
                "parent": "622ae8ea5507127df693035c",
                "status": true,
                "_id": "62b304112a62aa5591e469b9",
                "category_name": "Chettinadu Pookoodai",
                "specification": "62b306422a62aa5591e46a67",
                "createdAt": "2022-06-22T11:59:13.958Z",
                "updatedAt": "2022-06-22T12:10:01.782Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Lovely to carry for  your temple functions",
            "Fill them with goodies for all function takeaways"
        ],
        "key_words": [
            ""
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b30d762a62aa5591e46b82",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P0059A",
        "model": "PK",
        "specification": [
            {
                "_id": "62b5a05b2a62aa5591e4a326",
                "title": "Material",
                "value": "Plastic",
                "suffix": ""
            },
            {
                "_id": "62b5a05b2a62aa5591e4a327",
                "title": "Colour",
                "value": "Pink With Grey",
                "suffix": ""
            },
            {
                "_id": "62b5a05b2a62aa5591e4a328",
                "title": "Size",
                "value": "6 X 5 X 4 (In Inches)",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-22T12:39:18.229Z",
        "updatedAt": "2022-06-24T11:30:35.065Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Chettinadu Pookoodai Pink with Grey Combination",
        "display_date": null,
        "hsn_code": "3924",
        "min_order_qty": 1,
        "mrp": 800,
        "sp": 500,
        "stock": 0,
        "tax": {
            "status": true,
            "_id": "61f7dde28d37e6262ba17c80",
            "tax_name": "GST_18",
            "tax_percentage": 18,
            "__v": 0
        },
        "meta_desc": "Small Basket ",
        "meta_key": "Koodai",
        "note": "Carry your flowers and garlands in a trendy basket.",
        "images": [
            "public/product/1655979378561.2246.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.2,
            "length": 31,
            "breadth": 31,
            "height": 8
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "622341265507127df692c50f",
                "category_name": "Home Utilities",
                "specification": null,
                "createdAt": "2022-03-05T10:53:26.643Z",
                "updatedAt": "2022-03-17T08:17:50.624Z",
                "__v": 0,
                "images": "public/category/1664342495502.3452.webp"
            },
            {
                "parent": "622341265507127df692c50f",
                "status": true,
                "_id": "622ae8ea5507127df693035c",
                "category_name": "Chettinad Baskets",
                "specification": null,
                "createdAt": "2022-03-11T06:15:06.440Z",
                "updatedAt": "2022-10-19T09:12:02.077Z",
                "__v": 0,
                "images": "public/category/1666170722075.4104.webp"
            },
            {
                "parent": "622ae8ea5507127df693035c",
                "status": true,
                "_id": "62b3e7fd2a62aa5591e46de6",
                "category_name": "Chettinadu Storage Box",
                "specification": "62b3e75e2a62aa5591e46db7",
                "createdAt": "2022-06-23T04:11:41.370Z",
                "updatedAt": "2022-06-23T04:15:26.025Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "For all Your Knick Knacks ",
            "Multiple Storage Box"
        ],
        "key_words": [
            "Koodai ,Storage Box"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b3e9012a62aa5591e46e58",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P0060",
        "model": "SB",
        "specification": [
            {
                "_id": "62b5a0df2a62aa5591e4a373",
                "title": "Material",
                "value": "Plastic",
                "suffix": ""
            },
            {
                "_id": "62b5a0df2a62aa5591e4a374",
                "title": "Colour",
                "value": "Green With Pink",
                "suffix": ""
            },
            {
                "_id": "62b5a0df2a62aa5591e4a375",
                "title": "Size",
                "value": "6.5 X 6 X 4 (In Inches)",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-23T04:16:01.436Z",
        "updatedAt": "2022-06-24T11:36:43.421Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Chettinadu Storage Box",
        "display_date": null,
        "hsn_code": "3924",
        "min_order_qty": 1,
        "mrp": 1000,
        "sp": 800,
        "stock": 0,
        "tax": {
            "status": true,
            "_id": "61f7dde28d37e6262ba17c80",
            "tax_name": "GST_18",
            "tax_percentage": 18,
            "__v": 0
        },
        "meta_desc": "Storage Box",
        "meta_key": "Koodai",
        "note": "Place it on your Table or in your Cupboard and organise your things&#160;",
        "images": [
            "public/product/1655979822611.9915.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.2,
            "length": 10,
            "breadth": 5,
            "height": 6
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "622341265507127df692c50f",
                "category_name": "Home Utilities",
                "specification": null,
                "createdAt": "2022-03-05T10:53:26.643Z",
                "updatedAt": "2022-03-17T08:17:50.624Z",
                "__v": 0,
                "images": "public/category/1664342495502.3452.webp"
            },
            {
                "parent": "622341265507127df692c50f",
                "status": true,
                "_id": "622ae8ea5507127df693035c",
                "category_name": "Chettinad Baskets",
                "specification": null,
                "createdAt": "2022-03-11T06:15:06.440Z",
                "updatedAt": "2022-10-19T09:12:02.077Z",
                "__v": 0,
                "images": "public/category/1666170722075.4104.webp"
            },
            {
                "parent": "622ae8ea5507127df693035c",
                "status": true,
                "_id": "622c3ddd8bc4af4c77b201a6",
                "category_name": "Lunch Bags",
                "specification": "622ae9a55507127df69303d6",
                "createdAt": "2022-03-12T06:29:49.596Z",
                "updatedAt": "2022-03-12T06:29:49.596Z",
                "__v": 0
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Store in your car space",
            "For your kids to take to school",
            "The Basket has Double weave Design "
        ],
        "key_words": [
            ""
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b3ec302a62aa5591e46f2a",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P0061",
        "model": "LB",
        "specification": [
            {
                "_id": "62b5a2092a62aa5591e4a3e0",
                "title": "Material",
                "value": "Plastic",
                "suffix": ""
            },
            {
                "_id": "62b5a2092a62aa5591e4a3e1",
                "title": "Colour",
                "value": "Pink with Yellow and Green Design ",
                "suffix": ""
            },
            {
                "_id": "62b5a2092a62aa5591e4a3e2",
                "title": "Size",
                "value": "7 X 4 X 6 (In Inches)",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-23T04:29:36.552Z",
        "updatedAt": "2022-06-24T11:39:34.527Z",
        "__v": 0,
        "delivery_days": 7,
        "description": " Standard Lunch bags",
        "display_date": null,
        "hsn_code": "3924",
        "min_order_qty": 1,
        "mrp": 1000,
        "sp": 900,
        "stock": 0,
        "tax": {
            "status": true,
            "_id": "61f7dde28d37e6262ba17c80",
            "tax_name": "GST_18",
            "tax_percentage": 18,
            "__v": 0
        },
        "meta_desc": "Small baskets",
        "meta_key": "Koodai",
        "note": "An comfortable size to hand carry anywhere&#160;",
        "images": [
            "public/product/1655979921620.072.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.25,
            "length": 31,
            "breadth": 31,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6234634f462a810f782266a6",
                "category_name": "Paper Craft",
                "createdAt": "2022-03-18T10:47:43.637Z",
                "updatedAt": "2022-10-19T09:12:36.034Z",
                "__v": 0,
                "images": "public/category/1666170756033.8086.webp",
                "specification": null
            },
            {
                "parent": "6234634f462a810f782266a6",
                "status": true,
                "_id": "62b3eef32a62aa5591e46fe4",
                "category_name": "Gift Hamper Tray",
                "specification": "62b3eea32a62aa5591e46fcb",
                "createdAt": "2022-06-23T04:41:23.872Z",
                "updatedAt": "2022-06-23T04:41:23.872Z",
                "__v": 0
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Pack Your Goodies in this re-usable tray",
            "An easy gift to buy ,store and gift at any time with memories to hold."
        ],
        "key_words": [
            "Paper craft"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b3ef152a62aa5591e46ff7",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P0062",
        "model": "GHT",
        "specification": [
            {
                "_id": "62b5a5a92a62aa5591e4a519",
                "title": "Material",
                "value": "Paper And Jute ",
                "suffix": ""
            },
            {
                "_id": "62b5a5a92a62aa5591e4a51a",
                "title": "Colour",
                "value": "Golden Colour with Red Zari Design",
                "suffix": ""
            },
            {
                "_id": "62b5a5a92a62aa5591e4a51b",
                "title": "Size",
                "value": "8.5 X 5.5 X 4.5 (In Inches)",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-23T04:41:57.263Z",
        "updatedAt": "2022-06-24T11:53:13.007Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Gift Hamper Tray",
        "display_date": null,
        "hsn_code": "3924",
        "min_order_qty": 1,
        "mrp": 800,
        "sp": 660,
        "stock": 0,
        "tax": {
            "status": true,
            "_id": "61f7dde28d37e6262ba17c80",
            "tax_name": "GST_18",
            "tax_percentage": 18,
            "__v": 0
        },
        "meta_desc": "Hamper Tray, Paper craft",
        "meta_key": "Paper craft",
        "note": "Gift Hamper Tray to Fill With Sweets&#160; And Candys",
        "images": [
            "public/product/1656161033330.8318.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.25,
            "length": 10,
            "breadth": 5,
            "height": 6
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "622341265507127df692c50f",
                "category_name": "Home Utilities",
                "specification": null,
                "createdAt": "2022-03-05T10:53:26.643Z",
                "updatedAt": "2022-03-17T08:17:50.624Z",
                "__v": 0,
                "images": "public/category/1664342495502.3452.webp"
            },
            {
                "parent": "622341265507127df692c50f",
                "status": true,
                "_id": "622ae8ea5507127df693035c",
                "category_name": "Chettinad Baskets",
                "specification": null,
                "createdAt": "2022-03-11T06:15:06.440Z",
                "updatedAt": "2022-10-19T09:12:02.077Z",
                "__v": 0,
                "images": "public/category/1666170722075.4104.webp"
            },
            {
                "parent": "622ae8ea5507127df693035c",
                "status": true,
                "_id": "62b3f2642a62aa5591e470e6",
                "category_name": "Chettinadu Arachana koodai",
                "specification": "62b3f2282a62aa5591e470d3",
                "createdAt": "2022-06-23T04:56:04.658Z",
                "updatedAt": "2022-06-23T04:57:42.624Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Pooja Basket for Temple",
            "Fill Them With Anything For Takeaway Gifts",
            "Multipurpose"
        ],
        "key_words": [
            "Pooja Koodai"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b3f2e12a62aa5591e4712b",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P0063",
        "model": "CAK",
        "specification": [
            {
                "_id": "62baadf12a62aa5591e4f8f8",
                "title": "Material",
                "value": "Plastic ",
                "suffix": ""
            },
            {
                "_id": "62baadf12a62aa5591e4f8f9",
                "title": "Colur",
                "value": "Pink  and purple",
                "suffix": ""
            },
            {
                "_id": "62baadf12a62aa5591e4f8fa",
                "title": "Size",
                "value": "6 X 6 X 5.5 (In Inches)",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-23T04:58:09.754Z",
        "updatedAt": "2022-06-28T07:30:51.404Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Archanai  Koodai With Double handle",
        "display_date": null,
        "hsn_code": "3924",
        "min_order_qty": 1,
        "mrp": 1000,
        "sp": 800,
        "stock": 0,
        "tax": {
            "status": true,
            "_id": "61f7dde28d37e6262ba17c80",
            "tax_name": "GST_18",
            "tax_percentage": 18,
            "__v": 0
        },
        "meta_desc": "Basket ,Pooja Koodai",
        "meta_key": "Pooja Koodai",
        "note": "An comfortable size to hand carry anywhere .<div>Washable Baskets .</div>",
        "images": [
            "public/product/1655960911823.476.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.2,
            "length": 21,
            "breadth": 12,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6234634f462a810f782266a6",
                "category_name": "Paper Craft",
                "createdAt": "2022-03-18T10:47:43.637Z",
                "updatedAt": "2022-10-19T09:12:36.034Z",
                "__v": 0,
                "images": "public/category/1666170756033.8086.webp",
                "specification": null
            },
            {
                "parent": "6234634f462a810f782266a6",
                "status": true,
                "_id": "62b403452a62aa5591e471e8",
                "category_name": "Jewel Box",
                "specification": "62b402fb2a62aa5591e471d5",
                "createdAt": "2022-06-23T06:08:05.406Z",
                "updatedAt": "2022-06-23T06:08:05.406Z",
                "__v": 0
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Great utility on your desk.",
            "Multi Organizers",
            "Great to Fill  for your festive moods ",
            "Store Your Jewells Too"
        ],
        "key_words": [
            "Storage Box , Sweet Box , Jewel Box "
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b403d42a62aa5591e4720e",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P0064",
        "model": "JB",
        "specification": [
            {
                "_id": "62b5a6582a62aa5591e4a55f",
                "title": "Material",
                "value": "paper",
                "suffix": ""
            },
            {
                "_id": "62b5a6582a62aa5591e4a560",
                "title": "Colour",
                "value": "Red",
                "suffix": ""
            },
            {
                "_id": "62b5a6582a62aa5591e4a561",
                "title": "Size",
                "value": "8.5 X 4.5 X 1.5 (In Inches)",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-23T06:10:28.522Z",
        "updatedAt": "2022-06-24T12:01:53.928Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Red Jewel Box",
        "display_date": null,
        "hsn_code": "3924",
        "min_order_qty": 1,
        "mrp": 800,
        "sp": 600,
        "stock": 0,
        "tax": {
            "status": true,
            "_id": "61f7dde28d37e6262ba17c80",
            "tax_name": "GST_18",
            "tax_percentage": 18,
            "__v": 0
        },
        "meta_desc": "Paper made products, Storage Box , Sweet Box , Jewel Box ",
        "meta_key": "Storage Box , Sweet Box , Jewel Box ",
        "note": "<div>Totally Handmade With Craft Paper And Silk Cloth</div>",
        "images": [
            "public/product/1655965318435.7988.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.2,
            "length": 22,
            "breadth": 22,
            "height": 9
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6234634f462a810f782266a6",
                "category_name": "Paper Craft",
                "createdAt": "2022-03-18T10:47:43.637Z",
                "updatedAt": "2022-10-19T09:12:36.034Z",
                "__v": 0,
                "images": "public/category/1666170756033.8086.webp",
                "specification": null
            },
            {
                "parent": "6234634f462a810f782266a6",
                "status": true,
                "_id": "62b407242a62aa5591e472a2",
                "category_name": "Gift hamper Box",
                "specification": "62b406e42a62aa5591e4728f",
                "createdAt": "2022-06-23T06:24:36.126Z",
                "updatedAt": "2022-06-23T06:24:36.126Z",
                "__v": 0
            }
        ],
        "pricestatus": false,
        "highlight": [
            "An Excellent Packing box for all Gifts ",
            "Reusable Packing Box"
        ],
        "key_words": [
            "Paper Craft Hamper Box , Packing Box "
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b407522a62aa5591e472b5",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P0065",
        "model": "GHB",
        "specification": [
            {
                "_id": "62b68d772a62aa5591e4aabf",
                "title": "Material",
                "value": "Paper ",
                "suffix": ""
            },
            {
                "_id": "62b68d772a62aa5591e4aac0",
                "title": "Colur",
                "value": "Orange and White combination ",
                "suffix": ""
            },
            {
                "_id": "62b68d772a62aa5591e4aac1",
                "title": "Size",
                "value": "9 x 9 x 3.5 (In Inches)",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-23T06:25:22.323Z",
        "updatedAt": "2022-06-25T04:29:04.994Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Gift hamper Box ",
        "display_date": null,
        "hsn_code": "3924",
        "min_order_qty": 1,
        "mrp": 1000,
        "sp": 800,
        "stock": 0,
        "tax": {
            "status": true,
            "_id": "61f7dde28d37e6262ba17c80",
            "tax_name": "GST_18",
            "tax_percentage": 18,
            "__v": 0
        },
        "meta_desc": "Paper Craft Hamper Box , Packing Box ",
        "meta_key": "Paper Craft Hamper Box , Packing Box ",
        "note": "<div>Handmade Paper Crafted Box to Pack Your Gift For all Occasion&#160;</div>",
        "images": [
            "public/product/1655966074634.8904.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.3,
            "length": 31,
            "breadth": 31,
            "height": 10
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6234634f462a810f782266a6",
                "category_name": "Paper Craft",
                "createdAt": "2022-03-18T10:47:43.637Z",
                "updatedAt": "2022-10-19T09:12:36.034Z",
                "__v": 0,
                "images": "public/category/1666170756033.8086.webp",
                "specification": null
            },
            {
                "parent": "6234634f462a810f782266a6",
                "status": true,
                "_id": "623c257c1d83b224a0469ae9",
                "category_name": "Desk top Holders",
                "createdAt": "2022-03-24T08:02:04.087Z",
                "updatedAt": "2022-03-24T10:31:44.555Z",
                "__v": 0,
                "images": null,
                "specification": "62321c97434e6366c9fdac36"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Great utility on on your desk.",
            "Best organiser."
        ],
        "key_words": [
            ""
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b409e42a62aa5591e47359",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P053",
        "model": "MM",
        "specification": [
            {
                "_id": "62b40a432a62aa5591e4737c",
                "title": "Material",
                "value": "Paper",
                "suffix": ""
            },
            {
                "_id": "62b40a432a62aa5591e4737d",
                "title": "Colour",
                "value": "Grey marble painting",
                "suffix": ""
            },
            {
                "_id": "62b40a432a62aa5591e4737e",
                "title": "Size",
                "value": "5\"*5\"*4\"(in inches)",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-23T06:36:20.329Z",
        "updatedAt": "2022-06-23T06:48:08.373Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Grey Desk Top Holders",
        "display_date": null,
        "hsn_code": "2934",
        "min_order_qty": 1,
        "mrp": 800,
        "sp": 750,
        "stock": 0,
        "tax": {
            "status": true,
            "_id": "61f7dde28d37e6262ba17c80",
            "tax_name": "GST_18",
            "tax_percentage": 18,
            "__v": 0
        },
        "meta_desc": "Paper made products",
        "meta_key": "Hand made products",
        "note": "Marble Painted kraft paper used and desk top holder is wholly hand made.<div>Lovely and fancy handles for the miniature draws.</div>",
        "images": [
            "public/product/1655966850151.3171.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.25,
            "length": 20,
            "breadth": 20,
            "height": 1
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6234634f462a810f782266a6",
                "category_name": "Paper Craft",
                "createdAt": "2022-03-18T10:47:43.637Z",
                "updatedAt": "2022-10-19T09:12:36.034Z",
                "__v": 0,
                "images": "public/category/1666170756033.8086.webp",
                "specification": null
            },
            {
                "parent": "6234634f462a810f782266a6",
                "status": true,
                "_id": "62346405462a810f782266de",
                "category_name": "Photo Frame",
                "createdAt": "2022-03-18T10:50:45.256Z",
                "updatedAt": "2022-06-23T12:33:45.449Z",
                "__v": 0,
                "images": null,
                "specification": "62321be0434e6366c9fdac28"
            },
            {
                "parent": "62346405462a810f782266de",
                "status": true,
                "_id": "62b40ea82a62aa5591e47486",
                "category_name": "Single photo frames",
                "specification": "62321be0434e6366c9fdac28",
                "createdAt": "2022-06-23T06:56:40.678Z",
                "updatedAt": "2022-06-23T12:35:21.122Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Nice to gift to your loved ones.",
            "An easy gift to buy ,store and gift at any time with memories to hold."
        ],
        "key_words": [
            "Paper craft"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b40ffa2a62aa5591e4752b",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P0066",
        "model": "SPF",
        "specification": [
            {
                "_id": "62b5aa362a62aa5591e4a671",
                "title": "Material",
                "value": "Paper",
                "suffix": ""
            },
            {
                "_id": "62b5aa362a62aa5591e4a672",
                "title": "Colour",
                "value": "Off White",
                "suffix": ""
            },
            {
                "_id": "62b5aa362a62aa5591e4a673",
                "title": "Size",
                "value": "7.5 X 7.5 (in inches)",
                "suffix": ""
            },
            {
                "_id": "62b5aa362a62aa5591e4a674",
                "title": "Available Colours",
                "value": "",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-23T07:02:18.211Z",
        "updatedAt": "2022-06-24T12:13:01.713Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Single Photo Frames with Flower Design ",
        "display_date": null,
        "hsn_code": "3924",
        "min_order_qty": 1,
        "mrp": 500,
        "sp": 300,
        "stock": 0,
        "tax": {
            "status": true,
            "_id": "61f7dde28d37e6262ba17c80",
            "tax_name": "GST_18",
            "tax_percentage": 18,
            "__v": 0
        },
        "meta_desc": "Photo frame, Paper craft",
        "meta_key": "Paper craft",
        "note": "Single Side Photo frames with Flower Design",
        "images": [
            "public/product/1655985874043.8958.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.25,
            "length": 31,
            "breadth": 31,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6234634f462a810f782266a6",
                "category_name": "Paper Craft",
                "createdAt": "2022-03-18T10:47:43.637Z",
                "updatedAt": "2022-10-19T09:12:36.034Z",
                "__v": 0,
                "images": "public/category/1666170756033.8086.webp",
                "specification": null
            },
            {
                "parent": "6234634f462a810f782266a6",
                "status": true,
                "_id": "62346405462a810f782266de",
                "category_name": "Photo Frame",
                "createdAt": "2022-03-18T10:50:45.256Z",
                "updatedAt": "2022-06-23T12:33:45.449Z",
                "__v": 0,
                "images": null,
                "specification": "62321be0434e6366c9fdac28"
            },
            {
                "parent": "62346405462a810f782266de",
                "status": true,
                "_id": "62b40ec42a62aa5591e4748f",
                "category_name": "Double Photo Frames",
                "specification": "62b40df92a62aa5591e47454",
                "createdAt": "2022-06-23T06:57:08.252Z",
                "updatedAt": "2022-06-23T07:01:47.204Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Nice to gift to your loved ones.",
            "An easy gift to buy ,store and gift at any time with memories to hold.",
            "An Affordable Price to Gift"
        ],
        "key_words": [
            "paper Craft "
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b411502a62aa5591e47594",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P0067",
        "model": "DPF",
        "specification": [
            {
                "_id": "62b5aaf52a62aa5591e4a6f7",
                "title": "material",
                "value": "Paper",
                "suffix": ""
            },
            {
                "_id": "62b5aaf52a62aa5591e4a6f8",
                "title": "Colour",
                "value": "Red",
                "suffix": ""
            },
            {
                "_id": "62b5aaf52a62aa5591e4a6f9",
                "title": "Size",
                "value": "12 X 8 (In Inches)",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-23T07:08:00.530Z",
        "updatedAt": "2022-06-24T12:17:02.666Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Double Photo Frames ",
        "display_date": null,
        "hsn_code": "3924",
        "min_order_qty": 1,
        "mrp": 400,
        "sp": 360,
        "stock": 0,
        "tax": {
            "status": true,
            "_id": "61f7dde28d37e6262ba17c80",
            "tax_name": "GST_18",
            "tax_percentage": 18,
            "__v": 0
        },
        "meta_desc": "Photo Frames ,paper Craft ",
        "meta_key": "paper Craft ",
        "note": "Double&#160; Side Photo Frames Which is Foldable .<div><br></div>",
        "images": [
            "public/product/1655968765028.8474.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.22,
            "length": 23,
            "breadth": 15,
            "height": null
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6225aa6c5507127df692d326",
                "category_name": "Wedding hand bags",
                "createdAt": "2022-03-07T06:47:08.299Z",
                "updatedAt": "2022-10-19T09:11:12.613Z",
                "__v": 0,
                "images": "public/category/1666170672612.1301.webp",
                "specification": null
            },
            {
                "parent": "6225aa6c5507127df692d326",
                "status": true,
                "_id": "62345cbc462a810f78226389",
                "category_name": "Clutch Hand Bags",
                "specification": "6227066b5507127df692d69c",
                "createdAt": "2022-03-18T10:19:40.691Z",
                "updatedAt": "2022-03-19T10:21:06.145Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "For weddings and parties",
            "Matches all outfits traditional or western"
        ],
        "key_words": [
            "Fancy clutch "
        ],
        "status": true,
        "featured": false,
        "publish": false,
        "_id": "62b419ab2a62aa5591e4788c",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P0068",
        "model": "FCB",
        "specification": [
            {
                "_id": "62b6a7b52a62aa5591e4ac89",
                "title": "Material",
                "value": "Silk With Embroidery",
                "suffix": ""
            },
            {
                "_id": "62b6a7b52a62aa5591e4ac8a",
                "title": "Colour",
                "value": "Off White",
                "suffix": ""
            },
            {
                "_id": "62b6a7b52a62aa5591e4ac8b",
                "title": "Size",
                "value": "9.5 X 6 X 1  (in inches)",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-23T07:43:39.806Z",
        "updatedAt": "2022-06-25T06:14:35.371Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Fancy Clutch With Sling ",
        "display_date": null,
        "hsn_code": "6305",
        "min_order_qty": 1,
        "mrp": 1200,
        "sp": 1000,
        "stock": 0,
        "tax": null,
        "meta_desc": "Clutch Bag ,Fancy clutch ",
        "meta_key": "Fancy clutch ",
        "note": "Slim Bag With Silk Cloth and Embroidery.<div>Can&#160;<span>Use it as Hand Clutch Bag Too.</span></div>",
        "images": [
            "public/product/1655970531888.2742.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.33,
            "length": 20,
            "breadth": 15,
            "height": null
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6225aa6c5507127df692d326",
                "category_name": "Wedding hand bags",
                "createdAt": "2022-03-07T06:47:08.299Z",
                "updatedAt": "2022-10-19T09:11:12.613Z",
                "__v": 0,
                "images": "public/category/1666170672612.1301.webp",
                "specification": null
            },
            {
                "parent": "6225aa6c5507127df692d326",
                "status": true,
                "_id": "62345cbc462a810f78226389",
                "category_name": "Clutch Hand Bags",
                "specification": "6227066b5507127df692d69c",
                "createdAt": "2022-03-18T10:19:40.691Z",
                "updatedAt": "2022-03-19T10:21:06.145Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Party wear",
            "Matches all outfits."
        ],
        "key_words": [
            "Party clutch"
        ],
        "status": true,
        "featured": false,
        "publish": false,
        "_id": "62b41ca82a62aa5591e479ae",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P0069",
        "model": "PC",
        "specification": [
            {
                "_id": "62b6ab7b2a62aa5591e4adb5",
                "title": "Material",
                "value": "Metal",
                "suffix": ""
            },
            {
                "_id": "62b6ab7b2a62aa5591e4adb6",
                "title": "Colour",
                "value": "Multicolour ",
                "suffix": ""
            },
            {
                "_id": "62b6ab7b2a62aa5591e4adb7",
                "title": "Size",
                "value": "5.5 X 7.5  (In Inches)",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-23T07:56:24.743Z",
        "updatedAt": "2022-06-25T06:30:19.464Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Party Clutch",
        "display_date": null,
        "hsn_code": "6305",
        "min_order_qty": 1,
        "mrp": 1800,
        "sp": 1500,
        "stock": 0,
        "tax": null,
        "meta_desc": "Clutch Bag, Party clutch",
        "meta_key": "Party clutch",
        "note": "<div>Metal Purse yet Light in weight to carry.</div>",
        "images": [
            "public/product/1655971947871.4214.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.26,
            "length": 31,
            "breadth": 31,
            "height": 2.5
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6225aa6c5507127df692d326",
                "category_name": "Wedding hand bags",
                "createdAt": "2022-03-07T06:47:08.299Z",
                "updatedAt": "2022-10-19T09:11:12.613Z",
                "__v": 0,
                "images": "public/category/1666170672612.1301.webp",
                "specification": null
            },
            {
                "parent": "6225aa6c5507127df692d326",
                "status": true,
                "_id": "62345cbc462a810f78226389",
                "category_name": "Clutch Hand Bags",
                "specification": "6227066b5507127df692d69c",
                "createdAt": "2022-03-18T10:19:40.691Z",
                "updatedAt": "2022-03-19T10:21:06.145Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Carry your personals at weddings and parties.",
            ""
        ],
        "key_words": [
            "Bag"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b44cdf2a62aa5591e48917",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P0070",
        "model": "PBWH",
        "specification": [
            {
                "_id": "62b6a9582a62aa5591e4ad3f",
                "title": "Material",
                "value": "silk",
                "suffix": ""
            },
            {
                "_id": "62b6a9582a62aa5591e4ad40",
                "title": "Colour",
                "value": "Multi colour",
                "suffix": ""
            },
            {
                "_id": "62b6a9582a62aa5591e4ad41",
                "title": "Size",
                "value": "8 X 2.5 X 7 (In Inches)",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-23T11:22:07.164Z",
        "updatedAt": "2022-06-25T06:31:20.423Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Party Bag With Wooden handle ",
        "display_date": null,
        "hsn_code": "6305",
        "min_order_qty": 1,
        "mrp": 1500,
        "sp": 1200,
        "stock": 0,
        "tax": {
            "status": true,
            "_id": "61f7dde28d37e6262ba17c80",
            "tax_name": "GST_18",
            "tax_percentage": 18,
            "__v": 0
        },
        "meta_desc": "Hand Bag ,Bag",
        "meta_key": "Bag",
        "note": "Party hand bag With Wooden handles&#160;",
        "images": [
            "public/product/1655983940590.7576.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.3,
            "length": 31,
            "breadth": 31,
            "height": 2
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6225aa6c5507127df692d326",
                "category_name": "Wedding hand bags",
                "createdAt": "2022-03-07T06:47:08.299Z",
                "updatedAt": "2022-10-19T09:11:12.613Z",
                "__v": 0,
                "images": "public/category/1666170672612.1301.webp",
                "specification": null
            },
            {
                "parent": "6225aa6c5507127df692d326",
                "status": true,
                "_id": "62345cbc462a810f78226389",
                "category_name": "Clutch Hand Bags",
                "specification": "6227066b5507127df692d69c",
                "createdAt": "2022-03-18T10:19:40.691Z",
                "updatedAt": "2022-03-19T10:21:06.145Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Carry your personals at weddings and parties."
        ],
        "key_words": [
            "Bag"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b44fd62a62aa5591e489b0",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P0071",
        "model": "SC",
        "specification": [
            {
                "_id": "62b6ac212a62aa5591e4ae21",
                "title": "Material",
                "value": "Cloth",
                "suffix": ""
            },
            {
                "_id": "62b6ac212a62aa5591e4ae22",
                "title": "Colour",
                "value": "Multicolour",
                "suffix": ""
            },
            {
                "_id": "62b6ac212a62aa5591e4ae23",
                "title": "Size",
                "value": "10.5 X 6.5  (In Inches)",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-23T11:34:46.277Z",
        "updatedAt": "2022-06-25T06:34:25.730Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Striped Cloth with wooden handle Clutch",
        "display_date": null,
        "hsn_code": "6305",
        "min_order_qty": 1,
        "mrp": 1500,
        "sp": 1200,
        "stock": 0,
        "tax": {
            "status": true,
            "_id": "61f7dde28d37e6262ba17c80",
            "tax_name": "GST_18",
            "tax_percentage": 18,
            "__v": 0
        },
        "meta_desc": "Hand Bag, Bag",
        "meta_key": "Bag",
        "note": "Striped Cloth Bag with Wooden handles .",
        "images": [
            "public/product/1655984586537.881.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.35,
            "length": 31,
            "breadth": 31,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6225aa6c5507127df692d326",
                "category_name": "Wedding hand bags",
                "createdAt": "2022-03-07T06:47:08.299Z",
                "updatedAt": "2022-10-19T09:11:12.613Z",
                "__v": 0,
                "images": "public/category/1666170672612.1301.webp",
                "specification": null
            },
            {
                "parent": "6225aa6c5507127df692d326",
                "status": true,
                "_id": "62345cbc462a810f78226389",
                "category_name": "Clutch Hand Bags",
                "specification": "6227066b5507127df692d69c",
                "createdAt": "2022-03-18T10:19:40.691Z",
                "updatedAt": "2022-03-19T10:21:06.145Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Carry your personals at weddings and parties."
        ],
        "key_words": [
            "Bag"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b4524c2a62aa5591e48a20",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P0072",
        "model": "PG",
        "specification": [
            {
                "_id": "62b6acda2a62aa5591e4ae89",
                "title": "Material",
                "value": "Silk ",
                "suffix": ""
            },
            {
                "_id": "62b6acda2a62aa5591e4ae8a",
                "title": "Colour",
                "value": "Gold ",
                "suffix": ""
            },
            {
                "_id": "62b6acda2a62aa5591e4ae8b",
                "title": "Size",
                "value": "10.5 X 6.5  (In Inches)",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-23T11:45:16.685Z",
        "updatedAt": "2022-06-25T06:36:44.377Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Plain Gold With Wooden  Handle Clutch",
        "display_date": null,
        "hsn_code": "6305",
        "min_order_qty": 1,
        "mrp": 1500,
        "sp": 1200,
        "stock": 0,
        "tax": {
            "status": true,
            "_id": "61f7dde28d37e6262ba17c80",
            "tax_name": "GST_18",
            "tax_percentage": 18,
            "__v": 0
        },
        "meta_desc": "Hand Bag ,Bag",
        "meta_key": "Bag",
        "note": "Plain Gold With Woodden Handle clutch&#160;",
        "images": [
            "public/product/1655985564685.412.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.15,
            "length": 31,
            "breadth": 31,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6234634f462a810f782266a6",
                "category_name": "Paper Craft",
                "createdAt": "2022-03-18T10:47:43.637Z",
                "updatedAt": "2022-10-19T09:12:36.034Z",
                "__v": 0,
                "images": "public/category/1666170756033.8086.webp",
                "specification": null
            },
            {
                "parent": "6234634f462a810f782266a6",
                "status": true,
                "_id": "62346405462a810f782266de",
                "category_name": "Photo Frame",
                "createdAt": "2022-03-18T10:50:45.256Z",
                "updatedAt": "2022-06-23T12:33:45.449Z",
                "__v": 0,
                "images": null,
                "specification": "62321be0434e6366c9fdac28"
            },
            {
                "parent": "62346405462a810f782266de",
                "status": true,
                "_id": "62b40ea82a62aa5591e47486",
                "category_name": "Single photo frames",
                "specification": "62321be0434e6366c9fdac28",
                "createdAt": "2022-06-23T06:56:40.678Z",
                "updatedAt": "2022-06-23T12:35:21.122Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            ""
        ],
        "key_words": [
            ""
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b45b362a62aa5591e48bf6",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P057A",
        "model": "PF",
        "specification": [
            {
                "_id": "62b45f262a62aa5591e48d3d",
                "title": "Material",
                "value": "paper",
                "suffix": ""
            },
            {
                "_id": "62b45f262a62aa5591e48d3e",
                "title": "Colour",
                "value": "Red",
                "suffix": ""
            },
            {
                "_id": "62b45f262a62aa5591e48d3f",
                "title": "Size",
                "value": "8.5\"*6.5\"(In Inches)",
                "suffix": ""
            },
            {
                "_id": "62b45f262a62aa5591e48d40",
                "title": "Available Colours",
                "value": "",
                "suffix": "Blue"
            }
        ],
        "createdAt": "2022-06-23T12:23:18.432Z",
        "updatedAt": "2022-06-23T12:50:20.366Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Paper Board Photo Frames-Blue Colour",
        "display_date": null,
        "hsn_code": "3924",
        "min_order_qty": 1,
        "mrp": 350,
        "sp": 300,
        "stock": 0,
        "tax": {
            "status": true,
            "_id": "61f7dde28d37e6262ba17c80",
            "tax_name": "GST_18",
            "tax_percentage": 18,
            "__v": 0
        },
        "meta_desc": "Paper Board ",
        "meta_key": "Photo frame ",
        "note": "",
        "images": [
            "public/product/1655988061271.702.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.15,
            "length": 31,
            "breadth": 31,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6234634f462a810f782266a6",
                "category_name": "Paper Craft",
                "createdAt": "2022-03-18T10:47:43.637Z",
                "updatedAt": "2022-10-19T09:12:36.034Z",
                "__v": 0,
                "images": "public/category/1666170756033.8086.webp",
                "specification": null
            },
            {
                "parent": "6234634f462a810f782266a6",
                "status": true,
                "_id": "62346405462a810f782266de",
                "category_name": "Photo Frame",
                "createdAt": "2022-03-18T10:50:45.256Z",
                "updatedAt": "2022-06-23T12:33:45.449Z",
                "__v": 0,
                "images": null,
                "specification": "62321be0434e6366c9fdac28"
            },
            {
                "parent": "62346405462a810f782266de",
                "status": true,
                "_id": "62b40ea82a62aa5591e47486",
                "category_name": "Single photo frames",
                "specification": "62321be0434e6366c9fdac28",
                "createdAt": "2022-06-23T06:56:40.678Z",
                "updatedAt": "2022-06-23T12:35:21.122Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            ""
        ],
        "key_words": [
            ""
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b460f62a62aa5591e48ec1",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P057 B",
        "model": "PF",
        "specification": [
            {
                "_id": "62b463722a62aa5591e491ed",
                "title": "Material",
                "value": "Paper",
                "suffix": ""
            },
            {
                "_id": "62b463722a62aa5591e491ee",
                "title": "Colour",
                "value": "Green",
                "suffix": ""
            },
            {
                "_id": "62b463722a62aa5591e491ef",
                "title": "Size",
                "value": "8.5 X 6.5 (in inches)",
                "suffix": ""
            },
            {
                "_id": "62b463722a62aa5591e491f0",
                "title": "Available Colours",
                "value": "",
                "suffix": "Green"
            }
        ],
        "createdAt": "2022-06-23T12:47:50.571Z",
        "updatedAt": "2022-06-23T12:58:26.146Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Paper Board Photo Frames -Green ",
        "display_date": null,
        "hsn_code": "3924",
        "min_order_qty": 1,
        "mrp": 350,
        "sp": 300,
        "stock": 0,
        "tax": {
            "status": true,
            "_id": "61f7dde28d37e6262ba17c80",
            "tax_name": "GST_18",
            "tax_percentage": 18,
            "__v": 0
        },
        "meta_desc": "Paper board ",
        "meta_key": "Photo Frame",
        "note": "",
        "images": [
            "public/product/1655988664654.4792.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.1,
            "length": 31,
            "breadth": 31,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6225aa6c5507127df692d326",
                "category_name": "Wedding hand bags",
                "createdAt": "2022-03-07T06:47:08.299Z",
                "updatedAt": "2022-10-19T09:11:12.613Z",
                "__v": 0,
                "images": "public/category/1666170672612.1301.webp",
                "specification": null
            },
            {
                "parent": "6225aa6c5507127df692d326",
                "status": true,
                "_id": "6225aa0b5507127df692d314",
                "category_name": "Surukku Bags",
                "createdAt": "2022-03-07T06:45:31.847Z",
                "updatedAt": "2022-10-19T09:11:03.348Z",
                "__v": 0,
                "images": "public/category/1666170663347.396.webp",
                "specification": "6226f5ec5507127df692d460"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Great Give aways at weddings and any ceremonies tucked with sweets"
        ],
        "key_words": [
            "Potli bags"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b539b12a62aa5591e492c1",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P0073",
        "model": "SB1",
        "specification": [
            {
                "_id": "62b6ad4c2a62aa5591e4aee1",
                "title": "Material",
                "value": "Silk with zari",
                "suffix": ""
            },
            {
                "_id": "62b6ad4c2a62aa5591e4aee2",
                "title": "Colour",
                "value": "Silver",
                "suffix": ""
            },
            {
                "_id": "62b6ad4c2a62aa5591e4aee3",
                "title": "Size",
                "value": "8 X 9  (In Inches )",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-24T04:12:33.057Z",
        "updatedAt": "2022-06-25T06:38:22.332Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Silver Surukku Bag with Pearl Design ",
        "display_date": null,
        "hsn_code": "6305",
        "min_order_qty": 1,
        "mrp": 650,
        "sp": 590,
        "stock": 0,
        "tax": {
            "status": true,
            "_id": "61f7dde28d37e6262ba17c80",
            "tax_name": "GST_18",
            "tax_percentage": 18,
            "__v": 0
        },
        "meta_desc": "Surukku bags, Potli bags",
        "meta_key": "Potli bags",
        "note": "Potli bags for take aways at any occassion.<div>Beaded with embroidery.</div>",
        "images": [
            "public/product/1656045417305.696.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.05,
            "length": 31,
            "breadth": 31,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6225aa6c5507127df692d326",
                "category_name": "Wedding hand bags",
                "createdAt": "2022-03-07T06:47:08.299Z",
                "updatedAt": "2022-10-19T09:11:12.613Z",
                "__v": 0,
                "images": "public/category/1666170672612.1301.webp",
                "specification": null
            },
            {
                "parent": "6225aa6c5507127df692d326",
                "status": true,
                "_id": "6225aa0b5507127df692d314",
                "category_name": "Surukku Bags",
                "createdAt": "2022-03-07T06:45:31.847Z",
                "updatedAt": "2022-10-19T09:11:03.348Z",
                "__v": 0,
                "images": "public/category/1666170663347.396.webp",
                "specification": "6226f5ec5507127df692d460"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Great Give aways at weddings and any ceremonies tucked with sweets",
            "Great to use as Thamboolam Bags ."
        ],
        "key_words": [
            "Potli bags"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b53fe32a62aa5591e49377",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P0074",
        "model": "PB1",
        "specification": [
            {
                "_id": "62b6adf82a62aa5591e4af7e",
                "title": "Material",
                "value": "Silk With Zari",
                "suffix": ""
            },
            {
                "_id": "62b6adf82a62aa5591e4af7f",
                "title": "Colour",
                "value": "Red",
                "suffix": ""
            },
            {
                "_id": "62b6adf82a62aa5591e4af80",
                "title": "Size",
                "value": "8 X 9.5 (In Inches)",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-24T04:38:59.133Z",
        "updatedAt": "2022-06-25T06:42:16.710Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Red Colour Surukku bag With Ikkat Design ",
        "display_date": null,
        "hsn_code": "6305",
        "min_order_qty": 1,
        "mrp": 450,
        "sp": 390,
        "stock": 0,
        "tax": {
            "status": true,
            "_id": "61f7dde28d37e6262ba17c80",
            "tax_name": "GST_18",
            "tax_percentage": 18,
            "__v": 0
        },
        "meta_desc": "Surukku bags, Potli bags",
        "meta_key": "Potli bags",
        "note": "Potli bags for take aways at any occassion.<div><br></div>",
        "images": [
            "public/product/1656045811161.3425.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.1,
            "length": 31,
            "breadth": 31,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6225aa6c5507127df692d326",
                "category_name": "Wedding hand bags",
                "createdAt": "2022-03-07T06:47:08.299Z",
                "updatedAt": "2022-10-19T09:11:12.613Z",
                "__v": 0,
                "images": "public/category/1666170672612.1301.webp",
                "specification": null
            },
            {
                "parent": "6225aa6c5507127df692d326",
                "status": true,
                "_id": "6225aa0b5507127df692d314",
                "category_name": "Surukku Bags",
                "createdAt": "2022-03-07T06:45:31.847Z",
                "updatedAt": "2022-10-19T09:11:03.348Z",
                "__v": 0,
                "images": "public/category/1666170663347.396.webp",
                "specification": "6226f5ec5507127df692d460"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Great Give aways at weddings and any ceremonies tucked with sweets"
        ],
        "key_words": [
            "Potli bags"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b544472a62aa5591e493ca",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P0075",
        "model": "PB1",
        "specification": [
            {
                "_id": "62b6aed82a62aa5591e4b018",
                "title": "Material",
                "value": "Cotton and Silk mix with  Orissa Print ",
                "suffix": ""
            },
            {
                "_id": "62b6aed82a62aa5591e4b019",
                "title": "Colour",
                "value": "Red",
                "suffix": ""
            },
            {
                "_id": "62b6aed82a62aa5591e4b01a",
                "title": "Size",
                "value": "8.5 X 8.5  (In Inches)",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-24T04:57:43.226Z",
        "updatedAt": "2022-06-25T06:44:55.627Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Printed Surukku Bag With elephant Design ",
        "display_date": null,
        "hsn_code": "6305",
        "min_order_qty": 1,
        "mrp": 450,
        "sp": 390,
        "stock": 0,
        "tax": {
            "status": true,
            "_id": "61f7dde28d37e6262ba17c80",
            "tax_name": "GST_18",
            "tax_percentage": 18,
            "__v": 0
        },
        "meta_desc": "Surukku bags, Potli bags",
        "meta_key": "Potli bags",
        "note": "Potli bags for take aways at any occassion.<div>Beaded with Handles.&#160;</div>",
        "images": [
            "public/product/1656046948062.482.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.1,
            "length": 31,
            "breadth": 31,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6225aa6c5507127df692d326",
                "category_name": "Wedding hand bags",
                "createdAt": "2022-03-07T06:47:08.299Z",
                "updatedAt": "2022-10-19T09:11:12.613Z",
                "__v": 0,
                "images": "public/category/1666170672612.1301.webp",
                "specification": null
            },
            {
                "parent": "6225aa6c5507127df692d326",
                "status": true,
                "_id": "6225aa0b5507127df692d314",
                "category_name": "Surukku Bags",
                "createdAt": "2022-03-07T06:45:31.847Z",
                "updatedAt": "2022-10-19T09:11:03.348Z",
                "__v": 0,
                "images": "public/category/1666170663347.396.webp",
                "specification": "6226f5ec5507127df692d460"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Great Give aways at weddings and any ceremonies tucked with sweets"
        ],
        "key_words": [
            "Potli bags"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b546132a62aa5591e49461",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P0076",
        "model": "PB1",
        "specification": [
            {
                "_id": "62b6af242a62aa5591e4b06c",
                "title": "Material",
                "value": "Silk With Zari",
                "suffix": ""
            },
            {
                "_id": "62b6af242a62aa5591e4b06d",
                "title": "Colour",
                "value": "Golden ",
                "suffix": ""
            },
            {
                "_id": "62b6af242a62aa5591e4b06e",
                "title": "Size",
                "value": "6.5 X 9 (In Inches )",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-24T05:05:23.772Z",
        "updatedAt": "2022-06-25T06:46:16.657Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Golden Colour Surukku Bag With Pearls ",
        "display_date": null,
        "hsn_code": "6305",
        "min_order_qty": 1,
        "mrp": 650,
        "sp": 590,
        "stock": 0,
        "tax": {
            "status": true,
            "_id": "61f7dde28d37e6262ba17c80",
            "tax_name": "GST_18",
            "tax_percentage": 18,
            "__v": 0
        },
        "meta_desc": "Surukku bags ,Potli bags",
        "meta_key": "Potli bags",
        "note": "Potli bags for take aways at any occassion.<div>Beaded with embroidery.</div>",
        "images": [
            "public/product/1656047253419.1384.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.07,
            "length": 31,
            "breadth": 31,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6225aa6c5507127df692d326",
                "category_name": "Wedding hand bags",
                "createdAt": "2022-03-07T06:47:08.299Z",
                "updatedAt": "2022-10-19T09:11:12.613Z",
                "__v": 0,
                "images": "public/category/1666170672612.1301.webp",
                "specification": null
            },
            {
                "parent": "6225aa6c5507127df692d326",
                "status": true,
                "_id": "6225aa0b5507127df692d314",
                "category_name": "Surukku Bags",
                "createdAt": "2022-03-07T06:45:31.847Z",
                "updatedAt": "2022-10-19T09:11:03.348Z",
                "__v": 0,
                "images": "public/category/1666170663347.396.webp",
                "specification": "6226f5ec5507127df692d460"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Great Give aways at weddings and any ceremonies tucked with sweets"
        ],
        "key_words": [
            "Potli bags"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b546ea2a62aa5591e494a8",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P0077",
        "model": "PB1",
        "specification": [
            {
                "_id": "62b6afb72a62aa5591e4b0c3",
                "title": "Material",
                "value": "Silk With mirror",
                "suffix": ""
            },
            {
                "_id": "62b6afb72a62aa5591e4b0c4",
                "title": "Colour",
                "value": "Blue",
                "suffix": ""
            },
            {
                "_id": "62b6afb72a62aa5591e4b0c5",
                "title": "Size",
                "value": "8 X 8.5  (In Inches)",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-24T05:08:58.282Z",
        "updatedAt": "2022-06-25T06:49:26.872Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Blue Colour Surukku Bag with Mirror",
        "display_date": null,
        "hsn_code": "6305",
        "min_order_qty": 1,
        "mrp": 450,
        "sp": 390,
        "stock": 0,
        "tax": {
            "status": true,
            "_id": "61f7dde28d37e6262ba17c80",
            "tax_name": "GST_18",
            "tax_percentage": 18,
            "__v": 0
        },
        "meta_desc": "Surukku bags ,Potli bags",
        "meta_key": "Potli bags",
        "note": "Potli bags for take aways at any occassion.<div>Mirror Work embroidery.</div><div>Beaded Handles&#160;</div>",
        "images": [
            "public/product/1656047538178.9429.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.06,
            "length": 31,
            "breadth": 31,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6225aa6c5507127df692d326",
                "category_name": "Wedding hand bags",
                "createdAt": "2022-03-07T06:47:08.299Z",
                "updatedAt": "2022-10-19T09:11:12.613Z",
                "__v": 0,
                "images": "public/category/1666170672612.1301.webp",
                "specification": null
            },
            {
                "parent": "6225aa6c5507127df692d326",
                "status": true,
                "_id": "6225aa0b5507127df692d314",
                "category_name": "Surukku Bags",
                "createdAt": "2022-03-07T06:45:31.847Z",
                "updatedAt": "2022-10-19T09:11:03.348Z",
                "__v": 0,
                "images": "public/category/1666170663347.396.webp",
                "specification": "6226f5ec5507127df692d460"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Great Give aways at weddings and any ceremonies tucked with sweets"
        ],
        "key_words": [
            "Potli bags"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b548272a62aa5591e494f9",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P0078",
        "model": "PB1",
        "specification": [
            {
                "_id": "62b6b0782a62aa5591e4b114",
                "title": "Material",
                "value": "Synthetic With zari",
                "suffix": ""
            },
            {
                "_id": "62b6b0782a62aa5591e4b115",
                "title": "Colour",
                "value": "Pink ",
                "suffix": ""
            },
            {
                "_id": "62b6b0782a62aa5591e4b116",
                "title": "Size",
                "value": "7.5 X 9 (In Inches)",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-24T05:14:15.747Z",
        "updatedAt": "2022-06-25T06:52:13.230Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Pink and Gold Surukku Bag with Ikkat Design ",
        "display_date": null,
        "hsn_code": "6305",
        "min_order_qty": 1,
        "mrp": 300,
        "sp": 200,
        "stock": 0,
        "tax": {
            "status": true,
            "_id": "61f7dde28d37e6262ba17c80",
            "tax_name": "GST_18",
            "tax_percentage": 18,
            "__v": 0
        },
        "meta_desc": "Surukku bags ,Potli bags",
        "meta_key": "Potli bags",
        "note": "Potli bags for take aways at any occassion.<div>.</div>",
        "images": [
            "public/product/1656047944277.3735.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.06,
            "length": 31,
            "breadth": 31,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6225aa6c5507127df692d326",
                "category_name": "Wedding hand bags",
                "createdAt": "2022-03-07T06:47:08.299Z",
                "updatedAt": "2022-10-19T09:11:12.613Z",
                "__v": 0,
                "images": "public/category/1666170672612.1301.webp",
                "specification": null
            },
            {
                "parent": "6225aa6c5507127df692d326",
                "status": true,
                "_id": "6225aa0b5507127df692d314",
                "category_name": "Surukku Bags",
                "createdAt": "2022-03-07T06:45:31.847Z",
                "updatedAt": "2022-10-19T09:11:03.348Z",
                "__v": 0,
                "images": "public/category/1666170663347.396.webp",
                "specification": "6226f5ec5507127df692d460"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Great Give aways at weddings and any ceremonies tucked with sweets",
            "Provided with Plastic Inner linning"
        ],
        "key_words": [
            "Potli bags"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b549e72a62aa5591e49540",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P0079",
        "model": "PB1",
        "specification": [
            {
                "_id": "62b6b1592a62aa5591e4b1c8",
                "title": "Material",
                "value": "Cotton",
                "suffix": ""
            },
            {
                "_id": "62b6b1592a62aa5591e4b1c9",
                "title": "Colour",
                "value": "Orange",
                "suffix": ""
            },
            {
                "_id": "62b6b1592a62aa5591e4b1ca",
                "title": "Size",
                "value": "8.5 X 8.5 (In Inches)",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-24T05:21:43.822Z",
        "updatedAt": "2022-06-25T06:56:56.668Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Lucknowi Surukku bag with Beads",
        "display_date": null,
        "hsn_code": "6305",
        "min_order_qty": 1,
        "mrp": 450,
        "sp": 350,
        "stock": 0,
        "tax": {
            "status": true,
            "_id": "61f7dde28d37e6262ba17c80",
            "tax_name": "GST_18",
            "tax_percentage": 18,
            "__v": 0
        },
        "meta_desc": "Surukku bags ,Potli bags",
        "meta_key": "Potli bags",
        "note": "Potli bags for take aways at any occassion.<div><br></div>",
        "images": [
            "public/product/1656048383434.9043.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.06,
            "length": 31,
            "breadth": 31,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6225aa6c5507127df692d326",
                "category_name": "Wedding hand bags",
                "createdAt": "2022-03-07T06:47:08.299Z",
                "updatedAt": "2022-10-19T09:11:12.613Z",
                "__v": 0,
                "images": "public/category/1666170672612.1301.webp",
                "specification": null
            },
            {
                "parent": "6225aa6c5507127df692d326",
                "status": true,
                "_id": "6225aa0b5507127df692d314",
                "category_name": "Surukku Bags",
                "createdAt": "2022-03-07T06:45:31.847Z",
                "updatedAt": "2022-10-19T09:11:03.348Z",
                "__v": 0,
                "images": "public/category/1666170663347.396.webp",
                "specification": "6226f5ec5507127df692d460"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Great Give aways at weddings and any ceremonies tucked with sweets"
        ],
        "key_words": [
            "Potli bags"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b54b4c2a62aa5591e4958a",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P080",
        "model": "PB1",
        "specification": [
            {
                "_id": "62b6b2572a62aa5591e4b298",
                "title": "Material",
                "value": "Cotton ",
                "suffix": ""
            },
            {
                "_id": "62b6b2572a62aa5591e4b299",
                "title": "Colour",
                "value": "Green ",
                "suffix": ""
            },
            {
                "_id": "62b6b2572a62aa5591e4b29a",
                "title": "Size",
                "value": "8.5 X 8.5  (In Inches)",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-24T05:27:40.806Z",
        "updatedAt": "2022-06-25T07:00:02.874Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Lucknowi Surukku Bag with Beads",
        "display_date": null,
        "hsn_code": "6305",
        "min_order_qty": 1,
        "mrp": 450,
        "sp": 350,
        "stock": 0,
        "tax": {
            "status": true,
            "_id": "61f7dde28d37e6262ba17c80",
            "tax_name": "GST_18",
            "tax_percentage": 18,
            "__v": 0
        },
        "meta_desc": "Surukku bags ,Potli bags",
        "meta_key": "Potli bags",
        "note": "Potli bags for take aways at any occassion.<div><br></div>",
        "images": [
            "public/product/1656048574977.1108.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.1,
            "length": 31,
            "breadth": 31,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6225aa6c5507127df692d326",
                "category_name": "Wedding hand bags",
                "createdAt": "2022-03-07T06:47:08.299Z",
                "updatedAt": "2022-10-19T09:11:12.613Z",
                "__v": 0,
                "images": "public/category/1666170672612.1301.webp",
                "specification": null
            },
            {
                "parent": "6225aa6c5507127df692d326",
                "status": true,
                "_id": "6225aa0b5507127df692d314",
                "category_name": "Surukku Bags",
                "createdAt": "2022-03-07T06:45:31.847Z",
                "updatedAt": "2022-10-19T09:11:03.348Z",
                "__v": 0,
                "images": "public/category/1666170663347.396.webp",
                "specification": "6226f5ec5507127df692d460"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Great Give aways at weddings and any ceremonies tucked with sweets"
        ],
        "key_words": [
            "Potli bags"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b54dde2a62aa5591e495fa",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P081",
        "model": "PB1",
        "specification": [
            {
                "_id": "62b6b3f62a62aa5591e4b308",
                "title": "Material",
                "value": "Silk with Zari",
                "suffix": ""
            },
            {
                "_id": "62b6b3f62a62aa5591e4b309",
                "title": "Colour",
                "value": "Peach",
                "suffix": ""
            },
            {
                "_id": "62b6b3f62a62aa5591e4b30a",
                "title": "Size",
                "value": "8 X 8.5 (In Inches)",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-24T05:38:38.305Z",
        "updatedAt": "2022-06-25T07:09:44.106Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Peach Colour Surukku Bag with pearls",
        "display_date": null,
        "hsn_code": "6305",
        "min_order_qty": 1,
        "mrp": 450,
        "sp": 390,
        "stock": 0,
        "tax": {
            "status": true,
            "_id": "61f7dde28d37e6262ba17c80",
            "tax_name": "GST_18",
            "tax_percentage": 18,
            "__v": 0
        },
        "meta_desc": "Surukku bags ,Potli bags",
        "meta_key": "Potli bags",
        "note": "Potli bags for take aways at any occassion.<div>Sequence embroidery.</div>",
        "images": [
            "public/product/1656049359471.7236.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.05,
            "length": 31,
            "breadth": 31,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6225aa6c5507127df692d326",
                "category_name": "Wedding hand bags",
                "createdAt": "2022-03-07T06:47:08.299Z",
                "updatedAt": "2022-10-19T09:11:12.613Z",
                "__v": 0,
                "images": "public/category/1666170672612.1301.webp",
                "specification": null
            },
            {
                "parent": "6225aa6c5507127df692d326",
                "status": true,
                "_id": "6225aa0b5507127df692d314",
                "category_name": "Surukku Bags",
                "createdAt": "2022-03-07T06:45:31.847Z",
                "updatedAt": "2022-10-19T09:11:03.348Z",
                "__v": 0,
                "images": "public/category/1666170663347.396.webp",
                "specification": "6226f5ec5507127df692d460"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Great Give aways at weddings and any ceremonies tucked with sweets",
            "Fashionable Thamboolam bags"
        ],
        "key_words": [
            "Potli bags"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b554772a62aa5591e4965b",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P082",
        "model": "PB1",
        "specification": [
            {
                "_id": "62b6b5212a62aa5591e4b371",
                "title": "Material",
                "value": "Synthetic Zari",
                "suffix": ""
            },
            {
                "_id": "62b6b5212a62aa5591e4b372",
                "title": "Colour",
                "value": "Pink",
                "suffix": ""
            },
            {
                "_id": "62b6b5212a62aa5591e4b373",
                "title": "Size",
                "value": "8.5 X 9.5  (In Inches)",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-24T06:06:47.662Z",
        "updatedAt": "2022-06-25T07:14:10.561Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Zari Surukku Bag  ",
        "display_date": null,
        "hsn_code": "6305",
        "min_order_qty": 1,
        "mrp": 450,
        "sp": 390,
        "stock": 0,
        "tax": {
            "status": true,
            "_id": "61f7dde28d37e6262ba17c80",
            "tax_name": "GST_18",
            "tax_percentage": 18,
            "__v": 0
        },
        "meta_desc": "Surukku bags ,Potli bags",
        "meta_key": "Potli bags",
        "note": "Potli bags for take aways at any occassion.<div><br></div>",
        "images": [
            "public/product/1656052871537.8457.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.25,
            "length": 31,
            "breadth": 31,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6225aa6c5507127df692d326",
                "category_name": "Wedding hand bags",
                "createdAt": "2022-03-07T06:47:08.299Z",
                "updatedAt": "2022-10-19T09:11:12.613Z",
                "__v": 0,
                "images": "public/category/1666170672612.1301.webp",
                "specification": null
            },
            {
                "parent": "6225aa6c5507127df692d326",
                "status": true,
                "_id": "62345cbc462a810f78226389",
                "category_name": "Clutch Hand Bags",
                "specification": "6227066b5507127df692d69c",
                "createdAt": "2022-03-18T10:19:40.691Z",
                "updatedAt": "2022-03-19T10:21:06.145Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Carry your personals at weddings and parties."
        ],
        "key_words": [
            "Bags "
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b561862a62aa5591e49727",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P083",
        "model": "PB1",
        "specification": [
            {
                "_id": "62b6b6382a62aa5591e4b3eb",
                "title": "Material",
                "value": "Silk With Ikkat",
                "suffix": ""
            },
            {
                "_id": "62b6b6382a62aa5591e4b3ec",
                "title": "Colour",
                "value": "Pink",
                "suffix": ""
            },
            {
                "_id": "62b6b6382a62aa5591e4b3ed",
                "title": "Size",
                "value": "8 X 3 X 7  (In Inches)",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-24T07:02:30.479Z",
        "updatedAt": "2022-06-25T07:17:26.057Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Ikkat Hand bags",
        "display_date": null,
        "hsn_code": "6305",
        "min_order_qty": 1,
        "mrp": 1200,
        "sp": 990,
        "stock": 0,
        "tax": {
            "status": true,
            "_id": "61f7dde28d37e6262ba17c80",
            "tax_name": "GST_18",
            "tax_percentage": 18,
            "__v": 0
        },
        "meta_desc": "Hand bags  ,Bags ",
        "meta_key": "Bags ",
        "note": "Fancy handbags",
        "images": [
            "public/product/1656054383497.311.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.1,
            "length": 23,
            "breadth": 15,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6225aa6c5507127df692d326",
                "category_name": "Wedding hand bags",
                "createdAt": "2022-03-07T06:47:08.299Z",
                "updatedAt": "2022-10-19T09:11:12.613Z",
                "__v": 0,
                "images": "public/category/1666170672612.1301.webp",
                "specification": null
            },
            {
                "parent": "6225aa6c5507127df692d326",
                "status": true,
                "_id": "62345cbc462a810f78226389",
                "category_name": "Clutch Hand Bags",
                "specification": "6227066b5507127df692d69c",
                "createdAt": "2022-03-18T10:19:40.691Z",
                "updatedAt": "2022-03-19T10:21:06.145Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "For weddings and parties",
            "Matches all outfits traditional or western"
        ],
        "key_words": [
            "Fancy clutch "
        ],
        "status": true,
        "featured": false,
        "publish": false,
        "_id": "62b564a52a62aa5591e49823",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P084",
        "model": "PB",
        "specification": [
            {
                "_id": "62b6b72b2a62aa5591e4b469",
                "title": "Material",
                "value": "Silk Printed",
                "suffix": ""
            },
            {
                "_id": "62b6b72b2a62aa5591e4b46a",
                "title": "Colour",
                "value": "Multi Colour",
                "suffix": ""
            },
            {
                "_id": "62b6b72b2a62aa5591e4b46b",
                "title": "Size",
                "value": "8 X  4 (In Inches)",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-24T07:15:49.966Z",
        "updatedAt": "2022-06-25T07:22:34.668Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Fancy Clutch With Sling ",
        "display_date": null,
        "hsn_code": "6305",
        "min_order_qty": 1,
        "mrp": 750,
        "sp": 675,
        "stock": 0,
        "tax": {
            "status": true,
            "_id": "61f7dde28d37e6262ba17c80",
            "tax_name": "GST_18",
            "tax_percentage": 18,
            "__v": 0
        },
        "meta_desc": "Clutch Bag ,Fancy clutch ",
        "meta_key": "Fancy clutch ",
        "note": "Can be used as sling or clutch&#160;",
        "images": [
            "public/product/1656055251460.3054.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.1,
            "length": 23,
            "breadth": 15,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6225aa6c5507127df692d326",
                "category_name": "Wedding hand bags",
                "createdAt": "2022-03-07T06:47:08.299Z",
                "updatedAt": "2022-10-19T09:11:12.613Z",
                "__v": 0,
                "images": "public/category/1666170672612.1301.webp",
                "specification": null
            },
            {
                "parent": "6225aa6c5507127df692d326",
                "status": true,
                "_id": "62345cbc462a810f78226389",
                "category_name": "Clutch Hand Bags",
                "specification": "6227066b5507127df692d69c",
                "createdAt": "2022-03-18T10:19:40.691Z",
                "updatedAt": "2022-03-19T10:21:06.145Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [
            "For weddings and parties",
            "Matches all outfits traditional or western"
        ],
        "key_words": [
            "Fancy clutch "
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b566a52a62aa5591e498bf",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P085",
        "model": "PB1",
        "specification": [
            {
                "_id": "62b6b71f2a62aa5591e4b459",
                "title": "Material",
                "value": "Silk Printed",
                "suffix": ""
            },
            {
                "_id": "62b6b71f2a62aa5591e4b45a",
                "title": "Colour",
                "value": "Green",
                "suffix": ""
            },
            {
                "_id": "62b6b71f2a62aa5591e4b45b",
                "title": "Size",
                "value": "8 X  4 (In Inches)",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-24T07:24:21.855Z",
        "updatedAt": "2022-06-25T07:22:14.108Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Fancy Clutch With Sling ",
        "display_date": null,
        "hsn_code": "6305",
        "min_order_qty": 1,
        "mrp": 750,
        "sp": 675,
        "stock": 0,
        "tax": {
            "status": true,
            "_id": "61f7dde28d37e6262ba17c80",
            "tax_name": "GST_18",
            "tax_percentage": 18,
            "__v": 0
        },
        "meta_desc": "Clutch Bag ,Fancy clutch ",
        "meta_key": "Fancy clutch ",
        "note": "Can be used as sling or clutch&#160;",
        "images": [
            "public/product/1656055692783.5984.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.08,
            "length": 31,
            "breadth": 31,
            "height": 3
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6225aa7f5507127df692d32f",
                "category_name": " Mobile or Cell phone Pouches ",
                "createdAt": "2022-03-07T06:47:27.047Z",
                "updatedAt": "2022-10-19T09:11:23.410Z",
                "__v": 0,
                "images": "public/category/1666170683409.058.webp",
                "specification": null
            },
            {
                "parent": "6225aa7f5507127df692d32f",
                "status": true,
                "_id": "62345e60462a810f782264ea",
                "category_name": "Saree Mobile phone pouches",
                "createdAt": "2022-03-18T10:26:40.949Z",
                "updatedAt": "2022-03-18T10:31:06.762Z",
                "__v": 0,
                "images": null,
                "specification": "62345ef7462a810f78226517"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Ethnic to wear on your saree hip to be hands free"
        ],
        "key_words": [
            "mobile phone pouch"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b56aa72a62aa5591e49969",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P086",
        "model": "PB1",
        "specification": [
            {
                "_id": "62b6b8662a62aa5591e4b523",
                "title": "Material",
                "value": "Silk",
                "suffix": ""
            },
            {
                "_id": "62b6b8662a62aa5591e4b524",
                "title": "Colour",
                "value": "Black",
                "suffix": ""
            },
            {
                "_id": "62b6b8662a62aa5591e4b525",
                "title": "Size",
                "value": "7.5 X 3.5 (In Inches)",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-24T07:41:27.820Z",
        "updatedAt": "2022-06-25T07:29:02.485Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Ladies mobile pouch with saree Hook",
        "display_date": null,
        "hsn_code": "6305",
        "min_order_qty": 1,
        "mrp": 650,
        "sp": 585,
        "stock": 0,
        "tax": {
            "status": true,
            "_id": "61f7dde28d37e6262ba17c80",
            "tax_name": "GST_18",
            "tax_percentage": 18,
            "__v": 0
        },
        "meta_desc": "Saree phone holder ,mobile phone pouch",
        "meta_key": "mobile phone pouch",
        "note": "Saree hook provided to hold yor mobile safely<div><span>Sequence Embrodiery</span></div>",
        "images": [
            "public/product/1656063756253.7295.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.08,
            "length": 31,
            "breadth": 31,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6225aa7f5507127df692d32f",
                "category_name": " Mobile or Cell phone Pouches ",
                "createdAt": "2022-03-07T06:47:27.047Z",
                "updatedAt": "2022-10-19T09:11:23.410Z",
                "__v": 0,
                "images": "public/category/1666170683409.058.webp",
                "specification": null
            },
            {
                "parent": "6225aa7f5507127df692d32f",
                "status": true,
                "_id": "62345e60462a810f782264ea",
                "category_name": "Saree Mobile phone pouches",
                "createdAt": "2022-03-18T10:26:40.949Z",
                "updatedAt": "2022-03-18T10:31:06.762Z",
                "__v": 0,
                "images": null,
                "specification": "62345ef7462a810f78226517"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Ethnic to wear on your saree hip to be hands free"
        ],
        "key_words": [
            "Mobile phone pouch"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b57e792a62aa5591e49bd3",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P087",
        "model": "PB",
        "specification": [
            {
                "_id": "62b6ba3a2a62aa5591e4b659",
                "title": "Material",
                "value": "Synthetic",
                "suffix": ""
            },
            {
                "_id": "62b6ba3a2a62aa5591e4b65a",
                "title": "Colour",
                "value": "Black",
                "suffix": ""
            },
            {
                "_id": "62b6ba3a2a62aa5591e4b65b",
                "title": "Size",
                "value": "7.5 X 3.5 (In Inches)",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-24T09:06:01.423Z",
        "updatedAt": "2022-06-25T07:39:36.221Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Sequence Work Saree mobile  Pouch ",
        "display_date": null,
        "hsn_code": "6305",
        "min_order_qty": 1,
        "mrp": 800,
        "sp": 750,
        "stock": 0,
        "tax": {
            "status": true,
            "_id": "61f7dde28d37e6262ba17c80",
            "tax_name": "GST_18",
            "tax_percentage": 18,
            "__v": 0
        },
        "meta_desc": "Saree phone pouch , Mobile phone pouch",
        "meta_key": "Mobile phone pouch",
        "note": "Saree hook provided to hold yor mobile safely<div><span>Sequence Embrodiery</span></div>",
        "images": [
            "public/product/1656063905058.5393.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.08,
            "length": 31,
            "breadth": 31,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6225aa7f5507127df692d32f",
                "category_name": " Mobile or Cell phone Pouches ",
                "createdAt": "2022-03-07T06:47:27.047Z",
                "updatedAt": "2022-10-19T09:11:23.410Z",
                "__v": 0,
                "images": "public/category/1666170683409.058.webp",
                "specification": null
            },
            {
                "parent": "6225aa7f5507127df692d32f",
                "status": true,
                "_id": "62345e60462a810f782264ea",
                "category_name": "Saree Mobile phone pouches",
                "createdAt": "2022-03-18T10:26:40.949Z",
                "updatedAt": "2022-03-18T10:31:06.762Z",
                "__v": 0,
                "images": null,
                "specification": "62345ef7462a810f78226517"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Ethnic to wear on your saree hip to be hands free"
        ],
        "key_words": [
            "mobile phone pouch"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b580562a62aa5591e49c16",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P088",
        "model": "PB1",
        "specification": [
            {
                "_id": "62b6bb992a62aa5591e4b68a",
                "title": "Material",
                "value": "Synthetic",
                "suffix": ""
            },
            {
                "_id": "62b6bb992a62aa5591e4b68b",
                "title": "Colour",
                "value": "Red",
                "suffix": ""
            },
            {
                "_id": "62b6bb992a62aa5591e4b68c",
                "title": "Size",
                "value": "7.5 X 3.5  (In Inches)",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-24T09:13:58.129Z",
        "updatedAt": "2022-06-25T07:39:19.912Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Sequence Work Saree mobile  Pouch ",
        "display_date": null,
        "hsn_code": "6305",
        "min_order_qty": 1,
        "mrp": 800,
        "sp": 750,
        "stock": 0,
        "tax": {
            "status": true,
            "_id": "61f7dde28d37e6262ba17c80",
            "tax_name": "GST_18",
            "tax_percentage": 18,
            "__v": 0
        },
        "meta_desc": "Saree phone pouch ,mobile phone pouch",
        "meta_key": "Mobile phone pouch",
        "note": "Saree hook provided to hold yor mobile safely<div><span>Sequence Embrodiery</span></div>",
        "images": [
            "public/product/1656063823459.0803.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.08,
            "length": 31,
            "breadth": 31,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6225aa7f5507127df692d32f",
                "category_name": " Mobile or Cell phone Pouches ",
                "createdAt": "2022-03-07T06:47:27.047Z",
                "updatedAt": "2022-10-19T09:11:23.410Z",
                "__v": 0,
                "images": "public/category/1666170683409.058.webp",
                "specification": null
            },
            {
                "parent": "6225aa7f5507127df692d32f",
                "status": true,
                "_id": "62345e60462a810f782264ea",
                "category_name": "Saree Mobile phone pouches",
                "createdAt": "2022-03-18T10:26:40.949Z",
                "updatedAt": "2022-03-18T10:31:06.762Z",
                "__v": 0,
                "images": null,
                "specification": "62345ef7462a810f78226517"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "For regular use.",
            "Hang it on your hip to carry your mobile and be hands free."
        ],
        "key_words": [
            "Mobile phone pouch"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b581082a62aa5591e49c5a",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P089",
        "model": "PB1",
        "specification": [
            {
                "_id": "62b6bc5f2a62aa5591e4b709",
                "title": "Material",
                "value": "Synthetic",
                "suffix": ""
            },
            {
                "_id": "62b6bc5f2a62aa5591e4b70a",
                "title": "Colour",
                "value": "Blue",
                "suffix": ""
            },
            {
                "_id": "62b6bc5f2a62aa5591e4b70b",
                "title": "Size",
                "value": "7.5 X 4  (In Inches)",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-24T09:16:56.443Z",
        "updatedAt": "2022-06-25T07:46:51.730Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Blue printed with  Saree Mobile Pouch ",
        "display_date": null,
        "hsn_code": "6305",
        "min_order_qty": 1,
        "mrp": 650,
        "sp": 525,
        "stock": 0,
        "tax": {
            "status": true,
            "_id": "61f7dde28d37e6262ba17c80",
            "tax_name": "GST_18",
            "tax_percentage": 18,
            "__v": 0
        },
        "meta_desc": "Saree phone pouch ,Mobile phone pouch",
        "meta_key": "Mobile phone pouch",
        "note": "Digital Print Fabric and Light Weight.<div><br></div>",
        "images": [
            "public/product/1656064126862.923.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.08,
            "length": 31,
            "breadth": 31,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6225aa7f5507127df692d32f",
                "category_name": " Mobile or Cell phone Pouches ",
                "createdAt": "2022-03-07T06:47:27.047Z",
                "updatedAt": "2022-10-19T09:11:23.410Z",
                "__v": 0,
                "images": "public/category/1666170683409.058.webp",
                "specification": null
            },
            {
                "parent": "6225aa7f5507127df692d32f",
                "status": true,
                "_id": "62345e60462a810f782264ea",
                "category_name": "Saree Mobile phone pouches",
                "createdAt": "2022-03-18T10:26:40.949Z",
                "updatedAt": "2022-03-18T10:31:06.762Z",
                "__v": 0,
                "images": null,
                "specification": "62345ef7462a810f78226517"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "For regular use.",
            "Hang it on your hip to carry your mobile and be hands free."
        ],
        "key_words": [
            "mobile phone pouch"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b589802a62aa5591e49d4c",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P090",
        "model": "PB1",
        "specification": [
            {
                "_id": "62b6bc512a62aa5591e4b6e9",
                "title": "Material",
                "value": "Synthetic ",
                "suffix": ""
            },
            {
                "_id": "62b6bc512a62aa5591e4b6ea",
                "title": "Colour",
                "value": "green ",
                "suffix": ""
            },
            {
                "_id": "62b6bc512a62aa5591e4b6eb",
                "title": "Size",
                "value": "7.5 X 4  (In Inches)",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-24T09:53:04.262Z",
        "updatedAt": "2022-06-25T07:46:43.340Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Mango Printed  Saree Mobile Pouch ",
        "display_date": null,
        "hsn_code": "6305",
        "min_order_qty": 1,
        "mrp": 650,
        "sp": 525,
        "stock": 0,
        "tax": {
            "status": true,
            "_id": "61f7dde28d37e6262ba17c80",
            "tax_name": "GST_18",
            "tax_percentage": 18,
            "__v": 0
        },
        "meta_desc": "Saree phone holder ,mobile phone pouch",
        "meta_key": "mobile phone pouch",
        "note": "Digital Print Fabric and Light Weight.<div><br></div>",
        "images": [
            "public/product/1656064593398.0813.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.08,
            "length": 31,
            "breadth": 31,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6225aa7f5507127df692d32f",
                "category_name": " Mobile or Cell phone Pouches ",
                "createdAt": "2022-03-07T06:47:27.047Z",
                "updatedAt": "2022-10-19T09:11:23.410Z",
                "__v": 0,
                "images": "public/category/1666170683409.058.webp",
                "specification": null
            },
            {
                "parent": "6225aa7f5507127df692d32f",
                "status": true,
                "_id": "62345e60462a810f782264ea",
                "category_name": "Saree Mobile phone pouches",
                "createdAt": "2022-03-18T10:26:40.949Z",
                "updatedAt": "2022-03-18T10:31:06.762Z",
                "__v": 0,
                "images": null,
                "specification": "62345ef7462a810f78226517"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "For regular use.",
            "Hang it on your hip to carry your mobile and be hands free."
        ],
        "key_words": [
            "mobile phone pouch"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b58ac82a62aa5591e49d9a",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P091",
        "model": "PB1",
        "specification": [
            {
                "_id": "62b6bc582a62aa5591e4b6f9",
                "title": "Material",
                "value": "Synthetic",
                "suffix": ""
            },
            {
                "_id": "62b6bc582a62aa5591e4b6fa",
                "title": "Colour",
                "value": "Multicolour",
                "suffix": ""
            },
            {
                "_id": "62b6bc582a62aa5591e4b6fb",
                "title": "Size",
                "value": "7.5 X 4  (In Inches)",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-24T09:58:32.753Z",
        "updatedAt": "2022-06-25T07:46:47.874Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Floral Printed Saree Mobile Pouch ",
        "display_date": null,
        "hsn_code": "6305",
        "min_order_qty": 1,
        "mrp": 650,
        "sp": 525,
        "stock": 0,
        "tax": {
            "status": true,
            "_id": "61f7dde28d37e6262ba17c80",
            "tax_name": "GST_18",
            "tax_percentage": 18,
            "__v": 0
        },
        "meta_desc": "Saree phone holder ,mobile phone pouch\n",
        "meta_key": "mobile phone pouch",
        "note": "Digital Print Fabric and Light Weight.<div><br></div>",
        "images": [
            "public/product/1656066078497.6392.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.1,
            "length": 31,
            "breadth": 31,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6225aa7f5507127df692d32f",
                "category_name": " Mobile or Cell phone Pouches ",
                "createdAt": "2022-03-07T06:47:27.047Z",
                "updatedAt": "2022-10-19T09:11:23.410Z",
                "__v": 0,
                "images": "public/category/1666170683409.058.webp",
                "specification": null
            },
            {
                "parent": "6225aa7f5507127df692d32f",
                "status": true,
                "_id": "62345e60462a810f782264ea",
                "category_name": "Saree Mobile phone pouches",
                "createdAt": "2022-03-18T10:26:40.949Z",
                "updatedAt": "2022-03-18T10:31:06.762Z",
                "__v": 0,
                "images": null,
                "specification": "62345ef7462a810f78226517"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Ethnic to wear on your saree hip to be hands free",
            "For Party Wear"
        ],
        "key_words": [
            ""
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b58c3b2a62aa5591e49dcd",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P092",
        "model": "PB1",
        "specification": [
            {
                "_id": "62b6bdd82a62aa5591e4b809",
                "title": "Material",
                "value": "Rexin",
                "suffix": ""
            },
            {
                "_id": "62b6bdd82a62aa5591e4b80a",
                "title": "Colour",
                "value": "Gold ",
                "suffix": ""
            },
            {
                "_id": "62b6bdd82a62aa5591e4b80b",
                "title": "Size",
                "value": "7 X 3.5  (In Inches)",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-24T10:04:43.369Z",
        "updatedAt": "2022-06-25T07:49:24.177Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Gold Rexin Saree Mobile poch with Petal Desing",
        "display_date": null,
        "hsn_code": "6305",
        "min_order_qty": 1,
        "mrp": 800,
        "sp": 750,
        "stock": 0,
        "tax": {
            "status": true,
            "_id": "61f7dde28d37e6262ba17c80",
            "tax_name": "GST_18",
            "tax_percentage": 18,
            "__v": 0
        },
        "meta_desc": "Saree phone holder",
        "meta_key": "mobile phone pouch",
        "note": "Saree hook provided to hold yor mobile safely",
        "images": [
            "public/product/1656066184625.658.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.1,
            "length": 31,
            "breadth": 31,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6225aa7f5507127df692d32f",
                "category_name": " Mobile or Cell phone Pouches ",
                "createdAt": "2022-03-07T06:47:27.047Z",
                "updatedAt": "2022-10-19T09:11:23.410Z",
                "__v": 0,
                "images": "public/category/1666170683409.058.webp",
                "specification": null
            },
            {
                "parent": "6225aa7f5507127df692d32f",
                "status": true,
                "_id": "62345e60462a810f782264ea",
                "category_name": "Saree Mobile phone pouches",
                "createdAt": "2022-03-18T10:26:40.949Z",
                "updatedAt": "2022-03-18T10:31:06.762Z",
                "__v": 0,
                "images": null,
                "specification": "62345ef7462a810f78226517"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Ethnic to wear on your saree hip to be hands free",
            "For Party Wear"
        ],
        "key_words": [
            "mobile phone pouch"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b58ce82a62aa5591e49e0c",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P093",
        "model": "PB1",
        "specification": [
            {
                "_id": "62b6bdd02a62aa5591e4b7f6",
                "title": "Material",
                "value": "Rexin",
                "suffix": ""
            },
            {
                "_id": "62b6bdd02a62aa5591e4b7f7",
                "title": "Colour",
                "value": "Golden",
                "suffix": ""
            },
            {
                "_id": "62b6bdd02a62aa5591e4b7f8",
                "title": "Size",
                "value": "7 X 3.5  (In Inches)",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-24T10:07:36.588Z",
        "updatedAt": "2022-06-27T10:26:30.197Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Gold Rexin Saree Mobil Pouch With Temple design ",
        "display_date": null,
        "hsn_code": "6305",
        "min_order_qty": 1,
        "mrp": 800,
        "sp": 750,
        "stock": 0,
        "tax": {
            "status": true,
            "_id": "61f7dde28d37e6262ba17c80",
            "tax_name": "GST_18",
            "tax_percentage": 18,
            "__v": 0
        },
        "meta_desc": "Saree phone holder ,mobile phone pouch\n",
        "meta_key": "mobile phone pouch",
        "note": "Saree hook provided to hold yor mobile safely",
        "images": [
            "public/product/1656066305657.2268.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.1,
            "length": 31,
            "breadth": 31,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6225aa7f5507127df692d32f",
                "category_name": " Mobile or Cell phone Pouches ",
                "createdAt": "2022-03-07T06:47:27.047Z",
                "updatedAt": "2022-10-19T09:11:23.410Z",
                "__v": 0,
                "images": "public/category/1666170683409.058.webp",
                "specification": null
            },
            {
                "parent": "6225aa7f5507127df692d32f",
                "status": true,
                "_id": "62345e60462a810f782264ea",
                "category_name": "Saree Mobile phone pouches",
                "createdAt": "2022-03-18T10:26:40.949Z",
                "updatedAt": "2022-03-18T10:31:06.762Z",
                "__v": 0,
                "images": null,
                "specification": "62345ef7462a810f78226517"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Ethnic to wear on your saree hip to be hands free",
            "mobile phone pouch come money purse"
        ],
        "key_words": [
            "mobile phone pouch"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b58dab2a62aa5591e49e4c",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P094",
        "model": "PB1",
        "specification": [
            {
                "_id": "62b6be9b2a62aa5591e4b8cb",
                "title": "Material",
                "value": "Silk With Zari",
                "suffix": ""
            },
            {
                "_id": "62b6be9b2a62aa5591e4b8cc",
                "title": "Colour",
                "value": "Yellow",
                "suffix": ""
            },
            {
                "_id": "62b6be9b2a62aa5591e4b8cd",
                "title": "Size",
                "value": "7.5 X 4 (In Inches)",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-24T10:10:51.829Z",
        "updatedAt": "2022-06-25T07:54:29.342Z",
        "__v": 0,
        "delivery_days": 7,
        "description": " Yellow Zari Mobile phone Pouch ",
        "display_date": null,
        "hsn_code": "6305",
        "min_order_qty": 1,
        "mrp": 650,
        "sp": 585,
        "stock": 0,
        "tax": {
            "status": true,
            "_id": "61f7dde28d37e6262ba17c80",
            "tax_name": "GST_18",
            "tax_percentage": 18,
            "__v": 0
        },
        "meta_desc": "Saree phone holder",
        "meta_key": "mobile phone pouch",
        "note": "Saree hook provided to hold your mobile safely<div>The Pouch has two Zips on Either Side&#160;</div>",
        "images": [
            "public/product/1656066413256.5757.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.1,
            "length": 31,
            "breadth": 31,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6225aa7f5507127df692d32f",
                "category_name": " Mobile or Cell phone Pouches ",
                "createdAt": "2022-03-07T06:47:27.047Z",
                "updatedAt": "2022-10-19T09:11:23.410Z",
                "__v": 0,
                "images": "public/category/1666170683409.058.webp",
                "specification": null
            },
            {
                "parent": "6225aa7f5507127df692d32f",
                "status": true,
                "_id": "62345e60462a810f782264ea",
                "category_name": "Saree Mobile phone pouches",
                "createdAt": "2022-03-18T10:26:40.949Z",
                "updatedAt": "2022-03-18T10:31:06.762Z",
                "__v": 0,
                "images": null,
                "specification": "62345ef7462a810f78226517"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Ethnic to wear on your saree hip to be hands free",
            "mobile phone pouch come money purse"
        ],
        "key_words": [
            "mobile phone pouch"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b58e6d2a62aa5591e49e8f",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P095",
        "model": "PB1",
        "specification": [
            {
                "_id": "62b6be952a62aa5591e4b8bb",
                "title": "Material",
                "value": "Silk With Zari",
                "suffix": ""
            },
            {
                "_id": "62b6be952a62aa5591e4b8bc",
                "title": "Colour",
                "value": "Blue",
                "suffix": ""
            },
            {
                "_id": "62b6be952a62aa5591e4b8bd",
                "title": "Size",
                "value": "7.5 X 4 (In Inches))",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-24T10:14:05.340Z",
        "updatedAt": "2022-06-25T07:54:24.480Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Blue Zari mobile Phone Pouch",
        "display_date": null,
        "hsn_code": "6305",
        "min_order_qty": 1,
        "mrp": 650,
        "sp": 585,
        "stock": 0,
        "tax": {
            "status": true,
            "_id": "61f7dde28d37e6262ba17c80",
            "tax_name": "GST_18",
            "tax_percentage": 18,
            "__v": 0
        },
        "meta_desc": "Saree phone holder , mobile phone pouch",
        "meta_key": "mobile phone pouch",
        "note": "Saree hook provided to hold your mobile safely<div>The Pouch has two Zips on Either Side&#160;</div>",
        "images": [
            "public/product/1656066513533.9058.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.1,
            "length": 31,
            "breadth": 31,
            "height": 4
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6225aa7f5507127df692d32f",
                "category_name": " Mobile or Cell phone Pouches ",
                "createdAt": "2022-03-07T06:47:27.047Z",
                "updatedAt": "2022-10-19T09:11:23.410Z",
                "__v": 0,
                "images": "public/category/1666170683409.058.webp",
                "specification": null
            },
            {
                "parent": "6225aa7f5507127df692d32f",
                "status": true,
                "_id": "62345e60462a810f782264ea",
                "category_name": "Saree Mobile phone pouches",
                "createdAt": "2022-03-18T10:26:40.949Z",
                "updatedAt": "2022-03-18T10:31:06.762Z",
                "__v": 0,
                "images": null,
                "specification": "62345ef7462a810f78226517"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Ethnic to wear on your saree hip to be hands free",
            "mobile phone pouch come money purse"
        ],
        "key_words": [
            "mobile phone pouch"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b58f2c2a62aa5591e49ed2",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P096",
        "model": "PB1",
        "specification": [
            {
                "_id": "62b6be902a62aa5591e4b8a8",
                "title": "Material",
                "value": "Silk With Zari",
                "suffix": ""
            },
            {
                "_id": "62b6be902a62aa5591e4b8a9",
                "title": "Colour",
                "value": "Red",
                "suffix": ""
            },
            {
                "_id": "62b6be902a62aa5591e4b8aa",
                "title": "Size",
                "value": "7.5 X 4 (In Inches)",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-24T10:17:16.369Z",
        "updatedAt": "2022-06-25T07:54:18.480Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Red Zari mobile Phone Pouch",
        "display_date": null,
        "hsn_code": "6305",
        "min_order_qty": 1,
        "mrp": 650,
        "sp": 585,
        "stock": 0,
        "tax": {
            "status": true,
            "_id": "61f7dde28d37e6262ba17c80",
            "tax_name": "GST_18",
            "tax_percentage": 18,
            "__v": 0
        },
        "meta_desc": "Saree phone holder ,mobile phone pouch",
        "meta_key": "mobile phone pouch",
        "note": "Saree hook provided to hold your mobile safely<div>The Pouch has two Zips on Either Side&#160;</div>",
        "images": [
            "public/product/1656066582130.949.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.12,
            "length": 22,
            "breadth": 22,
            "height": 9
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6234634f462a810f782266a6",
                "category_name": "Paper Craft",
                "createdAt": "2022-03-18T10:47:43.637Z",
                "updatedAt": "2022-10-19T09:12:36.034Z",
                "__v": 0,
                "images": "public/category/1666170756033.8086.webp",
                "specification": null
            },
            {
                "parent": "6234634f462a810f782266a6",
                "status": true,
                "_id": "62b407242a62aa5591e472a2",
                "category_name": "Gift hamper Box",
                "specification": "62b406e42a62aa5591e4728f",
                "createdAt": "2022-06-23T06:24:36.126Z",
                "updatedAt": "2022-06-23T06:24:36.126Z",
                "__v": 0
            }
        ],
        "pricestatus": false,
        "highlight": [
            "An Excellent Packing box for all Gifts ",
            "Reusable Packing Box"
        ],
        "key_words": [
            "Paper Craft Hamper Box , Packing Box "
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b68cf02a62aa5591e4aa80",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P097",
        "model": "PB 1",
        "specification": [
            {
                "_id": "62b6bfbf2a62aa5591e4b940",
                "title": "Material",
                "value": "Paper ",
                "suffix": ""
            },
            {
                "_id": "62b6bfbf2a62aa5591e4b941",
                "title": "Colur",
                "value": "Golden Colour with Red Zari Border ",
                "suffix": ""
            },
            {
                "_id": "62b6bfbf2a62aa5591e4b942",
                "title": "Size",
                "value": "3 X 3  X 3 (In Inches)",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-25T04:20:00.780Z",
        "updatedAt": "2022-06-25T07:57:22.842Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Gift hamper Box ",
        "display_date": null,
        "hsn_code": "3924",
        "min_order_qty": 1,
        "mrp": 300,
        "sp": 225,
        "stock": 0,
        "tax": {
            "status": true,
            "_id": "61f7dde28d37e6262ba17c80",
            "tax_name": "GST_18",
            "tax_percentage": 18,
            "__v": 0
        },
        "meta_desc": "Paper Craft Hamper Box , Packing Box ",
        "meta_key": "Paper Craft Hamper Box , Packing Box ",
        "note": "Handmade Paper Crafted Box to Pack Your Gift For all Occasion&#160;",
        "images": [
            "public/product/1656131226644.7068.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.4,
            "length": 31,
            "breadth": 31,
            "height": 10
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6234634f462a810f782266a6",
                "category_name": "Paper Craft",
                "createdAt": "2022-03-18T10:47:43.637Z",
                "updatedAt": "2022-10-19T09:12:36.034Z",
                "__v": 0,
                "images": "public/category/1666170756033.8086.webp",
                "specification": null
            },
            {
                "parent": "6234634f462a810f782266a6",
                "status": true,
                "_id": "623c257c1d83b224a0469ae9",
                "category_name": "Desk top Holders",
                "createdAt": "2022-03-24T08:02:04.087Z",
                "updatedAt": "2022-03-24T10:31:44.555Z",
                "__v": 0,
                "images": null,
                "specification": "62321c97434e6366c9fdac36"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Great utility on on your desk.",
            "Best organiser."
        ],
        "key_words": [
            "Hand made products"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b68fb62a62aa5591e4ab6e",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P098",
        "model": "PB1",
        "specification": [
            {
                "_id": "62b6c09a2a62aa5591e4b98b",
                "title": "Material",
                "value": "Paper and Cloth",
                "suffix": ""
            },
            {
                "_id": "62b6c09a2a62aa5591e4b98c",
                "title": "Colour",
                "value": "Red Block Print ",
                "suffix": ""
            },
            {
                "_id": "62b6c09a2a62aa5591e4b98d",
                "title": "Size",
                "value": "6.5 X 3.5 X 3.5 (In Inches)",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-25T04:31:50.979Z",
        "updatedAt": "2022-06-25T08:03:02.733Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Red Desk Top Holders",
        "display_date": null,
        "hsn_code": "2934",
        "min_order_qty": 1,
        "mrp": 1000,
        "sp": 800,
        "stock": 0,
        "tax": {
            "status": true,
            "_id": "61f7dde28d37e6262ba17c80",
            "tax_name": "GST_18",
            "tax_percentage": 18,
            "__v": 0
        },
        "meta_desc": "Paper made products, and made products",
        "meta_key": "Hand made products",
        "note": "Block Printed Cloth used on handmade desktop holder<div>Fancy Handle for miniature draws</div>",
        "images": [
            "public/product/1656131730930.06.webp"
        ]
    },
    {
        "packing_detail": {
            "weight": 0.1,
            "length": 31,
            "breadth": 31,
            "height": 3
        },
        "delivery_charge": {
            "local": 100,
            "zonal": 200,
            "national": 300
        },
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6225aa7f5507127df692d32f",
                "category_name": " Mobile or Cell phone Pouches ",
                "createdAt": "2022-03-07T06:47:27.047Z",
                "updatedAt": "2022-10-19T09:11:23.410Z",
                "__v": 0,
                "images": "public/category/1666170683409.058.webp",
                "specification": null
            },
            {
                "parent": "6225aa7f5507127df692d32f",
                "status": true,
                "_id": "62345e60462a810f782264ea",
                "category_name": "Saree Mobile phone pouches",
                "createdAt": "2022-03-18T10:26:40.949Z",
                "updatedAt": "2022-03-18T10:31:06.762Z",
                "__v": 0,
                "images": null,
                "specification": "62345ef7462a810f78226517"
            }
        ],
        "pricestatus": false,
        "highlight": [
            "Ethnic to wear on your saree hip to be hands free"
        ],
        "key_words": [
            "Saree phone holder, mobile phone pouch"
        ],
        "status": true,
        "featured": false,
        "publish": true,
        "_id": "62b6fb7b2a62aa5591e4cfff",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P050A",
        "model": "SMP1",
        "specification": [
            {
                "_id": "62b6fbdd2a62aa5591e4d02d",
                "title": "Material",
                "value": "Silk",
                "suffix": ""
            },
            {
                "_id": "62b6fbdd2a62aa5591e4d02e",
                "title": "Colour",
                "value": "Black",
                "suffix": ""
            },
            {
                "_id": "62b6fbdd2a62aa5591e4d02f",
                "title": "Size",
                "value": "7 X 4. 5 (In Inches)",
                "suffix": ""
            }
        ],
        "createdAt": "2022-06-25T12:11:39.494Z",
        "updatedAt": "2022-06-27T05:39:57.414Z",
        "__v": 0,
        "delivery_days": 7,
        "description": "Floral silk saree mobile pouch",
        "display_date": null,
        "hsn_code": "6305",
        "min_order_qty": 1,
        "mrp": 650,
        "sp": 600,
        "stock": 0,
        "tax": {
            "status": true,
            "_id": "61f7dde28d37e6262ba17c80",
            "tax_name": "GST_18",
            "tax_percentage": 18,
            "__v": 0
        },
        "meta_desc": "Saree phone holder, mobile phone pouch",
        "meta_key": "Saree phone holder, mobile phone pouch",
        "note": "Saree hook provided to hold yor mobile safely",
        "images": [
            "public/product/1656308865626.9082.webp"
        ]
    },
    {
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "622341265507127df692c50f",
                "category_name": "Home Utilities",
                "specification": null,
                "createdAt": "2022-03-05T10:53:26.643Z",
                "updatedAt": "2022-03-17T08:17:50.624Z",
                "__v": 0,
                "images": "public/category/1664342495502.3452.webp"
            },
            {
                "parent": "622341265507127df692c50f",
                "status": true,
                "_id": "622ae8ea5507127df693035c",
                "category_name": "Chettinad Baskets",
                "specification": null,
                "createdAt": "2022-03-11T06:15:06.440Z",
                "updatedAt": "2022-10-19T09:12:02.077Z",
                "__v": 0,
                "images": "public/category/1666170722075.4104.webp"
            },
            {
                "parent": "622ae8ea5507127df693035c",
                "status": true,
                "_id": "622c34a08bc4af4c77b1fd17",
                "category_name": "Chettinad Basket set of 5 with Lids",
                "createdAt": "2022-03-12T05:50:24.289Z",
                "updatedAt": "2022-03-17T08:17:41.538Z",
                "__v": 0,
                "images": null,
                "specification": "62233e595507127df692c4db"
            }
        ],
        "pricestatus": false,
        "highlight": [],
        "key_words": [],
        "status": false,
        "featured": false,
        "publish": false,
        "_id": "633fe8648797560b6c0ae0f4",
        "price_id": [],
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "FGDFG",
        "model": "GDGD",
        "specification": [],
        "createdAt": "2022-10-07T08:50:44.912Z",
        "updatedAt": "2022-10-10T09:37:04.007Z",
        "__v": 0,
        "stock": 0
    },
    {
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6225aa6c5507127df692d326",
                "category_name": "Wedding hand bags",
                "createdAt": "2022-03-07T06:47:08.299Z",
                "updatedAt": "2022-10-19T09:11:12.613Z",
                "__v": 0,
                "images": "public/category/1666170672612.1301.webp",
                "specification": null
            },
            {
                "parent": "6225aa6c5507127df692d326",
                "status": true,
                "_id": "62345cbc462a810f78226389",
                "category_name": "Clutch Hand Bags",
                "specification": "6227066b5507127df692d69c",
                "createdAt": "2022-03-18T10:19:40.691Z",
                "updatedAt": "2022-03-19T10:21:06.145Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [],
        "key_words": [],
        "status": true,
        "featured": false,
        "publish": false,
        "_id": "63439e4bbdaef31c208776dd",
        "price_id": [],
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "FFG",
        "model": "FDFDF",
        "specification": [],
        "createdAt": "2022-10-10T04:23:39.359Z",
        "updatedAt": "2022-10-10T04:23:39.359Z",
        "__v": 0,
        "stock": 0
    },
    {
        "category": [],
        "pricestatus": false,
        "highlight": [],
        "key_words": [],
        "status": true,
        "featured": false,
        "publish": false,
        "_id": "6347e7ceadc31d01fc008403",
        "price_id": [],
        "specification": [],
        "createdAt": "2022-10-13T10:26:22.796Z",
        "updatedAt": "2022-10-13T10:26:22.796Z",
        "__v": 0,
        "stock": 0
    },
    {
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6234634f462a810f782266a6",
                "category_name": "Paper Craft",
                "createdAt": "2022-03-18T10:47:43.637Z",
                "updatedAt": "2022-10-19T09:12:36.034Z",
                "__v": 0,
                "images": "public/category/1666170756033.8086.webp",
                "specification": null
            },
            {
                "parent": "6234634f462a810f782266a6",
                "status": true,
                "_id": "62b403452a62aa5591e471e8",
                "category_name": "Jewel Box",
                "specification": "62b402fb2a62aa5591e471d5",
                "createdAt": "2022-06-23T06:08:05.406Z",
                "updatedAt": "2022-06-23T06:08:05.406Z",
                "__v": 0
            }
        ],
        "pricestatus": false,
        "highlight": [],
        "key_words": [],
        "status": true,
        "featured": false,
        "publish": false,
        "_id": "63497b95bfb64a46b5dd3da5",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "P071",
        "model": "PM12",
        "specification": [],
        "createdAt": "2022-10-14T15:09:09.205Z",
        "updatedAt": "2022-10-14T15:09:09.205Z",
        "__v": 0,
        "stock": 0
    },
    {
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "6225aa6c5507127df692d326",
                "category_name": "Wedding hand bags",
                "createdAt": "2022-03-07T06:47:08.299Z",
                "updatedAt": "2022-10-19T09:11:12.613Z",
                "__v": 0,
                "images": "public/category/1666170672612.1301.webp",
                "specification": null
            },
            {
                "parent": "6225aa6c5507127df692d326",
                "status": true,
                "_id": "62345cbc462a810f78226389",
                "category_name": "Clutch Hand Bags",
                "specification": "6227066b5507127df692d69c",
                "createdAt": "2022-03-18T10:19:40.691Z",
                "updatedAt": "2022-03-19T10:21:06.145Z",
                "__v": 0,
                "images": null
            }
        ],
        "pricestatus": false,
        "highlight": [],
        "key_words": [],
        "status": true,
        "featured": false,
        "publish": false,
        "_id": "63620f69fcf2551258ea7e46",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "212",
        "model": "321",
        "specification": [],
        "createdAt": "2022-11-02T06:34:17.618Z",
        "updatedAt": "2022-11-02T06:34:17.618Z",
        "__v": 0,
        "stock": 0
    },
    {
        "category": [
            {
                "parent": null,
                "status": true,
                "_id": "622341265507127df692c50f",
                "category_name": "Home Utilities",
                "specification": null,
                "createdAt": "2022-03-05T10:53:26.643Z",
                "updatedAt": "2022-03-17T08:17:50.624Z",
                "__v": 0,
                "images": "public/category/1664342495502.3452.webp"
            },
            {
                "parent": "622341265507127df692c50f",
                "status": true,
                "_id": "622ae8ea5507127df693035c",
                "category_name": "Chettinad Baskets",
                "specification": null,
                "createdAt": "2022-03-11T06:15:06.440Z",
                "updatedAt": "2022-10-19T09:12:02.077Z",
                "__v": 0,
                "images": "public/category/1666170722075.4104.webp"
            },
            {
                "parent": "622ae8ea5507127df693035c",
                "status": true,
                "_id": "622c34a08bc4af4c77b1fd17",
                "category_name": "Chettinad Basket set of 5 with Lids",
                "createdAt": "2022-03-12T05:50:24.289Z",
                "updatedAt": "2022-03-17T08:17:41.538Z",
                "__v": 0,
                "images": null,
                "specification": "62233e595507127df692c4db"
            }
        ],
        "pricestatus": false,
        "highlight": [],
        "key_words": [],
        "status": true,
        "featured": false,
        "publish": false,
        "_id": "6364db5d623a9135e804a51a",
        "brand": {
            "status": true,
            "_id": "61f78a738d37e6262ba17bcf",
            "brand_name": "Poornima",
            "__v": 0
        },
        "sku": "2546",
        "model": "564",
        "specification": [],
        "createdAt": "2022-11-04T09:29:01.729Z",
        "updatedAt": "2022-11-04T09:29:01.729Z",
        "__v": 0,
        "stock": 0
    }
]