import { publicRequest, userRequest } from "../Api/Authentication";
import {
  loginStart,
  loginSuccess,
  loginFailure,
  registerStart,
  registerSuccess,
  registerFailure,
  forgotStart,
  forgotSuccess,
  forgotFailure,
  loginOtpStart,
  loginOtpSuccess,
  loginOtpFailure,
  logoutUser,
} from "../Store/userRedux";
class API {
  constructor() {
    this.rootUrl = process.env.REACT_APP_API;
  }

  login = async (dispatch, user) => {
    dispatch(loginStart());
    try {
      const res = await publicRequest.post("api/login", user);
      dispatch(loginSuccess(res.data));
      return res;
    } catch (err) {
      dispatch(loginFailure());
    }
  };

  logout = async (dispatch) => {
    dispatch(logoutUser({currentUser:null}));
  }

  registerMobile = async (mobile_no) => {
    try {
      const res = await publicRequest.get(`api/registration/${mobile_no}`);
      return res;
    } catch (err) {}
  };

  newRegister = async (dispatch, data) => {
    dispatch(registerStart());
    try {
      const res = await publicRequest.post("api/registration", data);
      dispatch(registerSuccess(res.data));
      return res;
    } catch (err) {
      dispatch(registerFailure());
    }
  };

  forgotMobile = async (data) => {
    try {
      const res = await publicRequest.post(`api/forgotpassword`, data);
      return res;
    } catch (err) {}
  };

  forgotPassword = async (dispatch, data) => {
    dispatch(loginOtpStart());
    try {
      const res = await publicRequest.post("api/forgotcheck", data);
      dispatch(loginOtpSuccess(res.data));
      return res;
    } catch (err) {
      dispatch(loginOtpFailure());
    }
  };

  sentOtp = async (data) => {
    try {
      const res = await publicRequest.post(`api/loginwithotp`, data);
      return res;
    } catch (err) {}
  };

  loginOtp = async (dispatch, data) => {
    dispatch(forgotStart());
    try {
      const res = await publicRequest.post("api/loginotpcheck", data);
      dispatch(forgotSuccess(res.data));
      return res;
    } catch (err) {
      dispatch(forgotFailure());
    }
  };

  company = async () => {
    try {
      const res = await publicRequest.get("api/company");
      return res;
    } catch (err) {}
  };

  socialmedia = async () => {
    try {
      const res = await publicRequest.get("api/social-media-link");
      return res;
    } catch (err) {}
  };

  template = async () => {
    try {
      const res = await publicRequest.get("api/template");
      return res;
    } catch (err) {}
  };

  homeComponent = async () => {
    try {
      const res = await publicRequest.get("api/home");
      return res;
    } catch (err) {}
  };

  banner = async () => {
    try {
      const res = await publicRequest.get("api/banner");
      return res;
    } catch (err) {}
  };

  themes = async () => {
    try {
      const res = await publicRequest.get("api/templatecustom");
      return res;
    } catch (err) {}
  };

  topCategory = async () => {
    try {
      const res = await publicRequest.get("api/category");
      return res;
    } catch (err) {}
  };

  featureProduct = async () => {
    try {
      const res = await publicRequest.get("api/filter");
      return res;
    } catch (err) {}
  };

  filter = async () => {
    try {
      const res = await publicRequest.get("api/product/");
      return res;
    } catch (err) {}
  };

  getMyProfile = async () => {
    try {
      const res = await userRequest.get("api/profile");
      return res;
    } catch (err) {}
  };

  updateMyProfile = async (data) => {
    try {
      const res = await userRequest.post("api/profile", data);
      return res;
    } catch (err) {}
  };

  updateProfileImage = async (url, id) => {
    try {
      let data = {"image":url }
      const res = await userRequest.put(`api/profile/${id}`, data);
      return res;
    } catch (err) {}
  };

  countryList = async () => {
    try {
      const res = await publicRequest.get("api/country");
      return res;
    } catch (err) {}
  };

  stateList = async () => {
    try {
      let data = { country: "India" };
      const res = await publicRequest.post(
        `https://countriesnow.space/api/v0.1/countries/states`,
        data
      );
      return res;
    } catch (err) {}
  };

  cityList = async (data) => {
    try {
      let data1 = { country: "India", state: data };
      const res = await publicRequest.post(
        `https://countriesnow.space/api/v0.1/countries/state/cities
        `,
        data1
      );
      return res;
    } catch (err) {}
  };

  addressList = async () => {
    try {
      const res = await userRequest.get("api/address");
      return res;
    } catch (err) {}
  };

  addAddress = async (data) => {
    try {
      const res = await userRequest.post("api/address", data);
      return res;
    } catch (err) {}
  };

  deleteAddress = async (data) => {
    try {
      const res = await userRequest.delete(`api/address/${data}`);
      return res;
    } catch (err) {}
  };

  getSingleAddress = async (data) => {
    try {
      const res = await userRequest.get(`api/address/${data}`);
      return res;
    } catch (err) {}
  };

  updateAddress = async (data, id) => {
    try {
      const res = await userRequest.put(`api/address/${id}`, data);
      return res;
    } catch (err) {}
  };

  setDeliveryAddress = async (id) => {
    try {
      const res = await userRequest.post(`api/address/set-address`, {id:id});
      return res;
    } catch (err) {}
  }


  singleProduct = async (id) => {
    try {
      const res = await userRequest.get(`api/products/${id}`);
      return res;
    } catch (err) {}
  };

  getAllProductReview = async (pid) => {
    try {
      const res = await userRequest.get(`api/reviews/star/${pid}`);
      return res;
    } catch (err) {}
  };

  addNewReview = async (data) => {
    try {
      const res = await userRequest.post(`api/reviews/`,data);
      return res;
    } catch (err) {}
  }

  getSingleBuyerReview = async (data) => {
    try {
      const res = await userRequest.get("api/reviews/",data);
      return res;
    } catch (err) {}
  }

  updateReview = async (data, id) => {
    try {
      const res = await userRequest.put(`api/reviews/${id}`,data);
      return res;
    } catch (err) {}
  }

  allCategory = async () => {
    try {
      const res = await userRequest.get(`api/category`);
      return res;
    } catch (err) {}
  }

  addToCart = async (data) => {
    try {
      const res = await userRequest.post(`api/cart`,data);
      return res;
    } catch (err) {}
  }

  singleProductDlchrg = async (data) => {
    try {
      const res = await userRequest.post(`api/shipping`, data);
      return res;
    } catch (err) {}
  }

  cartList = async () => {
    try {
      const res = await userRequest.get(`api/cart`);
      return res;
    } catch (err) {}
  }

  updateCart = async (id, quantity, delivery) => {
    try {
      const res = await userRequest.put(`api/cart/${id}`, { quantity: quantity, delivery: delivery });
      return res;
    } catch (err) {}
  }

  deleteCart = async (id) => {
    try {
      const res = await userRequest.delete(`api/cart/${id}`);
      return res;
    } catch (err) {}
  }

  suggest = async (data) => {
    try {
      const res = await userRequest.get(`api/search-suggest`, { params: { search: data} });
      return res;
    } catch (err) {}
  }

  dynamicPage = async (page) => {
    try {
      const res = await userRequest.get(`api/dynamic/${page}`);
      return res;
    } catch (err) {}
  }

  enquiry = async (data) => {
    try {
      const res = await userRequest.post(`api/enquiry`,data);
      return res;
    } catch (err) {}
  }

  colorComponent = async () => {
    try {
      const res = await userRequest.get(`api/home-component`);
      return res;
    } catch (err) {}
  }






}

export default API;
