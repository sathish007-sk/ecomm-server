import React, { useEffect, useState } from "react";
import Carousel from "react-multi-carousel";
import "react-multi-carousel/lib/styles.css";
import API from "../../Api/ApiService";
import Default from '../../Assets/Images/banner_default.png'
import {
  LeftOutlined,
  RightOutlined,
  CaretRightFilled,
  CaretLeftFilled,
} from "@ant-design/icons";
import { Link } from "react-router-dom";
import styled, { ThemeProvider } from "styled-components";

const responsive = {
  superLargeDesktop: {
    breakpoint: { max: 4000, min: 3000 },
    items: 1,
  },
  desktop: {
    breakpoint: { max: 3000, min: 1024 },
    items: 1,
  },
  tablet: {
    breakpoint: { max: 1024, min: 464 },
    items: 1,
  },
  mobile: {
    breakpoint: { max: 464, min: 0 },
    items: 1,
  },
};

const size = {
  desktop: "1920px",
  laptop: "1440px",
  minilaptop: "1200px",
  tabletl: "992px",
  tablet: "768px",
  mobilel: "580px",
  mobilep: "480px",
  mobiles: "380px",
};

const device = {
  desktop: `@media screen and (max-width: ${size.desktop})`,
  laptop: `@media screen and (max-width: ${size.laptop})`,
  minilaptop: `@media screen and (max-width: ${size.minilaptop})`,
  tabletl: `@media screen and (max-width: ${size.tabletl})`,
  tablet: `@media screen and (max-width: ${size.tablet})`,
  mobilel: `@media screen and (max-width: ${size.mobilel})`,
  mobilep: `@media screen and (max-width: ${size.mobilep})`,
  mobiles: `@media screen and (max-width: ${size.mobiles})`,
};

const theme = {
  id: 1,
  color: "#000",
  background: "#000",
  border: "#ee8f0a",
  gray: "#888",
  bg70: "rgb(255 255 255 / 70%)",
  bglight: "#f5f5f5",
  titlesize: [
    {
      screen: "desktop",
      value: 30,
    },
    {
      screen: "tablet",
      value: 20,
    },
    {
      screen: "mobile",
      value: 20,
    },
  ],
  colcount: [
    {
      screen: "desktop",
      value: 3,
    },
    {
      screen: "tablet",
      value: 2,
    },
    {
      screen: "mobile",
      value: 1,
    },
  ],
  gap: [
    {
      screen: "desktop",
      value: 25,
    },
    {
      screen: "tablet",
      value: 20,
    },
    {
      screen: "mobile",
      value: 15,
    },
  ],
};

const Section = styled.section`
  width: 100%;
  display: inline-block;
  position: relative;

  .react-multi-carousel-dot-list.Premium1_BA1_Dots {
    width: fit-content !important;
    display: flex;
    margin: auto;
    bottom: 10px;
  }
  .react-multi-carousel-dot-list.Premium1_BA1_Dots li {
    width: fit-content;
    padding: 0 6px;
  }
  .react-multi-carousel-dot-list.Premium1_BA1_Dots li button {
    height: 16px;
    width: 16px;
    border-radius: 2px;
    background: transparent;
    box-shadow: 0 0 15px rgb(0 0 0 / 30%);
    border: 2px solid
      ${(props) => (props.theme.background ? props.theme.background : "#000")};
  }
  .react-multi-carousel-dot-list.Premium1_BA1_Dots li.active button {
    background: ${(props) =>
      props.theme.background ? props.theme.background : "#000"};
  }
`;
const Image = styled.img``;

const PremiumBA1 = () => {
  const CustomDot = ({ onClick, active }) => {
    return (
      <li className={active ? "active" : "inactive"}>
        <button onClick={() => onClick()}></button>
      </li>
    );
  };
  const CustomRight = ({ onClick }) => (
    <button className="bannerarrow right" onClick={onClick}>
      <CaretRightFilled />
    </button>
  );
  const CustomLeft = ({ onClick }) => (
    <button className="bannerarrow left" onClick={onClick}>
      <CaretLeftFilled />
    </button>
  );
  const [images, setImage] = useState([]);
  const api = new API();
  useEffect(()=>{
    api.banner().then((res)=>{
      setImage(res.data)
    }).catch((err)=>{})
  },[])

  return (
    <ThemeProvider theme={theme}>
      <Section className="Premium1_BA1" id={theme.id}>
        <Carousel
          infinite
          arrows={false}
          customLeftArrow={<CustomLeft />}
          customRightArrow={<CustomRight />}
          pauseOnHover
          showDots
          autoPlay
          partialVisible={true}
          itemClass="image-item"
          responsive={responsive}
          autoPlaySpeed={5000}
          slidesToSlide={1}
          swipeable
          dotListClass="Premium1_BA1_Dots"
          customDot={<CustomDot />}
        >
          {images?.map((e, i) => {
            return (
              <Link to={e.link} key={`ban_${i}`}>
                <Image
                  draggable={false}
                  style={{ width: "100%", height: "100%" }}
                  src={e.image ? api.rootUrl + e.image : Default}
                />
              </Link>
            );
          })}
        </Carousel>
      </Section>
    </ThemeProvider>
  );
};
export default PremiumBA1;
