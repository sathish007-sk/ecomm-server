import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Swiper, SwiperSlide } from "swiper/react";
import { Navigation, Pagination, Autoplay } from "swiper";
import "swiper/css";
import "swiper/scss/pagination";
import API from "../../Api/ApiService";
import Default from "../../Assets/Images/banner_default.png";
import styled from "styled-components";
import { styles } from "../../Api/Data";
const user = JSON.parse(localStorage.getItem("persist:root"))?.company;
const colorCustom = user && JSON.parse(user).setColor;
const BA5 = () => {
  const [images, setImage] = useState([]);
  const api = new API();
  useEffect(() => {
    api
      .banner()
      .then((res) => {
        setImage(res.data);
      })
      .catch((err) => {});
  }, []);

  return (
    <React.Fragment>
      <BannerSection>
        <section className="Temp5_Banner">
          <Swiper
            pagination={{
              type: "progressbar",
            }}
            speed={2000}
            autoplay={{
              delay: 5000,
              disableOnInteraction: false,
            }}
            loop={true}
            navigation={false}
            modules={[Pagination, Navigation, Autoplay]}
            className="mySwiper"
          >
            {images?.map((e, i) => {
              return (
                <SwiperSlide key={`ban_t1${i}`}>
                  <Link to={e.link}>
                    <img
                      draggable={false}
                      style={{ width: "100%", height: "100%" }}
                      src={e.image ? api.rootUrl + e.image : Default}
                    />
                  </Link>
                </SwiperSlide>
              );
            })}
          </Swiper>
        </section>
      </BannerSection>
    </React.Fragment>
  );
};

export default BA5;

const BannerSection = styled.div`
  .Temp5_Banner {
    width: 90%;
    margin-top: 10px;
  }
`;
