import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Swiper, SwiperSlide } from "swiper/react";
import { EffectCreative, Pagination, Navigation, Autoplay } from "swiper";

import "swiper/css";
import "swiper/css/pagination";
import "swiper/css/navigation";
import "swiper/css/effect-creative";
import API from "../../Api/ApiService";
import Default from "../../Assets/Images/banner_default.png";
import styled from "styled-components";
import { styles } from "../../Api/Data";
const user = JSON.parse(localStorage.getItem("persist:root"))?.company;
const colorCustom = user && JSON.parse(user).setColor;

const BA6 = () => {
  const [images, setImage] = useState([]);
  const api = new API();
  useEffect(() => {
    api
      .banner()
      .then((res) => {
        setImage(res.data);
      })
      .catch((err) => {});
  }, []);

  return (
    <React.Fragment>
      <BannerSection>
        <section className="Temp6_Banner">
          <Swiper
            hashNavigation={{
              watchState: true,
            }}
            pagination={{
              clickable: true,
            }}
            navigation={true}
            effect={"creative"}
            creativeEffect={{
              prev: {
                shadow: true,
                translate: [0, 0, -400],
              },
              next: {
                translate: ["100%", 0, 0],
              },
            }}
            speed={1500}
            autoplay={{
              delay: 5000,
              disableOnInteraction: false,
            }}
            modules={[EffectCreative, Pagination, Autoplay, Navigation]}
            loop={true}
            className="mySwiper"
          >
            {images?.map((e, i) => {
              return (
                <SwiperSlide data-hash="" key={`ban_t1${i}`}>
                  <Link to={e.link}>
                    <img
                      draggable={false}
                      style={{ width: "100%", height: "100%" }}
                      src={e.image ? api.rootUrl + e.image : Default}
                      alt=""
                    />
                  </Link>
                </SwiperSlide>
              );
            })}
          </Swiper>
        </section>
      </BannerSection>
    </React.Fragment>
  );
};

export default BA6;


const BannerSection = styled.div`

span.swiper-pagination-bullet.swiper-pagination-bullet-active {
  background: ${styles?.colorapi};
}

`;