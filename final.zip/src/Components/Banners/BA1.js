import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Swiper, SwiperSlide } from "swiper/react";
import { Navigation, Pagination, Autoplay } from "swiper";
import "swiper/css";
import "swiper/scss/pagination";
import API from "../../Api/ApiService";
import Default from '../../Assets/Images/banner_default.png'

const BA1 = () => {
  const [images, setImage] = useState([]);
  const api = new API();
  useEffect(()=>{
    api.banner().then((res)=>{
      setImage(res.data)
    }).catch((err)=>{})
  },[])

  return (
    <section className="Temp1_Banner">
      <Swiper
        pagination={{
          type: "progressbar",
        }}
        speed={2000}
        autoplay={{
          delay: 5000,
          disableOnInteraction: false,
        }}
        loop={true}
        navigation={true}
        modules={[Pagination, Navigation, Autoplay]}
        className="mySwiper"
      >
        {images?.map((e, i) => {
          return (
            <SwiperSlide key={`ban_t1${i}`}>
              <Link to={e.link}>
                <img
                  draggable={false}
                  style={{ width: "100%", height: "100%" }}
                  src={e.image ? api.rootUrl + e.image : Default}
                />
              </Link>
            </SwiperSlide>
          );
        })}
      </Swiper>
    </section>
  );
};

export default BA1;
