import React, { useEffect, useState } from "react";
import { Navigation, Pagination, Autoplay } from "swiper";
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css";
import "swiper/css/navigation";
import "swiper/css/pagination";
import "swiper/css/scrollbar";
import { styles } from "../../Api/Data";
import Default from '../../Assets/Images/default.png'
import API from "../../Api/ApiService";
import styled from "styled-components";
const Banner = () => {
  const api = new API();
  const [banner,setBanner] = useState([]);
  useEffect(()=>{
    api.banner().then((res)=>{
      setBanner(res.data)
    }).catch((err)=>{})
  },[])


  return (
    <React.Fragment>
      <section className="slider">
        <Swiper
          className="home_banner_slider"
          spaceBetween={0}
          slidesPerView={1}
          loop={true}
          speed={1500}
          autoplay={{
            delay: 10000,
            disableOnInteraction: false,
          }}
          pagination={{
            clickable: true,
          }}
          navigation={true}
          modules={[Autoplay, Pagination, Navigation]}
        >
          {banner?.map((data) => (
            <SwiperSlide key={data._id}>
              <SliderSection>
                <Img src={data.image ? api.rootUrl + data.image : Default} />
              </SliderSection>
            </SwiperSlide>
          ))}
        </Swiper>
      </section>
    </React.Fragment>
  );
};

export default Banner;

const SliderSection = styled.div`
  display: inline-block;
  margin: 0 0 60px;
  position: relative;
  width: 100%;
  box-sizing: border-box;
  h2,
  p {
    padding: 0;
    margin: 0;
  }
  .home_banner_slider .swiper-button-next,
  .home_banner_slider .swiper-button-prev {
    color: ${styles.background} !important;
  }
  .home_banner_slider .swiper-button-next:after,
  .home_banner_slider .swiper-button-prev:after {
    color: ${styles.background} !important;
    font-size: 25px !important;
  }
  .home_banner_slider .swiper-pagination span {
    background: ${styles.background} !important;
  }
`;

const Img = styled.img`
max-width: 100%;
width:100%;
`;