import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import API from "../../Api/ApiService";
import Default from "../../Assets/Images/default.png";
import styled from "styled-components";
import { styles } from "../../Api/Data";
const user = JSON.parse(localStorage.getItem("persist:root"))?.company;
const colorCustom = user && JSON.parse(user).setColor;

export default function Design3HC1(props) {
  const api = new API();
  const [data, setData] = useState([]);
  useEffect(() => {
    if (props.data) setData(props.data);
  }, [props]);
  return (
    <React.Fragment>
      <Hc1>
        <section className="Temp3_HC1">
          {data.title && <H2>{data.title}</H2>}
          <div className="wrapper">
            <div className="Temp3_HC1_Align">
              {data?.content?.map((e, i) => {
                return (
                  <div className="Temp3_HC1_Box" key={`hc1_1_${i}`}>
                    <div className="Temp3_HC1_Box_Align">
                      <div className="Temp3_HC1_Box_Zoom">
                        <img
                          src={e.image ? api.rootUrl + e.image : Default}
                          alt={e.sub_title}
                        />
                      </div>
                      <div className="Temp3_HC1_Box_Content">
                        <small>
                          <i>{e.sub_title}</i>
                        </small>
                        <h4>{e.title}</h4>

                        {e.description && (
                          <p
                            dangerouslySetInnerHTML={{ __html: e.description }}
                          ></p>
                        )}
                        {e.link_text && (
                          <div className="Temp3_HC1_Box_Content_Btn">
                            <Link
                              to={e.link
                                .toLowerCase()
                                .replace(/ /g, "-")
                                .replace(/[^\w-]+/g, "")}
                            >
                              <button>{e.link_text}</button>
                            </Link>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </section>
      </Hc1>
    </React.Fragment>
  );
}

const H2 = styled.h2`
  font-size: ${styles?.h2};
  font-family: ${styles?.font} !important;
  color: ${colorCustom?.color ? colorCustom?.color : styles?.color} !important;
  line-height: 1.4;
  margin: 0 0 25px;
  text-align: center;

  @media screen and (max-width: 768px) {
    text-align: center;
  }
`;



const Hc1 = styled.div`


.Temp3_HC1 {
  display: inline-block;
  width: 100%;
  position: relative;
}


.Temp3_HC1 .Temp3_HC1_Align {
  display: grid;
  grid-template-columns: repeat(2,1fr);
  gap: 30px;

}


.Temp3_HC1 .Temp3_HC1_Align .Temp3_HC1_Box {
  display: inline-block;
  width: 100%;
  position: relative;
}
.Temp3_HC1 .Temp3_HC1_Align .Temp3_HC1_Box .Temp3_HC1_Box_Align {
  display: inline-block;
  width: 100%;
  position: relative;
  overflow: hidden;
  height: 400px;
  border-radius: 0px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-wrap: wrap;
}
.Temp3_HC1 .Temp3_HC1_Align .Temp3_HC1_Box .Temp3_HC1_Box_Align::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
  z-index: 10;
  background: ${styles?.bg60};
}
.Temp3_HC1 .Temp3_HC1_Align .Temp3_HC1_Box .Temp3_HC1_Box_Align .Temp3_HC1_Box_Zoom {
  position: absolute;
    top: 0;
    left: 0;
    bottom: 0;
    right: 0;
    background-size: cover !important;
    height: 100%;
    width: 100%;
    background-repeat: no-repeat;
    background-position: center !important;
    transform: scale(1);
    z-index: 5;
    transition: all 1.3s ease-in-out;
    display: flex;
    align-items: center;
    justify-content: center;
}
.Temp3_HC1 .Temp3_HC1_Align .Temp3_HC1_Box .Temp3_HC1_Box_Align:hover .Temp3_HC1_Box_Zoom {
  transform: scale(1.12);
  z-index: 5;
  transition: all 1.3s ease-in-out;
}
.Temp3_HC1 .Temp3_HC1_Align .Temp3_HC1_Box .Temp3_HC1_Box_Align .Temp3_HC1_Box_Content {
  position: relative;
  z-index: 15;
  width: 100%;
  text-align: center;
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  height: fit-content;
  margin: auto;
  padding: 15px;
  gap: 15px;
}
.Temp3_HC1 .Temp3_HC1_Align .Temp3_HC1_Box .Temp3_HC1_Box_Align .Temp3_HC1_Box_Content small {
  color: ${styles?.white} !important;
}
.Temp3_HC1 .Temp3_HC1_Align .Temp3_HC1_Box .Temp3_HC1_Box_Align .Temp3_HC1_Box_Content h4 {
  width: 100%;
  text-align: center;
  color: ${styles?.white} !important;
  font-size: ${styles?.h4} !important;
  line-height: 1.5;
  margin: 0;
}
.Temp3_HC1 .Temp3_HC1_Align .Temp3_HC1_Box .Temp3_HC1_Box_Align .Temp3_HC1_Box_Content p {
  margin: 0;
  line-height: 1.8;
  text-align: center;
  color: ${styles?.white} !important;
  font-size: 16px;
  font-weight: 300;
 padding: 0 30px;
 width: 100%;
 display: inline-block;
}

.Temp3_HC1 .Temp3_HC1_Align .Temp3_HC1_Box .Temp3_HC1_Box_Align .Temp3_HC1_Box_Content .Temp3_HC1_Box_Content_Btn button {
  padding: 7px 20px;
  border: 1.5px solid ${styles?.white};
  outline: none;
  color: ${styles?.white};
  background: transparent;
  font-size: 14px;
  border-radius: 30px;
  font-family: ${styles?.medium} !important;
  
  margin: 0px 0 0 0;
  text-transform: capitalize;
  display: flex;
  align-items: center;
  gap: 8px;
}

@media screen and (max-width:768px) {
  .Temp3_HC1 .Temp3_HC1_Align, .Temp3_HC2 .Temp3_HC2_Align {
  grid-template-columns: repeat(1,1fr);
}

  
}



`;
