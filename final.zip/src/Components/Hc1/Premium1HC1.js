import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import DefaultImg from "../../Assets/Images/default.png";
import styled, { ThemeProvider } from "styled-components";
import API from "../../Api/ApiService";
import Default from '../../Assets/Images/default.png'
export default function Premium1HC1(props) {
  const api = new API();


  


  const [data, setData] = useState([]);
  useEffect(() => {
    if (props.data) setData(props.data);
    customize()
  }, [props]);


  const customize = () => {
    api.colorComponent().then((res)=>{
      console.log(res)
    })
  }
















  const size = {
    desktop: "1920px",
    laptop: "1440px",
    minilaptop: "1200px",
    tabletl: "992px",
    tablet: "768px",
    mobilel: "580px",
    mobilep: "480px",
    mobiles: "380px",
  };

  const device = {
    desktop: `@media screen and (max-width: ${size.desktop})`,
    laptop: `@media screen and (max-width: ${size.laptop})`,
    minilaptop: `@media screen and (max-width: ${size.minilaptop})`,
    tabletl: `@media screen and (max-width: ${size.tabletl})`,
    tablet: `@media screen and (max-width: ${size.tablet})`,
    mobilel: `@media screen and (max-width: ${size.mobilel})`,
    mobilep: `@media screen and (max-width: ${size.mobilep})`,
    mobiles: `@media screen and (max-width: ${size.mobiles})`,
  };

  const theme = {
    id: 2,
    color: "#000",
    background: "#000",
    border: "#ee8f0a",
    bg70: "rgb(255 255 255 / 70%)",
    bglight: "#f5f5f5",
    titlesize: [
      {
        screen: "desktop",
        value: 30,
      },
      {
        screen: "tablet",
        value: 25,
      },
      {
        screen: "mobile",
        value: 20,
      },
    ],
    colcount: [
      {
        screen: "desktop",
        value: 2,
      },
      {
        screen: "tablet",
        value: 2,
      },
      {
        screen: "mobile",
        value: 1,
      },
    ],
    gap: [
      {
        screen: "desktop",
        value: 25,
      },
      {
        screen: "tablet",
        value: 20,
      },
      {
        screen: "mobile",
        value: 15,
      },
    ],
  };

  const Section = styled.section`
    display: inline-block;
    width: 100%;
    position: relative;
  `;
  const WrapperFull = styled.div`
    max-width: 100%;
    padding: 0 20px;
  `;
  const Permium1HC1Align = styled.div`
    display: grid;
    justify-content: center;

    ${device.desktop} {
      grid-template-columns: repeat(
        ${(props) =>
          props.theme.colcount[0].screen == "desktop"
            ? props.theme.colcount[0].value
            : 3},
        1fr
      );
      gap: ${(props) =>
        props.theme.gap[0].screen == "desktop"
          ? props.theme.gap[0].value
          : 25}px;
    }
    ${device.tabletl} {
      grid-template-columns: repeat(
        ${(props) =>
          props.theme.colcount[1].screen == "tablet"
            ? props.theme.colcount[1].value
            : 2},
        1fr
      );
      gap: ${(props) =>
        props.theme.gap[0].screen == "tablet"
          ? props.theme.gap[0].value
          : 20}px;
    }
    ${device.tablet} {
      grid-template-columns: repeat(
        ${(props) =>
          props.theme.colcount[2].screen == "mobile"
            ? props.theme.colcount[2].value
            : 1},
        1fr
      );
      gap: ${(props) =>
        props.theme.gap[0].screen == "mobile"
          ? props.theme.gap[0].value
          : 15}px;
    }
  `;
  const Premium1HC1Box = styled.div`
    display: flex;
    position: relative;
    min-height: 400px;
    margin: 0px;
    align-items: center;
    justify-content: center;
    text-align: center;
    box-shadow: 0 0 12px rgb(0 0 0 / 16%);
    border: 1px solid
      ${(props) => (props.theme.border ? props.theme.border : "#000")};
    &:before {
      content: "";
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      position: absolute;
      z-index: 6;
    }
  `;

  const Permium1HC1Bg = styled.div`
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    height: 100%;
    width: 100%;
    background-position: center center !important;
    background-size: cover !important;
    z-index: 1;
    background-color: ${(props) =>
      props.theme.bglight ? props.theme.bglight : "#f5f5f5"} !important;
    background-repeat: no-repeat !important;
  `;

  const Permium1HC1Content = styled.div`
    align-items: flex-start;
    z-index: 10;
    position: relative;
    width: auto;
    justify-content: center;
    padding: 20px 30px;
    background: ${(props) =>
      props.theme.bg70 ? props.theme.bg70 : "rgb(255 255 255 / 70%)"};
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    display: flex;
    gap: 18px;
    flex-direction: column;
  `;

  const Premium1HC1Title = styled.h4`
    color: ${(props) =>
      props.theme.color ? props.theme.color : "000"} !important;
    font-weight: 600;
    margin: 0;

    ${device.desktop} {
      font-size: ${(props) =>
        props.theme.titlesize[0].screen == "desktop"
          ? props.theme.titlesize[0].value
          : 30}px;
    }
    ${device.tabletl} {
      font-size: ${(props) =>
        props.theme.titlesize[1].screen == "tablet"
          ? props.theme.titlesize[1].value
          : 25}px;
    }
    ${device.mobilel} {
      font-size: ${(props) =>
        props.theme.titlesize[2].screen == "mobile"
          ? props.theme.titlesize[2].value
          : 20}px;
    }
  `;

  const Premium1HC1Button = styled.button`
    position: relative;
    display: inline-block;
    padding: 0 0 6px 6px;
    width: fit-content;
    border: 0;
    outline: none;
    background: transparent;
    &:before {
      content: "";
      position: absolute;
      left: 0;
      bottom: 0;
      top: 6px;
      right: 6px;

      border: 1px solid
        ${(props) => (props.theme.background ? props.theme.background : "#000")};
      border-radius: 3px;
    }
    &:hover {
      padding: 0 0 6px 6px;
    }
    a {
      padding: 9px 20px;
      border: 0;
      background: ${(props) =>
        props.theme.background ? props.theme.background : "#000"};
      border-radius: 3px;
      color: #fff;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      font-size: 13px !important;
      display: inline-block;
      position: relative;
      z-index: 11;
    }
  `;

  return (
    <>
      <ThemeProvider theme={theme}>
        <Section className="Premium1HC1" id={theme.id}>
          <WrapperFull>
            {data.title && <h2 className="HeadTextTemp1">{data.title}</h2>}
            <Permium1HC1Align>
              {data?.content?.map((e, i) => {
                return (
                  <Premium1HC1Box key={`premiumhc11${i}`}>
                    {/* <Permium1HC1Bg
                    style={{
                      background: `url("${
                         ? e.image : DefaultImg
                      }")no-repeat`,
                    }}
                  ></Permium1HC1Bg> */}
                    <img src={e.image ? api.rootUrl + e.image : DefaultImg} />
                    <Permium1HC1Content>
                    
                      <Premium1HC1Title>{e.title}</Premium1HC1Title>
                      <Premium1HC1Button>
                        {e.link_text && <Link to={e.link.toLowerCase().replace(/ /g, '-')
                      .replace(/[^\w-]+/g, '')}>{e.link_text}</Link>}
                      </Premium1HC1Button>
                    </Permium1HC1Content>
                  </Premium1HC1Box>
                );
              })}
            </Permium1HC1Align>
          </WrapperFull>
        </Section>
      </ThemeProvider>
    </>
  );
}
