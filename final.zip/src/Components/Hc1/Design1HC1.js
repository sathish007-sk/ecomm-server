import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import API from "../../Api/ApiService";
import Default from "../../Assets/Images/default.png";
import styled from "styled-components";
import { styles } from "../../Api/Data";
const user = JSON.parse(localStorage.getItem("persist:root"))?.company;
const colorCustom = user && JSON.parse(user).setColor;
export default function Design1HC1({ data }) {
  const api = new API();
  const [content, setContent] = useState([]);

  useEffect(() => {
    setContent(data.content);
  }, []);

  return (
    <React.Fragment>
      <Hc1>
        <section className="Temp1_HC1">
          <div className="Wrapper_Full">
            {data.title && <H2>{data.title}</H2>}
            <div className="Temp1_HC1_Align">
              {content?.map((e, i) => {
                return (
                  <div key={`hc1_1_${i}`} className="Temp1_HC1_Box">
                    <div className="Temp1_HC1_Box_Bg">
                      <img
                        src={e.image ? api.rootUrl + e.image : Default}
                        alt={e.sub_title}
                      />
                    </div>
                    <div className="Temp1_HC1_Box_Content">
                      <h5>
                        {e.sub_title} {e.span}
                      </h5>
                      <h4>{e.title}</h4>
                      {e.description && (
                        <p
                          dangerouslySetInnerHTML={{ __html: e.description }}
                        ></p>
                      )}
                      {e.link_text && (
                        <div className="Temp1_HC1_Box_Btn">
                          <Link
                            to={e.link
                              .toLowerCase()
                              .replace(/ /g, "-")
                              .replace(/[^\w-]+/g, "")}
                          >
                            <button>{e.link_text}</button>
                          </Link>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </section>
      </Hc1>
    </React.Fragment>
  );
}

const H2 = styled.h2`
  font-size: ${styles?.h2};
  font-family: ${styles?.font} !important;
  color: ${colorCustom?.color ? colorCustom?.color : styles?.color} !important;
  line-height: 1.4;
  margin: 0 0 25px;

  @media screen and (max-width: 768px) {
    text-align: center;
  }
`;

const Hc1 = styled.div`
  .Temp1_HC1 {
    width: 100%;
    display: inline-block;
    position: relative;
  }

  .Temp1_HC1 .Temp1_HC1_Align {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 40px 30px;
  }
  .Temp1_HC1 .Temp1_HC1_Align .Temp1_HC1_Box {
    position: relative;
    min-height: 450px;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 40px;
    overflow: hidden;
  }
  .Temp1_HC1 .Temp1_HC1_Align .Temp1_HC1_Box::after {
    content: "";
    position: absolute;
    height: 100%;
    width: 100%;
    top: 0;
    left: 0;
    background: ${styles?.bg60};
    z-index: 7;
  }
  .Temp1_HC1 .Temp1_HC1_Align .Temp1_HC1_Box .Temp1_HC1_Box_Bg {
    position: absolute;
    top: 0;
    left: 0%;
    bottom: 0%;
    right: 0;
    background-repeat: no-repeat !important;
    background-position: center center;
    background-size: cover;
    z-index: 5;
    transition: all 0.7s ease-in-out;
    display: flex;
    align-items: center;
    justify-content: center;
  }

  .Temp1_HC1 .Temp1_HC1_Align .Temp1_HC1_Box:hover .Temp1_HC1_Box_Bg {
    transition: all 0.7s ease-in-out;
    transform: scale(1.2);
  }
  .Temp1_HC1 .Temp1_HC1_Align .Temp1_HC1_Box .Temp1_HC1_Box_Content {
    position: relative;
    width: 100%;
    display: flex;
    flex-direction: column;
    gap: 15px;
    z-index: 10;
  }
  .Temp1_HC1 .Temp1_HC1_Align .Temp1_HC1_Box .Temp1_HC1_Box_Content h5 {
    font-size: 14px;
    line-height: 1;
    color: ${styles?.white};
    font-family: $bold;
    margin: 0;
  }
  .Temp1_HC1 .Temp1_HC1_Align .Temp1_HC1_Box .Temp1_HC1_Box_Content h4 {
    font-size: ${styles?.h2};
    font-family: ${styles?.bold} !important;
    color: ${styles?.white} !important;
    margin: 0;
  }
  .Temp1_HC1 .Temp1_HC1_Align .Temp1_HC1_Box .Temp1_HC1_Box_Content p {
    color: ${styles?.white} !important;
    font-size: ${styles?.p} !important;
    line-height: 1.6;
    max-width: 90%;
    font-family: ${styles?.regular};
    margin: 0;
  }
  .Temp1_HC1
    .Temp1_HC1_Align
    .Temp1_HC1_Box
    .Temp1_HC1_Box_Content
    .Temp1_HC1_Box_Btn {
    display: inline-block;
    width: 100%;
  }
  .Temp1_HC1
    .Temp1_HC1_Align
    .Temp1_HC1_Box
    .Temp1_HC1_Box_Content
    .Temp1_HC1_Box_Btn
    button {
    padding: 7px 18px;
    outline: none;
    position: relative;
    border: 1px solid ${styles?.white};
    color: ${styles?.white};
    background: transparent;
    cursor: pointer;
    font-family: ${styles?.regular};
    font-size: ${styles?.p};
    margin: 10px 0 0 0;
  }

  @media screen and (max-width: 768px) {
    .Temp1_HC1 .Temp1_HC1_Align {
      grid-template-columns: repeat(1, 1fr);
      text-align: center;
    }

    .Temp1_HC1 .Temp1_HC1_Align .Temp1_HC1_Box,
    .Temp1_HC2 .Temp1_HC2_Align .Temp1_HC2_Box {
      padding: 25px;
    }
  }
`;
