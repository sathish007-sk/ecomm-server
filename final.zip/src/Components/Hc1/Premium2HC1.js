import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import styled, { ThemeProvider } from "styled-components";
import API from "../../Api/ApiService";
import Default from '../../Assets/Images/default.png'

export default function Premium2HC1(props) {
  const api = new API();
  const [data, setData] = useState([]);
  useEffect(() => {
    if (props.data) setData(props.data);
  }, [props]);


  const size = {
    desktop: "1920px",
    laptop: "1440px",
    minilaptop: "1200px",
    tabletl: "992px",
    tablet: "768px",
    mobilel: "580px",
    mobilep: "480px",
    mobiles: "380px",
  };
  
const device = {
    desktop: `@media screen and (max-width: ${size.desktop})`,
    laptop: `@media screen and (max-width: ${size.laptop})`,
    minilaptop: `@media screen and (max-width: ${size.minilaptop})`,
    tabletl: `@media screen and (max-width: ${size.tabletl})`,
    tablet: `@media screen and (max-width: ${size.tablet})`,
    mobilel: `@media screen and (max-width: ${size.mobilel})`,
    mobilep: `@media screen and (max-width: ${size.mobilep})`,
    mobiles: `@media screen and (max-width: ${size.mobiles})`,
  };
  
  const theme = {
    id: 1,
    background: "#fff",
    color: "#dfad54",
    background: "#0d0d0d",
    border: "#dfad54",
    gray: "#8d8d8d",
    bg70: "rgb(255 255 255 / 70%)",
    bglight: "#f5f5f5",
    titlesize: [
      {
        screen: "desktop",
        value: 30,
      },
      {
        screen: "tablet",
        value: 25,
      },
      {
        screen: "mobile",
        value: 20,
      },
    ],
    colcount: [
      {
        screen: "desktop",
        value: 2,
      },
      {
        screen: "tablet",
        value: 2,
      },
      {
        screen: "mobile",
        value: 1,
      },
    ],
    gap: [
      {
        screen: "desktop",
        value: 25,
      },
      {
        screen: "tablet",
        value: 20,
      },
      {
        screen: "mobile",
        value: 25,
      },
    ],
  };
  
  const Section = styled.section`
    display: inline-block;
    width: 100%;
    position: relative;
    h2 {
      color:${props=> props.theme.id && props.theme.color ? props.theme.color : '#000'} !important;
      text-align: center;
      margin: 0 0 45px;
      position: relative;
      padding: 0 0 18px;
      &:before {
          content: '';
      height: 4px;
      width: 75px;
      position: absolute;
      bottom: 0;
      left: 50%;
      transform: translate(-50%, 0px);
      border-radius: 3px;
          background:${props=> props.theme.id && props.theme.color ? props.theme.color : '#000'};
      }
    }
  `;
  const WrapperFull = styled.div`
    max-width: 100%;
    padding: 0 20px;
  `;
  const Permium2HC1Align = styled.div`
    display: grid;
    justify-content: center;
  
    ${device.desktop} {
      grid-template-columns: repeat(
        ${(props) =>
          props.theme.id && props.theme.colcount[0].screen == "desktop"
            ? props.theme.colcount[0].value
            : 3},
        1fr
      );
      gap: ${(props) =>
        props.theme.id && props.theme.gap[0].screen == "desktop" ? props.theme.gap[0].value : 25}px;
    }
    ${device.tabletl} {
      grid-template-columns: repeat(
        ${(props) =>
          props.theme.id && props.theme.colcount[1].screen == "tablet"
            ? props.theme.colcount[1].value
            : 2},
        1fr
      );
      gap: ${(props) =>
        props.theme.id && props.theme.gap[0].screen == "tablet" ? props.theme.gap[0].value : 20}px;
    }
    ${device.tablet} {
      grid-template-columns: repeat(
        ${(props) =>
          props.theme.id && props.theme.colcount[2].screen == "mobile"
            ? props.theme.colcount[2].value
            : 1},
        1fr
      );
      gap: ${(props) =>
        props.theme.id && props.theme.gap[0].screen == "mobile" ? props.theme.gap[0].value : 20}px;
    }
  `;
  const Premium1HC1Box = styled.div`
    display: flex;
    position: relative;
    flex-direction: column;
    margin: 0px;
    align-items: flex-end;
    justify-content: center;
    text-align: center;
    /* box-shadow: 0 0 12px rgb(0 0 0 / 16%); */
    border: 0px solid
      ${(props) => (props.theme.id && props.theme.border ? props.theme.border : "#000")};
    gap:40px 0;
  `;
  
  const Permium2HC1Img = styled.div`
  display: inline-block;
  width: 100%;
  position: relative;
  border: 1px solid
    ${props=> props.theme.id && props.theme.color ? props.theme.color : '#000'};
    border-radius: 180px 10px 180px 180px;
    overflow:hidden;
    &:hover img {
      transform: scale(1.2);
      transition: all 0.5s ease-in-out;
    }
  `;
  
  
  const Permium2HC1Bg = styled.img`
    position: relative;
    width: 100%;
    transition: all 0.5s ease-in-out;
    
  `;
  
  const Permium2HC1Content = styled.div`
    align-items: flex-start;
    z-index: 10;
    position: relative;
    width: 100%;
    justify-content: center;
    padding: 0px 20px;
    text-align:center;
    display: flex;
    gap: 18px;
    flex-direction: column;
  `;
  
  const Premium1HC1Title = styled.h4`
    color: ${(props) =>
      props.theme.id && props.theme.color ? props.theme.color : "000"} !important;
    font-weight: 600;
    margin: 0;
    text-align:center;
    width:100%;
  
    ${device.desktop} {
      font-size: ${(props) =>
        props.theme.id && props.theme.titlesize[0].screen == "desktop" ? props.theme.titlesize[0].value : 30}px;
    }
    ${device.tabletl} {
      font-size: ${(props) =>
        props.theme.id && props.theme.titlesize[1].screen == "tablet" ? props.theme.titlesize[1].value : 25}px;
    }
    ${device.mobilel} {
      font-size: ${(props) =>
        props.theme.id && props.theme.titlesize[2].screen == "mobile" ? props.theme.titlesize[2].value : 20}px;
    }
  `;
  
  const Premium1HC1Button = styled.button`
  position: relative;
    display: inline-block;
    padding: 0 0 0px 0px;
    width: fit-content;
    border: 1px solid ${props=> props.theme.id && props.theme.color ? props.theme.color : '#000'};
    background: transparent;
    outline: none;
    margin: auto;
    background: transparent;
      border-radius: 24px 5px 24px 24px;
      color: ${props=> props.theme.id && props.theme.background ? props.theme.background : '#000'};
    a {
      padding: 9px 20px;
      border: 0;
      
      border-radius: 3px;
      color: ${props=> props.theme.id && props.theme.color ? props.theme.color : '#000'};
      font-weight:700;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      font-size: 13px !important;
      display: inline-block;
      position: relative;
      z-index: 11;
    }
  `;




  return (
    <ThemeProvider theme={theme}>
      <Section className="Premium1HC1" id={theme.id}>
        <WrapperFull>
          {data.title && <h2 className="HeadTextTemp1">{data.title}</h2>}
          <Permium2HC1Align>
            {data?.content?.map((e, i) => {
             
              return (
                <Premium1HC1Box key={`premiumhc11${i}`}>
                  <Permium2HC1Img>
                  <Permium2HC1Bg src={e.image ? api.rootUrl + e.image : Default} alt={e.sub_title} />
                 </Permium2HC1Img>
                  <Permium2HC1Content>
                    <Premium1HC1Title>{e.title}</Premium1HC1Title>
                    <Premium1HC1Button>
                      {e.linktext && <Link to={e.link.toLowerCase().replace(/ /g, '-')
                      .replace(/[^\w-]+/g, '')}>{e.linktext}</Link>}
                    </Premium1HC1Button>
                  </Permium2HC1Content>
                </Premium1HC1Box>
              );
            })}
          </Permium2HC1Align>
        </WrapperFull>
      </Section>
    </ThemeProvider>
  );
}
