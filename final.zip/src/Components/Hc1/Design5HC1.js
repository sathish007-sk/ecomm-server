import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import DefaultImg from "../../Assets/Images/default.png";
import API from "../../Api/ApiService";
import styled from "styled-components";
import { styles } from "../../Api/Data";
const user = JSON.parse(localStorage.getItem("persist:root"))?.company;
const colorCustom = user && JSON.parse(user).setColor;

export default function Design5HC1(props) {
  const api = new API();
  const [data, setData] = useState([]);
  useEffect(() => {
    if (props.data) setData(props.data);
  }, [props]);

  return (
    <React.Fragment>
      <Hc1>
        <section className="Temp5_HC1">
          <div className="Wrapper_Full">
            {data.title && <H2>{data.title}</H2>}
            <div className="Temp5_HC1_Align">
              {data?.content?.map((e, i) => {
                return (
                  <div class="Temp5_HC1_flip-box">
                    <div class="Temp5_HC1_flip-box-inner">
                      <div class="Temp5_HC1_flip-box-front">
                        <img
                          src={e.image ? api.rootUrl + e.image : DefaultImg}
                        />
                        <h4>{e.title}</h4>
                      </div>
                      <div class="Temp5_HC1_flip-box-back">
                        <div className="Temp5_HC1_backside">
                          <h5 style={{ color: "white" }}>
                            {e.sub_title} {e.span}
                          </h5>
                          <p className="Temp5_HC1_dis">
                            {e.description && (
                              <p
                                dangerouslySetInnerHTML={{
                                  __html: e.description,
                                }}
                              ></p>
                            )}
                          </p>
                          {e.link_text && (
                            <div>
                              <Link
                                to={e.link
                                  .toLowerCase()
                                  .replace(/ /g, "-")
                                  .replace(/[^\w-]+/g, "")}
                              >
                                <button className="Temp5_HC1_Box_Btn">
                                  {e.link_text}
                                </button>
                              </Link>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </section>
      </Hc1>
    </React.Fragment>
  );
}

const H2 = styled.h1`
  font-size: ${styles?.h2};
  font-family: ${styles?.font} !important;
  color: ${colorCustom?.color ? colorCustom?.color : styles?.color} !important;
  line-height: 1.4;
  margin: 0 0 25px;
  text-align: center;

  @media screen and (max-width: 768px) {
    text-align: center;
  }
`;

const Hc1 = styled.div`
  .Temp5_HC1_Align {
    display: flex;
    gap: 100px;
    align-items: center;
    justify-content: center;
  }

  .Temp5_HC1_flip-box {
    background-color: transparent;
    width: 100%;

    border: 1px solid #f1f1f1;
    perspective: 1000px;
  }

  .Temp5_HC1 {
    margin: 0px;
  }

  .Temp5_HC1_flip-box-inner {
    position: relative;
    width: 100%;
    height: 100%;
    text-align: center;
    transition: transform 1s;
    transform-style: preserve-3d;
  }

  .Temp5_HC1_flip-box:hover .Temp5_HC1_flip-box-inner {
    transform: rotateY(180deg);
  }

  .Temp5_HC1_flip-box-front,
  .Temp5_HC1_flip-box-back {
    width: 100%;
    height: 100%;
    -webkit-backface-visibility: hidden;
    backface-visibility: hidden;
  }

  .Temp5_HC1_backside {
    padding: 12%;
  }

  .Temp5_HC1_flip-box-front {
    background-color: #bbbbbb14;
    color: black;
    display: flex;
    align-items: center;
    flex-direction: column;
    justify-content: center;
    img {
      padding: 60px 0;
      height: 400px;
      object-fit: contain;
    }
  }

  .Temp5_HC1_flip-box-back {
    background-color: #2d2e2edb;
    color: white;
    transform: rotateY(180deg);
    position: absolute;
    top: 0px;
  }

  .Temp5_HC1_Box_Btn {
    padding: 10px 15px;
    font-size: 14px;
    text-align: center;
    cursor: pointer;
    outline: none;
    color: #fff;
    background-color: ${styles?.colorapi};
    border: none;
    border-radius: 15px;
  }

  .Temp5_HC1_Box_Btn:hover {
    background-color: ${styles?.white};
    color: ${styles?.colorapi};
  }

  .Temp5_HC1_Box_Btn:active {
    background-color: ${styles?.white};
    color: ${styles?.colorapi};
    box-shadow: 0 5px #666;
    transform: translateY(4px);
  }

  .Temp5_HC1
    .Temp5_HC1_Align
    .Temp5_HC1_Box
    .Temp5_HC1_Box_Grid
    .Temp5_HC1_Box_Link
    button {
    background: ${styles?.bg60};
    border: 1px solid ${styles?.bg60};
    display: flex;
    margin: auto;
  }

  @media screen and (max-width: 992px) {
    .Temp5_HC1_dis {
      display: none;
    }
  }

  @media screen and (max-width: 600px) {
    .Temp5_HC1_Align {
      flex-wrap: wrap;
    }
  }

  @media screen and (max-width: 480px) {
    .Temp5_HC1_Align {
      flex-wrap: wrap;
    }
  }
`;
