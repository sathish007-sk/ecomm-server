import React from 'react'
import {testComponent} from '../../ApiData'

const Premium3HC1 = (props) => {
  return (
    <React.Fragment>{testComponent}</React.Fragment>
  )
}

export default Premium3HC1