import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import API from "../../Api/ApiService";
import DefaultImg from "../../Assets/Images/default.png";
import styled from "styled-components";
import { styles } from "../../Api/Data";
const user = JSON.parse(localStorage.getItem("persist:root"))?.company;
const colorCustom = user && JSON.parse(user).setColor;
export default function Design4HC1(props) {
  const api = new API();
  const [data, setData] = useState([]);
  useEffect(() => {
    if (props.data) setData(props.data);
  }, [props]);
  return (
    <React.Fragment>
      <Hc1>
        <section className="Template4_HC_1">
          <div className="wrapper_full">
            {data.title && <H2>{data.title}</H2>}
            <div className="Template4_HC_1_Align">
              {data?.content?.map((e, i) => {
                return (
                  <div className="Template4_HC_1_Item" key={`hc1_1_${i}`}>
                    <div className="Template4_HC_1_Box">
                      <div className="Template4_HC_1_Zoom">
                        <img
                          src={e.image ? api.rootUrl + e.image : DefaultImg}
                          alt={e.sub_title}
                        />
                      </div>
                      <div className="Template4_HC_1_Content">
                        <small className="Template4_HC_1_SubTitle">
                          <i>{e.sub_title}</i>
                        </small>
                        <h4 className="Template4_HC_1_Title">{e.title}</h4>
                        {e.description && (
                          <p
                            dangerouslySetInnerHTML={{ __html: e.description }}
                          ></p>
                        )}
                        {e.link_text && (
                          <div className="Template4_HC_1_Action">
                            <Link
                              to={e.link
                                .toLowerCase()
                                .replace(/ /g, "-")
                                .replace(/[^\w-]+/g, "")}
                            >
                              <button className="Template4_HC_1_Button">
                                {e.link_text}
                              </button>
                            </Link>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </section>
      </Hc1>
    </React.Fragment>
  );
}
const H2 = styled.h1`
  font-size: ${styles?.h2};
  font-family: ${styles?.font} !important;
  color: ${colorCustom?.color ? colorCustom?.color : styles?.color} !important;
  line-height: 1.4;
  margin: 0 0 25px !important;

  @media screen and (max-width: 768px) {
    text-align: center;
  }
`;

const Hc1 =styled.div`



.Template4_HC_1 {
  padding: 0px 0;
  display: inline-block;
  width: 100%;
}
.Template4_HC_1 * {
  margin: 0%;
  padding: 0;
  box-sizing: border-box;
}
.Template4_HC_1 .wrapper_full {
  padding: 0 20px;
}
.Template4_HC_1 .Template4_HC_1_Align {
  display: grid;
  grid-template-columns: repeat(2,1fr);
  gap: 20px;
  width: 100%;
}
.Template4_HC_1_Item {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  width: 100%;
}
.Template4_HC_1_Item .Template4_HC_1_Box {
  display: flex;
  position: relative;
  padding: 60px 40px;
  background: ${styles?.white} !important;
  min-height: 450px;
  flex-wrap: wrap;
  align-items: center;
  
  width: 100%;

}
.Template4_HC_1_Item .Template4_HC_1_Box::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: ${styles?.bg60};
  z-index: 7;
}
.Template4_HC_1_Item .Template4_HC_1_Box .Template4_HC_1_Zoom {
  position: absolute;
  z-index: 5;
  top:0;
  left:0;
  bottom:0;
  right:0;
  height: 100%;
  width: 100%;
  background-size: cover;
  background-position: center center;
  display: flex;
  align-items: center;
  justify-content: center;
}
.Template4_HC_1_Item .Template4_HC_1_Box .Template4_HC_1_Content {
  position: relative;
    z-index: 10;
    padding: 0px;
    color: ${styles?.white} !important;
    max-width: 80%;
    margin: 0;
    display: flex;
    flex-wrap: wrap;
    flex-direction: column;
    gap: 15px;
}
.Template4_HC_1_Item .Template4_HC_1_Box .Template4_HC_1_Content small.Template4_HC_1_SubTitle {
  font-size: 14px;

}
.Template4_HC_1_Item .Template4_HC_1_Box .Template4_HC_1_Content h4.Template4_HC_1_Title {
  font-size: 30px;
  color: ${styles?.white} !important;
}
.Template4_HC_1_Item .Template4_HC_1_Box .Template4_HC_1_Content p {
  line-height: 27px;
  font-size: 15px;
}
.Template4_HC_1_Item .Template4_HC_1_Box .Template4_HC_1_Content .Template4_HC_1_Action .Template4_HC_1_Button {
  padding: 0 0 4px;
  background: transparent;
  border: 0;
  text-transform: uppercase;
  font-weight: 700;
  letter-spacing: 2px;
  border-bottom: 2px solid ${styles?.white} !important;
  color:  ${styles?.white} !important;
  margin: 0 0 0 0;
}

@media screen and (max-width:992px) {
  .Template4_HC_1 .Template4_HC_1_Align {
  grid-template-columns: repeat(1,1fr);
}

@media screen and (max-width:768px) {
  .Template4_HC_1_Item .Template4_HC_1_Box .Template4_HC_1_Content {
    max-width: 100%;
    text-align: center;
  }
}












}







`;