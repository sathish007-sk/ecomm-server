import React, { useState, useEffect } from 'react'
import styled from 'styled-components'
import b1 from "../../Assets/Images/furniture/hc1.jpg"
import { Button } from 'antd';
import { Link } from "react-router-dom";
import { styles } from '../../Api/Data';
import API from '../../Api/ApiService';
import DefaultImg from "../../Assets/Images/default.png";
const FHc1 = (props) => {
    const api = new API();
    const [data, setData] = useState([]);
    useEffect(() => {
        if (props.data) setData(props.data);
    }, [props]);
  return (
    <React.Fragment>
                    <Hc1Section>
                        <div className='hc1_section'>
                            <div className='wrapper'>
                            {data.title && <H2>{data.title}</H2>}
                                <ul>
                                   
                                    {
                                data?.content?.map((item) => {
                                    return (
                                        <li key={item?._id}>
                                        <div className='hc1_box'>
                                            <div className='left'>
                                            <img src={item.image ? api.rootUrl + item.image : DefaultImg} alt="Product" />
                                            <Link to={item?.link.toLowerCase()
                                                        .replace(/ /g, "-")
                                                        .replace(/[^\w-]+/g, "")}>
                                                    <Button>Shop Now</Button>
                                                </Link>
                                            </div>
                                            <div className='right'>
                                                <h4>{item?.title}</h4>
                                                <h5>{item?.sub_title}</h5>

                                            </div>
                                        </div>
                                    </li>
                                    )
                                })
                            }
                                </ul>
                            </div>
                        </div>
                    </Hc1Section>
                </React.Fragment>
  )
}

export default FHc1;



const H2 = styled.h2`
   font-size:30px;
   margin : 0 0 35px;
   text-transform: uppercase;
   font-family: ${styles?.r_regular} !important;
   letter-spacing: 0.7px;

   @media screen and (max-width:768px) {
    text-align: center;
   }

`

const Hc1Section = styled.section`
    * {
        font-family: ${styles?.r_regular};
    }
    width:100%;
    display: inline-block;
    position: relative;
    .hc1_section {
        display: inline-block;
        width: 100%;
        position: relative;
    }

    .hc1_section ul {
        display: grid;
        padding: 0;
        grid-template-columns: repeat(2,1fr);
        gap: 45px;
    }
    .hc1_section ul li {
        background: transparent;
    padding: 0 45px 45px 45px;
    width: 100%;
    border-radius: 0px;
    display: grid;
    align-items: center;
    position: relative;
    }
    .hc1_section ul li::before {
        content: "";
        position: absolute;
        border: 1px solid #bfbbbb;
        /* border-style: dashed; */
    }
    .hc1_section ul li .hc1_box {
        display: flex;
        align-items: flex-end;
        justify-content: space-between;
        flex-wrap: wrap;
    }
    .hc1_section ul li .hc1_box .left {
        width: 47%;
        display: inline-block;
        position: relative;
        z-index: 10;
        img {
            border-radius: 10px;
            width: 100%;
    height: 300px;
    object-fit: cover;
        }
        button {
            width: fit-content;
        margin: 30px auto 0 auto;
        border: 0;
        border-radius: 8px;
        padding: 7px 15px;
        display: flex;
        text-align: center;
        background: linear-gradient(14.29deg, #efbc48 7.56%, #ffd064 87.33%);
        color: #206942;
        font-family: ${styles?.r_regular} !important;
        }
    }
    .hc1_section ul li .hc1_box .right {
        width: 47%;
        display: flex;
        gap: 15px;
        text-align: center;
        flex-direction: column;
        padding: 50px 0;
    }
    .hc1_section ul li .hc1_box .right::before {
        content: "";
    position: absolute;
    border: 1px solid #c7c7c7;
    /* border-style: dashed; */
    height: 55%;
    width: 100%;
    right: 0;
    bottom: 0;
    z-index: 1;
    border-radius: 10px;
}
    .hc1_section ul li .hc1_box .right h4 {
        font-size: 30px;
        text-transform: uppercase;
        margin: 0 !important;
        font-family: ${styles?.r_bold} !important;
    }
    .hc1_section ul li .hc1_box .right h5 {
        margin: 0 !important;
        font-size: 18px;
        font-family: ${styles?.r_regular};
    }
    .hc1_section ul li .hc1_box .right button {
        padding: 0 !important;
    background: transparent;
    border: 0;
    padding: 0;
    margin: auto;
    font-size: 13px;
    font-style: italic;
    -webkit-text-decoration: underline;
    text-decoration: underline;
    font-weight: 600;
    font-family: r_regular !important;
    -webkit-letter-spacing: 0.7px;
    -moz-letter-spacing: 0.7px;
    -ms-letter-spacing: 0.7px;
    letter-spacing: 0.7px;
    display: flex;
    }

    @media screen and (max-width:1200px) {
        .hc1_section ul li {
            padding: 35px;
        }
        .hc1_section ul li .hc1_box .right::before {
            height: 65%;
        }
    }


    @media screen and (max-width:992px) {
        .hc1_section ul {
            grid-template-columns: repeat(1,1fr);
        }
        .hc1_section ul li {
            padding: 25px;
        }
        .hc1_section ul li:nth-child(even) .hc1_box {
            flex-direction: row-reverse;
        }
        .hc1_section ul li .hc1_box .right::before {
    height: 100%;
}
.hc1_section ul li .hc1_box {
    align-items: center;
}
.hc1_section ul li .hc1_box .left button {
    display: none;
}


    }


    @media screen and (max-width:768px) {
        .hc1_section ul li {
        border: 0;
        background: #fff;
        border-radius: 15px;
    box-shadow: 0 0 15px rgb(0 0 0 / 5%);
    }
    .hc1_section ul li .hc1_box .right::before {
        content: inherit;
    }









    }


    @media screen and (max-width:480px) {
         .hc1_section ul li .hc1_box .right h4 {
    font-size: 25px;
        }
        .hc1_section ul li {
            padding: 25px 15px;
        }


    }





`