import React, { useState, useEffect } from 'react'
import styled from 'styled-components';
import { styles } from '../../Api/Data';
import hmain from "../../Assets/Images/dry/hmain.png"
import hc1 from "../../Assets/Images/dry/hc1.png"
import rightarrow from "../../Assets/Images/dry/right_arrow.png"
import API from '../../Api/ApiService';
import DefaultImg from "../../Assets/Images/default.png";
import { Link } from "react-router-dom";
const DryHc1 = (props) => {

  const api = new API();
  const [data, setData] = useState([]);
  useEffect(() => {
      if (props.data) setData(props.data);
  }, [props]);


  return (
    <React.Fragment>
                <Hc1Section>
                    <div className='hc1_section'>
                        <div className='wrapper'>
                        {data.title && <H2>{data.title}</H2>}
                            <div className='hc1_align'>
                                <ul>
                                    {
                                data?.content?.map((item) => {
                                    return ( 
                                    <li key={item?._id}>
                                        <div className='hc1_box'>
                                        <span className='subtitle'>{item?.sub_title}</span>
                                            <div className='hc1_box_left'>
                                            <Link to={item?.link.toLowerCase()
                                                        .replace(/ /g, "-")
                                                        .replace(/[^\w-]+/g, "")}>
                                                <img src={item.image ? api.rootUrl + item.image : DefaultImg} alt="hc1" />
                                                </Link>
                                            </div>
                                            <div className='hc1_box_right'>
                                                <h4>{item?.title}</h4>
                                                
                                                <Link to={item?.link.toLowerCase()
                                                        .replace(/ /g, "-")
                                                        .replace(/[^\w-]+/g, "")}><button>
                                                    <img src={rightarrow} alt="" />
                                                </button></Link>
                                            </div>
                                        </div>
                                    </li>
                                     )
                                    })
                                }
                                </ul>
                            </div>
                        </div>
                    </div>
                </Hc1Section>
            </React.Fragment>
  )
}

export default DryHc1
const H2 = styled.h2`
   font-size:32px;
   margin : 0 0 50px;
   font-family: ${styles?.q_bold} !important;
   text-align: center;
   padding: 55px 0 0 0;
   &::before {
    content: "";
    position: absolute;
    background: url(${hmain});
    background-repeat: no-repeat;
    height: 46px;
    width: 46px;
    background-size: contain;
    top: 0;
    left: 50%;
    transform: translate(-50%, 0px);
   }

   @media screen and (max-width:768px) {
    text-align: center;
   }

`

const Hc1Section = styled.section`
    width:100%;
    display: inline-block;
    position: relative;

    .hc1_section {
        display: inline-block;
        width:100%;
        position: relative;
    }
    .hc1_align {
        width: 100%;
        display: inline-block;
        position: relative;
    }
    ul {
        display: grid;
        grid-template-columns: repeat(2,1fr);
        gap: 40px;
        padding: 0;
        margin: 0;
    }
    ul li {
        width: 100%;
        display: inline-block;
        border: 1px solid #ebebeb;
        border-radius: 8px;
        padding: 24px;
    }
.subtitle {
    display: block;
    width: fit-content;
    text-align: end;
    background: ${styles?.themegreen};
    color: #fff;
    padding: 4px 20px;
    border-radius: 15px 1px 15px 1px;
    margin: 0 0 22px auto;
}
ul li img {
    width: 100%;
    padding: 0 50px;
}

.hc1_box_right {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 20px;
    margin: 30px 0 0 0;
}
.hc1_box_right h4 {
    margin: 0 !important;
    width: 75%;
    text-align: left;
    line-height: 1.4;
    font-family: ${styles?.q_bold};
    font-size: 23px;
}
.hc1_box_right button {
    border: 0;
    background: transparent;
    outline: none;
    img {
        padding: 0;
        height: 30px;
    }
}

@media screen and (max-width:768px) {
    ul {
        grid-template-columns: repeat(1,1fr);
    } 
}

@media screen and (max-width:480px) {
    .hc1_box_right h4 {
        font-size: 18px;
    }
}




`