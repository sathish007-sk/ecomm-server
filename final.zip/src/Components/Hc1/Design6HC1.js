import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import Default from "../../Assets/Images/default.png";
import API from "../../Api/ApiService";
import styled from "styled-components";
import { styles } from "../../Api/Data";
const user = JSON.parse(localStorage.getItem("persist:root"))?.company;
const colorCustom = user && JSON.parse(user).setColor;
export default function Design6HC1(props) {
  const api = new API();
  const [data, setData] = useState([]);
  useEffect(() => {
    if (props.data) setData(props.data);
  }, [props]);

  return (
    <React.Fragment>
      <Hc1>
        <section className="Temp6_HC1">
          <div className="Wrapper_Full">
            {data.title && <h2 className="Head_Text_Temp6">{data.title}</h2>}
            <div className="Temp6_HC1_Align">
              {data?.content?.map((e, i) => {
                return (
                  <div key={`hc1_1_${i}`} className="Temp6_HC1_Box">
                    <div className="Temp6_HC1_Image">
                      <div className="Temp6_HC1_Box_Bg">
                        <img
                          src={e.image ? api.rootUrl + e.image : Default}
                          alt={e.sub_title}
                        />
                      </div>
                    </div>
                    <div className="Temp6_HC1_Box_Content">
                      <p>
                        {e.sub_title} {e.span}
                      </p>
                      <h4>{e.title}</h4>
                      {e.description && (
                        <p
                          dangerouslySetInnerHTML={{ __html: e.description }}
                        ></p>
                      )}
                      {e.link_text && (
                        <div className="Temp6_HC1_Box_Btn">
                          <Link
                            to={e.link
                              .toLowerCase()
                              .replace(/ /g, "-")
                              .replace(/[^\w-]+/g, "")}
                          >
                            <button>{e.link_text}</button>
                          </Link>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </section>
      </Hc1>
    </React.Fragment>
  );
}

const Hc1 = styled.div`
  .Temp6_HC1 {
    width: 100%;
    display: inline-block;
    position: relative;
  }
  h2.Head_Text_Temp6 {
    font-size: 24px;
    font-family: ${styles?.bold} !important;
    color: ${styles?.colorapi} !important;
    line-height: 1.4;
    margin: 0 0 25px;
    text-transform: uppercase;
  }

  .Temp6_HC1_Align {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 25px;
  }

  .Temp6_HC1_Align .row:nth-last-child(odd) {
    display: flex;
    flex-direction: row-reverse;
  }

  .Temp6_HC1 .Temp6_HC1_Align .Temp6_HC1_Box .Temp6_HC1_Box_Bg {
    width: 100%;
    position: relative;
    height: 300px;
    width: 100%;
    top: 0;
    left: 0;
    z-index: 5;
    background-repeat: no-repeat !important;
    background-position: center center;
    transition: all 0.7s ease-in-out;
    display: flex;
    align-items: center;
    justify-content: center;

    img {
      height: 100%;
      object-fit: contain;
    }
  }
  .Temp6_HC1 .Temp6_HC1_Align .Temp6_HC1_Box {
    border: 1px solid ${styles?.light};
    border-radius: 5px;
  }

  .Temp6_HC1 .Temp6_HC1_Align .Temp6_HC1_Box_Content .Temp6_HC1_Box_Btn button {
    padding: 7px 18px;
    outline: none;
    position: relative;
    border: 1px solid ${styles?.color};
    color: ${styles?.color};
    background: transparent;
    cursor: pointer;
    font-family: ${styles?.regular};
    font-size: 16px;
    margin: 10px 0 0 0;
  }

  .Temp6_HC1 .Temp6_HC1_Align .Temp6_HC1_Box .Temp6_HC1_Box_Content {
    text-align: center;
    padding: 35px;
  }

  .Temp6_HC1 .Temp6_HC1_Align .Temp6_HC1_Box .Temp6_HC1_Box_Content h3 {
    font-size: 24px;
    color: ${styles?.color} !important;
    font-family: ${styles?.bold} !important;
    margin: 0;
  }

  @media screen and (max-width: 768px) {
    .Temp6_HC1 .Temp6_HC1_Align {
      grid-template-columns: repeat(1, 1fr);
      text-align: center;
    }
    .Temp6_HC1 .Temp6_HC1_Align .Temp6_HC1_Box {
      padding: 25px;
    }
  }
`;
