import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import API from "../../Api/ApiService";
import styled, { ThemeProvider } from "styled-components";

export default function PremiumFP1() {
  const api = new API();
  const [featureProduct, setFeatureProduct] = useState([]);

  useEffect(() => {
    api
      .featureProduct()
      .then((res) => {
        setFeatureProduct(res.data.product);
      })
      .catch((err) => {});
  }, []);
  const contentFilter = featureProduct.filter((e) => {
    return e.featured === true;
  });



  const size = {
    desktop: "1920px",
    laptop: "1440px",
    minilaptop: "1200px",
    tabletl: "992px",
    tablet: "768px",
    mobilel: "580px",
    mobilep: "480px",
    mobiles: "380px",
  };

  const device = {
    desktop: `@media screen and (max-width: ${size.desktop})`,
    laptop: `@media screen and (max-width: ${size.laptop})`,
    minilaptop: `@media screen and (max-width: ${size.minilaptop})`,
    tabletl: `@media screen and (max-width: ${size.tabletl})`,
    tablet: `@media screen and (max-width: ${size.tablet})`,
    mobilel: `@media screen and (max-width: ${size.mobilel})`,
    mobilep: `@media screen and (max-width: ${size.mobilep})`,
    mobiles: `@media screen and (max-width: ${size.mobiles})`,
  };

  const theme = {
    id: 1,
    color: "#000",
    background: "#000",
    border: "#ee8f0a",
    gray: "#888",
    bg70: "rgb(255 255 255 / 70%)",
    bglight: "#f5f5f5",
    titlesize: [
      {
        screen: "desktop",
        value: 30,
      },
      {
        screen: "tablet",
        value: 20,
      },
      {
        screen: "mobile",
        value: 20,
      },
    ],
    colcount: [
      {
        screen: "desktop",
        value: 3,
      },
      {
        screen: "tablet",
        value: 2,
      },
      {
        screen: "mobile",
        value: 1,
      },
    ],
    gap: [
      {
        screen: "desktop",
        value: 25,
      },
      {
        screen: "tablet",
        value: 20,
      },
      {
        screen: "mobile",
        value: 15,
      },
    ],
  };

  const Section = styled.section`
    display: inline-block;
    position: relative;
    width: 100%;
  `;
  const WrapperFull = styled.div`
    max-width: 100%;
    padding: 0 20px;
  `;
  const Permium1FP1Align = styled.div`
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 40px 25px;
    position: relative;

    ${device.minilaptop} {
      grid-template-columns: repeat(3, 1fr);
      gap: 40px 20px;
    }
    ${device.tabletl} {
      grid-template-columns: repeat(2, 1fr);
      gap: 30px 15px;
    }
    ${device.mobilep} {
      grid-template-columns: repeat(1, 1fr);
      gap: 30px 15px;
    }
  `;
  const PermiumFP1Box = styled.div`
    padding: 15px;
    box-shadow: 0 0 12px rgb(0 0 0 / 16%);
    display: flex;
    height: 100%;
    width: 100%;

    flex-direction: column;
    justify-content: space-between;
    border: 1px solid
      ${(props) => (props.theme.border ? props.theme.border : "#000")};
  `;
  const PermiumFP1Image = styled.div`
    display: inline-block;
    width: 100%;
    position: relative;

    img {
      width: 100%;
    }
  `;
  const PermiumFP1Content = styled.div`
    margin: 20px 0 15px 0;
    display: flex;
    flex-direction: column;
    gap: 15px;
  `;
  const PermiumFP1Title = styled.h4`
    font-size: 20px;
    font-weight: 600;
    line-height: 1.5;
    margin: 0 !important;
    color: ${(props) =>
      props.theme.color ? props.theme.color : "#000"} !important;
  `;
  // const PermiumFP1Category = styled.h5``;
  const PermiumFP1Price = styled.div`
    display: flex;
    align-items: center;
    gap: 6px;
    flex-wrap: wrap;
  `;
  const PermiumFP1SalePrice = styled.span`
    color: ${(props) => (props.theme.border ? props.theme.border : "#000")};
    font-size: 24px;
    font-weight: 700;
  `;
  const PermiumFP1MrpPrice = styled.span`
    font-size: 15px;
  `;
  const PermiumFP1Button = styled.button`
    position: relative;
    display: inline-block;
    padding: 0 0 6px 6px;
    width: fit-content;
    border: 0;
    background: transparent;
    outline: none;
    margin: auto 0 0 0;
    &:before {
      content: "";
      position: absolute;
      left: 0;
      bottom: 0;
      top: 6px;
      right: 6px;
      border: 1px solid
        ${(props) => (props.theme.background ? props.theme.background : "#000")};
      border-radius: 3px;
    }
    &:hover {
      padding: 0 0 6px 6px;
    }
    a {
      padding: 9px 20px;
      border: 0;
      background: ${(props) =>
        props.theme.background ? props.theme.background : "#000"};
      border-radius: 3px;
      color: #fff;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      font-size: 13px !important;
      display: inline-block;
      position: relative;
      z-index: 11;
    }
  `;

  return (
    <ThemeProvider theme={theme}>
      <Section className="Premium1_FP1" id={theme.id}>
        <WrapperFull>
          <h2 className="Head_Text_Temp1">Featured Products</h2>
          <Permium1FP1Align>
            {contentFilter?.slice(0, 8).map?.((e, i) => {
              let img;
              if (e.images?.length > 0) img = e.images[0];

              let link = "";
              let n = e.category.length;
              if (n > 0) {
                link = `${e.category[n - 1].category_name
                  ?.toLowerCase()
                  .replace(/ /g, "-")
                  .replace(/[^\w-]+/g, "")}/${e.description
                  ?.toLowerCase()
                  .replace(/ /g, "-")
                  .replace(/[^\w-]+/g, "")}?pid=${e._id}`;
              }
              return (
                <PermiumFP1Box key={`PreFP1_${i}`}>
                  <PermiumFP1Image>
                  <Link to={link}>
                    <img
                      alt={e.description}
                      src={api.rootUrl + e.images[0].thumbnail}
                    />
                    </Link>
                  </PermiumFP1Image>
                  <PermiumFP1Content>
                    <PermiumFP1Title>{e.description}</PermiumFP1Title>
                    {/* <PermiumFP1Category>
                      {e.category[0].category_name}
                    </PermiumFP1Category> */}
                    <PermiumFP1Price>
                      <PermiumFP1SalePrice className="sp">
                        ₹{e.sp}
                      </PermiumFP1SalePrice>
                      <PermiumFP1MrpPrice className="mrp">
                        ₹{e.mrp}
                      </PermiumFP1MrpPrice>
                    </PermiumFP1Price>

                    <PermiumFP1Button>
                      <Link to={link}>Buy Now</Link>
                    </PermiumFP1Button>
                  </PermiumFP1Content>
                </PermiumFP1Box>
              );
            })}
          </Permium1FP1Align>
        </WrapperFull>
      </Section>
    </ThemeProvider>
  );
}
