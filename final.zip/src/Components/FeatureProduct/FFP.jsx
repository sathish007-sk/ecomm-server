import React, { useState, useEffect } from 'react'
import styled from 'styled-components';
import { Link } from "react-router-dom"
import { styles } from '../../Api/Data';
import pro from "../../Assets/Images/furniture/pro.png"
import API from "../../Api/ApiService";
import Default from "../../Assets/Images/default.png";
const FFP = () => {

    const api = new API();
    const [featureProduct, setFeatureProduct] = useState([]);

    useEffect(() => {
        api
            .featureProduct()
            .then((res) => {
                setFeatureProduct(res.data.product);
            })
            .catch((err) => { });
    }, []);
    const contentFilter = featureProduct.filter((e) => {
        return e.featured === true;
    });

    return (
        <React.Fragment>
            <FeatureProduct>
                <div className='feature_product'>
                    <div className='wrapper'>
                        <H2>Featured Product</H2>
                        <ul>

                            {
                                contentFilter?.slice(0, 8).map((item) => {
                                    return (
                                        <li key={item?._id}>
                                            <div className='feature_box'>
                                                <div className='feature_img'>
                                                    <Link to={`/${item.category[0]?.category_name.toLowerCase()
                                                        .replace(/ /g, "-")
                                                        .replace(/[^\w-]+/g, "") + "/" + item?.description.toLowerCase()
                                                            .replace(/ /g, "-")
                                                            .replace(/[^\w-]+/g, "") + "?pid=" + item?._id}`}>
                                                        <img src={item.images[0].thumbnail
                                                            ? api.rootUrl + item.images[0].thumbnail
                                                            : Default} alt="Products" />
                                                    </Link>
                                                </div>
                                                <h4>{item.description}</h4>
                                                <div className='price'>
                                                    <span className='sp'>{styles?.currency}{(Number(item.sp).toFixed(0))}</span>
                                                    <span className='mrp'>{styles?.currency}{(Number(item.mrp).toFixed(0))}</span>
                                                </div>
                                                <Link to={`/${item.category[0]?.category_name.toLowerCase()
                                                    .replace(/ /g, "-")
                                                    .replace(/[^\w-]+/g, "") + "/" + item?.description.toLowerCase()
                                                        .replace(/ /g, "-")
                                                        .replace(/[^\w-]+/g, "") + "?pid=" + item?._id}`}><button>Add to Cart</button></Link>
                                            </div>
                                        </li>
                                    )
                                })}

                        </ul>
                    </div>
                </div>
            </FeatureProduct>
        </React.Fragment>
    )
}

export default FFP

const H2 = styled.h2`
   font-size:30px;
   margin : 0 0 35px;
   text-transform: uppercase;
   font-family: ${styles?.r_regular} !important;
   letter-spacing: 0.7px;

   @media screen and (max-width:768px) {
    text-align: center;
   }

`

const FeatureProduct = styled.section`
    width: 100%;
    display: inline-block;
    position: relative;

    .feature_product {
        display: inline-block;
        width: 100%;
        position: relative;
    }
    .feature_product ul {
        list-style: none;
        width: 100%;
        display: grid;
        grid-template-columns: repeat(4,1fr);
        gap: 40px 25px;
        padding: 0;
        margin: 0;
    }
    .feature_product ul li {
        width: 100%;
    display: inline-block;
    background: #fff;
    padding: 25px 20px;
    border-radius: 15px;
    box-shadow: 0 0 15px rgb(0 0 0 / 5%);
}
    .feature_product ul li .feature_box {
        width: 100%;
        display: inline-block;
    }
    .feature_product ul li .feature_box .feature_img {
        width: 100%;
        display: inline-block;
        margin: 0 0 25px;
    }
    .feature_product ul li .feature_box .feature_img img {
        width: 100%;
    }
    .feature_product ul li .feature_box h4 {
        font-size: 20px;
        line-height: 1.4;
    font-family: r_regular !important;
    text-transform: uppercase;
    color: #000;
    font-weight: 500;
    -webkit-letter-spacing: 1px;
    -moz-letter-spacing: 1px;
    -ms-letter-spacing: 1px;
    letter-spacing: 1px;
    margin: 0 0 7px;
    text-align: center;
    }
    .feature_product ul li .feature_box .price {
        display: flex;
        flex-wrap: wrap;
        width: fit-content;
        margin: auto;
        gap: 4px;
    }
    .feature_product ul li .feature_box .price span.sp {
        font-size: 18px;
        font-family: r_regular !important;
        color: #000;
    font-weight: 600;
    }
    .feature_product ul li .feature_box .price span.mrp {

    }
    .feature_product ul li .feature_box button {
        width: 100%;
        margin: 15px 0 0 0;
        border: 0;
        border-radius: 8px;
        padding: 7px 15px;
        text-align: center;
        background: linear-gradient(14.29deg, #efbc48 7.56%, #ffd064 87.33%);
        color: #206942;
        font-family: ${styles?.r_regular} !important;
    }

    @media screen and (max-width:992px) {
        .feature_product ul {
            grid-template-columns: repeat(3,1fr);
        }
    }

    @media screen and (max-width:768px) {
        .feature_product ul {
            grid-template-columns: repeat(2,1fr);
        }
    }

    @media screen and (max-width:580px) {
        .feature_product ul li {
    padding: 20px 15px;

        }
        .feature_product ul {
    grid-template-columns: repeat(2,1fr);
    gap: 30px 15px;
}


.feature_product ul li .feature_box h4 {
    font-size: 15px;
}






    }




`