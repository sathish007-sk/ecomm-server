import React, { useState, useEffect } from 'react'
import styled from 'styled-components';
import {Link} from "react-router-dom"
import { styles } from '../../Api/Data';
import { Divider,Button } from 'antd';
import pro from '../../Assets/Images/Temp/product.webp'
import bg from '../../Assets/Images/Temp/bg.jpg'
import { ShoppingCartOutlined } from '@ant-design/icons';
import API from "../../Api/ApiService";
import Default from "../../Assets/Images/default.png";
const GiftFeatureProduct = () => {
  const api = new API();
    const [featureProduct, setFeatureProduct] = useState([]);

    useEffect(() => {
        api
            .featureProduct()
            .then((res) => {
                setFeatureProduct(res.data.product);
            })
            .catch((err) => { });
    }, []);
    const contentFilter = featureProduct.filter((e) => {
        return e.featured === true;
    });
  return (
    <React.Fragment>
                <FPSection>
                    <div className='fp_section'>
                        <div className='wrapper'>
                        <HeadDivider>
                            <Divider><h2>Featured Products</h2></Divider>
                        </HeadDivider>
                        <ul>
                        {
                                contentFilter?.slice(0, 8).map((item) => {
                                    return (
                                <li key={item?._id}>
                                <div className='fp_box'>
                                    <div className='fp_img'>
                                    <Link to={`/${item.category[0]?.category_name.toLowerCase()
                                                .replace(/ /g, "-")
                                                .replace(/[^\w-]+/g, "") + "/" + item?.description.toLowerCase()
                                                    .replace(/ /g, "-")
                                                    .replace(/[^\w-]+/g, "") + "?pid=" + item?._id}`}>
                                                <img src={item.images[0].thumbnail
                                                    ? api.rootUrl + item.images[0].thumbnail
                                                    : Default} alt="Products" />
                                            </Link>
                                    </div>
                                    <div className='fp_content'>
                                        <h4>{item.description}</h4>
                                        <div className='fp_content_align'>
                                        <div className='fp_price'>
                                            <span className='sp'>{styles?.currency}{(Number(item.sp).toFixed(0))}</span>
                                            <span className='mrp'>{styles?.currency}{(Number(item.mrp).toFixed(0))}</span>
                                        </div>
                                        <Link to={`/${item.category[0]?.category_name.toLowerCase()
                                                        .replace(/ /g, "-")
                                                        .replace(/[^\w-]+/g, "") + "/" + item?.description.toLowerCase()
                                                            .replace(/ /g, "-")
                                                            .replace(/[^\w-]+/g, "") + "?pid=" + item?._id}`}><Button type='primary' size='small'><ShoppingCartOutlined /> Buy Now</Button></Link>
                                        </div>
                                    </div>
                                </div>
                            </li>
                                    )
                                })}
                            
                           

                        </ul>
                        </div>
                    </div>                    
                </FPSection>
            </React.Fragment>
  )
}

export default GiftFeatureProduct;


const HeadDivider = styled.div`
display: inline-block;
margin: 0 0 55px;
width: 100%;
    h1, h2 {
        margin: 0 !important;
        font-size: 30px !important;
        font-weight: 600;
        font-family: ${styles?.medium} !important;
    }
    .ant-divider-horizontal.ant-divider-with-text {
        border-top-color: ${styles?.color} !important;
        margin: 0;
    }

@media screen and (max-width:1200px) {
    margin: 0 0 40px;
}
@media screen and (max-width:480px) {
    h1, h2 {
        font-size: 27px !important;
    }

}

`
const FPSection = styled.section`
    display: inline-block;
    position: relative;
    width: 100%;
    background: url(${bg});
    background-repeat: repeat;
    padding: 80px 0;

    ul {
        list-style: none;
        padding: 0;
        margin: 0;
        display: grid;
        grid-template-columns: repeat(4,1fr);
        gap: 50px 25px;
    }
    ul li {
        width: 100%;
        display: inline-block;
        position: relative;
        box-shadow: 0 0 30px rgb(0 0 0 / 10%);
    border-radius: 6px;
    overflow: hidden;
    background: #fff;
    }
    ul li .fp_box, ul li .fp_box .fp_img {
        width: 100%;
        display: flex;
    flex-direction: column;
    }
    ul li .fp_box .fp_img img {
        width: 100%;
        display: flex;
        align-items: center;
    }
    ul li .fp_box .fp_content {
        width: 100%;
        display: inline-block;
        padding: 15px 20px 20px 20px;
        background: #fff;
    }
    ul li .fp_box .fp_content h4 {
        text-align: left;
        font-size: 15px;
        font-family: ${styles?.regular}!important;
        line-height: 1.7;
        color: ${styles?.color};
        margin: 0 !important;
    }
    ul li .fp_box .fp_content .fp_price {
        display: flex;
        align-items: center;
        gap: 6px;
    }
    ul li .fp_box .fp_content .fp_price span.sp {
        font-size: 18px;
        font-family: ${styles?.bold};
    }
    ul li .fp_box .fp_content .fp_price span.mrp {
        font-size: 12px;
    }
    ul li .fp_box .fp_content button {
        display: flex;
        align-items: center;
        padding: 4px 7px;
        height: auto;
        font-size: 12px;
    } 
    .fp_content_align {
        display: flex;
        align-items: center;
        gap: 20px;
        justify-content: space-between;
        flex-wrap: wrap;
        margin: 25px 0 0 0;
    }


    @media screen and (max-width:1200px) {
        padding: 50px 0;
    }


    @media screen and (max-width:992px) {
        ul {
    grid-template-columns: repeat(3,1fr);
    gap: 30px 20px;
}
    }


    @media screen and (max-width:768px) {
         ul {
    grid-template-columns: repeat(2,1fr);
    gap: 30px 15px;
}
    }

    @media screen and (max-width:480px) {
       
        ul li .fp_box .fp_content {
            padding: 15px 15px 20px 15px;
        }
        ul li .fp_box .fp_content h4 {
            font-size: 14px;
            line-height: 1.5;
        }
        .fp_content_align {
            margin: 14px 0 0 0;
            gap: 9px;
        }


    }







`