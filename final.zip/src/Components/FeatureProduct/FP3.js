import React, { useState, useEffect } from "react";
import { ShoppingCartOutlined } from "@ant-design/icons";
import { Link } from "react-router-dom";
import { Tabs } from "antd";
import DefaultImg from "../../Assets/Images/default.png";
import "antd/dist/antd.css";
import styled from "styled-components";
import { styles } from "../../Api/Data";
import API from "../../Api/ApiService";
const user = JSON.parse(localStorage.getItem("persist:root"))?.company;
const colorCustom = user && JSON.parse(user).setColor;

export default function FP3() {
  const api = new API();
  const [featureProduct, setFeatureProduct] = useState([]);

  useEffect(() => {
    api
      .featureProduct()
      .then((res) => {
        setFeatureProduct(res.data.product);
      })
      .catch((err) => {});
  }, []);
  const contentFilter = featureProduct.filter((e) => {
    return e.featured === true;
  });

  const items = [
    {
      label: "Featured",
      key: "1",
      children: (
        <div className="Temp3_FP_Box_Align">
          {contentFilter?.map?.((e, i) => {
            let img;
            if (e.images?.length > 0) img = e.images[0];

            let link = "";
            let n = e.category.length;
            if (n > 0) {
              link = `${e.category[n - 1].category_name
                ?.toLowerCase()
                .replace(/ /g, "-")
                .replace(/[^\w-]+/g, "")}/${e.description
                ?.toLowerCase()
                .replace(/ /g, "-")
                .replace(/[^\w-]+/g, "")}?pid=${e._id}`;
            }
            return (

              <div className="Temp3_FP_Box" key={`FE3_${i}`}>
                <div className="Temp3_FP_Box_Image">
                <Link to={link}>
                  <img
                    alt="Chettinad Baskets set of 5 with lids"
                    className="ant-image-img"
                    src={
                      e.images[0].thumbnail
                        ? api.rootUrl + e.images[0].thumbnail
                        : DefaultImg
                    }
                  />
                  </Link>
                </div>
                <div className="Temp3_FP_Box_Content">
                  <h4>{e.description}</h4>
                  <div className="ant-card-meta-description">
                    <span className="price">
                      <span className="sp">₹{e.sp}</span>
                      <span className="mrp">₹{e.mrp}</span>
                    </span>
                  </div>
                  <div className="Temp3_FP_Box_Buynow">
                    <Link to={link}>
                      <button>
                        <span>Buy Now</span>

                        <ShoppingCartOutlined />
                      </button>
                    </Link>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      ),
    },
  ];

  return (
    <React.Fragment>
      <FPSection>
      {contentFilter.length > 1 ? (
    <section className="Temp3_FP_Section">
      <div className="wrapper">
        <div className="Temp3_FP_Align">
          <div className="Temp3_FP_Top">
            <Tabs items={items} centered />
          </div>
          <div className="feature_product_3_bottom"></div>
        </div>
      </div>
    </section>
   
    ) : (
      ""
    )}
     </FPSection>
  </React.Fragment>
  );
}


const FPSection = styled.div`



.Temp3_FP_Section {
  display: inline-block;
  margin: 0px 0;
  position: relative;
  width:100%;
}
.Temp3_FP_Section .Temp3_FP_Box_Align {
  display: grid;
  grid-template-columns: repeat(4,1fr);
  gap: 40px 25px;
  margin: 40px 0 0;
}
.Temp3_FP_Section .Temp3_FP_Box_Align .Temp3_FP_Box {
  display: inline-block;
  width: 100%;
}

.Temp3_FP_Section .ant-tabs-nav {
    position: relative;
    display: flex;
    flex: none;
    align-items: center;
    
}
.Temp3_FP_Section .ant-tabs-nav .ant-tabs-nav-wrap {
  width: 100%;
    margin: auto;
    flex: none !important;
}
.Temp3_FP_Section .ant-tabs-nav .ant-tabs-nav-wrap .ant-tabs-tab.ant-tabs-tab-active .ant-tabs-tab-btn {
  text-shadow: 0 0 0.25px currentColor;
  font-size: 16px;
}
.Temp3_FP_Section .ant-tabs-nav .ant-tabs-nav-wrap .ant-tabs-tab {
  font-size: 16px;
}

.Temp3_FP_Section .Temp3_FP_Box_Align .Temp3_FP_Box {
  border: 1px solid ${styles?.light};
  border-radius: 5px;
  display: grid;
}
.Temp3_FP_Section .Temp3_FP_Box_Align .Temp3_FP_Box .Temp3_FP_Box_Image {
  width: 100%;
  display: flex;
  position: relative;
  height: auto;
  flex-wrap: wrap;
  align-items: center;
  a {
    width: 100%;
  }
}
.Temp3_FP_Section .Temp3_FP_Box_Align .Temp3_FP_Box .Temp3_FP_Box_Image img {
  height: 100%;
  width: 100%;
  object-fit: cover;
  background: transparent;
  padding: 10px;
}
.Temp3_FP_Section .Temp3_FP_Box_Align .Temp3_FP_Box .Temp3_FP_Box_Content {
  width: 100%;
  display: flex;
  gap: 14px;
  padding: 20px 16px;
  justify-content: space-between;
  margin: auto auto 0 0;
  flex-direction: column;
  align-items: flex-start;
}
.Temp3_FP_Section .Temp3_FP_Box_Align .Temp3_FP_Box .Temp3_FP_Box_Content .Temp3_FP_Box_Buynow {
  margin: auto auto 0 0 ;
}
.Temp3_FP_Section .Temp3_FP_Box_Align .Temp3_FP_Box .Temp3_FP_Box_Content h4 {
  font-size: 18px !important;
  line-height: 1.5;
  margin: 0 0 0px;
  text-align: left;
  font-family: ${styles?.regular} !important;
}
.Temp3_FP_Section .Temp3_FP_Box_Align .Temp3_FP_Box .Temp3_FP_Box_Content .ant-card-meta-description {
  width: 100%;
  display: inline-block;
  position: relative;
}
.Temp3_FP_Section .Temp3_FP_Box_Align .Temp3_FP_Box .Temp3_FP_Box_Content .ant-card-meta-description span.price {
  width: fit-content;
  margin: 0;
}
.Temp3_FP_Section .Temp3_FP_Box_Align .Temp3_FP_Box .Temp3_FP_Box_Content .ant-card-meta-description span.price span.sp {
  position: relative;
  font-size: ${styles?.p};
  color: ${styles?.color};
  font-family: ${styles?.medium} !important;
}
.Temp3_FP_Section .Temp3_FP_Box_Align .Temp3_FP_Box .Temp3_FP_Box_Content .ant-card-meta-description span.price span.mrp {
  position: relative;
}
.Temp3_FP_Section .Temp3_FP_Box_Align .Temp3_FP_Box .Temp3_FP_Box_Content .Temp3_FP_Box_Buynow button {
  display: flex;
  margin: 0px 0 0;
  background: ${styles?.colorapi};
  color: ${styles?.white};
  border: 0;
  outline: none;
  padding: 7px 10px;
  width: 90px;
  position: relative;
  border-radius: 5px;
  height: 35px;
  overflow: hidden;
  font-size: 13px;
  transition: all 0.4s ease-in-out;
}
.Temp3_FP_Section .Temp3_FP_Box_Align .Temp3_FP_Box .Temp3_FP_Box_Content .Temp3_FP_Box_Buynow button span:nth-child(1) {
  font-size: 12px;
  text-align: center;
  width: 100%;
  display: inline-block;
  font-weight: 600;
  letter-spacing: 0.5px;
  text-transform: uppercase;
  transition: all 0.4s ease-in-out;
  position: absolute;
  top:50%;
  left:50%;
  transform: translate(-50%,-50%);
}
.Temp3_FP_Section .Temp3_FP_Box_Align .Temp3_FP_Box .Temp3_FP_Box_Content .Temp3_FP_Box_Buynow button span:nth-child(2) {
  position: absolute;
    transform: translate(-50%, -50%) translateY(30px);
    top: 50%;
    left: 50%;
    font-size: 20px;
    font-weight: 700;
    transition: all 0.4s ease-in-out;
}
.Temp3_FP_Section .Temp3_FP_Box_Align .Temp3_FP_Box .Temp3_FP_Box_Content .Temp3_FP_Box_Buynow button:hover span:nth-child(1) {
  transform: translate(-50%,-50%) translateY(-30px);
}
.Temp3_FP_Section .Temp3_FP_Box_Align .Temp3_FP_Box .Temp3_FP_Box_Content .Temp3_FP_Box_Buynow button:hover span:nth-child(2) {
  transform: translate(-50%, -50%) translateY(0px);
}

.Temp3_FP_Section .ant-tabs > .ant-tabs-nav .ant-tabs-nav-list, .Temp3_FP_Section .ant-tabs > div > .ant-tabs-nav .ant-tabs-nav-list {
  position: relative;
  display: flex;
  transition: transform 0.3s;
  align-items: center;
  justify-content: center;
  width: 100%;
}
.Temp3_FP_Section .ant-tabs-tab.ant-tabs-tab-active .ant-tabs-tab-btn {
  font-size: ${styles?.h2} !important;
  font-family: ${styles?.bold} !important;
  color: ${colorCustom?.color ? colorCustom?.color : styles?.color} !important;
  line-height: 1.4;
  margin: 0 0 0px;
  text-align: center;
  text-shadow: 0 0 0.25px currentColor;
}
.Temp3_FP_Section .ant-tabs-ink-bar {
  position: absolute;
  background: ${styles?.colorapi};
  pointer-events: none;
}
.Temp3_FP_Section .ant-tabs-tab:hover {
  color: ${styles?.colorapi};
}


@media screen and (max-width:992px) {
  .Temp3_FP_Section .Temp3_FP_Box_Align {
  grid-template-columns: repeat(3,1fr);
  gap: 30px 15px;
  margin: 30px 0 0 0;
}


  
}


@media screen and (max-width:768px) {
  .Temp3_FP_Section .Temp3_FP_Box_Align {
  grid-template-columns: repeat(2,1fr);
}  
}


@media screen and (max-width:380px) {


.Temp3_FP_Section .Temp3_FP_Box_Align {
  grid-template-columns: repeat(1,1fr);
}



}












`