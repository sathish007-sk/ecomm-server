import React, { useState, useEffect } from "react";
import { Tabs } from "antd";
import { Link } from "react-router-dom";
import { Swiper, SwiperSlide } from "swiper/react";
import { Navigation, Pagination, Autoplay } from "swiper";
import "swiper/css";
import "swiper/scss/pagination";
import API from "../../Api/ApiService";
import DefaultImg from "../../Assets/Images/default.png";
import styled from "styled-components";
import { styles } from "../../Api/Data";
const user = JSON.parse(localStorage.getItem("persist:root"))?.company;
const colorCustom = user && JSON.parse(user).setColor;

function FP2() {
  const api = new API();
  const [featureProduct, setFeatureProduct] = useState([]);

  useEffect(() => {
    api
      .featureProduct()
      .then((res) => {
        setFeatureProduct(res.data.product);
      })
      .catch((err) => {});
  }, []);
  const contentFilter = featureProduct.filter((e) => {
    return e.featured === true;
  });

  const items = [
    {
      label: "Featured",
      key: "1",
      children: (
        <React.Fragment>
          <FPSection>
            <Swiper
              className="temp2__slide"
              slidesPerView={4}
              spaceBetween={20}
              freeMode={true}
              Navigation={true}
              loop={true}
              breakpoints={{
                320: {
                  slidesPerView: 1,
                  spaceBetween: 40,
                },
                400: {
                  slidesPerView: 2,
                  spaceBetween: 10,
                },
                580: {
                  slidesPerView: 2,
                  spaceBetween: 10,
                },
                768: {
                  slidesPerView: 3,
                  spaceBetween: 20,
                },
                1200: {
                  slidesPerView: 4,
                  spaceBetween: 20,
                },
              }}
              autoplay={{
                delay: 2500,
                disableOnInteraction: true,
              }}
              modules={[Pagination, Autoplay, Navigation]}
            >
              {contentFilter?.map((e, i) => {
                let img;
                if (e.images?.length > 0) img = e.images[0];

                let link = "";
                let n = e.category.length;
                if (n > 0) {
                  link = `${e.category[n - 1].category_name
                    ?.toLowerCase()
                    .replace(/ /g, "-")
                    .replace(/[^\w-]+/g, "")}/${e.description
                    ?.toLowerCase()
                    .replace(/ /g, "-")
                    .replace(/[^\w-]+/g, "")}?pid=${e._id}`;
                }

                return (
                  <SwiperSlide key={`FE2_${i}`}>
                    <div className="Temp2_FP_Slider_Box">
                      <div className="Temp2_FP_Slider_Box_Align">
                        <div className="Temp2_FP_Slider_Box_Image">
                          <Link to={link}>
                            <img
                              src={
                                e.images[0].thumbnail
                                  ? api.rootUrl + e.images[0].thumbnail
                                  : DefaultImg
                              }
                            />
                          </Link>
                        </div>
                        <h3>{e.description}</h3>
                        <h4>{e.category[0].category_name}</h4>
                        <p>₹{e.sp}</p>
                      </div>
                    </div>
                  </SwiperSlide>
                );
              })}
            </Swiper>
          </FPSection>
        </React.Fragment>
      ),
    },
  ];

  return (
    <React.Fragment>
      <FPSection>
      {contentFilter.length > 1 ? (
        <section className="Temp2_FP_Section">
          <div className="Wrapper_Full">
            <Tabs items={items} centered />
          </div>
        </section>
      ) : (
        ""
      )}
      </FPSection>
    </React.Fragment>
  );
}

export default FP2;



const FPSection = styled.div`

.Temp2_FP_Section {
  width: 100%;
  display: inline-block;
  position: relative;
}
.Temp2_FP_Section .ant-tabs-tab.ant-tabs-tab-active .ant-tabs-tab-btn,
.Temp2_FP_Section .ant-tabs-tab-btn {
  font-size: ${styles?.h2};
  font-family: ${styles?.bold} !important;
  color: ${colorCustom?.color ? colorCustom?.color : styles?.color} !important;
  line-height: 1.4;
}
.Temp2_FP_Section .ant-tabs-tab-btn {
  color: ${styles?.light};
}
.Temp2_FP_Section .ant-tabs-tab-btn:focus,
.Temp2_FP_Section .ant-tabs-tab-remove:focus,
.Temp2_FP_Section .ant-tabs-tab-btn:active,
.Temp2_FP_Section .ant-tabs-tab-remove:active {
  color: ${styles?.colorapi};
}
.Temp2_FP_Section .ant-tabs-ink-bar {
  background: ${styles?.colorapi};
}
.Temp2_FP_Section .ant-tabs-nav {
  margin: 0 0 35px !important;
}
.Temp2_FP_Section .swiper-slide {
  display: flex;
  border: 1px solid ${styles?.light};
}

.Temp2_FP_Section .swiper, .Temp2_FP_Section .swiper-wrapper, .Temp2_FP_Section .swiper-slide {
  display: flex;
  
}
.Temp2_FP_Section .swiper-slide {
  display: grid;
  height: 100%;
}
.Temp2_FP_Section .Temp2_FP_Slider_Box {
  display: grid;
  position: relative;
  padding: 30px;
  
}
.Temp2_FP_Section .Temp2_FP_Slider_Box .Temp2_FP_Slider_Box_Align {
  display: grid;
  position: relative;
}
.Temp2_FP_Section .Temp2_FP_Slider_Box .Temp2_FP_Slider_Box_Align .Temp2_FP_Slider_Box_Image {
  width: 100%;
  display: inline-block;
  position: relative;
}
.Temp2_FP_Section .Temp2_FP_Slider_Box .Temp2_FP_Slider_Box_Align .Temp2_FP_Slider_Box_Image a {
  width: 100%;
  display: inline-block;
  position: relative;
}
.Temp2_FP_Section .Temp2_FP_Slider_Box .Temp2_FP_Slider_Box_Align .Temp2_FP_Slider_Box_Image a img {
  width: 100%;
}
.Temp2_FP_Section .Temp2_FP_Slider_Box .Temp2_FP_Slider_Box_Align h3 {
  text-align: center;
  font-size: ${styles?.h5};
  color: ${styles?.color} !important;
  font-family: ${styles?.medium} !important;
  line-height: 1.5;
  margin: 15px 0 10px 0;
  min-height: 60px;
}
.Temp2_FP_Section .Temp2_FP_Slider_Box .Temp2_FP_Slider_Box_Align h4 {
  text-align: center;
  color: ${styles?.gray} !important;
  font-size: ${styles?.p};
  font-family: ${styles?.regular} !important;
  margin: 0 0 10px;
}
.Temp2_FP_Section .Temp2_FP_Slider_Box .Temp2_FP_Slider_Box_Align p {
  text-align: center;
  font-size: ${styles?.h5};
  color: ${styles?.color} !important;
  font-family: ${styles?.medium} !important;
  line-height: 1.5;
  margin: auto auto 0 auto;
}
.Temp2_FP_Section .Temp2_FP_Card {
  display: inline-block;
  width: 100%;
  padding: 12px;
  margin: 0;
}
.Temp2_FP_Section .Temp2_FP_Card img {
  width: 100%;
  display: inline-block;
}
.Temp2_FP_Section .Temp2_FP_Card p {
  text-align: center;
  color: ${styles?.color};
  text-align: center;
  margin: 15px 0 0 0;
  font-size: ${styles?.p};
  font-family: ${styles?.regular};
  padding: 0px 0;
}

@media screen and (max-width:768px) {
  .Temp2_FP_Section .ant-tabs-tab-btn {
    font-size: 15px;
  }
  .Temp2_FP_Section .Temp2_FP_Slider_Box {
    padding: 15px;
  }
  
 
.Temp2_FP_Section .Temp2_FP_Slider_Box .Temp2_FP_Slider_Box_Align h3 {
  font-size: ${styles?.p};
}

.Temp2_FP_Section .ant-tabs-tab + .ant-tabs-tab {
  margin: 0 0 0 15px;
}
}


@media screen and (max-width:480px) {


 .Temp2_FP_Section .ant-tabs-tab-btn {
  font-size: 12px;
}
.Temp2_FP_Section .ant-tabs-tab + .ant-tabs-tab {
  margin: 0 0 0 10px;
}


}







`;