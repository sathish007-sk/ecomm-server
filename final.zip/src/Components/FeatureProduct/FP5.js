import React, { useState, useEffect } from "react";
import { Tabs } from "antd";
import { Link } from "react-router-dom";
import "swiper/css";
import "swiper/scss/pagination";
import DefaultImg from "../../Assets/Images/default.png";
import API from "../../Api/ApiService";
import styled from "styled-components";
import { styles } from "../../Api/Data";
const user = JSON.parse(localStorage.getItem("persist:root"))?.company;
const colorCustom = user && JSON.parse(user).setColor;

function FP5() {
  const api = new API();
  const [featureProduct, setFeatureProduct] = useState([]);

  useEffect(() => {
    api
      .featureProduct()
      .then((res) => {
        setFeatureProduct(res.data.product);
      })
      .catch((err) => {});
  }, []);
  const contentFilter = featureProduct.filter((e) => {
    return e.featured === true;
  });

  const items = [
    {
      label: 'Featured', key: '1', children:
      
      <div className="Temp5_FP_Box_Align">
        {contentFilter?.map?.((e, i) => {
          let img;
          if (e.images?.length > 0) img = e.images[0];

          let link = "";
          let n = e.category.length;
          if (n > 0) {
            link = `${e.category[n - 1].category_name
              ?.toLowerCase()
              .replace(/ /g, "-")
              .replace(/[^\w-]+/g, "")}/${e.description
              ?.toLowerCase()
              .replace(/ /g, "-")
              .replace(/[^\w-]+/g, "")}?pid=${e._id}`;
          }

          return (
            <div className="Temp5_FP_Box" key={`fp_t1${i}`}>
              <div className="Temp5_FP_Img">
                <Link to={link}>
                  <img className="Temp5_FP_img"
                    src={
                      e.images[0].thumbnail
                        ? api.rootUrl + e.images[0].thumbnail
                        : DefaultImg
                    }
                  />
                </Link>
              </div>
              <div className="Temp5_FP_content">
                <h4>{e.description}</h4>
                <p>{e.category[0].category_name}</p>
                <span className="Temp5_FP_Price">₹{e.sp}</span>
              </div>
            </div>

          );
        })}
      </div> }, // remember to pass the key prop
  
  ];

    return (
      <React.Fragment>
        <FPSection>
      {contentFilter.length > 1 ? (
        <section className="Temp5_FP_Section">
            <div className="Wrapper_Full">
                <div className="Temp5_FP_Align">
              <Tabs items={items} centered/>  
                </div>
            </div>
        </section>
         ) : (
          ""
        )}
        </FPSection>
      </React.Fragment>
    );
}

export default FP5;



const FPSection = styled.div`

.Wrapper_Full {
  max-width: 1200px;
  padding: 0 10px;
  margin: auto;
}
.Temp5_FP_Box_Align {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 20px;
}

.Temp5_FP_Box:nth-child(odd) {
  display: flex;
  flex-direction: column;
}

.Temp5_FP_Box:nth-child(even) {
  display: flex;
  flex-direction: column-reverse;
}

.Temp5_FP_Box {
  border: 2px solid #7a797942;
  box-shadow: -13px 17px 1px -6px #c7c4c4;
  text-align: center;
  padding: 12px;
}

.Temp5_FP_Section .ant-tabs-tab.ant-tabs-tab-active .ant-tabs-tab-btn,
.Temp5_FP_Section .ant-tabs-tab-btn {
  font-size: ${styles?.h2};
  font-family: ${styles?.bold} !important;
  color: ${colorCustom?.color ? colorCustom?.color : styles?.color} !important;
  line-height: 1.4;
}

.Temp5_FP_Section .ant-tabs-tab-btn {
  color: ${styles?.gray};
}
.Temp5_FP_Section .ant-tabs-tab-btn:focus,
.Temp5_FP_Section .ant-tabs-tab-remove:focus,
.Temp5_FP_Section .ant-tabs-tab-btn:active,
.Temp5_FP_Section .ant-tabs-tab-remove:active {
  color: ${colorCustom?.color} !important;
}
.Temp5_FP_Section .ant-tabs-ink-bar {
  background: ${colorCustom?.color};
}
.Temp5_FP_Section .ant-tabs-nav {
  margin: 0 0 35px !important;
}

.Temp5_FP_Box h4 {
  font-size: 16px;
}

.Temp5_FP_Box p {
  font-size: 16px;
  margin: 0px;
}

.Temp5_FP_Align .ant-tabs-tab-btn {
  font-size: 25px;
}

.Temp5_FP_Align .ant-tabs-tab.ant-tabs-tab-active .ant-tabs-tab-btn {
  color: black;
}

.Temp5_FP_Box:nth-child(even) .Temp5_FP_content {
  flex-direction: column;
  display: flex;
}

.Temp5_FP_img {
  border-radius: 100%;
  background: #00000042;
  height: 200px;
  margin: 0 auto;
}
.Temp5_FP_content{
  margin: 10px;
}

@media screen and (max-width:992px) {
  .Temp5_FP_Box_Align {
    grid-template-columns: repeat(3, 1fr);
  }
}


@media screen and (max-width:768px) {
  .Temp5_FP_Box_Align {
    grid-template-columns: repeat(2, 1fr);
  }
}

@media screen and (max-width:600px) {
  .Temp5_FP_Box_Align {
    grid-template-columns: repeat(1, 1fr);
  }
}

@media screen and (max-width:480px) {
  .Temp5_FP_Box_Align {
    grid-template-columns: repeat(1, 1fr);
  }
}




`;