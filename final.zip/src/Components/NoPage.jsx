import React from 'react'
import { Button, Empty } from "antd";
import styled from 'styled-components';
import { styles } from './../Api/Data';
import { Link } from 'react-router-dom';
const NoPage = () => {
  return (
    <React.Fragment>
      <PageEmpty>
        <h1>Oops that page Con't be Found!!</h1>
        <Empty />
        <Link to="/">
          <Button>Home</Button>
        </Link>
      </PageEmpty>
    </React.Fragment>
  );
}

export default NoPage;


const PageEmpty = styled.div`
  max-width: 1200px;
  margin: 60px auto;
  display: flex;
  flex-wrap: wrap;
  min-height: 300px;
  border: 0px solid ${styles.light};
  align-items: center;
  justify-content: center;
  flex-direction: column;
  gap: 50px;
  h1 {
    margin: 0;
    font-size: 30px;
    width:100%;
    display:inline-block;
    text-align: center;
  }

`;
