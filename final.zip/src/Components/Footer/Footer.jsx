import React from "react";
import { styles } from "../../Api/Data";
import { Link } from "react-router-dom";
import styled from "styled-components";
import { useSelector } from "react-redux";
import {  Tooltip, Avatar } from "antd";
import API from "../../Api/ApiService";
const Footer = () => {
  const api = new API();
  const company = useSelector((state) => {
    return state.company?.value;
  });
  const socialMediaLink = useSelector(
    (state) => state.company?.socialMediaLinks
  );

  

  return (
    <React.Fragment>
      <FooterSection>
        <Wrapper>
          <FooterAlign>
            <Footer1>
              <Link to="/">
                <H2>
                  <Img src={company?.logo ? company?.logo : ""} />
                </H2>
              </Link>
              <P>
                {company.address?.address_line1 ? company.address?.address_line1 : ""}, 
                {company.address?.address_line2 ? company.address?.address_line2 : ""}, 
                {company.address?.area ? company.address?.area : ""}, 
                {company.address?.district.name ? company.address?.district.name : ""}, 
                {company.address?.state.name ? company.address?.state.name : ""}, 
                {company.address?.country.name ? company.address?.country.name : ""} - 
                {company.address?.pincode ? company.address?.pincode : ""}
              </P>
               <Ul>
                {socialMediaLink.map((e, i) => (
                  <Tooltip title={e.label} key={`smL${i}`}>
                    <a href={e.link} target="_blank">
                      <Avatar gap={4} src={api.rootUrl + e.icon}></Avatar>
                    </a>
                  </Tooltip>
                ))}
              </Ul>
            </Footer1>
            <Footer2>
              <FTitle>Useful Links</FTitle>
              <List>
                <Link to="/">
                  <Items>Privacy Policy</Items>
                </Link>
                <Link to="/">
                  <Items>Terms and Conditions</Items>
                </Link>
                <Link to="/">
                  <Items>Refund Policy</Items>
                </Link>
                <Link to="/">
                  <Items>Delivery Policy</Items>
                </Link>
                <Link to="/">
                  <Items>Return Policy</Items>
                </Link>
                <Link to="/">
                  <Items>Cancellation Policy</Items>
                </Link>
              </List>
            </Footer2>

            <Footer4>
              <FTitle>Contact Us</FTitle>
              <P>

                <a href={'tel:' + company?.mobile_no ? company?.mobile_no : "#"}>+91 {company?.mobile_no ? company?.mobile_no : ""}</a>
              </P>
              <P>

                <a href={'tel:' + company?.landline_no ? company?.landline_no : "#"}>{company?.landline_no ? company?.landline_no : ""}</a>
              </P>
              <P>

                <a href={'mailto:' + company?.email ? company?.email : "#"}>{company?.email ? company?.email : ""}</a>
              </P>


            </Footer4>
            <Footer5>
              <FTitle>Our Location</FTitle>
              {company?.map && (
                <iframe
                  src={company?.map}
                  width="100%"
                  height="200"
                  style={{ border: 0 }}
                  allowFullScreen=""
                  loading="lazy"
                ></iframe>
              )}
            </Footer5>
          </FooterAlign>
        </Wrapper>
      </FooterSection>
    </React.Fragment>
  );
};

export default Footer;

const FooterSection = styled.footer`
  display: inline-block;
  margin: 60px 0 0 0;
  position: relative;
  width: 100%;
  padding: 60px 0;
  background: ${styles.light};
`;
const Wrapper = styled.div`
  max-width: 1200px;
  margin: auto;
`;
const FooterAlign = styled.div`
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  flex-wrap: wrap;
  width: 100%;
`;
const Footer1 = styled.div`
  display: inline-block;
  width:25%;
  position: relative;
`;
const Footer2 = styled.div`
  width:fit-content;
  display: inline-block;
`;
const Footer3 = styled.div`
  width: fit-content;
  display: inline-block;
`;
const Footer4 = styled.div`
  width: 25%;
  display: inline-block;
`;
const H2 = styled.h2`
  border-radius: 2px;
  height: auto;
  width: fit-content;
  margin: 0 0 20px;
  font-size: 25px;
  font-weight: 700;
  text-transform: uppercase;
`;

const Img = styled.img`
height: 50px;
`;
const P = styled.div`
  color:${styles.color};
  line-height: 1.6;
  font-size: 16px;
  display: flex;
  align-items: center;
  gap: 10px;
  :not(:last-child) {
    margin: 0 0 15px;
  }
`;
const Ul = styled.div`
  display: flex;
  margin: 25px 0 0 0;
  align-items: center;
  gap: 20px;
`;
const Li = styled.div`
  color: ${styles.color};
  svg {
    height: 35px;
    color: ${styles.color} !important;
    path {
      color: ${styles.color} !important;
    }
  }
`;
const FTitle = styled.div`
  font-size: 25px;
  line-height: 1.5;
  margin: 0 0 25px;
  font-weight: 600;
  color: ${styles.color};
`;
const Payment = styled.img`
  max-width: 100%;
  width: 100%;
  margin: 12px 0 0 0;
`;
const List = styled.div`
  display: inline-block;
  width:100%;
  position: relative;
`;
const Items = styled.div`
  color: ${styles.color};
  position: relative;
  line-height: 1.8;

  font-size: 16px;
  :not(:last-child) {
    margin: 0 0 8px;
  }
`;

const Footer5 = styled.div`
width: 23%;
display: inline-block;
`;