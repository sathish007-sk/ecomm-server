import React, { useState, useEffect } from "react";
import { Layout, Row, Col, Avatar, Tooltip, Space } from "antd";
import { Link } from "react-router-dom";
import API from "../../Api/ApiService";
import { MailFilled, PhoneFilled, MobileFilled } from "@ant-design/icons";
import { useSelector } from "react-redux";
import styled from "styled-components";
import { styles } from "../../Api/Data";
const user = JSON.parse(localStorage.getItem("persist:root"))?.company;
const colorCustom = user && JSON.parse(user).setColor;
const { Header, Footer, Sider, Content } = Layout;

export default function Footer6(props) {
  const company = useSelector((state) => state.company?.value);

  const socialMediaLink = useSelector(
    (state) => state.company?.socialMediaLinks
  );
  const year = new Date().getFullYear();
  const api = new API();
  // const [socialMediaLink, setSocialMediaLink] = useState([]);

  const FooterLinks = [
    { path: "/", title: "Home" },
    { path: "/about", title: "About Us" },
    { path: "/contact", title: "Contact Us" },
    { path: "/enquiry", title: "Enquiry" },
  ];

  const OtherLinks = [
    { path: "/privacy-policy", title: "Privacy Policy" },
    { path: "/terms", title: "Terms and Conditions" },
    { path: "/refund-policy", title: "Refund Policy" },
    { path: "/delivery-policy", title: "Delivery Policy" },
    { path: "/return-policy", title: "Return Policy" },
    { path: "/cancellation-policy", title: "Cancellation Policy" },
  ];

  return (
    <React.Fragment>
      <FooterSection>
<section className="Template6_Footer">
        <div className="Template6_Footer_Align">
          <div className="Template6_Footer_Align_Bottom">
            <div className="Template6_Footer_Logo">
              <img src={company.logo} />
            </div>
            <div>
              <ul className="Template6_Footer_QuickLinks">
                {OtherLinks.map((e, i) => (
                  <li key={`qL_${i}`}>
                    <Link to={e.path}>{e.title}</Link>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
        <footer className="Template6_Footer_CopyRights">
          <div>
            &copy; {year} Designed by{" "}
            <a href="https://blazon.in" target="_blank">
              Blazon
            </a>
          </div>
          <div className="Template6_Footer_get_directions"><a href={company.map} target="_blank">GET DIRECTIONS</a></div>
        </footer>
      </section>
      </FooterSection>
    </React.Fragment>
    
  );
}


const FooterSection = styled.div`
display: inline-block;
position: relative;
width: 100%;



.Template6_Footer * {
  margin: 0%;
  padding: 0%;
  box-sizing: border-box;
}
.Template6_Footer {
  display: inline-block;
  padding: 20px 0 0 0;
  width: 100%;
  text-align: center;
  border: 1px solid ${styles?.light};
}
.Template6_Footer .Template6_Footer_Align {
  display: inline-block;
  width: 100%;
  padding: 25px 0;
}
.Template6_Footer .Template6_Footer_Align .Template6_Footer_Align_Top {
  display: inline-block;
  width: 100%;
  position: relative;
  margin: 0 0 0px;
}
.Template6_Footer .Template6_Footer_Align .Template6_Footer_Align_Top iframe {
  padding: 0%;
  outline: none;
  height: 350px;
  width: 100%;
}
.Template6_Footer .Template6_Footer_Align .Template6_Footer_Align_Bottom {
  width: 100%;
  display: inline-block;
  // padding: 25px 0;
}
.Template6_Footer
  .Template6_Footer_Align
  .Template6_Footer_Align_Bottom
  .Template6_Footer_Logo {
  width: 100%;
  display: inline-block;
  margin: 0 0 15px;
}
.Template6_Footer
  .Template6_Footer_Align
  .Template6_Footer_Align_Bottom
  .Template6_Footer_Logo
  img {
  height: 80px;
  display: flex;
  margin: auto;
}
.Template6_Footer
  .Template6_Footer_Align
  .Template6_Footer_Align_Bottom
  .Template6_Footer_Address {
  width: 100%;
  display: inline-block;
}
.Template6_Footer
  .Template6_Footer_Align
  .Template6_Footer_Align_Bottom
  .Template6_Footer_Address
  p {
  color: ${styles?.color};
  line-height: 1.5;
}
.Template6_Footer
  .Template6_Footer_Align
  .Template6_Footer_Align_Bottom
  .Template6_Footer_Social_Media {
  margin: 15px 0;
  display: inline-block;
  width: 100%;
  position: relative;
}

.Template6_Footer
  .Template6_Footer_Align
  .Template6_Footer_Align_Bottom
  .Template6_Footer_MailUs {
  display: flex;
  width: fit-content;
  margin: 20px auto;
  flex-wrap: wrap;
  align-items: center;
  justify-content: center;
  gap: 30px;
}

.Template6_Footer
  .Template6_Footer_Align
  .Template6_Footer_Align_Bottom
  .Template6_Footer_MailUs
  p
  a {
  display: flex;
  align-items: center;
  gap: 12px;
  color: ${styles?.color};
  font-size: 17px;
}
.Template6_Footer
  .Template6_Footer_Align
  .Template6_Footer_Align_Bottom
  ul.Template6_Footer_QuickLinks {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  justify-content: center;
  width: 100%;
  list-style: none;
}
.Template6_Footer
  .Template6_Footer_Align
  .Template6_Footer_Align_Bottom
  ul.Template6_Footer_QuickLinks
  li {
  padding: 0 15px 0 0;
  margin: 0 15px 0 0;
  position: relative;
  color: ${styles?.color};
  font-size: 14px;
  line-height: 1.5;
}
.Template6_Footer
  .Template6_Footer_Align
  .Template6_Footer_Align_Bottom
  ul.Template6_Footer_QuickLinks
  li::before {
  content: "";
  position: absolute;
  height: 12px;
  top: 50%;
  right: 0;
  transform: translate(0, -50%);
  width: 1px;
  background: ${styles?.light};
}
.Template6_Footer
  .Template6_Footer_Align
  .Template6_Footer_Align_Bottom
  ul.Template6_Footer_QuickLinks
  li
  a {
  color: ${styles?.color};
  font-size: 14px;
}
.Template6_Footer
  .Template6_Footer_Align
  .Template6_Footer_Align_Bottom
  ul.Template6_Footer_QuickLinks
  li:last-child {
  padding: 0%;
  margin: 0%;
}
.Template6_Footer
  .Template6_Footer_Align
  .Template6_Footer_Align_Bottom
  ul.Template6_Footer_QuickLinks
  li:last-child::before {
  content: inherit;
}
.Template6_Footer_CopyRights {
  background: ${styles?.light};
  padding: 10px 25px;
  display: flex;
  justify-content: space-between;
  width: 100%;
}
.Template6_Footer_CopyRights a {
  color: ${styles?.colorapi} !important;
  font-weight: 600;
}
.bg_light {
  background: ${styles?.light};
}

.Template6_Footer_get_directions {
  background: ${styles?.colorapi};
  font-size: 10px;
  line-height: 24px;
  color: ${styles?.white};
  padding: 0 10px;
  a {
    color: ${styles?.white} !important;
  }
}

.Menu_Contact_Info {
  padding: 25px;
  background: #1c1c1c;
  color: ${styles?.white};
}
.Menu_Contact_Info h3 {
  font-size: 18px;
  color: ${styles?.white} !important;
}
.Menu_Contact_Info p {
  font-size: 12px;
}
.Menu_Contact_Info p a {
  color: ${styles?.white};
  display: flex;
  align-items: center;
  gap: 10px;
}

.Template6_Footer_Social_Media
  .ant-space.ant-space-horizontal.ant-space-align-center
  .ant-space-item
  .ant-avatar {
  height: 25px !important;
  width: 25px !important;
}
.Template6_Footer_Social_Media
  .ant-space.ant-space-horizontal.ant-space-align-center
  .ant-space-item
  .ant-avatar
  img {
  filter: grayscale(1);
}











`