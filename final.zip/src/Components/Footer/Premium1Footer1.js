import React, { useState, useEffect } from "react";
import { Layout, Row, Col, Avatar, Tooltip, Space } from "antd";
import DefaultImg from "../../Assets/Images/default.png";
import styled, { ThemeProvider } from "styled-components";
import { Link } from "react-router-dom";
import API from "../../Api/ApiService";
import { MailFilled, PhoneFilled, MobileFilled } from "@ant-design/icons";
import { useSelector } from "react-redux";
const { Header, Footer, Sider, Content } = Layout;



export default function Premium1Footer1(props) {
  const company = useSelector((state) => state.company?.value);

  const socialMediaLink = useSelector(
    (state) => state.company?.socialMediaLinks
  );
  const year = new Date().getFullYear();
  const api = new API();
  // const [socialMediaLink, setSocialMediaLink] = useState([]);

  const FooterLinks = [
    { path: "/", title: "Home" },
    { path: "/about", title: "About Us" },
    { path: "/contact", title: "Contact Us" },
    { path: "/enquiry", title: "Enquiry" },
  ];

  const OtherLinks = [
    { path: "/privacy-policy", title: "Privacy Policy" },
    { path: "/terms", title: "Terms and Conditions" },
    { path: "/refund-policy", title: "Refund Policy" },
    { path: "/delivery-policy", title: "Delivery Policy" },
    { path: "/return-policy", title: "Return Policy" },
    { path: "/cancellation-policy", title: "Cancellation Policy" },
  ];

  const size = {
  desktop: "1920px",
  laptop: "1440px",
  minilaptop: "1200px",
  tabletl: "992px",
  tablet: "768px",
  mobilel: "580px",
  mobilep: "480px",
  mobiles: "380px",
};

const device = {
  desktop: `@media screen and (max-width: ${size.desktop})`,
  laptop: `@media screen and (max-width: ${size.laptop})`,
  minilaptop: `@media screen and (max-width: ${size.minilaptop})`,
  tabletl: `@media screen and (max-width: ${size.tabletl})`,
  tablet: `@media screen and (max-width: ${size.tablet})`,
  mobilel: `@media screen and (max-width: ${size.mobilel})`,
  mobilep: `@media screen and (max-width: ${size.mobilep})`,
  mobiles: `@media screen and (max-width: ${size.mobiles})`,
};

const theme = {
  id: 1,
  color: "#000",
  background: "#000",
  border: "#ee8f0a",
  gray: "#888",
  bg70: "rgb(255 255 255 / 70%)",
  bglight: "#f5f5f5",
  titlesize: [
    {
      screen: "desktop",
      value: 30,
    },
    {
      screen: "tablet",
      value: 20,
    },
    {
      screen: "mobile",
      value: 20,
    },
  ],
  colcount: [
    {
      screen: "desktop",
      value: 3,
    },
    {
      screen: "tablet",
      value: 2,
    },
    {
      screen: "mobile",
      value: 1,
    },
  ],
  gap: [
    {
      screen: "desktop",
      value: 25,
    },
    {
      screen: "tablet",
      value: 20,
    },
    {
      screen: "mobile",
      value: 15,
    },
  ],
};

const Section = styled.section`
  display: inline-block;
  position: relative;
  width: 100%;
  margin: 50px 0 0 0;
`;
const FooterAlign = styled.div`
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  position: relative;

  ${device.tabletl} {
    grid-template-columns: repeat(1, 1fr);
  }
`;
const FooterLeft = styled.div`
  display: inline-block;
  height: 100%;
  position: relative;
  iframe {
    height: 100%;
    width: 100%;
  }

  ${device.tabletl} {
    iframe {
      height: 350px;
    }
  }
`;
const FooterRight = styled.div`
  background: ${(props) =>
    props.theme.bglight ? props.theme.bglight : "#f5f5f5"};
  padding: 50px 45px 0 45px;

  h4 {
    font-size: 27px;
    font-weight: 700;
    margin: 12px 0 25px 0 !important;
  }

  ${device.tablet} {
    padding: 50px 25px 0 25px;
  }
`;
const LogoFooter = styled.div`
  display: inline-block;
  width: 100%;
  position: relative;
`;
const Image = styled.img`
  height: 70px;
  margin: auto auto 25px;
`;
const FooterAddress = styled.div`
  text-align: center;
  margin: auto;
  max-width: 95%;
  line-height: 1.8;
  font-size: 16px;
  color: ${(props) => (props.theme.gray ? props.theme.gray : "#000")};

  ${device.mobilep} {
    max-width: 100%;
  }
`;
const AddressText = styled.p``;
const FooterRightAlign = styled.div`
  margin: 40px 0 0 0;
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  text-align: center;

  ${device.mobilep} {
    grid-template-columns: repeat(1, 1fr);
    gap: 40px 0;
  }
`;
const FooterMailUs = styled.div`
  width: 100%;
  display: inline-block;
  position: relative;
  p {
    font-size: 16px;
    display: flex;
    flex-wrap: wrap;
    text-align: center;
    gap: 10px;
    width: fit-content;
    color: ${(props) => (props.theme.gray ? props.theme.gray : "#000")};
    a {
      color: ${(props) => (props.theme.gray ? props.theme.gray : "#000")};
      display: flex;
      flex-wrap: wrap;
      gap: 13px;
      align-items: center;
    }
  }
  p:not(:last-child) {
    margin: auto auto 20px;
  }
`;

const FooterSocialMedia = styled.div`
  width: 100%;
  position: relative;
  display: inline-block;
`;

const P = styled.p``;
const A = styled.a``;
const FooterMaps = styled.div`
  display: inline-block;
  position: relative;
  ul {
    padding: 0;
  }
  ul li {
    font-size: 16px;

    text-align: center;

    color: ${(props) => (props.theme.gray ? props.theme.gray : "#000")};
    a {
      color: ${(props) => (props.theme.gray ? props.theme.gray : "#000")};
    }
  }
  ul li:not(:last-child) {
    margin: 0 0 11px;
  }
`;
const Ul = styled.ul``;
const Li = styled.li``;
const CopyRights = styled.div`
  margin: 70px 0 0 0;
  padding: 12px 15px;
  text-align: center;
  color: ${(props) =>
    props.theme.background ? props.theme.background : "#000"};
  font-weight: 700;
  a {
    color: ${(props) => (props.theme.border ? props.theme.border : "#000")};
  }

  ${device.mobilep} {
    margin: 40px 0 0 0;
  }
`;
const List = styled.div``;
const H4 = styled.h4``;

  return (
    <ThemeProvider theme={theme}>
      <Section>
        <FooterAlign>
          <FooterLeft>
            {company.map && (
              <iframe
                src={company.map}
                width="100%"
                height="230"
                style={{ border: 0 }}
                allowFullScreen=""
                loading="lazy"
              ></iframe>
            )}
          </FooterLeft>
          <FooterRight>
            <LogoFooter>
              <Image src={company.logo} />
            </LogoFooter>
            <FooterAddress>
              <AddressText>
                {company.address?.address_line1},{" "}
                {company.address?.address_line2},{company.address?.area},{" "}
                {company.address?.district?.name}-{company.address?.pincode},
                {company.address?.state?.name}
              </AddressText>
            </FooterAddress>
            <FooterRightAlign>
              <FooterMailUs>
                <H4>Contact Info</H4>
                {company.email && (
                  <P>
                    <A href={"mailto:" + company.email}>
                      <MailFilled style={{ color: "#434242" }} />{" "}
                      {company.email}
                    </A>
                  </P>
                )}
                {company.landline_no && (
                  <P>
                    <A href={"tel:" + company.landline_no}>
                      <PhoneFilled style={{ color: "#434242" }} />{" "}
                      {company.landline_no}
                    </A>
                  </P>
                )}
                {company.mobile_no && (
                  <P>
                    <A href={"tel:+91" + company.mobile_no}>
                      <MobileFilled style={{ color: "#434242" }} />{" "}
                      {company.mobile_no}
                    </A>
                  </P>
                )}
                <FooterSocialMedia>
                  <H4>Follow us</H4>
                  <Space>
                    {socialMediaLink.map((e, i) => (
                      <List title={e.label} key={`smL${i}`}>
                        <a href={e.link} target="_blank">
                          <Avatar gap={10} src={api.rootUrl + e.icon}></Avatar>
                        </a>
                      </List>
                    ))}
                  </Space>
                </FooterSocialMedia>
              </FooterMailUs>

              <FooterMaps>
                <H4>Quick Links</H4>
                <Ul>
                  {OtherLinks.map((e, i) => (
                    <Li key={`qL_${i}`}>
                      <Link to={e.path}>{e.title}</Link>
                    </Li>
                  ))}
                </Ul>
              </FooterMaps>
            </FooterRightAlign>
            <CopyRights>
              &copy; {year} Designed by{" "}
              <A href="https://blazon.in" target="_blank">
                Blazon
              </A>
            </CopyRights>
          </FooterRight>
        </FooterAlign>
      </Section>
    </ThemeProvider>
  );
}
