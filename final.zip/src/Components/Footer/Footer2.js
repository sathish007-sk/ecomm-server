import React, { useState, useEffect } from "react";
import { Layout, Row, Col, Avatar, Tooltip, Space } from "antd";
import { Link } from "react-router-dom";
import API from "../../Api/ApiService";
import { MailFilled, PhoneFilled, MobileFilled } from "@ant-design/icons";
import { useSelector } from "react-redux";
import styled from "styled-components";
import { styles } from "../../Api/Data";
const user = JSON.parse(localStorage.getItem("persist:root"))?.company;
const colorCustom = user && JSON.parse(user).setColor;

const { Header, Footer, Sider, Content } = Layout;

export default function Footer2(props) {
  const company = useSelector((state) => state.company?.value);
  const socialMediaLink = useSelector(
    (state) => state.company?.socialMediaLinks
  );
  const year = new Date().getFullYear();
  const api = new API();
  // const [socialMediaLink, setSocialMediaLink] = useState([]);

  const FooterLinks = [
    { path: "/", title: "Home" },
    { path: "/about", title: "About Us" },
    { path: "/contact", title: "Contact Us" },
    { path: "/enquiry", title: "Enquiry" },
  ];

  const OtherLinks = [
    { path: "/privacy-policy", title: "Privacy Policy" },
    { path: "/terms", title: "Terms and Conditions" },
    { path: "/refund-policy", title: "Refund Policy" },
    { path: "/delivery-policy", title: "Delivery Policy" },
    { path: "/return-policy", title: "Return Policy" },
    { path: "/cancellation-policy", title: "Cancellation Policy" },
  ];

  return (
    <React.Fragment>
      <FooterSection>
        <footer className="Temp2_Footer">
          <div className="Wrapper">
            <div className="footer_align">
              <div className="footer_1">
                <div className="footer-contact">
                  {company && (
                    <div className="address">
                      <div>
                        <img className="logo" src={company.logo} />
                      </div>
                      <p>
                        {company.address?.address_line1},{" "}
                        {company.address?.address_line2},{company.address?.area}
                        , {company.address?.district?.name}-
                        {company.address?.pincode}
                        ,<br />
                        {company.address?.state?.name}
                      </p>
                    </div>
                  )}
                </div>
              </div>

              <div className="footer_2">
                <div className="footer-contact">
                  <div className="mail-phone">
                    <h3>Contact Info</h3>
                    {company.email && (
                      <p>
                        <a href={"mailto:" + company.email}>
                          <MailFilled style={{ color: "#434242" }} />{" "}
                          {company.email}
                        </a>
                      </p>
                    )}
                    {company.landline_no && (
                      <p>
                        <a href={"tel:" + company.landline_no}>
                          <PhoneFilled style={{ color: "#434242" }} />{" "}
                          {company.landline_no}
                        </a>
                      </p>
                    )}
                    {company.mobile_no && (
                      <p>
                        <a href={"tel:+91" + company.mobile_no}>
                          <MobileFilled style={{ color: "#434242" }} />{" "}
                          {company.mobile_no}
                        </a>
                      </p>
                    )}
                  </div>
                  <div className="social-links">
                    <h3>Follow us</h3>
                    <Space>
                      {socialMediaLink.map((e, i) => (
                        <Tooltip title={e.label} key={`smL${i}`}>
                          <a href={e.link} target="_blank">
                            <Avatar gap={4} src={api.rootUrl + e.icon}></Avatar>
                          </a>
                        </Tooltip>
                      ))}
                    </Space>
                  </div>
                </div>
              </div>

              <div className="footer_3">
                <h3>Quick Links</h3>
                <ul className="quickLinks">
                  {OtherLinks.map((e, i) => (
                    <li key={`qL_${i}`}>
                      <Link to={e.path}>{e.title}</Link>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="footer_4">
                {company.map && (
                  <iframe
                    src={company.map}
                    width="100%"
                    height="200"
                    style={{ border: 0 }}
                    allowFullScreen=""
                    loading="lazy"
                  ></iframe>
                )}
              </div>
            </div>
          </div>
          <section className="bl-footer-1">
            &copy; {year} Designed by{" "}
            <a href="https://blazon.in" target="_blank">
              Blazon
            </a>
          </section>
        </footer>
      </FooterSection>
    </React.Fragment>
  );
}



const FooterSection = styled.div`



.Temp2_Footer {
  display: inline-block;
  padding: 40px 0 0px 0;
  position: relative;
  width: 100%;
  margin: 40px 0 0 0;
  background: ${styles?.light};
}
.Temp2_Footer .footer_align {
  display: flex;
  flex-wrap: wrap;
  align-items: flex-start;
  justify-content: space-between;
  margin: 0 0 50px;
}
.Temp2_Footer .footer_align .footer_1 {
  width: 22%;
  display: inline-block;
}
.Temp2_Footer .footer_align .footer_2 {
  width: fit-content;
  display: inline-block;
}
.Temp2_Footer .footer_align .footer_3 {
  width: fit-content;
  display: inline-block;
}
.Temp2_Footer .footer_align .footer_4 {
  width: 22%;
  display: inline-block;
}
.Temp2_Footer .footer_align a {
  display: flex;
  gap: 10px;
  align-items: center;
}
.Temp2_Footer .footer_align .footer_1 img {
  margin: 0 0 25px;
}



@media screen and (max-width:992px) {

.Temp2_Footer .footer_align .footer_1 {
  width: 100%;
  display: inline-block;
  text-align: center;
  margin: 0 0 50px;
}
.Temp2_Footer .footer_align .footer_1 img {
  margin: auto auto 25px;
}



}

@media screen and (max-width:576px) {

.Temp2_Footer .footer_align .footer_4 {
  width: 100%;
  margin: 40px 0 0 0;
}
.Temp2_Footer .footer_align .footer_2 {
  width: 50%;
  padding: 0 10px 0 0;
}
.Temp2_Footer .footer_align .footer_3 {
  width: 50%;
  padding: 0 0 0 10px;
}



}









`;