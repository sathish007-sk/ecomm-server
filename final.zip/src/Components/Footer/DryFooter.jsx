import React from 'react'
import { styles } from '../../Api/Data';
import logo from "../../Assets/Images/logo.png"
import styled from 'styled-components';
import { Link } from "react-router-dom";
import { useSelector } from "react-redux";
import API from "../../Api/ApiService";
import instgram from "../../Assets/Images/furniture/s2.png"
import facebook from "../../Assets/Images/furniture/s1.png"
import email from "../../Assets/Images/dry/email.png"
import address from "../../Assets/Images/dry/address.png"
import call from "../../Assets/Images/dry/call.png"



const DryFooter = (props) => {
  const company = useSelector((state) => state.company?.value);
  const socialMediaLink = useSelector(
    (state) => state.company?.socialMediaLinks
  );
  const year = new Date().getFullYear();
  const api = new API();
  return (
    <React.Fragment>
      <FooterSection>
        <div className='footer_section'>
          <div className='footer_top_wrap'>
            <div className='wrapper'>
              <div className='footer_top'>
                <div className='footer_top_left'>
                  <Link to="/">
                    <img src={company?.logo ? company?.logo : logo} alt={company?.name} />
                  </Link>
                </div>
                <div className='footer_top_center'>
                  <ul>
                    <li>
                      <Link to="/" title='Home'>Home</Link>
                    </li>
                    <li>
                      <Link to="/about" title='About Us'>About Us</Link>
                    </li>
                    <li>
                      <Link to="/enquiry" title='Enquiry Form'>Enquiry Form</Link>
                    </li>
                    <li>
                      <Link to="/contact" title='Contact Us'>Contact Us</Link>
                    </li>
                  </ul>
                </div>
                <div className='footer_top_right'>
                  {/* <h4>Follow us</h4> */}
                  <ul>
                    {
                      socialMediaLink?.map((item) => {
                        return (
                          <li key={item?._id}>
                            <a href={item?.link} title={item?.label} target="_blank">
                              <img src={api.rootUrl + item.icon} alt={item?.label} /></a>
                          </li>
                        )
                      })
                    }
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <div className='wrapper'>
            <div className='footer_bottom'>
              <div className='footer_1'>
                <h4>Userful Link</h4>
                <ul>
                  <li><Link to="/login" title="Login">Login</Link></li>
                  <li><Link to="/my-profile" title='My Profile'>My Profile</Link></li>
                  <li><Link to="/my-address" title="My Address">My Address</Link></li>
                  <li><Link to="/cart" title="Cart">Cart</Link></li>
                  <li><Link to="/checkout" title='Checkout'>Checkout</Link></li>
                  <li><Link to="/my-order" title='My Order'>My Order</Link></li>
                </ul>

              </div>
              <div className='footer_2'>
                <h4>Our Polices</h4>
                <ul>
                  <li><Link to="/privacy-policy" title='Privacy Policy'>Privacy Policy</Link></li>
                  <li><Link to="/terms" title='Terms and Conditions'>Terms and Conditions</Link></li>
                  <li><Link to="/refund-policy" title='Refund Policy'>Refund Policy</Link></li>
                  <li><Link to="/delivery-policy" title='Delivery Policy'>Delivery Policy</Link></li>
                  <li><Link to="/return-policy" title='Return Policy'>Return Policy</Link></li>
                  <li><Link to="/cancellation-policy" title='Cancellation Policy'>Cancellation Policy</Link></li>
                </ul>
              </div>
              <div className='footer_3'>
                <h4>Contact Us</h4>
                <ul>
                  <li className='address'>
                    {company.address?.address_line1},{" "}
                    {company.address?.address_line2},{company.address?.area}
                    , {company.address?.district?.name}-
                    {company.address?.pincode}
                    ,
                    {company.address?.state?.name}
                  </li>
                  <li className='call'>
                    <a href={"tel:" + company.landline_no}>{company.landline_no}</a>,  <a href={"tel:+91" + company.mobile_no}>
                      {company.mobile_no}
                    </a>
                  </li>
                  <li className='mail'><a href={"mailto:" + company.email}>

                    {company.email}
                  </a></li>
                </ul>
              </div>
              <div className='footer_4'>
                <h4>Our Location</h4>
                {company.map && (
                  <iframe
                    src={company.map}
                    width="100%"
                    height="200"
                    style={{ border: 0 }}
                    allowFullScreen=""
                    loading="lazy"
                  ></iframe>
                )}
              </div>
            </div>
          </div>
          <div className='copy_text'>
            <div className='wrapper'>
              <div className='copy_align'>
                <div className='copy_left'>
                  <p>All Rights Reserved. {company?.company_name}</p>
                </div>
                <div className='copy_right'>
                  <p>© 2022 Designed by <a href="https://ecdigi.com/" target="_blank" title='ecDigi Technologies'>ecDigi Technologies.</a></p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </FooterSection>
    </React.Fragment>
  )
}

export default DryFooter


const FooterSection = styled.section`
* {
    font-family: ${styles?.q_regular};
}
    width: 100%;
    display: inline-block;
    position: relative;
    
    .footer_section {
        width: 100%;
        display: inline-block;
        position: relative;
        margin: 60px 0 0 0;
        background: #f5f5f5;
    padding: 50px 0 0 0;
    }
    a {
        color: ${styles?.color};
    }
    .footer_top {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 20px;
        flex-wrap: wrap;
        
    }
    .footer_top_wrap {
        padding: 0 0 30px;
        border-bottom: 1px solid #e1e1e1;
        margin: 0 0 30px;
        width: 100%;
        display: inline-block;
    }
    .footer_top .footer_top_left {
        display: inline-block;
        width: fit-content;
    }
    .footer_top .footer_top_left img {
        height: 55px;
    }
    .footer_top .footer_top_center ul {
        width: fit-content;
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        gap: 30px;
    }
    .footer_top .footer_top_right {
        width: fit-content;
        display: inline-block;
    }
    .footer_top .footer_top_right h4 {
        font-family: ${styles?.q_bold} !important;
    }
    .footer_top .footer_top_right ul {
        display: flex;
        align-items: center;
        gap: 18px;
        margin: 0;
        padding: 0;
    }
    .footer_top .footer_top_right ul img {
        height: 29px;
    }

    .footer_bottom {
        display: flex;
        align-items: flex-start;
        justify-content: space-between;
        gap: 20px;
        flex-wrap: wrap;
    }
    iframe {
        width: 100%;
    }
    .footer_1 {
        width: fit-content;
        display: inline-block;
    }
    .footer_2 {
        width: fit-content;
        display: inline-block;
    }
    .footer_3 {
        width: 26%;
        display: inline-block;
    }
    .footer_4 {
        width: 23%;
        display: inline-block;
    }
    .footer_bottom ul {
        margin: 0;
        padding: 0;
        display: flex;
        flex-direction: column;
        gap: 8px;
        font-size: 14px;
        color: ${styles?.color};
    }
    .footer_bottom h4 {
        font-family: ${styles?.q_bold} !important;
        font-size: 22px !important;
        margin: 0 0 25px;
    }
    .footer_3 ul li {
        position: relative;
        padding: 0 0 0 35px;
        margin: 0 0 12px;
        &:last-child {
            margin: 0;
        }
    }
    .footer_3 ul li::before {
        content: "";
        position: absolute;
        background: url(${email});
        height: 16px;
    width: 17px;
    
    top: 3px;
    left: 0;
    background-size: contain !important;
    background-repeat: no-repeat !important;
    background-position: center left !important;
}
.footer_3 ul li.address::before {
    background: url(${address}) !important;
    background-size: contain !important;
    background-repeat: no-repeat !important;
    background-position: center left !important;
}
.footer_3 ul li.call::before {
    background: url(${call}) !important;
    background-size: contain !important;
    background-repeat: no-repeat !important;
    background-position: center left !important;
}
.footer_3 ul li.mail::before {
    background: url(${email}) !important;
    background-size: contain !important;
    background-repeat: no-repeat !important;
    background-position: center left !important;
}

    .copy_text {
        width: 100%;
        display: inline-block;
        padding: 10px 0;
        background: ${styles?.themegreen};
        border-top: 0px solid #c7c7c7;
        margin: 50px 0 0 0;
        p {
            line-height: 1.5;
            color: ${styles?.white};
            margin: 0;
            a {
                color: ${styles?.white};
            }
        }
    }
    .copy_text .copy_align {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 20px;
    }

    .copy_text .copy_align p {
        font-size: 14px;
    }



    @media screen and (max-width: 768px) {
        .footer_top {
            flex-direction: column;
        }
        .footer_bottom {
            display: grid;
            grid-template-columns: repeat(2,1fr);
            gap: 40px 20px;
        }
        .footer_1, .footer_2, .footer_3, .footer_4 {
            width: 100%;
            display: inline-block;
        }
        .copy_text .copy_align {
            flex-direction: column;
            gap: 8px;
        }
        .footer_top .footer_top_center ul {
    width: auto;
}
    }


@media screen and (max-width:480px) {
    .footer_top .footer_top_center ul {
    width: 100%;
    flex-wrap: wrap;
    gap: 6px 20px;
    justify-content: center;
} 
.footer_bottom {
    grid-template-columns: repeat(1,1fr);
}






}



`