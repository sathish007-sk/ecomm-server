import React, { useState,useEffect } from 'react'
import styled from 'styled-components';
import { Link, useNavigate } from "react-router-dom";
import footerlogo from "../../Assets/Images/Agri/footer_logo.png"
import instagram from "../../Assets/Images/Agri/instagram.png"
import footerbg from "../../Assets/Images/Agri/footer_bg.png"
import address from "../../Assets/Images/Agri/location.png"
import call from "../../Assets/Images/Agri/call.png"
import mail from "../../Assets/Images/Agri/mail.png"
import { Avatar, Tooltip, Space } from "antd";
import { styles } from '../../Api/Data';
import { useSelector } from "react-redux";
import API from "../../Api/ApiService";

const GiftFooter = () => {
    const company = useSelector((state) => state.company?.value);
  const socialMediaLink = useSelector(
    (state) => state.company?.socialMediaLinks
  );
    
  const FooterLinks = [
    { path: "/", title: "Home" },
    { path: "/about", title: "About Us" },
    { path: "/contact", title: "Contact Us" },
    { path: "/enquiry", title: "Enquiry" },
  ];

  const OtherLinks = [
    { path: "/privacy-policy", title: "Privacy Policy" },
    { path: "/terms", title: "Terms and Conditions" },
    { path: "/refund-policy", title: "Refund Policy" },
    { path: "/delivery-policy", title: "Delivery Policy" },
    { path: "/return-policy", title: "Return Policy" },
    { path: "/cancellation-policy", title: "Cancellation Policy" },
  ];
  const year = new Date().getFullYear();
  const api = new API();
    return (
        <React.Fragment>
            <FooterSection>
                <div className='footer_Section'>
                    <div className='wrapper'>
                        <div className='footer_align'>
                            <div className='footer_1'>
                                <h4>Contact Us</h4>
                                <ul>
                                    <li className='address'>{company.address?.address_line1},{" "}
                        {company.address?.address_line2},{company.address?.area}
                        , {company.address?.district?.name}-
                        {company.address?.pincode}
                        ,<br />
                        {company.address?.state?.name}</li>
                                    <li className='phone'>Office : <a href={"tel:" + company.landline_no}>{company.landline_no}</a>,  <a href={"tel:+91" + company.mobile_no}>
                          {company.mobile_no}
                        </a></li>
                                    <li className='email'><a href={"mailto:" + company.email}>
                          
                          {company.email}
                        </a></li>
                                </ul>
                            </div>
                            <div className='footer_2'>
                                <h4>Quick links</h4>
                                <ul>
                                {FooterLinks.map((e, i) => (
                    <li key={`qL_${i}`}>
                      <Link to={e.path}>{e.title}</Link>
                    </li>
                  ))}
                                </ul>
                            </div>
                            <div className='footer_3'>
                                <h4>Useful Links</h4>
                                <ul>
                                {OtherLinks.map((e, i) => (
                    <li key={`qL_${i}`}>
                      <Link to={e.path}>{e.title}</Link>
                    </li>
                  ))}
                                </ul>
                            </div>
                            <div className='footer_4'>
                                <img src={company?.logo} alt="Logo" />
                                
                                 <ul>
                                 {
                                            socialMediaLink?.map((item) => {
                                                return (
                                                    <li key={item?._id}>
                                                        <a href={item?.link} title={item?.label} target="_blank">
                                                            <img src={api.rootUrl + item.icon} alt={item?.label} /></a>
                                                    </li>
                                                )
                                            })
                                        }
                                    </ul>
                               
                            </div>
                        </div>
                    </div>
                    <div className='copy_text'>
                        <div className='wrapper'>
                            <div className='copy_align'>
                                <div className='copy_left'>
                                    <p>All Rights Reserved. {company?.company_name}</p>
                                </div>
                                <div className='copy_right'>
                                    <p>© {year} Designed by <a href="https://ecdigi.com/" target="_blank" title='ecDigi Technologies'>ecDigi Technologies.</a></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </FooterSection>
        </React.Fragment>
    )
}

export default GiftFooter


const FooterSection = styled.section`
   width: 100%;
    display: inline-block;
    position: relative;
    background: #eaeaea;
    margin: 60px 0 0 0;
    a {
        color: ${styles?.color};
    }
    .footer_Section {
        width: 100%;
        display: inline-block;
        position: relative;
        padding: 60px 0 0 0;
    }
    .footer_Section .footer_align {
        display: flex;
        align-items: flex-start;
        width: 100%;
        justify-content: space-between;
        gap: 20px;
        ul {
            padding: 0;
        }
        h4 {
            color: ${styles?.color} !important;
            font-family: ${styles?.bold} !important;
            font-size: 27px;
            margin: 0 0 30px !important;
           
        }
    }
    .footer_1 {
        width: 28%;
        display: inline-block;
        ul {
            list-style: none;
        }
        ul li {
            color: ${styles?.color};
            margin: 0 0 20px;
            padding: 0 0 0 40px;
            font-size: 15px;
            position: relative;
            line-height: 1.9;
        }
        ul li:last-child {
                margin: 0;
            }
        ul li::before {
            content: "";
            position: absolute;
            background: url(${address});
            background-repeat: no-repeat !important;
            height: 21px;
            filter: brightness(0) !important;
    width: 21px;
    background-size: contain !important;
    left: 0;
    top: 6px;
    background-position: center left !important;
}
    ul li.address::before {
        background: url(${address});
    }
    ul li.phone::before {
        background: url(${call});
    }
    ul li.email::before {
        background: url(${mail});
    }

    }
    .footer_2 {
      width: fit-content;
      display: inline-block;
      ul li {
        line-height: 1.9;
        margin: 0 0 8px;
        font-size: 15px;
        color: ${styles?.color} !important;
        a {
            color: ${styles?.color} !important;
        }
      }
    }
    .footer_3 {
        width: fit-content;
      display: inline-block;
      ul li {
        line-height: 1.9;
        margin: 0 0 8px;
        font-size: 15px;
        color: ${styles?.color} !important;
        a {
            color: ${styles?.color} !important;
        }
      }
    }
    .footer_4 {
        width: fit-content;
      display: inline-block;

      img {
        margin: auto;
        height: 60px;
      }

      ul {
        list-style: none;
        width: fit-content;
        margin: 30px auto auto;
        display: flex;
        align-items: center;
        gap: 15px;
        img {
            height: 35px;
        }
      }
    }

    .copy_text {
        width: 100%;
        display: inline-block;
        padding: 15px 0;
        border-top: 1px solid #888;
        margin: 50px 0 0 0;
        p {
            line-height: 1.5;
            color: ${styles?.color};
            margin: 0;
        }
    }
    .copy_text .copy_align {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 20px;
    }


    @media screen and (max-width:956px) {
        .footer_Section .footer_align {
            display: grid;
            grid-template-columns: repeat(2,1fr);
            gap: 45px 30px;
        }
        .footer_1, .footer_2, .footer_3, .footer_4 {
            display: inline-block;
            width: 100%;
        }
    }


    @media screen and (max-width:768px) {
        margin: 75px 0 0 0;
    }


    @media screen and (max-width:480px) {
        .footer_Section .footer_align {
    display: flex;
   flex-direction: column-reverse;
}

.copy_text .copy_align {
    flex-wrap: wrap;
    flex-direction: column;
    justify-content: center;
    gap: 10px;
}





    }






`;