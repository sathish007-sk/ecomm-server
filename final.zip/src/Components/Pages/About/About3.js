import React, { useState, useEffect } from "react";

import API from "../../../Api/ApiService";
function About3(props) {
  const [data, setData] = useState([]);
  const api = new API();
  useEffect(() => {
    api.dynamicPage(props.page).then((res) => {
      let data = {
        banner: res.data?.banner ? api.rootUrl + res.data.banner : "",
        content: res.data?.content,
      };
      setData(data);
    });
    
  }, [props]);

  return (
    <React.Fragment>
      <section className="Temp1_Common_Design Temp3_About">
        <div className="wrapper">
          <h1 className="Head_Text_Common">About Us</h1>
          <div className="Temp1_Common_Design_Align">
            <div className="Temp1_Common_Design_Left">
              <img src={data.banner} width="100%" />
              <span></span>
            </div>
            <div className="Temp1_Common_Design_Right">
              {data.content && (
                <div dangerouslySetInnerHTML={{ __html: data.content }}></div>
              )}
            </div>
          </div>
        </div>
      </section>
    </React.Fragment>
  );
}
export default About3;
