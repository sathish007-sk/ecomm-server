import React, { useState, useEffect } from "react";
import { message, Alert, Row, Col, Input, Form, Button, } from "antd";

import API from "../../../Api/ApiService";
function Contact3(props) {
  const [data, setData] = useState([]);
  const [response, setResponse] = useState(null);
  const [isSaving, setSaving] = useState(false);
  const [form] = Form.useForm();
  const api = new API();
  useEffect(() => {
    api.dynamicPage(props.page).then((response) => {
      let data = {
        banner: response.data?.banner ? api.rootUrl + response.data.banner : "",
        content: response.data?.content,
      };
      setData(data);
    });
  
  }, [props]);

  const onFinish = (values) => {
    setSaving(true);
    api
      .enquiry(values)
      .then((res) => {
        setResponse(null);
        let data = res.data;
        setSaving(false);
        if (data.success) {
          form.resetFields();
          setResponse("Submitted Successfully, thanks");
        } else message.error(data.message);
      })
      .catch((error) => {
        setSaving(false);
        message.error(error.message);
      });
  };

  return (
    <React.Fragment>
      <section className="Temp1_Common_Design Temp3_Contact">
        <div className="wrapper">
          <h1 className="Head_Text_Common">Contact Us</h1>
          <div className="Temp1_Common_Design_Align">
            <div className="Temp1_Common_Design_Left">
              {/* <img src={data.banner} width="100%" />
            <span></span> */}
              <div className="Temp1_Common_Design_Contact_Form design_style">
                <p
                  className="contact_form_title design_style_2"
                  style={{
                    fontSize: "18px !important",
                    fontWeight: "600",
                    textAlign: "left",
                  }}
                >
                  For all enquires, please email us from the form below.
                </p>

                <Form
                  size="middle"
                  labelCol={{ span: 24 }}
                  form={form}
                  onFinish={onFinish}
                >
                  <Row>
                    <Col lg={12} md={12} xs={24} >
                      <Form.Item
                        label="Enter Your Name"
                        name="name"
                        rules={[
                          { required: true, message: "Please enter your name" },
                        ]}
                      >
                        <Input />
                      </Form.Item>
                    </Col>
                    <Col lg={12} md={12} xs={24}>
                      <Form.Item
                        label="Enter Your Email"
                        name="email"
                        rules={[
                          { required: true, message: "Please enter e-Mail" },
                        ]}
                      >
                        <Input />
                      </Form.Item>
                    </Col>
                  </Row>

                  <Row>
                    <Col lg={12} md={12} xs={24}>
                      <Form.Item
                        label="Enter Your Mobile Number"
                        name="mobile_no"
                        rules={[
                          {
                            required: true,
                            message: "Please enter mobile number",
                          },
                        ]}
                      >
                        <Input />
                      </Form.Item>
                    </Col>
                    <Col lg={12} md={12} xs={24}>
                      <Form.Item
                        label="Enter Subject"
                        name="subject"
                        rules={[
                          { required: true, message: "Please enter subject" },
                        ]}
                      >
                        <Input />
                      </Form.Item>
                    </Col>
                  </Row>

                  <Row>
                    <Col span={24}>
                      <Form.Item
                        label="Enter Your Message"
                        name="description"
                        rules={[
                          {
                            required: true,
                            message: "Please enter Description!",
                          },
                        ]}
                      >
                        <Input.TextArea rows={3} />
                      </Form.Item>
                    </Col>
                  </Row>
                  <Form.Item>
                    <Button type="primary" htmlType="submit" loading={isSaving}>
                      Submit
                    </Button>
                  </Form.Item>
                </Form>
                {response && <Alert message={response} type="success" />}
              </div>
            </div>
            <div className="Temp1_Common_Design_Right">
              {data.content && (
                <div dangerouslySetInnerHTML={{ __html: data.content }}></div>
              )}
            </div>
          </div>
        </div>
      </section>
    </React.Fragment>
  );
}

export default Contact3;
