import React, { useState, useEffect } from "react";
import { message, Alert, Row, Col, Input, Form, Button, } from "antd";
import API from "../../../Api/ApiService";

export default function Contact1(props) {
  const [data, setData] = useState([]);
  const [response, setResponse] = useState(null);
  const [isSaving, setSaving] = useState(false);
  const [form] = Form.useForm();
  const api = new API();

  useEffect(() => {
    api.dynamicPage(props.page).then((response) => {
      let data = {
        banner: response.data?.banner ? api.rootUrl + response.data.banner : "",
        content: response.data?.content,
      };
      setData(data);
    });
  }, [props]);

  const onFinish = (values) => {
    setSaving(true);
    api
      .enquiry(values)
      .then((res) => {
        setResponse(null);
        let data = res.data;
        setSaving(false);
        if (data.success) {
          form.resetFields();
          setResponse("Submitted Successfully, thanks");
        } else message.error(data.message);
      })
      .catch((error) => {
        setSaving(false);
        message.error(error.message);
      });
  };

  return (
    <React.Fragment>
      <section className="Temp1_Common_Design">
        <div className="Temp1_Common_Design_Align">
          <div className="Temp1_Common_Design_Left">
            <img src={data.banner} width="100%" />
            <span></span>
          </div>
          <div className="wrapper">
            <div className="Temp1_Common_Design_Right">
              <h1 className="Head_Text_Common">Contact Us</h1>
              <Row>
                <Col lg={9} md={12}>
                  {data.content && (
                    <div
                      dangerouslySetInnerHTML={{ __html: data.content }}
                    ></div>
                  )}
                </Col>
                <Col lg={15} md={12}>
                  <p className="contact_form_title" style={{fontSize:"16px !important", fontWeight: "500", textAlign:"left"}}>For all enquires, please email us from the form below.</p>
                  <Form
                    size="middle"
                    labelCol={{ span: 24 }}
                    form={form}
                    onFinish={onFinish}
                  >
                    <Form.Item
                      label="Enter Your Name"
                      name="name"
                      rules={[
                        { required: true, message: "Please enter your name" },
                      ]}
                    >
                      <Input />
                    </Form.Item>
                    <Form.Item
                      label="Enter Your Email"
                      name="email"
                      rules={[
                        { required: true, message: "Please enter e-Mail" },
                      ]}
                    >
                      <Input />
                    </Form.Item>
                    <Form.Item
                      label="Enter Your Mobile Number"
                      name="mobile_no"
                      rules={[
                        {
                          required: true,
                          message: "Please enter mobile number",
                        },
                      ]}
                    >
                      <Input />
                    </Form.Item>
                    <Form.Item
                      label="Enter Subject"
                      name="subject"
                      rules={[
                        { required: true, message: "Please enter subject" },
                      ]}
                    >
                      <Input />
                    </Form.Item>
                    <Form.Item
                      label="Enter Your Message"
                      name="description"
                      rules={[
                        {
                          required: true,
                          message: "Please enter Description!",
                        },
                      ]}
                    >
                      <Input.TextArea />
                    </Form.Item>

                    <Form.Item>
                      <Button
                        type="primary"
                        htmlType="submit"
                        loading={isSaving}
                      >
                        Submit
                      </Button>
                    </Form.Item>
                  </Form>                
                  {response && <Alert message={response} type="success" />}                 
                </Col>
              </Row>
            </div>
          </div>
        </div>
      </section>
    </React.Fragment>
  );
}
