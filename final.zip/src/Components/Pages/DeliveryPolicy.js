import React, { useState, useEffect } from "react";


import API from "../../Api/ApiService";
function Deliverypolicy(props) {
  const [data, setData] = useState([]);
  const api = new API();
  useEffect(() => {
    api.dynamicPage(props.page).then((response) => {
      let data = {
        banner: response.data?.banner ? api.rootUrl + response.data.banner : "",
        content: response.data?.content,
      };
      setData(data);
    });
  }, [props]);

  return (
    <React.Fragment>
      <section className="Temp1_Common_Design">
        <div className="Temp1_Common_Design_Align">
          <div className="Temp1_Common_Design_Left">
            <img src={data.banner} width="100%" />
            <span></span>
          </div>
          <div className="wrapper">
            <div className="Temp1_Common_Design_Right">
              <h1 className="Head_Text_Common">Delivery Policy</h1>
              {data.content && (
                <div dangerouslySetInnerHTML={{ __html: data.content }}></div>
              )}
            </div>
          </div>
        </div>
      </section>
    </React.Fragment>
  );
}
export default Deliverypolicy;
