import React from 'react'

export default function DefaultPage() {
  return (
    <React.Fragment>
    <section>
        <h2>HC3</h2>
    </section>
    </React.Fragment>
  )
}