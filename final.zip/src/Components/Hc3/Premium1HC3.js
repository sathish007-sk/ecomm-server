import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import styled, { ThemeProvider } from "styled-components";
import API from "../../Api/ApiService";
import Default from '../../Assets/Images/default.png'

export default function Premium1HC3(props) {
  const api = new API();
  const [data, setData] = useState([]);
  useEffect(() => {
    if (props.data) setData(props.data);
  }, [props]);

  const size = {
    desktop: "1920px",
    laptop: "1440px",
    minilaptop: "1200px",
    tabletl: "992px",
    tablet: "768px",
    mobilel: "580px",
    mobilep: "480px",
    mobiles: "380px",
  };

  const device = {
    desktop: `@media screen and (max-width: ${size.desktop})`,
    laptop: `@media screen and (max-width: ${size.laptop})`,
    minilaptop: `@media screen and (max-width: ${size.minilaptop})`,
    tabletl: `@media screen and (max-width: ${size.tabletl})`,
    tablet: `@media screen and (max-width: ${size.tablet})`,
    mobilel: `@media screen and (max-width: ${size.mobilel})`,
    mobilep: `@media screen and (max-width: ${size.mobilep})`,
    mobiles: `@media screen and (max-width: ${size.mobiles})`,
  };

  const theme = {
    id: 1,
    color: "#000",
    background: "#000",
    border: "#ee8f0a",
    gray: "#888",
    bg70: "rgb(255 255 255 / 70%)",
    bglight: "#f5f5f5",
    titlesize: [
      {
        screen: "desktop",
        value: 27,
      },
      {
        screen: "tablet",
        value: 20,
      },
      {
        screen: "mobile",
        value: 20,
      },
    ],
    colcount: [
      {
        screen: "desktop",
        value: 3,
      },
      {
        screen: "tablet",
        value: 2,
      },
      {
        screen: "mobile",
        value: 1,
      },
    ],
    gap: [
      {
        screen: "desktop",
        value: 25,
      },
      {
        screen: "tablet",
        value: 20,
      },
      {
        screen: "mobile",
        value: 15,
      },
    ],
  };

  const Section = styled.section`
    width: 100%;
    display: inline-block;
    position: relative;
  `;
  const Wrapperfull = styled.div`
    max-width: 100%;
    padding: 0 20px;
  `;
  const Permium1HC3Align = styled.div`
    display: flex;
    width: 100%;
    position: relative;
    gap: 25px;

    ${device.minilaptop} {
      display: grid;
    }
  `;
  const Permium1HC3Grid1 = styled.div`
    flex: 1;

    display: flex;
    flex-direction: column;
    gap: 25px;

    .Permium1HC3_Box {
      border: 1px solid
        ${(props) => (props.theme.border ? props.theme.border : "#000")};
    }

    ${device.minilaptop} {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
    }

    ${device.tablet} {
      display: grid;
      grid-template-columns: repeat(1, 1fr);
    }
  `;
  const Permium1HC3Grid2 = styled.div`
    flex: 2;
    border: 1px solid
      ${(props) => (props.theme.border ? props.theme.border : "#000")};

    .Permium1HC3_Box {
      height: 100%;
      width: 100%;
    }
  `;
  const Permium1HC3Grid3 = styled.div`
    flex: 1;

    display: flex;
    flex-direction: column;
    gap: 25px;

    .Permium1HC3_Box {
      border: 1px solid
        ${(props) => (props.theme.border ? props.theme.border : "#000")};
    }

    ${device.minilaptop} {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
    }

    ${device.tablet} {
      display: grid;
      grid-template-columns: repeat(1, 1fr);
    }
  `;
  const Permium1HC3Box = styled.div`
    display: flex;
    min-height: 280px;
    position: relative;
    align-items: flex-end;
    justify-content: flex-start;

    ${device.minilaptop} {
      min-height: 400px;
    }

    ${device.tablet} {
      min-height: 400px;
    }
  `;
  const Permium1HC3BoxBg = styled.div`
    position: absolute;
    height: 100%;
    width: 100%;
    top: 0;
    left: 0;
    background-position: center center !important;
    background-size: cover !important;
    background-color: #f5f5f5 !important;
    background-repeat: no-repeat !important;
    z-index: 5;
  `;

  const Permium1HC3Content = styled.div`
    width: 100%;
    z-index: 10;
    padding: 20px 20px;
    background: ${(props) =>
      props.theme.bg70 ? props.theme.bg70 : "rgb(255 255 255 / 70%)"};
    display: flex;
    align-items: flex-start;
    flex-direction: column;
    gap: 15px;
    position: relative;
  `;

  const Permium1HC3Title = styled.h4`
    margin: 0 !important;
    color: ${(props) =>
      props.theme.color ? props.theme.color : "000"} !important;
    font-weight: 600;
    margin: 0;

    ${device.desktop} {
      font-size: ${(props) =>
        props.theme.titlesize[0].screen == "desktop"
          ? props.theme.titlesize[0].value
          : 27}px !important;
    }
    ${device.tabletl} {
      font-size: ${(props) =>
        props.theme.titlesize[1].screen == "tablet"
          ? props.theme.titlesize[1].value
          : 20}px !important;
    }
    ${device.mobilel} {
      font-size: ${(props) =>
        props.theme.titlesize[2].screen == "mobile"
          ? props.theme.titlesize[2].value
          : 20}px !important;
    }
  `;
  const Permium1HC3Button = styled.button`
    position: relative;
    display: inline-block;
    padding: 0 0 6px 6px;
    width: fit-content;
    border: 0;
    background: transparent;
    outline: none;
    &:before {
      content: "";
      position: absolute;
      left: 0;
      bottom: 0;
      top: 6px;
      right: 6px;
      border: 1px solid
        ${(props) => (props.theme.background ? props.theme.background : "#000")};
      border-radius: 3px;
    }
    &:hover {
      padding: 0 0 6px 6px;
    }
    a {
      padding: 8px 15px;
      border: 0;
      background: ${(props) =>
        props.theme.background ? props.theme.background : "#000"};
      border-radius: 3px;
      color: #fff;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      font-size: 13px !important;
      display: inline-block;
      position: relative;
      z-index: 11;
    }
  `;

  return (
    <ThemeProvider theme={theme}>
      <Section className="Premium1_HC3" id={theme.id}>
        <Wrapperfull>
          {data.title && <h2 className="Head_Text_Temp1">{data.title}</h2>}
          <Permium1HC3Align>
            <Permium1HC3Grid1>
              {data?.content?.slice(0, 2).map((e, i) => {
                return (
                  <Permium1HC3Box
                    key={`preHC3_1_${i}`}
                    className="Permium1HC3_Box"
                  >
                    <Permium1HC3BoxBg
                      style={{ backgroundImage: `url("${e.image ? api.rootUrl + e.image : Default}")` }}
                    ></Permium1HC3BoxBg>
                    {/* <img src={e.image ? api.rootUrl + e.image : Default} alt={e.title} /> */}
                    <Permium1HC3Content>
                      <Permium1HC3Title>{e.title}</Permium1HC3Title>
                      <Permium1HC3Button>
                        <Link
                          to={e.link ? e.link.toLowerCase().replace(/ /g, '-')
                          .replace(/[^\w-]+/g, '') : "/"}
                          className="Template4_HC_3_Link"
                        >
                          Shop Now
                        </Link>
                      </Permium1HC3Button>
                    </Permium1HC3Content>
                  </Permium1HC3Box>
                );
              })}
            </Permium1HC3Grid1>
            <Permium1HC3Grid2>
              {data?.content?.slice(2, 3).map((e, i) => {
                return (
                  <Permium1HC3Box
                    key={`preHC3_1_${i}`}
                    className="Permium1HC3_Box"
                  >
                     <Permium1HC3BoxBg
                      style={{ backgroundImage: `url("${e.image ? api.rootUrl + e.image : Default}")` }}
                    ></Permium1HC3BoxBg>
                    <Permium1HC3Content>
                      <Permium1HC3Title>{e.title}</Permium1HC3Title>
                      <Permium1HC3Button>
                        <Link
                          to={e.link ? e.link.toLowerCase().replace(/ /g, '-')
                          .replace(/[^\w-]+/g, '') : "/"}
                          className="Template4_HC_3_Link"
                        >
                          Shop Now
                        </Link>
                      </Permium1HC3Button>
                    </Permium1HC3Content>
                  </Permium1HC3Box>
                );
              })}
            </Permium1HC3Grid2>
            <Permium1HC3Grid3>
              {data?.content?.slice(3, 5).map((e, i) => {
                return (
                  <Permium1HC3Box
                    key={`preHC3_1_${i}`}
                    className="Permium1HC3_Box"
                  >
                    <Permium1HC3BoxBg
                      style={{ backgroundImage: `url("${e.image ? api.rootUrl + e.image : Default}")` }}
                    ></Permium1HC3BoxBg>
                    <Permium1HC3Content>
                      <Permium1HC3Title>{e.title}</Permium1HC3Title>
                      <Permium1HC3Button>
                        <Link
                          to={e.link ? e.link.toLowerCase().replace(/ /g, '-')
                          .replace(/[^\w-]+/g, '') : "/"}
                          className="Template4_HC_3_Link"
                        >
                          Shop Now
                        </Link>
                      </Permium1HC3Button>
                    </Permium1HC3Content>
                  </Permium1HC3Box>
                );
              })}
            </Permium1HC3Grid3>
          </Permium1HC3Align>
        </Wrapperfull>
      </Section>
    </ThemeProvider>
  );
}
