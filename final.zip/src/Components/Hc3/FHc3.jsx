import React, { useState, useEffect } from 'react'
import five from "../../Assets/Images/furniture/5.png"
import styled from 'styled-components';
import { styles } from '../../Api/Data';
import API from "../../Api/ApiService";
import { Link } from "react-router-dom";
import Default from '../../Assets/Images/default.png'
const FHc3 = (props) => {

    const api = new API();
    const [data, setData] = useState([]);
    useEffect(() => {
        if (props.data) setData(props.data);
    }, [props]);
    return (
        <React.Fragment>
            <Hc3Section>
                <div className='h3_section'>
                    <div className='wrapper'>
                        {data.title && <H2>{data.title}</H2>}
                        <div className='hc3_align'>
                            <div className='hc3_1'>
                                <ul>
                                    {data?.content?.slice(0, 2).map((e, i) => {
                                        return (
                                            <li>
                                                <div className='hc3_box'>
                                                    <img src={e.image ? api.rootUrl + e.image : Default} alt={e.title} />
                                                    <div className='hc3_content'>
                                                        <h4>{e.title}</h4>
                                                        <Link to={e?.link.toLowerCase()
                                                            .replace(/ /g, "-")
                                                            .replace(/[^\w-]+/g, "")}><button>Shop Now</button></Link>
                                                    </div>
                                                </div>


                                            </li>
                                        );
                                    })}

                                </ul>
                            </div>
                            <div className='hc3_2'>
                                <ul>
                                    {data?.content?.slice(2, 3).map((e, i) => {
                                        return (
                                            <li>
                                                <div className='hc3_box'>
                                                    <img src={e.image ? api.rootUrl + e.image : Default} alt={e.title} />
                                                    <div className='hc3_content'>
                                                        <h4>{e.title}</h4>
                                                        <Link to={e?.link.toLowerCase()
                                                            .replace(/ /g, "-")
                                                            .replace(/[^\w-]+/g, "")}><button>Shop Now</button></Link>
                                                    </div>
                                                </div>


                                            </li>
                                        );
                                    })}
                                </ul>
                            </div>
                            <div className='hc3_3'>
                                <ul>
                                    {data?.content?.slice(3, 5).map((e, i) => {
                                        return (
                                            <li>
                                                <div className='hc3_box'>
                                                    <img src={e.image ? api.rootUrl + e.image : Default} alt={e.title} />
                                                    <div className='hc3_content'>
                                                        <h4>{e.title}</h4>
                                                        <Link to={e?.link.toLowerCase()
                                                            .replace(/ /g, "-")
                                                            .replace(/[^\w-]+/g, "")}><button>Shop Now</button></Link>
                                                    </div>
                                                </div>


                                            </li>
                                        );
                                    })}
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </Hc3Section>
        </React.Fragment>
    )
}

export default FHc3;

const H2 = styled.h2`
   font-size:30px;
   margin : 0 0 35px;
   text-transform: uppercase;
   font-family: ${styles?.r_regular} !important;
   letter-spacing: 0.7px;

   @media screen and (max-width:768px) {
    text-align: center;
   }

`

const Hc3Section = styled.section`
   display:inline-block;
   width:100%;
   position: relative;

   .h3_section {
    display: inline-block;
    width: 100%;
    position: relative;
   }
   .h3_section .hc3_align {
    display: flex;
    align-items: stretch;
    width: 100%;
    gap: 25px;
   }
   .h3_section .hc3_align ul {
    list-style: none;
    padding: 0;
    margin: 0;
   }
   .h3_section .hc3_align .hc3_1, .h3_section .hc3_align .hc3_3 {
    flex:1;
   }
   .h3_section .hc3_align .hc3_2 {
    flex: 2;
   }
   .h3_section .hc3_align .hc3_1 ul, .h3_section .hc3_align .hc3_3 ul {
    display: grid;
    grid-template-columns: repeat(1,1fr);
    gap: 25px;
   }
   .h3_section .hc3_align .hc3_1 ul .hc3_box, .h3_section .hc3_align .hc3_3 ul li .hc3_box, .h3_section .hc3_align .hc3_2 ul .hc3_box {
    background: #fff;
    border-radius: 10px;
    overflow: hidden;
    box-shadow: 0 0 15px rgb(0 0 0 / 5%);
   }
   .h3_section .hc3_align .hc3_2 ul, .h3_section .hc3_align .hc3_2 ul li, .h3_section .hc3_align .hc3_2 ul li .hc3_box,.h3_section .hc3_align .hc3_2 ul li .hc3_box img  {
    height: 100%;
   }
   .h3_section .hc3_align .hc3_2 ul li .hc3_box img {
    object-fit: cover;
   }
   .h3_section .hc3_align img {
    padding: 0 0 40px;
   }
   .h3_section ul li {
    position: relative;
   }
   .h3_section ul li .hc3_box .hc3_content {
        display: flex;
        flex-direction: column;
        gap: 5px;
        position: absolute;
        bottom: 0;
        left: 0;
        width: 100%;
        padding: 20px;
        text-align: left;
    }
    .h3_section ul li .hc3_box .hc3_content h4 {
        font-size: 23px;
    font-family: r_regular !important;
    text-transform: uppercase;
    color: #000;
    font-weight: 600;
    -webkit-letter-spacing: 1px;
    -moz-letter-spacing: 1px;
    -ms-letter-spacing: 1px;
    letter-spacing: 1px;
    margin: 0 0 5px;
    width: 100%;
    }
    .h3_section ul li .hc3_box .hc3_content button {
        width: fit-content;
    margin: 0px 0 0 0;
    border: 0;
    border-radius: 8px;
    padding: 6px 15px;
   display: flex;
    text-align: center;
    background: linear-gradient(14.29deg,#efbc48 7.56%,#ffd064 87.33%);
    color: #206942;
    font-family: r_regular !important;
    }


    @media screen and (max-width:768px) {
        .h3_section .hc3_align {
            flex-direction: column;
        }

        .h3_section ul li .hc3_box .hc3_content {
            text-align: center;
        }

        .h3_section ul li .hc3_box .hc3_content button { 
            margin: auto;
        }












    }











`