import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Button } from "react-bootstrap";
import API from "../../Api/ApiService";
import Default from "../../Assets/Images/default.png";
import styled from "styled-components";
import { styles } from "../../Api/Data";
const user = JSON.parse(localStorage.getItem("persist:root"))?.company;
const colorCustom = user && JSON.parse(user).setColor;
export default function Design5HC3(props) {
  const api = new API();
  const [data, setData] = useState([]);
  useEffect(() => {
    if (props.data) setData(props.data);
  }, [props]);
  return (
    <React.Fragment>
      <Hc3>
        <section className="Temp5_HC3">
          <div className="Wrapper_Full">
            {data.title && <H2>{data.title}</H2>}

            <div className="Temp5_HC3_Algin">
              {data?.content?.map((e, i) => {
                return (
                  <>
                    <div class="Temp5_overly">
                      <img
                        src={e.image ? api.rootUrl + e.image : Default}
                        alt=""
                        class={e.title}
                      />
                      <div class="overlay">
                        <div className="Temp5_heading">
                          <h4>{e.title}</h4>
                        </div>

                        <div class="text">
                          <p>{e.sub_title}</p>

                          {e.link_text && (
                            <div className="Temp5_HC3_Box_Btn">
                              <Link
                                to={e.link
                                  .toLowerCase()
                                  .replace(/ /g, "-")
                                  .replace(/[^\w-]+/g, "")}
                              >
                                <Button>
                                  <span>{e.link_text}</span>
                                </Button>
                              </Link>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </>
                );
              })}
            </div>
          </div>
        </section>
      </Hc3>
    </React.Fragment>
  );
}


const H2 = styled.h1`
  font-size: ${styles?.h2};
  font-family: ${styles?.font} !important;
  color: ${colorCustom?.color ? colorCustom?.color : styles?.color} !important;
  line-height: 1.4;
  margin: 0 0 25px;
  text-align: center;

  @media screen and (max-width: 768px) {
    text-align: center;
  }
`;


const Hc3 = styled.div`

.Temp5_HC3_Algin {
  display: grid;
  grid-template-columns: repeat(5, 1fr);
  gap: 20px;
}

.Head_Text_Temp5 {
  text-align: center;
}

.Temp5_overly {
  position: relative;
  width: 86%;
  padding: 0px;
  margin: auto;
}

.image {
  display: block;
  width: 100%;
  height: auto;
}

.overlay {
  position: absolute;
  bottom: 0;
  left: 100%;
  right: 0;
  background-color: rgb(0 0 0 / 66%);
  overflow: hidden;
  width: 0;
  height: 100%;
  transition: 0.3s ease;
}

.Temp5_overly:hover .overlay {
  width: 100%;
  left: 0;
}

.Temp5_HC3_Box_Btn {
  text-align: center;
  background: ${styles?.colorapi};
  border-radius:6px ;
}

.Temp5_HC3_Box_Btn button {
  background: ${styles?.colorapi};
  border: 1px solid ${styles?.colorapi};
}

.Temp5_heading h4 {
  color: white !important;
  font-size: 18px;
}

.Temp5_heading {
  color: white;
  padding: 10px;
}

.text {
  color: white;
  font-size: 20px;
  position: absolute;
  top: 50%;
  left: 50%;
  -webkit-transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
  transform: translate(-50%, -50%);
  white-space: nowrap;
}
@media screen and (max-width: 992px) {
 .Temp5_HC3_Algin {
   grid-template-columns: repeat(3, 1fr);
 }
 
}


@media screen and (max-width:768px) {
  .Temp5_HC3_Algin {
    grid-template-columns: repeat(2, 1fr);
  }
}


@media screen and (max-width:600px) {
  .Temp5_HC3_Algin {
    grid-template-columns: repeat(1, 1fr);
  }
  
}
















`;
