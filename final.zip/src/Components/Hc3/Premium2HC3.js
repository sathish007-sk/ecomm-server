import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import styled, { ThemeProvider } from "styled-components";

export default function Premium2HC3(props) {
  const [data, setData] = useState([]);
  useEffect(() => {
    if (props.data) setData(props.data);
  }, [props]);

  const size = {
    desktop: "1920px",
    laptop: "1440px",
    minilaptop: "1200px",
    tabletl: "992px",
    tablet: "768px",
    mobilel: "580px",
    mobilep: "480px",
    mobiles: "380px",
  };

  const device = {
    desktop: `@media screen and (max-width: ${size.desktop})`,
    laptop: `@media screen and (max-width: ${size.laptop})`,
    minilaptop: `@media screen and (max-width: ${size.minilaptop})`,
    tabletl: `@media screen and (max-width: ${size.tabletl})`,
    tablet: `@media screen and (max-width: ${size.tablet})`,
    mobilel: `@media screen and (max-width: ${size.mobilel})`,
    mobilep: `@media screen and (max-width: ${size.mobilep})`,
    mobiles: `@media screen and (max-width: ${size.mobiles})`,
  };

  const theme = {
    id: {
      background: "#fff",
      color: "#dfad54",
      background: "#0d0d0d",
      border: "#dfad54",
      gray: "#888",
      bg70: "rgb(255 255 255 / 70%)",
      bglight: "#f5f5f5",
    },
    titlesize: [
      {
        screen: "desktop",
        value: 27,
      },
      {
        screen: "tablet",
        value: 20,
      },
      {
        screen: "mobile",
        value: 20,
      },
    ],
    colcount: [
      {
        screen: "desktop",
        value: 3,
      },
      {
        screen: "tablet",
        value: 2,
      },
      {
        screen: "mobile",
        value: 1,
      },
    ],
    gap: [
      {
        screen: "desktop",
        value: 25,
      },
      {
        screen: "tablet",
        value: 20,
      },
      {
        screen: "mobile",
        value: 15,
      },
    ],
  };

  const Section = styled.section`
    width: 100%;
    display: inline-block;
    position: relative;
    h2 {
      color: ${(props) =>
        props.theme.id.color ? props.theme.id.color : "#000"} !important;
      text-align: center;
      margin: 0 0 45px;
      position: relative;
      padding: 0 0 18px;
      &:before {
        content: "";
        height: 4px;
        width: 75px;
        position: absolute;
        bottom: 0;
        left: 50%;
        transform: translate(-50%, 0px);
        border-radius: 3px;
        background: ${(props) =>
          props.theme.id.color ? props.theme.id.color : "#000"};
      }
    }
  `;
  const Wrapperfull = styled.div`
    max-width: 100%;
    padding: 0 20px;
  `;
  const Permium1HC3Align = styled.div`
    display: flex;
    width: 100%;
    position: relative;
    gap: 40px;

    ${device.minilaptop} {
      display: grid;
    }
  `;
  const Permium1HC3Grid1 = styled.div`
    flex: 1;

    display: flex;
    flex-direction: column;
    gap: 25px;

    .Permium1HC3_Box {
      border: 0px solid
        ${(props) => (props.theme.border ? props.theme.border : "#000")};
    }

    ${device.minilaptop} {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
    }

    ${device.tablet} {
      display: grid;
      grid-template-columns: repeat(1, 1fr);
    }
  `;
  const Permium1HC3Grid2 = styled.div`
    flex: 2;
    border: 0px solid
      ${(props) => (props.theme.border ? props.theme.border : "#000")};

    .Permium1HC3_Box {
      height: 100%;
      width: 100%;
    }
  `;
  const Permium1HC3Grid3 = styled.div`
    flex: 1;

    display: flex;
    flex-direction: column;
    gap: 25px;

    .Permium1HC3_Box {
      border: 0px solid
        ${(props) => (props.theme.border ? props.theme.border : "#000")};
    }

    ${device.minilaptop} {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
    }

    ${device.tablet} {
      display: grid;
      grid-template-columns: repeat(1, 1fr);
    }
  `;
  const Permium1HC3Box = styled.div`
    display: flex;
    min-height: 280px;
    position: relative;
    align-items: flex-end;
    justify-content: flex-start;
    flex-direction: column;
    gap: 25px 0;
    ${device.minilaptop} {
      min-height: 400px;
    }

    ${device.tablet} {
      min-height: 400px;
    }
  `;

  const Permium1HC3BoxBgImg = styled.div`
    display: inline-block;
    width: 100%;
    position: relative;
    border: 7px solid
      ${(props) => (props.theme.id.color ? props.theme.id.color : "#000")};
    border-radius: 180px 10px 180px 180px;
    overflow: hidden;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    &:hover img {
      transform: scale(1.2);
      transition: all 0.5s ease-in-out;
    }
  `;

  const Permium1HC3BoxBg = styled.img`
    position: relative;
    width: 100%;
    transition: all 0.5s ease-in-out;
  `;

  const Permium1HC3Content = styled.div`
    width: 100%;
    z-index: 10;
    padding: 0px 20px;
    display: flex;
    align-items: flex-start;
    flex-direction: column;
    gap: 15px;
    position: relative;
  `;

  const Permium1HC3Title = styled.h4`
    margin: 0 !important;
    color: ${(props) =>
      props.theme.id.color ? props.theme.id.color : "000"} !important;
    font-weight: 600;
    margin: 0;
    width: 100%;
    display: inline-block;
    text-align: center;
    ${device.desktop} {
      font-size: ${(props) =>
        props.theme.titlesize[0].screen == "desktop"
          ? props.theme.titlesize[0].value
          : 27}px !important;
    }
    ${device.tabletl} {
      font-size: ${(props) =>
        props.theme.titlesize[1].screen == "tablet"
          ? props.theme.titlesize[1].value
          : 20}px !important;
    }
    ${device.mobilel} {
      font-size: ${(props) =>
        props.theme.titlesize[2].screen == "mobile"
          ? props.theme.titlesize[2].value
          : 20}px !important;
    }
  `;
  const Permium1HC3Button = styled.button`
    position: relative;
    display: inline-block;
    padding: 0 0 0px 0px;
    width: fit-content;
    border: 1px solid
      ${(props) => (props.theme.id.color ? props.theme.id.color : "#000")};
    background: transparent;
    outline: none;
    margin: auto;
    background: transparent;
    border-radius: 24px 5px 24px 24px;
    color: ${(props) =>
      props.theme.id.background ? props.theme.id.background : "#000"};
    a {
      padding: 9px 20px;
      border: 0;

      border-radius: 3px;
      color: ${(props) =>
        props.theme.id.color ? props.theme.id.color : "#000"};
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      font-size: 13px !important;
      display: inline-block;
      position: relative;
      z-index: 11;
    }
  `;

  return (
    <ThemeProvider theme={theme}>
      <Section className="Premium1_HC3" id={theme.id}>
        <Wrapperfull>
          {data.title && <h2 className="Head_Text_Temp1">{data.title}</h2>}
          <Permium1HC3Align>
            <Permium1HC3Grid1>
              {data?.content?.slice(0, 2).map((e, i) => {
                return (
                  <Permium1HC3Box
                    key={`preHC3_1_${i}`}
                    className="Permium1HC3_Box"
                  >
                    <Permium1HC3BoxBgImg>
                      <Permium1HC3BoxBg
                        src={e.image}
                        alt={e.title}
                      ></Permium1HC3BoxBg>
                    </Permium1HC3BoxBgImg>
                    <Permium1HC3Content>
                      <Permium1HC3Title>{e.title}</Permium1HC3Title>
                      <Permium1HC3Button>
                        <Link
                          to={e.link ? e.link.toLowerCase().replace(/ /g, '-')
                          .replace(/[^\w-]+/g, '') : "/"}
                          className="Template4_HC_3_Link"
                        >
                          Shop Now
                        </Link>
                      </Permium1HC3Button>
                    </Permium1HC3Content>
                  </Permium1HC3Box>
                );
              })}
            </Permium1HC3Grid1>
            <Permium1HC3Grid2>
              {data?.content?.slice(2, 3).map((e, i) => {
                return (
                  <Permium1HC3Box
                    key={`preHC3_1_${i}`}
                    className="Permium1HC3_Box"
                  >
                    <Permium1HC3BoxBgImg>
                      <Permium1HC3BoxBg
                        src={e.image}
                        alt={e.title}
                      ></Permium1HC3BoxBg>
                    </Permium1HC3BoxBgImg>
                    <Permium1HC3Content>
                      <Permium1HC3Title>{e.title}</Permium1HC3Title>
                      <Permium1HC3Button>
                        <Link
                          to={e.link ? e.link.toLowerCase().replace(/ /g, '-')
                          .replace(/[^\w-]+/g, '') : "/"}
                          className="Template4_HC_3_Link"
                        >
                          Shop Now
                        </Link>
                      </Permium1HC3Button>
                    </Permium1HC3Content>
                  </Permium1HC3Box>
                );
              })}
            </Permium1HC3Grid2>
            <Permium1HC3Grid3>
              {data?.content?.slice(3, 5).map((e, i) => {
                return (
                  <Permium1HC3Box
                    key={`preHC3_1_${i}`}
                    className="Permium1HC3_Box"
                  >
                    <Permium1HC3BoxBgImg>
                      <Permium1HC3BoxBg
                        src={e.image}
                        alt={e.title}
                      ></Permium1HC3BoxBg>
                    </Permium1HC3BoxBgImg>
                    <Permium1HC3Content>
                      <Permium1HC3Title>{e.title}</Permium1HC3Title>
                      <Permium1HC3Button>
                        <Link
                          to={e.link ? e.link.toLowerCase().replace(/ /g, '-')
                          .replace(/[^\w-]+/g, '') : "/"}
                          className="Template4_HC_3_Link"
                        >
                          Shop Now
                        </Link>
                      </Permium1HC3Button>
                    </Permium1HC3Content>
                  </Permium1HC3Box>
                );
              })}
            </Permium1HC3Grid3>
          </Permium1HC3Align>
        </Wrapperfull>
      </Section>
    </ThemeProvider>
  );
}
