import React, { useEffect, useState } from 'react'
import { Button } from "antd";
import styled from 'styled-components';
import { styles } from '../../Api/Data'
import { Link } from 'react-router-dom'
import { RightCircleOutlined } from "@ant-design/icons";
import API from "../../Api/ApiService";
import Default from '../../Assets/Images/default.png'


const Temp1HC3 = ({ data }) => {
    const api = new API();
    const [content, setContent] = useState([])

    useEffect(() => {
        setContent(data.content)
    }, [])

    return (
        <React.Fragment>
            <Section>
                <Wrapper>
                    <HeadText>
                        <H2>{data.title}</H2>
                        <Button>
                            View All
                            <RightCircleOutlined />
                        </Button>
                    </HeadText>
                    <Row>
                        <Col1>
                            {content?.slice(0, 2).map((data) => {
                                return (
                                    <Box key={data._id}>
                                        <BG>
                                            <Img src={data.image ? api.rootUrl + data.image : Default} />
                                        </BG>
                                        <Content>
                                            <Title>{data.title}</Title>
                                            <Link to={data.link}>
                                                <Button>{data.link_text}</Button>
                                            </Link>
                                        </Content>
                                    </Box>
                                )
                            })}


                        </Col1>
                        <Col2>
                            {content?.slice(2, 3).map((data) => {
                                return (
                                    <Box key={data._id}>
                                        <BG>
                                            <Img src={api.rootUrl + data.image} />
                                        </BG>
                                        <Content>
                                            <Title>{data.title}</Title>
                                            <Link to={data.link}>
                                                <Button>{data.link_text}</Button>
                                            </Link>
                                        </Content>
                                    </Box>
                                )
                            })}
                        </Col2>
                        <Col3>
                            {content?.slice(3, 5).map((data) => {
                                return (
                                    <Box key={data._id}>
                                        <BG>
                                            <Img src={data.image ? api.rootUrl + data.image : Default} />
                                        </BG>
                                        <Content>
                                            <Title>{data.title}</Title>
                                            <Link to={data.link}>
                                                <Button>{data.link_text}</Button>
                                            </Link>
                                        </Content>
                                    </Box>
                                )
                            })}
                        </Col3>
                    </Row>


                </Wrapper>
            </Section>
        </React.Fragment>
    )
}

export default Temp1HC3

const Section = styled.section`
width: 100%;
position: relative;
display: inline-block;
box-sizing: border-box;
`;
const Wrapper = styled.div`
max-width: 1200px;
padding: 0 10px;
margin: auto;
box-sizing: border-box;
`;

const HeadText = styled.div`
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: space-between;
  position: relative;
`;
const H2 = styled.h2`
  color: ${styles.color};
  font-size: ${styles.h2};
`;


const Row = styled.div`
display: flex;
flex-wrap: wrap;
gap: 30px;
margin: 25px 0 0 0;
`;
const Col1 = styled.div`
flex: 1;
display: flex;
flex-direction: column;
gap: 30px;
`;
const Col2 = styled.div`
flex: 2;

`;
const Col3 = styled.div`
flex: 1;
display: flex;
flex-direction: column;
gap: 30px;
`;
const Box = styled.div`
border: 1px solid ${styles.light};
`;
const BG = styled.div``;
const Img = styled.img`
max-width: 100%;
`;
const Content = styled.div`
padding: 20px;
display: flex;
flex-direction: column;
gap: 15px;

button {
    width:fit-content
}
`;
const Title = styled.div`
font-size: 22px;
color: ${styles.color};
font-weight: 600;
`;