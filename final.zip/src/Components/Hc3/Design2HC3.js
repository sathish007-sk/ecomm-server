import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import API from "../../Api/ApiService";
import Default from '../../Assets/Images/default.png'
import "bootstrap/dist/css/bootstrap.min.css";
import { Card, Button } from "react-bootstrap";
import { Swiper, SwiperSlide } from "swiper/react";
import { Navigation, Pagination, Autoplay } from "swiper";
import "swiper/css";
import "swiper/scss/pagination";
import "react-multi-carousel/lib/styles.css";
import styled from "styled-components";
import { styles } from "../../Api/Data";
const user = JSON.parse(localStorage.getItem("persist:root"))?.company;
const colorCustom = user && JSON.parse(user).setColor;


export default function Design2HC3(props) {
  const api = new API();
  const [data, setData] = useState([]);
  useEffect(() => {
    if (props.data) setData(props.data);
  }, [props]);
  return (
    <React.Fragment><Hc3>
    <section className="Temp2_HC3">
      <div className="Wrapper">
      {data.title && <H2>{data.title}</H2>}

        <Swiper
          slidesPerView={3}
          spaceBetween={20}
          freeMode={true}
          Navigation={true}
          autoplay={true}
          loop={true}
          breakpoints={{
            300: {
              slidesPerView: 1,
              spaceBetween: 0,
            },
            580: {
              slidesPerView: 2,
              spaceBetween: 10,
            },

            768: {
              slidesPerView: 2,
              spaceBetween: 20,
            },
            1200: {
              slidesPerView: 3,
              spaceBetween: 20,
            },
          }}
          modules={[Pagination, Autoplay, Navigation]}
        >
          {data?.content?.map((e) => {
            return (
              <SwiperSlide>
                <div className="Temp2_HC3_Box">
                  <div className="Temp2_HC3_Box_Grid">
                    <Link to={e.link.toLowerCase().replace(/ /g, '-')
                      .replace(/[^\w-]+/g, '')}>
                      <Card.Img
                        src={e.image ? api.rootUrl + e.image : Default}
                        style={{
                          width: "100%",
                          display: "block",
                          margin: "auto",
                        }}
                      />
                      <div className="Temp2_HC3_Box_Hover">
                        <div>
                          <h4>{e.sub_title}</h4>
                          {e.description && (
                            <p
                              dangerouslySetInnerHTML={{
                                __html: e.description,
                              }}
                            ></p>
                          )}
                          <Button>{e.link_text}</Button>
                        </div>
                      </div>
                    </Link>
                  </div>
                  <div className="Temp2_HC3_Box_Head">
                    <h4>{e.title}</h4>
                  </div>
                </div>
              </SwiperSlide>
            );
          })}
        </Swiper>
      </div>
    </section>
    </Hc3></React.Fragment>
  );
}

const H2 = styled.h2`
  font-size: ${styles?.h2};
  font-family: ${styles?.font} !important;
  color: ${colorCustom?.color ? colorCustom?.color : styles?.color} !important;
  line-height: 1.4;
  margin: 0 0 25px;
  text-align: center;

  @media screen and (max-width: 768px) {
    text-align: center;
  }
`;


const Hc3 = styled.div`


.Temp2_HC3 {
  display: inline-block;
  width: 100%;
  position: relative;
}
.Temp2_HC3 .Temp2_HC3_Box {
  display: inline-block;
  width: 100%;
  position: relative;
  border: 1px solid ${styles?.light};
}
.Temp2_HC3 .Temp2_HC3_Box .Temp2_HC3_Box_Grid {
  width: 100%;
  display: flex;
  position: relative;
  flex-wrap: wrap;
  overflow: hidden;
}
.Temp2_HC3 .Temp2_HC3_Box .Temp2_HC3_Box_Grid img {
  width: 100%;
  display: inline-block;
  transition: all 0.6s ease-in-out;
}
.Temp2_HC3 .Temp2_HC3_Box:hover .Temp2_HC3_Box_Grid img {
  transform: scale(1.2);
  transition: all 0.6s ease-in-out; 
}
.Temp2_HC3 .Temp2_HC3_Box .Temp2_HC3_Box_Grid .Temp2_HC3_Box_Hover {
  display: flex;
  top: 10px;
  left: 10px;
  bottom: 10px;
  right: 10px;
  position: absolute;
  background: ${styles?.colorapi+ "60"};
  border-radius: 5px;
  align-items: center;
  justify-content: center;
  padding: 20px;
  opacity: 0;
  transition: all 0.4s ease-in-out;
}
.Temp2_HC3 .Temp2_HC3_Box:hover .Temp2_HC3_Box_Grid .Temp2_HC3_Box_Hover {
  opacity: 1;
  transition: all 0.4s ease-in-out;
}
.Temp2_HC3 .Temp2_HC3_Box .Temp2_HC3_Box_Grid .Temp2_HC3_Box_Hover h4 {
  text-align: center;
  color: ${styles?.white} !important;
  font-family: ${styles?.medium};
  margin: 0 !important;
  font-size: ${styles?.h5} !important;
  padding: 0 !important;
}
.Temp2_HC3 .Temp2_HC3_Box .Temp2_HC3_Box_Grid .Temp2_HC3_Box_Hover div {
  display: flex;
  flex-direction: column;
  gap: 15px;
}
.Temp2_HC3 .Temp2_HC3_Box .Temp2_HC3_Box_Grid .Temp2_HC3_Box_Hover p {
  margin: 0;
}
.Temp2_HC3 .Temp2_HC3_Box .Temp2_HC3_Box_Grid .Temp2_HC3_Box_Hover p * {
  text-align: center;
  color: ${styles?.white} !important;
  line-height: 1.6;
  font-family: ${styles?.regular} !important;
  margin: 0;
  width: 100%;
  font-size: ${styles?.p};
  display: inline-block;
}
.Temp2_HC3 .Temp2_HC3_Box .Temp2_HC3_Box_Grid .Temp2_HC3_Box_Hover button {
  display: flex;
  margin: auto;
  background: ${styles?.color};
  border: 1px solid ${styles?.color};
  
}
.Temp2_HC3 .Temp2_HC3_Box h4 {
  text-align: center;
  color: ${styles?.color} !important;
  font-size: ${styles?.h5};
  margin: 0%;
  padding: 15px 20px;
  font-family: ${styles?.medium} !important;
}





`;