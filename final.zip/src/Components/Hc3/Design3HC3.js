import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";

import { Navigation, Pagination, EffectCoverflow } from "swiper";
import API from "../../Api/ApiService";
import Default from "../../Assets/Images/default.png";
import { Swiper, SwiperSlide } from "swiper/react";
import styled from "styled-components";
import { styles } from "../../Api/Data";
const user = JSON.parse(localStorage.getItem("persist:root"))?.company;
const colorCustom = user && JSON.parse(user).setColor;
export default function HC9(props) {
  const api = new API();
  const [data, setData] = useState([]);
  useEffect(() => {
    if (props.data) setData(props.data);
  }, [props]);
  return (
    <React.Fragment>
      <Hc3>
        <section className="Temp3_HC3">
          {data.title && <H2>{data.title}</H2>}

          <div className="Temp3_HC3_Align">
            <div>
              <Swiper
                spaceBetween={20}
                slidesPerView={5}
                modules={[Navigation, Pagination, EffectCoverflow]}
                effect="coverflow"
                pagination={{ clickable: true }}
                coverflowEffect={{
                  rotate: 30,
                  stretch: 0,
                  depth: 50,
                  modifier: 1,
                  slideShadows: false,
                }}
                autoplay={{
                  delay: 2500,
                  disableOnInteraction: false,
                }}
                breakpoints={{
                  1200: {
                    spaceBetween: 20,
                    slidesPerView: 5,
                    speed: 1500,
                  },
                  768: {
                    spaceBetween: 20,
                    slidesPerView: 3,
                  },
                  580: {
                    spaceBetween: 20,
                    slidesPerView: 2,
                    effect: "slide",
                  },
                  320: {
                    spaceBetween: 0,
                    slidesPerView: 1,
                    effect: "fade",
                    coverflowEffect: {
                      rotate: 0,
                      stretch: 0,
                      depth: 0,
                      modifier: 1,
                      slideShadows: false,
                    },
                  },
                }}
                className="Temp3_HC3_Slider"
              >
                {data?.content?.slice(0, 5).map((e, i) => {
                  return (
                    <SwiperSlide key={`hc3_1_${i}`}>
                      <div className="Temp3_HC3_Box">
                        <Link
                          to={
                            e.link
                              ? e.link
                                  .toLowerCase()
                                  .replace(/ /g, "-")
                                  .replace(/[^\w-]+/g, "")
                              : "/"
                          }
                          className="Temp3_HC3_Box_Link"
                        >
                          <div
                            className="Temp3_HC3_Box_Align"
                            style={{
                              backgroundImage: `url("${
                                e.image ? api.rootUrl + e.image : Default
                              }")`,
                            }}
                          >
                            <div
                              className="Temp3_HC3_Box_Bg"
                              style={{
                                backgroundImage: `url("${
                                  e.image ? api.rootUrl + e.image : Default
                                }")`,
                              }}
                            ></div>
                            <div className="Temp3_HC3_Box_Content">
                              <h4>{e.title}</h4>
                            </div>
                          </div>
                        </Link>
                      </div>
                    </SwiperSlide>
                  );
                })}
              </Swiper>
            </div>
          </div>
        </section>
      </Hc3>
    </React.Fragment>
  );
}

const H2 = styled.h2`
  font-size: ${styles?.h2};
  font-family: ${styles?.font} !important;
  color: ${colorCustom?.color ? colorCustom?.color : styles?.color} !important;
  line-height: 1.4;
  margin: 0 0 25px;
  text-align: center;

  @media screen and (max-width: 768px) {
    text-align: center;
  }
`;


const Hc3 = styled.div`
  .Temp3_HC3 {
    display: inline-block;
    width: 100%;
    position: relative;
  }
  .Temp3_HC3 .Temp3_HC3_Box {
    display: inline-block;
    width: 100%;
    padding: 12px 0;
  }

  .Temp3_HC3 .Temp3_HC3_Box .Temp3_HC3_Box_Align {
    height: 400px;
    width: 100%;
    border-radius: 5px;
    background-position: center center;
    background-size: cover;
    overflow: hidden;
  }
  .Temp3_HC3 .Temp3_HC3_Box .Temp3_HC3_Box_Align .Temp3_HC3_Box_Content h4 {
    padding: 15px;
    background: ${styles?.bg60};
    color: ${styles?.white} !important;
    bottom: 12px;
    position: absolute;
    text-align: center;
    font-size: ${styles?.h5} !important;
    width: 100%;
    left: 0;
    margin: 0;
    font-family: ${styles?.medium} !important;
    border-radius: 0 0 5px 5px;
  }

  @media screen and (max-width: 1200px) {
    .Temp3_HC3 .Temp3_HC3_Box .Temp3_HC3_Box_Align .Temp3_HC3_Box_Content h4 {
      bottom: 57px;
    }
    .Temp3_HC3 .Temp3_HC3_Box {
      margin: 0 0 45px;
    }
  }

  @media screen and (max-width: 768px) {
    .Temp3_HC3 {
      padding: 0 15px;
    }
  }
`;
