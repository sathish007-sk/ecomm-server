import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import API from "../../Api/ApiService";
import Default from "../../Assets/Images/default.png";
import styled from "styled-components";
import { styles } from "../../Api/Data";
const user = JSON.parse(localStorage.getItem("persist:root"))?.company;
const colorCustom = user && JSON.parse(user).setColor;
export default function DesignFourHc2(props) {
  const api = new API();
  const [data, setData] = useState([]);
  useEffect(() => {
    if (props.data) setData(props.data);
  }, [props]);
  return (
    <React.Fragment>
      <Hc3>
        <section className="Template4_HC_3">
          <div className="Wrapper_Full">
            {data.title && <H2>{data.title}</H2>}
            <div className="Template4_HC_3_Align">
              {data?.content?.slice(0, 5).map((e, i) => {
                return (
                  <div className="Template4_HC_3_Items" key={`de_4_hc3_1_${i}`}>
                    <div className="Template4_HC_3_Top">
                      <div
                        style={{
                          backgroundImage: `url("${
                            e.image ? api.rootUrl + e.image : Default
                          }")`,
                        }}
                        className="Template4_HC_3_Zoom"
                      ></div>
                    </div>
                    <div className="Template4_HC_3_Bottom">
                      <div className="Template4_HC_3_Bottom_Content">
                        <h4 className="Template4_HC_3_Title">{e.title}</h4>
                        <i>{e.sub_title}</i>

                        <Link
                          to={
                            e.link
                              ? e.link
                                  .toLowerCase()
                                  .replace(/ /g, "-")
                                  .replace(/[^\w-]+/g, "")
                              : "/"
                          }
                          className="Template4_HC_3_Link"
                        >
                          <button>Shop Now</button>
                        </Link>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </section>
      </Hc3>
    </React.Fragment>
  );
}
const H2 = styled.h1`
  font-size: ${styles?.h2};
  font-family: ${styles?.font} !important;
  color: ${colorCustom?.color ? colorCustom?.color : styles?.color} !important;
  line-height: 1.4;
  margin: 0 0 25px;

  @media screen and (max-width: 768px) {
    text-align: center;
  }
`;

const Hc3 = styled.div`
  .Template4_HC_3 {
    display: inline-block;
    padding: 0px 0;
    width: 100%;
  }

  .Template4_HC_3 .Template4_HC_3_Align {
    display: grid;
    grid-template-columns: repeat(5, 1fr);
    width: 100%;
  }
  .Template4_HC_3 .Template4_HC_3_Align .Template4_HC_3_Items {
    display: flex;
    width: 100%;
    position: relative;
    flex-wrap: wrap;
  }
  .Template4_HC_3 .Template4_HC_3_Align .Template4_HC_3_Items:nth-child(even) {
    flex-direction: column-reverse;
  }
  .Template4_HC_3
    .Template4_HC_3_Align
    .Template4_HC_3_Items
    .Template4_HC_3_Top {
    height: 250px;
    display: inline-block;
    position: relative;
    width: 100%;
  }
  .Template4_HC_3
    .Template4_HC_3_Align
    .Template4_HC_3_Items
    .Template4_HC_3_Top::before {
    content: "";
    position: absolute;
    z-index: 5;
    top: 0;
    bottom: 0%;
    left: 0%;
    right: 0%;
    background: ${styles?.bg60};
  }
  .Template4_HC_3
    .Template4_HC_3_Align
    .Template4_HC_3_Items
    .Template4_HC_3_Top
    .Template4_HC_3_Zoom {
    position: absolute;
    top: 0;
    left: 0;
    bottom: 0;
    right: 0%;
    height: 100%;
    width: 100%;
    background-position: center center;
    background-size: cover;
  }
  .Template4_HC_3
    .Template4_HC_3_Align
    .Template4_HC_3_Items
    .Template4_HC_3_Bottom {
    min-height: 250px;
    display: flex;
    align-items: center;
    justify-content: center;
    width: 100%;
    flex-wrap: wrap;
    background: ${styles?.white} !important;
  }
  .Template4_HC_3
    .Template4_HC_3_Align
    .Template4_HC_3_Items
    .Template4_HC_3_Bottom
    .Template4_HC_3_Bottom_Content {
    text-align: center;
    width: 100%;
    position: relative;
    display: flex;
    padding: 20px;
    flex-wrap: wrap;
    gap: 12px;
    align-items: center;
    justify-content: center;
  }
  .Template4_HC_3
    .Template4_HC_3_Align
    .Template4_HC_3_Items
    .Template4_HC_3_Bottom
    .Template4_HC_3_Bottom_Content
    h4.Template4_HC_3_Title {
    font-size: 25px;
    line-height: 1.5;
    color: ${styles?.color};
    font-weight: 700;
  }
  .Template4_HC_3
    .Template4_HC_3_Align
    .Template4_HC_3_Items
    .Template4_HC_3_Bottom
    .Template4_HC_3_Bottom_Content
    i {
    width: 100%;
    text-align: center;
    display: inline-block;
  }
  .Template4_HC_3
    .Template4_HC_3_Align
    .Template4_HC_3_Items
    .Template4_HC_3_Bottom
    .Template4_HC_3_Bottom_Content
    .Template4_HC_3_Link
    button {
    padding: 0 0 3px;
    background: transparent;
    border: 0;
    text-transform: uppercase;
    font-weight: 700;
    letter-spacing: 2px;
    border-bottom: 2px solid ${styles?.color};
    color: ${styles?.color};
    margin: auto;
    width: fit-content;
  }

  @media screen and (max-width: 992px) {
    .Template4_HC_3 .Template4_HC_3_Align {
      grid-template-columns: repeat(1, 1fr);
    }
    .Template4_HC_3 .Template4_HC_3_Align .Template4_HC_3_Items {
      display: flex;
      flex-wrap: wrap;
    }
    .Template4_HC_3
      .Template4_HC_3_Align
      .Template4_HC_3_Items
      .Template4_HC_3_Top {
      width: 50%;
    }
    .Template4_HC_3
      .Template4_HC_3_Align
      .Template4_HC_3_Items
      .Template4_HC_3_Bottom {
      width: 50%;
    }
    .Template4_HC_3
      .Template4_HC_3_Align
      .Template4_HC_3_Items:nth-child(even) {
      flex-direction: row-reverse;
    }
  }

  @media screen and (max-width: 480px) {
    .Template4_HC_3
      .Template4_HC_3_Align
      .Template4_HC_3_Items
      .Template4_HC_3_Top,
    .Template4_HC_3
      .Template4_HC_3_Align
      .Template4_HC_3_Items
      .Template4_HC_3_Bottom {
      width: 100%;
    }
    .Template4_HC_3
      .Template4_HC_3_Align
      .Template4_HC_3_Items
      .Template4_HC_3_Bottom {
      min-height: auto;
      padding: 40px 0;
    }

    .Template4_HC_3 .Template4_HC_3_Align {
      gap: 30px;
    }
  }
`;
