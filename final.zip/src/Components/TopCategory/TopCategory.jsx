import React, { useEffect, useState } from "react";
import styled from "styled-components";
import { styles } from "../../Api/Data";
import { RightCircleOutlined } from "@ant-design/icons";
import { Button } from "antd";
import { Link } from 'react-router-dom';
import Default from '../../Assets/Images/default.png'
import API from "../../Api/ApiService";


const TopCategory = () => {
  const api = new API();
  const [category, setCategory] = useState([])
  const topCategoryResult = category.filter(e => e.parent === null)
  useEffect(() => {
    api.topCategory().then((res) => {
      setCategory(res.data)
    }).catch((err) => { })
  }, [])

  return (
    <React.Fragment>
      <TopCategorySection>
        <Wrapper>
          <HeadText>
            <H1>Top Categories</H1>
            <Button>
              View All
              <RightCircleOutlined />
            </Button>
          </HeadText>
          <Ul>
            {topCategoryResult.length > 1 ? (
              topCategoryResult?.map((data) => (
                <Li key={data._id}>
                  <Link to={data.category_name.toLowerCase().replace(/ /g, '-')
                        .replace(/[^\w-]+/g, '')}>
                    <Img
                      src={data.images ? api.rootUrl + data.images : Default}
                      alt={data.category_name ? data.category_name : "Our Product"}
                    />
                    <H4>{data.category_name}</H4>
                    {/* <P></P> */}
                  </Link>
                </Li>
              ))
            ) : (
              <p className="no_result_fount">No Category Created yet</p>
            )}
          </Ul>
        </Wrapper>
      </TopCategorySection>
    </React.Fragment>
  );
};

export default TopCategory;


const TopCategorySection = styled.section`
  display: inline-block;
  width:100%;
  position: relative;
  margin: 0px 0;
`;
const Wrapper = styled.div`
  max-width: 1200px;
  margin: auto;
`;
const HeadText = styled.div`
  width:100%;
  display: flex;
  align-items: center;
  justify-content: space-between;
  position: relative;
`;
const H1 = styled.h1`
  color: ${styles.color};
  font-size: ${styles.h2};
`;
const Ul = styled.ul`
  display: grid;
  grid-template-columns: repeat(6,1fr);
  gap: 25px;
  list-style: none;
  margin: 45px 0 0 0;
  padding: 0;
`;
const Li = styled.li`
  width:100%;
  display: inline-block;
  position: relative;
`;
const Img = styled.img`
  height: 120px;
  width:120px;
  border-radius: 100%;
  max-width: 100%;
  display: block;
  margin: auto auto 15px;
`;
const H4 = styled.h4`
  text-align: center;
  color:${styles.color};
  font-size: 17px;
  font-weight: 600;
  margin: 0 0 5px;
`;
const P = styled.p`
  text-align: center;
  color: ${styles.gray};
  font-size: 14px;
  font-style: italic;
`;
