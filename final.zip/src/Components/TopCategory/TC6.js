import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import API from "../../Api/ApiService";
import { Swiper, SwiperSlide } from "swiper/react";
import { Pagination, Autoplay } from "swiper";
import "swiper/css";
import "swiper/scss/pagination";
import DefaultImg from "../../Assets/Images/default.png";
import styled from "styled-components";
import { styles } from "../../Api/Data";
const user = JSON.parse(localStorage.getItem("persist:root"))?.company;
const colorCustom = user && JSON.parse(user).setColor;
function TC6() {
  const api = new API();
  const [category, setCategory] = useState([]);
  const topCategoryResult = category.filter((e) => e.parent === null);
  useEffect(() => {
    api
      .topCategory()
      .then((res) => {
        setCategory(res.data);
      })
      .catch((err) => {});
  }, []);
  return (
    <React.Fragment>
      <TopCategory>
        <section className="Temp6_Top_Category">
          <div className="Wrapper_Full">
            <h1>TOP CATEGORIES</h1>
            <Swiper
              slidesPerView={5}
              spaceBetween={20}
              freeMode={true}
              loop={false}
              pagination={true}
              breakpoints={{
                320: {
                  slidesPerView: 1,
                  spaceBetween: 10,
                },
                380: {
                  slidesPerView: 1,
                  spaceBetween: 10,
                },
                768: {
                  slidesPerView: 2,
                  spaceBetween: 15,
                },
                992: {
                  slidesPerView: 3,
                  spaceBetween: 20,
                },
                1200: {
                  slidesPerView: 5,
                  spaceBetween: 20,
                },
              }}
              autoplay={{
                delay: 3000,
                disableOnInteraction: false,
              }}
              modules={[Pagination, Autoplay]}
              className="Temp6_Category_Slider"
            >
              {topCategoryResult?.map((e, i) => {
                return (
                  <SwiperSlide
                    className="Temp6_Category_Slider_Box"
                    key={`Temp6_Category_${i}`}
                  >
                    <div className="Temp6_Category_Slider_Link">
                      <Link
                        to={`/${e.category_name
                          .toLowerCase()
                          .replace(/ /g, "-")
                          .replace(/[^\w-]+/g, "")}`}
                      >
                        <img
                          alt={e.category_name}
                          src={e.images ? api.rootUrl + e.images : DefaultImg}
                        />
                        <p>{e.category_name}</p>
                      </Link>
                    </div>
                  </SwiperSlide>
                );
              })}
            </Swiper>
          </div>
        </section>
      </TopCategory>
    </React.Fragment>
  );
}

export default TC6;


const TopCategory = styled.div`

.Temp6_Top_Category {
  width: 100%;
  display: inline-block;
  position: relative;
}

.Temp6_Top_Category h1 {
  font-size: 20px;
  font-family: ${styles?.medium} !important;
  color: ${styles?.colorapi} !important;
}

.Temp6_Top_Category .Temp6_Category_Slider_Link {
  width: 100%;
  display: inline-block;
  position: relative;
  margin: 0 0 0px;
  padding: 10px 10px;
  color: ${styles?.color} !important;
  border: 1px solid ${styles?.light};
  border-radius: 5px;
}

.Temp6_Top_Category .Temp6_Category_Slider_Link p {
  font-size: 16px;
  color: ${styles?.color};
  font-family: "f_medium";
  text-transform: uppercase;
  text-align: center;
}

.Temp6_Top_Category .Temp6_Category_Slider_Link img {
  height: 100px;
  width: 100px;
  margin: 0 auto 20px;
}


`;