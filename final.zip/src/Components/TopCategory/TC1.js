import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Swiper, SwiperSlide } from "swiper/react";
import {  Pagination, Autoplay } from "swiper";
import "swiper/css";
import "swiper/scss/pagination";
import Default from '../../Assets/Images/default.png'
import API from "../../Api/ApiService";
import styled from "styled-components";
import { styles } from "../../Api/Data";
const user = JSON.parse(localStorage.getItem("persist:root"))?.company;
const colorCustom = user && JSON.parse(user).setColor;

function TC1() {
  const api = new API();
  const [category, setCategory] = useState([])
  const topCategoryResult = category.filter(e => e.parent === null)
  useEffect(() => {
    api.topCategory().then((res) => {
      setCategory(res.data)
    }).catch((err) => { })
  }, [])

  

  return (
    <React.Fragment>
      <TopCategory1>
    <section className="Temp1_Top_Category">
      <div className="Wrapper_Full">
        <H2>Top Categories</H2>
        <Swiper
          slidesPerView={5}
          spaceBetween={20}
          freeMode={true}
          loop={false}
          pagination={true}
          breakpoints={{
            320: {
              slidesPerView: 1,
              spaceBetween: 10,
            },
            380: {
              slidesPerView: 2,
              spaceBetween: 10,
            },
            768: {
              slidesPerView: 2,
              spaceBetween: 15,
            },
            992: {
              slidesPerView: 3,
              spaceBetween: 20,
            },
            1200: {
              slidesPerView: 5,
              spaceBetween: 20,
            },
          }}
          autoplay={{
            delay: 3000,
            disableOnInteraction: false,
          }}
          modules={[Pagination, Autoplay]}
          className="Temp1_Category_Slider"
        >
          {topCategoryResult?.map((e, i) => {
            return (
              <SwiperSlide className="Temp1_Category_Slider_Box" key={`Temp1_Category_${i}`}>
                <div className="Temp1_Category_Slider_Link">
                  <Link to={`/${e.category_name.replace(" ", "-").toLowerCase().replace(/ /g, '-')
                        .replace(/[^\w-]+/g, '')}`}>
                    <img
                      alt={e.category_name}
                      src={e.images ? api.rootUrl + e.images : Default}
                    />
                    <p>{e.category_name}</p>
                  </Link>
                </div>
              </SwiperSlide>
            );
          })}
        </Swiper>
      </div>
    </section>
    </TopCategory1>
    </React.Fragment>
  );
}

export default TC1;
const H2 = styled.h1`
  font-size: ${styles?.h2};
  font-family: ${styles?.font} !important;
  color: ${colorCustom?.color ? colorCustom?.color : styles?.color} !important;
  line-height: 1.4;
  margin: 0 0 25px;

  @media screen and (max-width: 768px) {
    text-align: center;
  }
`;

const TopCategory1 = styled.div`
.Temp1_Top_Category {
  width: 100%;
  display: inline-block;
  position: relative;
}
.Temp1_Top_Category h1 {
  font-size: ${styles?.h2};
  color: ${colorCustom?.color ? colorCustom?.color : styles?.color } !important;
}
.Temp1_Top_Category .Temp1_Category_Slider_Link {
  width: 100%;
  display: inline-block;
  position: relative;
  margin: 0 0 50px;
  padding: 40px 10px;
  background: ${styles?.bg30};
  border-radius: 5px;
}
.Temp1_Top_Category .Temp1_Category_Slider_Link img {
  height: 85px;
  width: 85px;
  margin: auto auto 20px;
}
.Temp1_Top_Category .Temp1_Category_Slider_Link p {
  font-size: ${styles?.p};
  color: ${styles?.color};
  font-family: ${styles?.medium};
  text-transform: uppercase;
  text-align: center;
}

.Temp1_Top_Category .swiper-pagination-bullet.swiper-pagination-bullet-active {
  background: ${colorCustom?.color};
}

@media screen and (max-width:768px) {
  .Temp1_Top_Category h1 {
    text-align: center;
  }
}





`