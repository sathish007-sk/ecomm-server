import React, { useState, useEffect } from 'react'
import top1 from "../../Assets/Images/dry/cat1.png"
import top2 from "../../Assets/Images/dry/cat2.png"
import hmain from "../../Assets/Images/dry/hmain.png"
import { styles } from '../../Api/Data';
import styled from 'styled-components';
import API from "../../Api/ApiService";
import Default from '../../Assets/Images/default.png'
import { Link } from 'react-router-dom'


const DryTopCategory = () => {

  const api = new API();
  const [category, setCategory] = useState([])
  const topCategoryResult = category.filter(e => e.parent === null)
  useEffect(() => {
    api.topCategory().then((res) => {
      setCategory(res.data)
    }).catch((err) => { })
  }, [])



  return (
    <React.Fragment>
      {topCategoryResult.length > 1 ? (
      <TopCategory>
        <div className='top_category_section'>
          <div className='wrapper'>
            <H2>Popular Categories</H2>
            <ul>
              {
                topCategoryResult?.slice(0, 6).map((item) => {
                  return (
                    <li>
                      <Link to={`/${item.category_name.replace(" ", "-").toLowerCase().replace(/ /g, '-').replace(/[^\w-]+/g, '')}`}>
                        <div className='top_box'>
                          <span>
                            <img src={item.images ? api.rootUrl + item.images : Default} alt="Popular Categories" />
                          </span>
                          <h4>{item?.category_name}</h4>
                        </div>
                      </Link>
                    </li>
                  )
                })
              }

            </ul>
          </div>
        </div>
      </TopCategory>
      ) : "" }
    </React.Fragment>
  )
}

export default DryTopCategory


const H2 = styled.h2`
   font-size:32px;
   margin : 0 0 50px;
   font-family: ${styles?.q_bold} !important;
   text-align: center;
   padding: 55px 0 0 0;
   &::before {
    content: "";
    position: absolute;
    background: url(${hmain});
    background-repeat: no-repeat;
    height: 46px;
    width: 46px;
    background-size: contain;
    top: 0;
    left: 50%;
    transform: translate(-50%, 0px);
   }

   @media screen and (max-width:768px) {
    text-align: center;
   }

`

const TopCategory = styled.section`
    display: inline-block;
    position: relative;
    width: 100%;

    .top_category_section {
        width: 100%;
        display: inline-block;
        position: relative;
    }
    .top_category_section ul {
        padding: 0;
        margin: 0;
        display: grid;
        grid-template-columns: repeat(6,1fr);
        gap: 25px;
    }
    .top_category_section ul li {
        
        width: 100%;
        display: inline-block;
        border-radius: 5px;
    }
    .top_category_section ul li span {
        width: 110px;
    height: 110px;
    border-radius: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: auto auto 22px;
   
   
    }
    .top_category_section ul li h4 {
        text-align: center;
        color: ${styles?.color};
        font-size: 15px;
        font-family: ${styles?.q_bold};
        text-transform: uppercase;
    }

    @media screen and (max-width:992px) {
        .top_category_section ul {
            grid-template-columns: repeat(4,1fr);
        }
    }

    @media screen and (max-width:768px) {
        .top_category_section ul {
    grid-template-columns: repeat(3,1fr);
    gap: 25px 15px;
}

    }


    @media screen and (max-width:480px) {
        .top_category_section ul {
    grid-template-columns: repeat(2,1fr);
    gap: 25px 15px;
}

    }







`