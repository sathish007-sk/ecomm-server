import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import API from "../../Api/ApiService";
import { Swiper, SwiperSlide } from "swiper/react";
import { Pagination, Autoplay } from "swiper";
import "swiper/css";
import "swiper/scss/pagination";
import DefaultImg from "../../Assets/Images/default.png";
import styled, { ThemeProvider } from "styled-components";

const size = {
  desktop: "1920px",
  laptop: "1440px",
  minilaptop: "1200px",
  tabletl: "992px",
  tablet: "768px",
  mobilel: "580px",
  mobilep: "480px",
  mobiles: "380px",
};

export const device = {
  desktop: `@media screen and (max-width: ${size.desktop})`,
  laptop: `@media screen and (max-width: ${size.laptop})`,
  minilaptop: `@media screen and (max-width: ${size.minilaptop})`,
  tabletl: `@media screen and (max-width: ${size.tabletl})`,
  tablet: `@media screen and (max-width: ${size.tablet})`,
  mobilel: `@media screen and (max-width: ${size.mobilel})`,
  mobilep: `@media screen and (max-width: ${size.mobilep})`,
  mobiles: `@media screen and (max-width: ${size.mobiles})`,
};

const theme = {
  id: 1,
  color: "#000",
  background: "#000",
  border: "#ee8f0a",
  gray: "#888",
  bg70: "rgb(255 255 255 / 70%)",
  bglight: "#f5f5f5",
  titlesize: [
    {
      screen: "desktop",
      value: 30,
    },
    {
      screen: "tablet",
      value: 20,
    },
    {
      screen: "mobile",
      value: 20,
    },
  ],
  colcount: [
    {
      screen: "desktop",
      value: 3,
    },
    {
      screen: "tablet",
      value: 2,
    },
    {
      screen: "mobile",
      value: 1,
    },
  ],
  gap: [
    {
      screen: "desktop",
      value: 25,
    },
    {
      screen: "tablet",
      value: 20,
    },
    {
      screen: "mobile",
      value: 15,
    },
  ],
};

function Permium1TC1() {
  const api = new API();
  const [category, setCategory] = useState([])
  const topCategoryResult = category.filter(e => e.parent === null)
  useEffect(() => {
    api.topCategory().then((res) => {
      setCategory(res.data)
    }).catch((err) => { })
  }, [])

  const Section = styled.section`
    width: 100%;
    display: inline-block;
    position: relative;
  `;
  const Wrapper_Full = styled.div`
    max-width: 100%;
    padding: 0 20px;
  `;
  const Permium1TC1_Align = styled.div`
    display: inline-block;
    position: relative;
    width: 100%;
  `;
  const Permium1TC1_SlideBox = styled.div`
    width: 100%;
    display: inline-block;
    position: relative;
    margin: 0 0 50px;

    &:hover .Permium1TC1_SlideBox_Text {
      background: ${(props) =>
        props.theme.border ? props.theme.border : "#000"};
      color: #fff !important;
    }
    &:hover .Permium1TC1_SlideBox_Image:before {
      border: 12px solid #fff;
      height: 100%;
      width: 100%;
      transition: all 0.4s ease-in-out;
    }
  `;
  const Permium1TC1_SlideBox_Image = styled.div`
    width: 190px;
    height: 190px;
    display: flex;
    margin: auto auto 25px;
    align-items: center;
    flex-wrap: wrap;
    border: 1px solid
      ${(props) => (props.theme.border ? props.theme.border : "#000")};
    border-radius: 100%;
    overflow: hidden;
    position: relative;
    &:before {
      content: "";
      border: 0px solid #fff;
      position: absolute;
      height: 0%;
      width: 0%;
      z-index: 10;
      border-radius: 100%;
      top: 50%;
      left: 50%;
      transition: all 0.4s ease-in-out;
      transform: translate(-50%, -50%);
    }
    img {
      height: 100%;
      width: 100%;
      object-fit: contain;
      position: relative;
    }
  `;

  const Permium1TC1_SlideBox_Text = styled.h4`
    font-size: 18px;
    text-align: center;
    font-weight: 600;
    padding: 8px 15px;
    background: transparent;
    width: fit-content;
    margin: auto;
    border-radius: 5px;
    &:hover {
      background: ${(props) =>
        props.theme.border ? props.theme.border : "#000"};
      color: #fff !important;
    }
  `;

  return (
    <ThemeProvider theme={theme}>
      <Section className="Premium1_TC1" id={theme.id}>
        <Wrapper_Full>
          <h2 className="Head_Text_Temp1">Shop By Categories</h2>
          <Permium1TC1_Align>
            <Swiper
              slidesPerView={6}
              spaceBetween={30}
              freeMode={true}
              loop={true}
              pagination={true}
              breakpoints={{
                320: {
                  slidesPerView: 1,
                  spaceBetween: 10,
                },
                380: {
                  slidesPerView: 1,
                  spaceBetween: 10,
                },
                480: {
                  slidesPerView: 2,
                  spaceBetween: 10,
                },
                768: {
                  slidesPerView: 2,
                  spaceBetween: 15,
                },
                992: {
                  slidesPerView: 3,
                  spaceBetween: 20,
                },
                1200: {
                  slidesPerView: 6,
                  spaceBetween: 30,
                },
              }}
              //   autoplay={{
              //     delay: 3000,
              //     disableOnInteraction: false,
              //   }}
              modules={[Pagination, Autoplay]}
              className="Temp1_Category_Slider"
            >
              {topCategoryResult?.map((e, i) => {
                return (
                  <SwiperSlide key={`Temp1_Category_${i}`}>
                    <Permium1TC1_SlideBox className="Temp1_Category_Slider_Link">
                      <Link
                        to={`/${e.category_name
                          .toLowerCase().replace(/ /g, '-')
                        .replace(/[^\w-]+/g, '')}`}
                      >
                        <Permium1TC1_SlideBox_Image className="Permium1TC1_SlideBox_Image">
                          <img
                            alt={e.category_name}
                            src={e.images ? api.rootUrl + e.images : DefaultImg}
                          />
                        </Permium1TC1_SlideBox_Image>
                        <Permium1TC1_SlideBox_Text className="Permium1TC1_SlideBox_Text">
                          {e.category_name}
                        </Permium1TC1_SlideBox_Text>
                      </Link>
                    </Permium1TC1_SlideBox>
                  </SwiperSlide>
                );
              })}
            </Swiper>
          </Permium1TC1_Align>
        </Wrapper_Full>
      </Section>
    </ThemeProvider>
  );
}


export default Permium1TC1;
