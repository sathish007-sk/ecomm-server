import React from 'react'

export default function TC2() {
  return (
    <React.Fragment></React.Fragment>
  )
}
