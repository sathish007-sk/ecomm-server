import React, { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import styled from 'styled-components';
import { styles } from '../../Api/Data';
import { Divider } from 'antd';
import top from '../../Assets/Images/Temp/cat.webp'
import API from "../../Api/ApiService";
import topbg from "../../Assets/Images/Agri/top_center.jpg"
import Default from '../../Assets/Images/default.png'
const GiftTopCategory = () => {
    const api = new API();
    const [category, setCategory] = useState([])
    const topCategoryResult = category.filter(e => e.parent === null)
    useEffect(() => {
        api.topCategory().then((res) => {
            setCategory(res.data)
        }).catch((err) => { })
    }, [])
    return (
        <React.Fragment>
            <TopCategory>
                <div className='top_category'>
                    <div className='wrapper'>
                        <HeadDivider>
                            <Divider><h1>Popular Category</h1></Divider>
                        </HeadDivider>
                        <ul>
                            {
                                topCategoryResult?.slice(0, 6).map((item) => {
                                    return (
                                        <li key={item?._id}>
                                            <div className='top_box'>
                                                <span>
                                                    <Link to={`/${item.category_name.replace(" ", "-").toLowerCase().replace(/ /g, '-').replace(/[^\w-]+/g, '')}`}>
                                                        <img src={item.images ? api.rootUrl + item.images : Default} alt="Top Category" /></Link>
                                                </span>
                                                <h4>{item?.category_name}</h4>
                                            </div>
                                        </li>
                                    )
                                }
                                )}


                        </ul>
                    </div>
                </div>
            </TopCategory>
        </React.Fragment>
    )
}

export default GiftTopCategory;

const HeadDivider = styled.div`
display: inline-block;
margin: 0 0 55px;
width: 100%;
    h1, h2 {
        margin: 0 !important;
        font-size: 30px !important;
        font-weight: 600;
        font-family: ${styles?.medium} !important;
    }
    .ant-divider-horizontal.ant-divider-with-text {
        border-top-color: ${styles?.color} !important;
        margin: 0;
    }

@media screen and (max-width:1200px) {
    margin: 0 0 40px;
}
@media screen and (max-width:480px) {
    h1, h2 {
        font-size: 27px !important;
    }

}

`

const TopCategory = styled.section`
    display: inline-block;
    width: 100%;
    position: relative;
    
    ul {
        width: 100%;
        display: grid;
        grid-template-columns: repeat(6,1fr);
        gap: 40px 30px;
        padding: 0;
        margin: 0;
    }
    ul li {
        width: 100%;
        display: inline-block;
    }
    ul li span {
        display: flex;
        width: 100%;
        position: relative;
        align-items: center;
        justify-content: center;
        img {
            width: 100%;
            border-radius: 10px;
            cursor: pointer;
            border: 1px solid #f5f5f5;
        }
    }
    ul li h4 {
        text-align: center;
        margin: 15px 0 0 0;
        font-size: 16px;
        color: ${styles?.color};
        font-weight: 600;
    }
    
    @media screen and (max-width:992px) {
        ul {
        grid-template-columns: repeat(3,1fr);
        gap: 30px 20px
    }
    }

    @media screen and (max-width:768px) {
        ul {
        grid-template-columns: repeat(2,1fr);
        gap: 30px 15px
        }
    }







`