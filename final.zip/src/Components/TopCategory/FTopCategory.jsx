import React, { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import styled from 'styled-components';
import top from "../../Assets/Images/furniture/b11.png"
import { styles } from '../../Api/Data';
import API from "../../Api/ApiService";
import Default from '../../Assets/Images/default.png'
const FTopCategory = () => {
    const api = new API();
    const [category, setCategory] = useState([])
    const topCategoryResult = category.filter(e => e.parent === null)
    useEffect(() => {
        api.topCategory().then((res) => {
            setCategory(res.data)
        }).catch((err) => { })
    }, [])

    return (
        <React.Fragment>
            <TopCategory>
                <div className='top_category_section'>
                    <div className='wrapper'>
                        <H2>Popular Category</H2>
                        <ul>

                            {
                                topCategoryResult?.slice(0, 6).map((item) => {
                                    return (
                                        <li key={item?._id}>
                                            <div className='top_box'>
                                                <div className='top_box_img'>
                                                    <Link to={`/${item.category_name.replace(" ", "-").toLowerCase().replace(/ /g, '-').replace(/[^\w-]+/g, '')}`}> <img src={item.images ? api.rootUrl + item.images : Default} alt="top" /></Link>
                                                </div>
                                                <div className='top_content'>
                                                    <h4>{item?.category_name}</h4>

                                                </div>
                                            </div>
                                        </li>

                                    )
                                }
                                )}
                        </ul>
                    </div>
                </div>
            </TopCategory>
        </React.Fragment>
    )
}

export default FTopCategory

const H2 = styled.h2`
   font-size:30px;
   margin : 0 0 35px;
   text-transform: uppercase;
   font-family: ${styles?.r_regular} !important;
   letter-spacing: 0.7px;

   @media screen and (max-width:768px) {
    text-align: center;
   }

`

const TopCategory = styled.section`
    width: 100%;
    display: inline-block;
    position: relative;

    .top_category_section {
        display: inline-block;
        width: 100%;
        position: relative;
    }
    .top_category_section ul {
        list-style: none;
        padding: 0;
        margin: 0;
        display: grid;
        grid-template-columns: repeat(6,1fr);
        gap: 25px;
    }
    .top_category_section ul li {
        width: 100%;
        display: inline-block;
        position: relative;
    }
    .top_category_section ul li .top_box {
        display: inline-block;
        position: relative;
        width: 100%;
        
    }
    .top_category_section ul li .top_box .top_box_img {
        height: 140px;
    width: 140px;
    padding: 35px;
    background: #fff;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: auto;
    border-radius: 0 60px 60px 60px;
    box-shadow: 0 0 15px rgb(0 0 0 / 5%);
    /* border: 1px solid #bfbbbb; */
    /* border-style: dashed; */
}






    .top_category_section ul li .top_box .top_content {
        width: 100%;
        padding: 20px 15px 0px 20px;
        text-align: center;
        
    }

    .top_category_section ul li .top_box .top_content h4 {
        font-size: 15px;
        font-family: ${styles?.r_regular} !important;
        text-transform: uppercase;
        color: ${styles?.color};
        font-weight: 600;
        letter-spacing: 1px;
        margin: 0 0 5px;
    }
   

    @media screen and (max-width:1200px) {
        .top_category_section ul li .top_box .top_box_img {
            height: 125px;
            width: 125px;
            padding: 33px;
        }

}

@media screen and (max-width:992px) {
    .top_category_section ul {
        grid-template-columns: repeat(3,1fr);
    }
}

@media screen and (max-width:580px) {
    .top_category_section ul {
    grid-template-columns: repeat(2,1fr);
    gap: 30px 15px;
}
}







`;