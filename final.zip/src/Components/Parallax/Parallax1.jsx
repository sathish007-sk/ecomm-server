import React, { useEffect, useState } from 'react'
import styled from 'styled-components'
import API from "../../Api/ApiService";
import Default from '../../Assets/Images/default.png'

const Parallax1 = ({ data }) => {
    const api = new API();
    const [content, setContent] = useState([])

    useEffect(() => {
        setContent(data.content)
    }, [data])

    
    return (
        <React.Fragment>
            <Section>
                {content?.slice(0, 1).map((data) => {
                    return (
                        <BG key={data._id}>
                            <Img src={data.image ? api.rootUrl + data.image : Default} />
                            <Title>{data.title}</Title>
                        </BG>
                    )
                })}

            </Section>
        </React.Fragment>
    )
}

export default Parallax1



const Section = styled.section`
width: 100%;
display: inline-block;

position: relative;
`;
const BG = styled.div`
display: inline-block;
width: 100%;
position: relative;
min-height: 85vh;
    text-align: center;
&:before {
    content: '';
    position: absolute;
    height: 100%;
    left: 0;
    background: rgb(0 0 0 / 80%);
    width: 100%;
}
`;
const Img = styled.img`
max-width: 100%;
display: block;

`;
const Title = styled.div`
    position: absolute;
    z-index: 15;
    top:50%;
    left:50%;
    transform: translate(-50%,-50%);
    color: #fff;
    font-size: 55px;
    font-weight: 600;
`;