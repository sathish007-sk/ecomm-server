import React, { useEffect, useState } from 'react'
import three from "../../Assets/Images/furniture/hc2.webp"
import styled from 'styled-components';
import API from "../../Api/ApiService";
import Default from '../../Assets/Images/default.png'

const FParallax = ({ data }) => {

    const api = new API();
    const [content, setContent] = useState([])

    useEffect(() => {
        setContent(data.content)
    }, [data])


  return (
    <React.Fragment>
    <ParallaxSection>
    {content?.slice(0, 1).map((data) => {
                    return (
        <div className='parallax_section' style={{ background: `url(${data.image ? api.rootUrl + data.image : Default})` }}>
            <h2>{data.title}</h2>
        </div>
         )
        })}
    </ParallaxSection>
</React.Fragment>
  )
}

export default FParallax;

const ParallaxSection = styled.section`
    width: 100%;
    display: inline-block;
    height: 85vh;
    overflow: hidden;
    position: relative;
    &::before {
        content: "";
    position: absolute;
    background: linear-gradient(to right, #fff 50%, transparent 50%);
    height: 100%;
    left: 0;
    top: 0;
    z-index: 10;
    width: 100%;
}
    .parallax_section {
        width:100%;
        display: flex;
        flex-direction: column;
        position: relative;
        height: 100%;
        position: absolute;
        top: 0;
    left: 0;
    background-repeat: no-repeat !important;
    background-attachment: fixed !important;
    background-position: right!important;
    background-size: 50% 100% !important;
}
    .parallax_section h2 {
        width: 50%;
        position: absolute;
        top: 50%;
        left: 0;
        transform: translate(0,-50%);
        padding: 50px 100px;
        z-index: 20;
        text-align: center;
        font-size: 55px;
    }


    @media screen and (max-width:1200px) {
        .parallax_section h2 {
            font-size: 45px;
            padding: 35px;
        }
        .parallax_section {
            background-size: cover !important;
        }
    }


    @media screen and (max-width:768px) {
    &::before {
    content: "";
    position: absolute;
    background: rgb(255 255 255 / 50%);
        }

        .parallax_section h2 {
    font-size: 35px;
    padding: 35px;
    width: 100%;
}



    }


   

`