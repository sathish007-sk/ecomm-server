import React, { useState, useEffect } from 'react'
import API from '../../Api/ApiService'


//Parallax
import Parallax1 from '../../Components/Parallax/Parallax1'

//HC1 Component
import Design1HC1 from '../../Components/Hc1/Design1HC1'
import Design2HC1 from '../../Components/Hc1/Design2HC1'
import Design3HC1 from '../../Components/Hc1/Design3HC1'
import Design4HC1 from '../../Components/Hc1/Design4HC1'
import Design5HC1 from '../../Components/Hc1/Design5HC1'
import Design6HC1 from '../../Components/Hc1/Design6HC1'
import Premium1HC1 from '../../Components/Hc1/Premium1HC1'
import Premium2HC1 from '../../Components/Hc1/Premium2HC1'

//HC2 Component
import Design1HC2 from '../../Components/Hc2/Design1HC2'
import Design2HC2 from '../../Components/Hc2/Design2HC2'
import Design3HC2 from '../../Components/Hc2/Design3HC2'
import Design4HC2 from '../../Components/Hc2/Design4HC2'
import Design5HC2 from '../../Components/Hc2/Design5HC2'
import Design6HC2 from '../../Components/Hc2/Design6HC2'
import Premium1HC2 from '../../Components/Hc2/Premium1HC2'
import Premium2HC2 from '../../Components/Hc2/Premium2HC2'

//HC3 Component
import Design1HC3 from '../../Components/Hc3/Design1HC3'
import Design2HC3 from '../../Components/Hc3/Design2HC3'
import Design3HC3 from '../../Components/Hc3/Design3HC3'
import Design4HC3 from '../../Components/Hc3/Design4HC3'
import Design5HC3 from '../../Components/Hc3/Design5HC3'
import Design6HC3 from '../../Components/Hc3/Design6HC3'
import Premium1HC3 from '../../Components/Hc3/Premium1HC3'
import Premium2HC3 from '../../Components/Hc3/Premium2HC3'
import AgriHc1 from '../Hc1/AgriHc1'
import GiftHc1 from '../Hc1/GiftHc1'
import FHc1 from '../Hc1/FHc1'
import FHc2 from '../Hc2/FHc2'
import FHc3 from '../Hc3/FHc3'
import FParallax from '../Parallax/FParallax'
import DryHc1 from '../Hc1/DryHc1'
import DryHc2 from '../Hc2/DryHc2'
import DryHc3 from '../Hc3/DryHc3'




const DynamicRows = () => {

  const [theme, setTheme] = useState([])
  const api = new API();

  useEffect(() => {
    api.homeComponent().then((res) => {
      setTheme(res.data.sort((a, b) => {
        return a.row - b.row;
      }))
    }).catch((err) => { })

  }, [])

  

  return (
    <React.Fragment>
      {theme?.map((e) => {

        switch (e.type) {
          case "hc1":
            return <FHc1 data={e} key={e.type} />;
          case "hc2":
            return <FHc2 data={e} key={e.type} />;
          case "hc3":
            return <FHc3 data={e} key={e.type} />;
          case "hc4":
            return <DryHc1 data={e} key={e.type} />;
          case "hc5":
            return <DryHc2 data={e} key={e.type} />;
          case "hc6":
            return <DryHc3 data={e} key={e.type} />;
          case "hc7":
            return <Design3HC1 data={e} key={e.type} />;
          case "hc8":
            return <Design3HC2 data={e} key={e.type} />;
          case "hc9":
            return <Design3HC3 data={e} key={e.type} />;
          case "hc10":
            return <Design4HC1 data={e} key={e.type} />;
          case "hc11":
            return <Design4HC2 data={e} key={e.type} />;
          case "hc12":
            return <Design4HC3 data={e} key={e.type} />;
          case "hc13":
            return <AgriHc1 data={e} key={e.type} />;
          case "hc14":
            return <Design5HC2 data={e} key={e.type} />;
          case "hc15":
            return <Design5HC3 data={e} key={e.type} />;
          case "hc16":
            return <GiftHc1 data={e} key={e.type} />;
          case "hc17":
            return <Design6HC2 data={e} key={e.type} />;
          case "hc18":
            return <Design6HC3 data={e} key={e.type} />;
          case "PRE-HC1":
            return <Premium1HC1 data={e} key={e.type} />;

          case "PRE-HC2":
            return <Premium1HC2 data={e} key={e.type} />;

          case "PRE-HC3":
            return <Premium1HC3 data={e} key={e.type} />;

          case "PRE-HC4":
            return <Premium2HC1 data={e} key={e.type} />;

          case "PRE-HC5":
            return <Premium2HC2 data={e} key={e.type} />;

          case "PRE-HC6":
            return <Premium2HC3 data={e} key={e.type} />;
          case "paralox":
            return <FParallax data={e} key={e.type} />;
          default:
            break;
        }

      })};
    </React.Fragment>
  )
}

export default DynamicRows;