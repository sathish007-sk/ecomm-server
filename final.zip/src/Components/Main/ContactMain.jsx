import React,{useState,useEffect} from 'react'
import API from '../../Api/ApiService';
import Contact1 from "../Pages/Contact/Contact1"
import Contact2 from "../Pages/Contact/Contact2"
import Contact3 from "../Pages/Contact/Contact3"
import Contact4 from "../Pages/Contact/Contact4"

import {
    Skeleton,
  } from "antd";


const ContactMain = () => {
    const [theme, setTheme] = useState("")
    const [loading, setLoading] = useState(false);
    const api = new API();
  
    useEffect(() => {
      setLoading(true)
      api.themes().then((res) => {
        setLoading(false)
        setTheme(res.data.contactustype)
      }).catch((err) => { setLoading(false) })
    }, [])
  return (
    <React.Fragment>
        {
        loading === true ?
          <Skeleton />
          :
          <>
            {theme === "CU1" ? <Contact1 page="contact" /> : ""}
            {theme === "CU2" ? <Contact2 page="contact" /> : ""}
            {theme === "CU3" ? <Contact3 page="contact" /> : ""}
            {theme === "CU4" ? <Contact4 page="contact" /> : ""}
          </>
      }
    </React.Fragment>
  )
}

export default ContactMain