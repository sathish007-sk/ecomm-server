import React from 'react'
import styled from 'styled-components';
import logo from "../../Assets/Images/logo.png"
import instgram from "../../Assets/Images/furniture/s2.png"
import facebook from "../../Assets/Images/furniture/s1.png"
import support from "../../Assets/Images/dry/support.png"
import cart from "../../Assets/Images/dry/cart.png"
import user from "../../Assets/Images/dry/user.png"
import shop from "../../Assets/Images/dry/shop.png"
import delivery from "../../Assets/Images/dry/delivery.png"
import checkout from "../../Assets/Images/dry/payment.png"
import profile from "../../Assets/Images/dry/myaccount.png"
import order from "../../Assets/Images/dry/wallet.png"
import email from "../../Assets/Images/dry/email.png"
import call from "../../Assets/Images/dry/call.png"
import address from "../../Assets/Images/dry/address.png"
import banner from "../../Assets/Images/dry/banner.png"
import hmain from "../../Assets/Images/dry/hmain.png"
import top1 from "../../Assets/Images/dry/cat1.png"
import top2 from "../../Assets/Images/dry/cat2.png"
import fp1 from "../../Assets/Images/dry/p1.png"
import fp2 from "../../Assets/Images/dry/p2.png"
import fp3 from "../../Assets/Images/dry/p3.png"
import hc1 from "../../Assets/Images/dry/hc1.png"
import hc2 from "../../Assets/Images/dry/hc2.png"
import rightarrow from "../../Assets/Images/dry/right_arrow.png"

import { Input, Badge,Menu } from 'antd';
import {Link} from "react-router-dom"
import { styles } from '../../Api/Data';
import {FilterOutlined } from '@ant-design/icons';
import MobileMenu from '../MenuBar/MobileMenu';

const { Search } = Input;
const { SubMenu } = Menu;

const DryFrutes = () => {
    const onSearch = (value) => console.log(value);


    return (
        <React.Fragment>
            {/* <React.Fragment>
                <HeaderSection>
                    <div className='header_section'>
                        <div className='header_text'>
                            <div className='wrapper'>
                                <div className='header_text_align'>
                                    <div className='header_text_left'>
                                        <p>
                                            <span>
                                                <img src={delivery} alt="delivery" />
                                            </span>
                                            <span>100% Secure delivery without contacting the courier</span>
                                        </p>
                                    </div>
                                    <div className='header_text_right'>
                                        <ul>
                                            <li>
                                                <span>
                                                    <img src={email} alt="email" />
                                                </span>
                                                <span>Mail Us</span>
                                            </li>
                                            <li>
                                                <span>
                                                    <img src={profile} alt="profile" />
                                                </span>
                                                <span>My Profile</span>
                                            </li>
                                            <li>
                                                <span>
                                                    <img src={order} alt="order" />
                                                </span>
                                                <span>My Order</span>
                                            </li>
                                            <li>
                                                <span>
                                                    <img src={checkout} alt="checkout" />
                                                </span>
                                                <span>Checkout</span>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className='header_top'>
                            <div className='wrapper'>
                                <div className='header_top_align'>
                                    <div className='header_top_left'>
                                        <img src={logo} alt="Logo" />
                                    </div>
                                    <div className='header_top_center'>
                                        <Search
                                            placeholder="Search Products..."
                                            onSearch={onSearch}
                                        />
                                    </div>
                                    <div className='header_top_right'>
                                        <div className='header_top_right_support'>
                                            <span>
                                                <img src={support} alt="Support" />
                                            </span>
                                            <span>
                                                <i>Online Support</i>
                                                <p>+91 98765 43210</p>
                                            </span>
                                        </div>
                                        <div className='shop_btn'>
                                            <ul>
                                                <li>
                                                    <img src={user} alt="My Account" />
                                                </li>
                                                <li>
                                                    <Badge count={0} showZero size='small'>
                                                        <img src={shop} alt="My Cart" />
                                                    </Badge>
                                                </li>
                                                <li className='dry_fruites_mob_menu'>
                                                    <MobileMenu />
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className='header_bottom'>
                            <div className='wrapper'>
                                <div className='header_bottom_align'>
                                    <div className='header_bottom_left'>
                                    <Menu mode="horizontal">
                                        <SubMenu key="AllCategories" title="All Categories" icon={<FilterOutlined />} className="submenu_btn">
                                        <Menu.Item key="home">
                                            <Link to="/">Home</Link>
                                        </Menu.Item>
                                        <Menu.Item key="about">
                                            <Link to="/about">About Us</Link>
                                        </Menu.Item>
                                        </SubMenu>
                                        <Menu.Item key="home">
                                            <Link to="/">Home</Link>
                                        </Menu.Item>
                                        <Menu.Item key="about">
                                            <Link to="/about">About Us</Link>
                                        </Menu.Item>
                                        <Menu.Item key="enquiry">
                                            <Link to="/">Enquiry Form</Link>
                                        </Menu.Item>
                                        <Menu.Item key="policy">
                                            <Link to="/">Our Policies</Link>
                                        </Menu.Item>
                                        <Menu.Item key="myaddress">
                                            <Link to="/">My Address</Link>
                                        </Menu.Item>
                                        <Menu.Item key="Contact">
                                            <Link to="/">Contact Us</Link>
                                        </Menu.Item>
                                    </Menu>
                                    </div>
                                    <div className='header_bottom_right'>
                                        <ul>
                                            <li>
                                                <img src={facebook} alt="facebook" />
                                            </li>
                                            <li>
                                                <img src={instgram} alt="instgram" />
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </HeaderSection>
            </React.Fragment> */}
            {/* <React.Fragment>
                <BannerSection>
                    <div className='banner_section'>
                        <img src={banner} alt="banner" />
                    </div>
                </BannerSection>
            </React.Fragment> */}
            <Body>
            {/* <React.Fragment>
                <TopCategory>
                    <div className='top_category_section'>
                        <div className='wrapper'>
                            <H2>Popular Categories</H2>
                            <ul>
                                <li>
                                    <div className='top_box'>
                                        <span>
                                            <img src={top1} alt="Popular Categories" />
                                        </span>
                                        <h4>Dried Fruits</h4>
                                    </div>
                                </li>
                                <li>
                                    <div className='top_box'>
                                        <span>
                                            <img src={top2} alt="Popular Categories" />
                                        </span>
                                        <h4>Dried Fruits</h4>
                                    </div>
                                </li>
                                <li>
                                    <div className='top_box'>
                                        <span>
                                            <img src={top1} alt="Popular Categories" />
                                        </span>
                                        <h4>Dried Fruits</h4>
                                    </div>
                                </li>
                                <li>
                                    <div className='top_box'>
                                        <span>
                                            <img src={top2} alt="Popular Categories" />
                                        </span>
                                        <h4>Dried Fruits</h4>
                                    </div>
                                </li>
                                <li>
                                    <div className='top_box'>
                                        <span>
                                            <img src={top1} alt="Popular Categories" />
                                        </span>
                                        <h4>Dried Fruits</h4>
                                    </div>
                                </li>
                                <li>
                                    <div className='top_box'>
                                        <span>
                                            <img src={top2} alt="Popular Categories" />
                                        </span>
                                        <h4>Dried Fruits</h4>
                                    </div>
                                </li>
                                
                            </ul>
                        </div>
                    </div>
                </TopCategory>
            </React.Fragment> */}
            <React.Fragment>
                <FeatureProductSection>
                    <div className='fp_section'>
                        <div className='wrapper'>
                            <H2>Featured Products</H2>
                            <ul>
                                <li>
                                    <span className='hotsale'>Hot Sale</span>
                                    <div className='fp_box'>
                                        <div className='fp_image'>
                                            <img src={fp1} alt="Featured Products" />
                                        </div>
                                        <div className='fp_content'>
                                            <h4>Dry Fruits, Nuts & Seeds</h4>
                                            <div className='fp_price'>
                                                <span className='sp'>{styles?.currency}85</span>
                                                <span className='mrp'>{styles?.currency}100</span>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                <span className='hotsale'>Hot Sale</span>
                                    <div className='fp_box'>
                                        <div className='fp_image'>
                                            <img src={fp2} alt="Featured Products" />
                                        </div>
                                        <div className='fp_content'>
                                            <h4>Dry Fruits, Nuts & Seeds</h4>
                                            <div className='fp_price'>
                                                <span className='sp'>{styles?.currency}85</span>
                                                <span className='mrp'>{styles?.currency}100</span>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                <span className='hotsale'>Hot Sale</span>
                                    <div className='fp_box'>
                                        <div className='fp_image'>
                                            <img src={fp3} alt="Featured Products" />
                                        </div>
                                        <div className='fp_content'>
                                            <h4>Dry Fruits, Nuts & Seeds</h4>
                                            <div className='fp_price'>
                                                <span className='sp'>{styles?.currency}85</span>
                                                <span className='mrp'>{styles?.currency}100</span>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                <span className='hotsale'>Hot Sale</span>
                                    <div className='fp_box'>
                                        <div className='fp_image'>
                                            <img src={fp1} alt="Featured Products" />
                                        </div>
                                        <div className='fp_content'>
                                            <h4>Dry Fruits, Nuts & Seeds</h4>
                                            <div className='fp_price'>
                                                <span className='sp'>{styles?.currency}85</span>
                                                <span className='mrp'>{styles?.currency}100</span>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                <span className='hotsale'>Hot Sale</span>
                                    <div className='fp_box'>
                                        <div className='fp_image'>
                                            <img src={fp2} alt="Featured Products" />
                                        </div>
                                        <div className='fp_content'>
                                            <h4>Dry Fruits, Nuts & Seeds</h4>
                                            <div className='fp_price'>
                                                <span className='sp'>{styles?.currency}85</span>
                                                <span className='mrp'>{styles?.currency}100</span>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                <span className='hotsale'>Hot Sale</span>
                                    <div className='fp_box'>
                                        <div className='fp_image'>
                                            <img src={fp3} alt="Featured Products" />
                                        </div>
                                        <div className='fp_content'>
                                            <h4>Dry Fruits, Nuts & Seeds</h4>
                                            <div className='fp_price'>
                                                <span className='sp'>{styles?.currency}85</span>
                                                <span className='mrp'>{styles?.currency}100</span>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                <span className='hotsale'>Hot Sale</span>
                                    <div className='fp_box'>
                                        <div className='fp_image'>
                                            <img src={fp1} alt="Featured Products" />
                                        </div>
                                        <div className='fp_content'>
                                            <h4>Dry Fruits, Nuts & Seeds</h4>
                                            <div className='fp_price'>
                                                <span className='sp'>{styles?.currency}85</span>
                                                <span className='mrp'>{styles?.currency}100</span>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                <span className='hotsale'>Hot Sale</span>
                                    <div className='fp_box'>
                                        <div className='fp_image'>
                                            <img src={fp2} alt="Featured Products" />
                                        </div>
                                        <div className='fp_content'>
                                            <h4>Dry Fruits, Nuts & Seeds</h4>
                                            <div className='fp_price'>
                                                <span className='sp'>{styles?.currency}85</span>
                                                <span className='mrp'>{styles?.currency}100</span>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                
                            </ul>
                        </div>
                    </div>
                </FeatureProductSection>
            </React.Fragment>
            <React.Fragment>
                <Hc1Section>
                    <div className='hc1_section'>
                        <div className='wrapper'>
                            <H2>Best Selling</H2>
                            <div className='hc1_align'>
                                <ul>
                                    
                                    <li>
                                        <div className='hc1_box'>
                                        <span className='subtitle'>30% special offers</span>
                                            <div className='hc1_box_left'>
                                                <img src={hc1} alt="hc1" />
                                            </div>
                                            <div className='hc1_box_right'>
                                                <h4>Dry Fruits, Nuts & Seeds</h4>
                                                
                                                <button>
                                                    <img src={rightarrow} alt="" />
                                                </button>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div className='hc1_box'>
                                        <span className='subtitle'>30% special offers</span>
                                            <div className='hc1_box_left'>
                                                <img src={hc1} alt="hc1" />
                                            </div>
                                            <div className='hc1_box_right'>
                                                <h4>Dry Fruits, Nuts & Seeds</h4>
                                                
                                                <button>
                                                    <img src={rightarrow} alt="" />
                                                </button>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </Hc1Section>
            </React.Fragment>
            <React.Fragment>
                <Hc2Section>
                    <div className='hc2_section'>
                        <div className='wrapper'>
                            <H2>Top Selling</H2>
                            <ul>
                                <li>
                                    <div className='hc2_box'>
                                        <div className='hc2_top'>
                                            <img src={hc2} alt="hc2" />
                                        </div>
                                        <div className='hc2_bottom'>
                                            <h4>Dry Fruits, Nuts & Seeds</h4>
                                            <h5>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</h5>
                                            <button>Shop Now</button>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <div className='hc2_box'>
                                        <div className='hc2_top'>
                                            <img src={hc2} alt="hc2" />
                                        </div>
                                        <div className='hc2_bottom'>
                                            <h4>Dry Fruits, Nuts & Seeds</h4>
                                            <h5>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</h5>
                                            <button>Shop Now</button>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <div className='hc2_box'>
                                        <div className='hc2_top'>
                                            <img src={hc2} alt="hc2" />
                                        </div>
                                        <div className='hc2_bottom'>
                                            <h4>Dry Fruits, Nuts & Seeds</h4>
                                            <h5>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</h5>
                                            <button>Shop Now</button>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </Hc2Section>
            </React.Fragment>
            <React.Fragment>
                <Hc3Section>
                    <div className='hc3_section'>
                        <div className='wrapper'>
                            <H2>Tranding Products</H2>
                            <div className='hc3_align'>
                                <div className='hc3_left'>
                                <ul>
                                <li>
                                    <div className='hc3_box'>
                                    <span className='trand_product'>20% extra offer</span>
                                        <div className='hc3_img'>
                                            <img src={hc1} alt="hc3" />
                                        </div>
                                        <div className='hc3_content'>
                                            <h4>Dry Fruits, Nuts & Seeds</h4>
                                            <button>
                                                    <img src={rightarrow} alt="" />
                                                </button>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                                </div>
                                <div className='hc3_right'>
                                <ul>
                                <li>
                                    <div className='hc3_box'>
                                    <span className='trand_product'>20% extra offer</span>
                                        <div className='hc3_img'>
                                            <img src={hc1} alt="hc3" />
                                        </div>
                                        <div className='hc3_content'>
                                            <h4>Dry Fruits, Nuts & Seeds</h4>
                                            <button>
                                                    <img src={rightarrow} alt="" />
                                                </button>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <div className='hc3_box'>
                                    <span className='trand_product'>20% extra offer</span>
                                        <div className='hc3_img'>
                                            <img src={hc1} alt="hc3" />
                                        </div>
                                        <div className='hc3_content'>
                                            <h4>Dry Fruits, Nuts & Seeds</h4>
                                            <button>
                                                    <img src={rightarrow} alt="" />
                                                </button>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <div className='hc3_box'>
                                    <span className='trand_product'>20% extra offer</span>
                                        <div className='hc3_img'>
                                            <img src={hc1} alt="hc3" />
                                        </div>
                                        <div className='hc3_content'>
                                            <h4>Dry Fruits, Nuts & Seeds</h4>
                                            <button>
                                                    <img src={rightarrow} alt="" />
                                                </button>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <div className='hc3_box'>
                                        <span className='trand_product'>20% extra offer</span>
                                        <div className='hc3_img'>
                                            <img src={hc1} alt="hc3" />
                                        </div>
                                        <div className='hc3_content'>
                                            <h4>Dry Fruits, Nuts & Seeds</h4>
                                            <button>
                                                    <img src={rightarrow} alt="" />
                                                </button>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </Hc3Section>
            </React.Fragment>
            </Body>
            <React.Fragment>
                <FooterSection>
                    <div className='footer_section'>
                        <div className='footer_top_wrap'>
                        <div className='wrapper'>
                            <div className='footer_top'>
                                <div className='footer_top_left'>
                                    <img src={logo} alt="logo" />
                                </div>
                                <div className='footer_top_center'>
                                    <Menu mode="horizontal">
                                        <Menu.Item key="home">
                                            <Link to="/">Home</Link>
                                        </Menu.Item>
                                        <Menu.Item key="about">
                                            <Link to="/about">About Us</Link>
                                        </Menu.Item>
                                        <Menu.Item key="enquiry">
                                            <Link to="/">Enquiry Form</Link>
                                        </Menu.Item>
                                       <Menu.Item key="Contact">
                                            <Link to="/">Contact Us</Link>
                                        </Menu.Item>
                                    </Menu>
                                </div>
                                <div className='footer_top_right'>
                                    {/* <h4>Follow us</h4> */}
                                    <ul>
                                            <li>
                                                <img src={facebook} alt="facebook" />
                                            </li>
                                            <li>
                                                <img src={instgram} alt="instgram" />
                                            </li>
                                        </ul>
                                </div>
                            </div>
                            </div>
                            </div>
                            <div className='wrapper'>
                            <div className='footer_bottom'>
                                <div className='footer_1'>
                                    <h4>Userful Link</h4>
                                    <ul>
                                        <li>Login</li>
                                        <li>My Profile</li>
                                        <li>My Address</li>
                                        <li>Cart</li>
                                        <li>Checkout</li>
                                        <li>My Order</li>
                                    </ul>
                                    
                                </div>
                                <div className='footer_2'>
                                    <h4>Our Polices</h4>
                                    <ul>
                                        <li>Privacy Policy</li>
                                        <li>Terms and Conditions</li>
                                        <li>Refund Policy</li>
                                        <li>Delivery Policy</li>
                                        <li>Return Policy</li>
                                        <li>Cancellation Policy</li>
                                    </ul>
                                </div>
                                <div className='footer_3'>
                                    <h4>Contact Us</h4>
                                    <ul>
                                        <li className='address'>
                                        Flat No.3, 3rd Floor, Srivari Kikani Centre , R.S. Puram,R.S. Puram, Coimbatore-641002,TAMILNADU
                                        </li>
                                        <li className='call'>
                                        6374445033, 6374445033
                                        </li>
                                        <li className='mail'>contact@ecdigi.com</li>
                                    </ul>
                                </div>
                                <div className='footer_4'>
                                    <h4>Our Location</h4>
                                    <iframe src="https://www.google.com/maps/embed?pb=!1m16!1m12!1m3!1d15665.868504196465!2d76.95237119791811!3d11.003536275925118!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!2m1!1sFlat%20No.3%2C%203rd%20Floor%2C%20Srivari%20Kikani%20Centre%20%2C%20R.S.%20Puram%2CR.S.%20Puram%2C%20Coimbatore-641002%2CTAMILNADU!5e0!3m2!1sen!2sin!4v1669726637762!5m2!1sen!2sin" allowfullscreen="" height={180} loading="lazy" style={{borderRadius:"5px"}} referrerpolicy="no-referrer-when-downgrade"></iframe>
                                </div>
                            </div>
                            </div>
                        <div className='copy_text'>
                            <div className='wrapper'>
                                <div className='copy_align'>
                                    <div className='copy_left'>
                                        <p>All Rights Reserved. ecDigi Technologies</p>
                                    </div>
                                    <div className='copy_right'>
                                        <p>© 2022 Designed by <a href="https://ecdigi.com/" target="_blank" title='ecDigi Technologies'>ecDigi Technologies.</a></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </FooterSection>
            </React.Fragment>
           
        </React.Fragment>
    )
}

export default DryFrutes;
const Body = styled.div`
    display: grid;
    padding: 40px 0;
    width:100%;
    gap: 80px;
    float: left;
`

const H2 = styled.h2`
   font-size:32px;
   margin : 0 0 50px;
   font-family: ${styles?.q_bold} !important;
   text-align: center;
   padding: 55px 0 0 0;
   &::before {
    content: "";
    position: absolute;
    background: url(${hmain});
    background-repeat: no-repeat;
    height: 46px;
    width: 46px;
    background-size: contain;
    top: 0;
    left: 50%;
    transform: translate(-50%, 0px);
   }

   @media screen and (max-width:768px) {
    text-align: center;
   }

`


const HeaderSection = styled.section`
    * {
        font-family: ${styles?.q_regular};
    }
  width  :100% ;
  display: inline-block;
  position: relative;

  .header_section, .header_top {
    width: 100%;
    display: inline-block;
    position: relative;
  }
  .header_text {
    width: 100%;
    display: inline-block;
    background: ${styles?.themegreen};
  }
  .header_text_align {
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
  }
  .header_text_align .header_text_left {
    width: fit-content;
    display: inline-block;
    
  }
  .header_text_align .header_text_left p {
    display: flex;
    align-items: center;
    gap: 10px;
    font-size: 13px;
  }
  .header_text_align .header_text_left img {
    height: 14px;
    filter: brightness(0) invert(1);
  }
  .header_text_align .header_text_right {
    width: fit-content;
    display: inline-block;
  }
  .header_text_align .header_text_right ul {
    display: flex;
    align-items: center;
    margin: 0;
    padding: 0;
    gap: 18px;
    line-height: 32px !important;
  }
  .header_text_align .header_text_right ul li {
    width: fit-content;
    display: flex;
    align-items: center;
    gap: 5px;
    padding: 1px 18px 1px 0;
    border-right: 1px solid rgb(255 255 255 / 40%);


    &:last-child {
        border: 0;
        padding: 0;
    }
  }
  .header_text_align .header_text_right ul li span:nth-child(1) {
    width: fit-content;
    display: inline-block;
    
  }
  .header_text_align .header_text_right ul li span:nth-child(2) {
    width: fit-content;
    display: inline-block;
}
.header_text_align .header_text_right ul li span:nth-child(1) img {
    height: 13px;
    filter: brightness(0) invert(1);
}
.header_text_align .header_text_right ul li span:nth-child(2) {
    color: ${styles?.white};
    font-size: 13px;
    letter-spacing: 0.2px;
}













  .header_text p {
    text-align: center;
    margin: 0;
    line-height: 1.5;
    padding: 6px 0;
    color: ${styles?.white};
  }
  .header_top { 
    border-bottom: 1px solid #f2f2f2;
  }
  .header_top_align {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    justify-content: space-between;
    gap: 15px;
    width: 100%;
    position: relative;
    padding: 15px 0;
  }
  .header_top_left {
    width: fit-content;
    display: inline-block;
  }
  .header_top_left img {
    height: 55px;
  }
  .header_top_center {
    width: 360px;
    border: 1px solid #ebebeb;
    display: inline-block;
    border-radius: 18px 18px 18px 18px;
    padding: 0 5px 0 0;
}
    
    input, button, .ant-input-group-addon {
        border: 0;
        background: transparent;
    }
    input {
        padding: 7px 15px;
    }
    input:focus {
        outline: none;
        box-shadow: inherit;
    }
  

.header_top_right {
    display: flex;
    align-items: center;
    gap: 50px;
    flex-wrap: wrap;
}
.header_top_right_support {
    display: flex;
    align-items: center;
    gap: 15px;
}
.header_top_right_support span:nth-child(1) {
    display: inline-block;
    position: relative;
    width: fit-content;
}
.header_top_right_support span:nth-child(1) img {
    height: 40px;
}
.header_top_right_support span:nth-child(2) {
    display: flex;
    position: relative;
    width: fit-content;
    flex-direction: column;
    gap: 8;
    i {
        color: ${styles?.gray};
        font-size: 13px;
    }
    p {
        margin: 0 !important;
        font-family: ${styles?.q_bold};
        font-size: 18px;
        color: ${styles?.color};
    }
}

.shop_btn {
    display: inline-block;
    width: fit-content;
    position: relative;
    a {
        display: flex;
    }
}
.shop_btn ul {
    margin: 0;
    padding: 0;
    display: flex;
    gap: 20px;
    align-items: center;
    flex-wrap: wrap;
}
.shop_btn ul li {
    display: flex;
}
.shop_btn ul img {
    height: 25px;
}
.header_bottom {
    width: 100%;
    display: inline-block;
}
.header_bottom_align {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 20px;
    padding: 12px 0;
}
.header_bottom_align .header_bottom_left {
    width: 75%;
    display: inline-block;
    .ant-menu-horizontal {
        line-height: 35px !important;
    }
}
.header_bottom_align .header_bottom_left ul {
    width: 100%;
    margin: 0;
    padding: 0;
}
.header_bottom_align .header_bottom_left ul li a {
    font-family: ${styles?.q_bold};
}
.header_bottom_align .header_bottom_right {
    width: fit-content;
    display: inline-block;
}
.header_bottom_align .header_bottom_right ul {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    gap: 15px;
    padding: 0;
    margin: 0;
}

.header_bottom_align .header_bottom_right ul img {
    height: 28px;
}


.submenu_btn {
    display: flex;
    align-items: center;
    background: ${styles?.themegreen};
    color:${styles?.white};
    border-radius: 5px;
    padding: 0 20px !important;

    .ant-menu-submenu-title {
        align-items: center;
    color: #fff !important;
    display: flex;
    }
}


.dry_fruites_mob_menu {
    display: none !important;
}


@media screen and (max-width:1200px) {
    .header_bottom {
        display: none;
    }
    .header_top_left img {
        height: 47px;
    }
    .header_top_center {
        width: 280px;
    }
    .dry_fruites_mob_menu {
    display: flex !important;
}
.dry_fruites_mob_menu button {
    display: flex;
    align-items: center;
    justify-content: center;
}





}



@media screen and (max-width:992px) {
    .header_top_right_support {
        display: none;
    }
    .header_text {
        display: none;
    }

}

@media screen and (max-width:768px) {
    .header_top_align {
        padding: 15px 0 70px 0;
        position: relative;
    }
    .header_top_center {
    width: 100%;
    position: absolute;
    bottom: 15px;
    left: 0;
}





}
















`

const BannerSection = styled.section`
    display: inline-block;
    width: 100%;
    position: relative;
    margin: 0 0 40px;
`

const TopCategory = styled.section`
    display: inline-block;
    position: relative;
    width: 100%;

    .top_category_section {
        width: 100%;
        display: inline-block;
        position: relative;
    }
    .top_category_section ul {
        padding: 0;
        margin: 0;
        display: grid;
        grid-template-columns: repeat(6,1fr);
        gap: 25px;
    }
    .top_category_section ul li {
        
        width: 100%;
        display: inline-block;
        border-radius: 5px;
    }
    .top_category_section ul li span {
        width: 110px;
    height: 110px;
    border-radius: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: auto auto 22px;
   
   
    }
    .top_category_section ul li h4 {
        text-align: center;
        color: ${styles?.color};
        font-size: 15px;
        font-family: ${styles?.q_bold};
        text-transform: uppercase;
    }

    @media screen and (max-width:992px) {
        .top_category_section ul {
            grid-template-columns: repeat(4,1fr);
        }
    }

    @media screen and (max-width:768px) {
        .top_category_section ul {
    grid-template-columns: repeat(3,1fr);
    gap: 25px 15px;
}

    }


    @media screen and (max-width:480px) {
        .top_category_section ul {
    grid-template-columns: repeat(2,1fr);
    gap: 25px 15px;
}

    }







`

const FeatureProductSection = styled.section`
    display: inline-block;
    width: 100%;
    position: relative;

    .fp_section {
        width: 100%;
        display: inline-block;
        position: relative;
    }

    ul {
        margin: 0;
        padding: 0;
        display: grid;
        grid-template-columns: repeat(4,1fr);
        gap: 35px 25px;
    }
    ul li {
        border: 1px solid #ebebeb;
        width: 100%;
        display: inline-block;
        padding: 24px 20px;
        border-radius: 5px;
        text-align: center;
        position: relative;
    }
    ul li .fp_box, ul li .fp_box .fp_image {
        width: 100%;
        display: inline-block;
    }
    ul li .fp_box .fp_image img {
        width: 100%;
    }
    ul li .fp_content {
        width: 100%;
        display: inline-block;
        position: relative;
    }
    ul li .fp_content h4 {
        font-size: 18px;
        font-family: ${styles?.q_medium} !important;
        line-height: 1.4;
    }
    ul li .fp_content .fp_price {
        display: flex;
        gap: 8px;
        flex-wrap: wrap;
        align-items: center;
        width: fit-content;
        margin: auto;
    }
    ul li .fp_content span.sp {
        font-size: 20px;
        font-family: ${styles?.q_bold};
    }
    ul li .fp_content span.mrp {
        
    }
    .hotsale {
        position: absolute;
        top: 13px;
        left: 13px;
        height: 45px;
        width: 45px;
        display: flex;
        align-items: center;
        justify-content: center;
        text-align: center;
        background: ${styles?.themegreen};
        border-radius: 100%;
        line-height: 1.1;
        color: #fff;
        font-size: 12px;
        font-family: ${styles?.q_medium};
    }

    @media screen and (max-width:992px) {
        ul {
            grid-template-columns: repeat(3,1fr);
            gap:35px 15px;
        }
    }

    @media screen and (max-width:768px) {
        ul {
    grid-template-columns: repeat(2,1fr);
    gap: 35px 15px;
}
    }


    @media screen and (max-width:480px) {
        ul li .fp_content h4 {
            font-size: 15px;
        }
        .hotsale {
    height: 35px;
    width: 35px;
   font-size: 10px;
        }




    }




`

const Hc1Section = styled.section`
    width:100%;
    display: inline-block;
    position: relative;

    .hc1_section {
        display: inline-block;
        width:100%;
        position: relative;
    }
    .hc1_align {
        width: 100%;
        display: inline-block;
        position: relative;
    }
    ul {
        display: grid;
        grid-template-columns: repeat(2,1fr);
        gap: 40px;
        padding: 0;
        margin: 0;
    }
    ul li {
        width: 100%;
        display: inline-block;
        border: 1px solid #ebebeb;
        border-radius: 8px;
        padding: 24px;
    }
.subtitle {
    display: block;
    width: fit-content;
    text-align: end;
    background: ${styles?.themegreen};
    color: #fff;
    padding: 4px 20px;
    border-radius: 15px 1px 15px 1px;
    margin: 0 0 22px auto;
}
ul li img {
    width: 100%;
    padding: 0 50px;
}

.hc1_box_right {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 20px;
    margin: 30px 0 0 0;
}
.hc1_box_right h4 {
    margin: 0 !important;
    width: 75%;
    text-align: left;
    line-height: 1.4;
    font-family: ${styles?.q_bold};
    font-size: 23px;
}
.hc1_box_right button {
    border: 0;
    background: transparent;
    outline: none;
    img {
        padding: 0;
        height: 30px;
    }
}

@media screen and (max-width:768px) {
    ul {
        grid-template-columns: repeat(1,1fr);
    } 
}

@media screen and (max-width:480px) {
    .hc1_box_right h4 {
        font-size: 18px;
    }
}




`

const Hc2Section = styled.section`

width: 100%;
display: inline-block;
position: relative;

.hc2_section {
    display: inline-block;
    position: relative;
    width: 100%;
}
ul {
    padding: 0;
    margin: 0;
    display: grid;
    grid-template-columns: repeat(3,1fr);
    gap: 40px 30px;
}

ul li {
    width: 100%;
    display: inline-block;
    position: relative;
}

ul li .hc2_box {
    width: 100%;
    position: relative;
    text-align: center;
}
ul li .hc2_box .hc2_top {
    display: inline-block;
    position: relative;
    padding: 0 20px;
}
ul li .hc2_box .hc2_top img {
    width: 100%;
    border-radius: 100%;
    position: relative;
    z-index: 10;
}
.hc2_bottom {
    width: 100%;
    display: flex;
    flex-direction: column;
    gap: 15px;
    padding: 60px 24px 30px 24px;
    border: 1px solid #ebebeb;
    border-radius: 5px;
    margin: -50px 0 0 0;
    position: relative;
}
.hc2_bottom h4 {
    font-size: 22px;
    margin: 0 !important;
    font-family: ${styles?.q_bold};
}
.hc2_bottom h5 {
    font-size: 15px;
    font-family: ${styles?.q_regular} !important;
    color: ${styles?.gray} !important;
    line-height: 1.6;
}
.hc2_bottom button {
width: fit-content;
    background: ${styles?.themegreen};
    color: #fff;
    padding: 5px 20px;
    border-radius: 15px 1px 15px 1px;
    margin: 0;
    border: 0;
    position: absolute;
    bottom: -15px;
    left: 50%;
    transform: translate(-50%, 0px);
}


@media screen and (max-width:768px) {
    ul {
        grid-template-columns: repeat(1,1fr);
        gap: 65px;
    }
}

@media screen and (max-width:480px) {
    .hc2_bottom h4 {
        font-size: 18px;
    }
}






`


const Hc3Section = styled.section`
    display: inline-block;
    width: 100%;
    position: relative;

    .hc3_align {
        display: flex;
        
        gap: 20px;
        width: 100%;
    }

    .hc3_left {
        flex: 1.2;
        
    }
    .hc3_right {
        flex: 2;
       
    }
    .hc3_left ul {
        margin: 0;
        padding: 0;
        grid-template-columns: repeat(1,1fr);
        gap: 0;
        display: grid;
        height: 100%;
    }
    .hc3_left ul li {
        height: 100%;
        display: flex;
        flex-wrap: wrap;
        border: 1px solid #ededed;
        padding: 20px;
        border-radius: 5px;
    }
    .hc3_left ul li .hc3_box {
        display: flex;
    flex-direction: column;
    justify-content: space-between;
}
.hc3_left ul li .hc3_box .hc3_img {
    margin: auto;
}



    .hc3_right ul {
        margin: 0;
        padding: 0;
        grid-template-columns: repeat(2,1fr);
        gap: 20px;
        display: grid;
        height: 100%;
    }
    .hc3_right ul li {
        height: 100%;
        display: flex;
        flex-wrap: wrap;
        border: 1px solid #ededed;
        padding: 20px;
        border-radius: 5px;
    }

.hc3_content {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin: 20px 0 0 0;
}
.hc3_right ul li img {
    padding: 0 20px;
}

    .hc3_align h4 {
    margin: 0 !important;
    width: 75%;
    text-align: left;
    line-height: 1.4;
    font-family: ${styles?.q_bold};
    font-size: 18px;
}
.hc3_align button {
    border: 0;
    background: transparent;
    outline: none;
    img {
        padding: 0 !important;
        height: 25px;
    }
}

.trand_product {
display: block;
    width: fit-content;
    text-align: end;
    background: ${styles?.themegreen};
    color: #fff;
    padding: 4px 15px;
    border-radius: 12px 1px 12px 1px;
    margin: 0 0 20px auto;
    font-size: 12px;
}

@media screen and (max-width:768px) {
    .hc3_align {
        flex-direction: column;
    }
    .hc3_left, .hc3_right {
        flex: auto;
        width: 100%;
    }
}

@media screen and (max-width:480px) {
    .hc3_right ul {
        grid-template-columns: repeat(1,1fr);
    }
}





`

const FooterSection = styled.section`
* {
    font-family: ${styles?.q_regular};
}
    width: 100%;
    display: inline-block;
    position: relative;
    
    .footer_section {
        width: 100%;
        display: inline-block;
        position: relative;
        margin: 60px 0 0 0;
        background: #f5f5f5;
    padding: 50px 0 0 0;
    }
    a {
        color: ${styles?.color};
    }
    .footer_top {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 20px;
        flex-wrap: wrap;
        
    }
    .footer_top_wrap {
        padding: 0 0 30px;
        border-bottom: 1px solid #e1e1e1;
        margin: 0 0 30px;
        width: 100%;
        display: inline-block;
    }
    .footer_top .footer_top_left {
        display: inline-block;
        width: fit-content;
    }
    .footer_top .footer_top_left img {
        height: 55px;
    }
    .footer_top .footer_top_center ul {
        width: 420px;
    }
    .footer_top .footer_top_right {
        width: fit-content;
        display: inline-block;
    }
    .footer_top .footer_top_right h4 {
        font-family: ${styles?.q_bold} !important;
    }
    .footer_top .footer_top_right ul {
        display: flex;
        align-items: center;
        gap: 18px;
        margin: 0;
        padding: 0;
    }
    .footer_top .footer_top_right ul img {
        height: 29px;
    }

    .footer_bottom {
        display: flex;
        align-items: flex-start;
        justify-content: space-between;
        gap: 20px;
        flex-wrap: wrap;
    }
    iframe {
        width: 100%;
    }
    .footer_1 {
        width: fit-content;
        display: inline-block;
    }
    .footer_2 {
        width: fit-content;
        display: inline-block;
    }
    .footer_3 {
        width: 26%;
        display: inline-block;
    }
    .footer_4 {
        width: 23%;
        display: inline-block;
    }
    .footer_bottom ul {
        margin: 0;
        padding: 0;
        display: flex;
        flex-direction: column;
        gap: 8px;
        font-size: 14px;
        color: ${styles?.color};
    }
    .footer_bottom h4 {
        font-family: ${styles?.q_bold} !important;
        font-size: 22px !important;
        margin: 0 0 25px;
    }
    .footer_3 ul li {
        position: relative;
        padding: 0 0 0 35px;
        margin: 0 0 12px;
        &:last-child {
            margin: 0;
        }
    }
    .footer_3 ul li::before {
        content: "";
        position: absolute;
        background: url(${email});
        height: 16px;
    width: 17px;
    
    top: 3px;
    left: 0;
    background-size: contain !important;
    background-repeat: no-repeat !important;
    background-position: center left !important;
}
.footer_3 ul li.address::before {
    background: url(${address}) !important;
    background-size: contain !important;
    background-repeat: no-repeat !important;
    background-position: center left !important;
}
.footer_3 ul li.call::before {
    background: url(${call}) !important;
    background-size: contain !important;
    background-repeat: no-repeat !important;
    background-position: center left !important;
}
.footer_3 ul li.mail::before {
    background: url(${email}) !important;
    background-size: contain !important;
    background-repeat: no-repeat !important;
    background-position: center left !important;
}

    .copy_text {
        width: 100%;
        display: inline-block;
        padding: 10px 0;
        background: ${styles?.themegreen};
        border-top: 0px solid #c7c7c7;
        margin: 50px 0 0 0;
        p {
            line-height: 1.5;
            color: ${styles?.white};
            margin: 0;
            a {
                color: ${styles?.white};
            }
        }
    }
    .copy_text .copy_align {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 20px;
    }

    .copy_text .copy_align p {
        font-size: 14px;
    }



    @media screen and (max-width: 768px) {
        .footer_top {
            flex-direction: column;
        }
        .footer_bottom {
            display: grid;
            grid-template-columns: repeat(2,1fr);
            gap: 40px 20px;
        }
        .footer_1, .footer_2, .footer_3, .footer_4 {
            width: 100%;
            display: inline-block;
        }
        .copy_text .copy_align {
            flex-direction: column;
            gap: 8px;
        }
        .footer_top .footer_top_center ul {
    width: auto;
}
    }


@media screen and (max-width:480px) {
    .footer_top .footer_top_center ul {
    width: 100%;
    flex-wrap: wrap;
} 
.footer_bottom {
    grid-template-columns: repeat(1,1fr);
}






}



`