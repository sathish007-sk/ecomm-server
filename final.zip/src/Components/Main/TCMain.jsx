import React, { useEffect, useState } from 'react'
import API from '../../Api/ApiService';
import TopCategory from '../TopCategory/TopCategory'
import TC1 from '../TopCategory/TC1'
import TC2 from '../TopCategory/TC2'
import TC3 from '../TopCategory/TC3'
import TC4 from '../TopCategory/TC4'
import TC5 from '../TopCategory/TC5'
import TC6 from '../TopCategory/TC6'
import Premium1TC1 from '../TopCategory/Premium1TC1'
import Premium2TC2 from '../TopCategory/Premium2TC2'






import {
  Skeleton,
} from "antd";
import AgriTopCategory from '../TopCategory/AgriTopCategory';
import GiftTopCategory from '../TopCategory/GiftTopCategory';
import FTopCategory from '../TopCategory/FTopCategory';
import DryTopCategory from '../TopCategory/DryTopCategory';

const TCMain = () => {
  const api = new API();
  const [theme, setTheme] = useState("")
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setLoading(true)
    api.themes().then((res) => {
      setLoading(false)
      setTheme(res.data.topcategorytype)
    }).catch((err) => { setLoading(false) })
  }, [])




  return (
    <React.Fragment>
      {
        loading === true ?
          <Skeleton />
          :
          <>
            {theme === "TC1" ? <FTopCategory /> : ""}
            {theme === "TC2" ? <DryTopCategory /> : ""}
            {theme === "TC3" ? <TC3 /> : ""}
            {theme === "TC4" ? <TC4 /> : ""}
            {theme === "TC5" ? <AgriTopCategory /> : ""}
            {theme === "TC6" ? <GiftTopCategory /> : ""}
            {theme === "PRE-TC1" ? <Premium1TC1 /> : ""}
            {theme === "PRE-TC2" ? <Premium2TC2 /> : ""}
          </>
      }
    </React.Fragment>
  )
}

export default TCMain