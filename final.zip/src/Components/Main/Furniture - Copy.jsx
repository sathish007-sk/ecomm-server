import React from 'react'
import styled from 'styled-components';
import logo from '../../Assets/Images/Temp/logo.png'
import { Input, Badge, Menu, Dropdown,Button } from 'antd';
import { Link, useNavigate } from "react-router-dom";
import hcart from '../../Assets/Images/Temp/icon/cart.png'
import huser from '../../Assets/Images/Temp/icon/profile.png'
import MobileMenu from '../MenuBar/MobileMenu';
import banner from "../../Assets/Images/furniture/banner.png"
import pro from "../../Assets/Images/furniture/pro.png"
import top from "../../Assets/Images/furniture/top.png"
import three from "../../Assets/Images/furniture/3.png"
import b1 from "../../Assets/Images/furniture/b11.png"
import five from "../../Assets/Images/furniture/5.jpg"
import { styles } from '../../Api/Data';
import GiftFooter from '../Footer/GiftFooter';





const Furniture = () => {
    return (
        <React.Fragment>
            <React.Fragment>
                <HeaderSection>
                    <div className='header_section'>
                        <div className='wrapper'>
                            <div className='header_align'>
                                <div className='header_left'>
                                    <img src={logo} alt="" />
                                </div>
                                <div className='header_center'>
                                    <Menu mode="horizontal">
                                        <Menu.Item key="home">
                                            <Link to="/">Home</Link>
                                        </Menu.Item>
                                        <Menu.Item key="about">
                                            <Link to="/about">About Us</Link>
                                        </Menu.Item>
                                        <Menu.Item key="Category">
                                            <Link to="/">Categories</Link>
                                        </Menu.Item>
                                        <Menu.Item key="Contact">
                                            <Link to="/">Contact Us</Link>
                                        </Menu.Item>
                                    </Menu>
                                </div>
                                <div className='header_right'>
                                    <div className='shop_cart'>
                                        <ul>
                                            <li>
                                                <Link to="/">
                                                    <img src={huser} alt="User" />
                                                </Link>
                                            </li>
                                            <li>
                                                <Link to="/">
                                                    <Badge count={0} showZero size='small'><img src={hcart} alt="Cart" /></Badge>
                                                </Link>
                                            </li>
                                            <li>
                                                <MobileMenu />
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </HeaderSection>
            </React.Fragment>
            <React.Fragment>
                <BannerSection>
                    <div className='banner_section'>
                        <div>
                            <img src={banner} alt="" />
                        </div>
                    </div>
                </BannerSection>
            </React.Fragment>
            <Body>
                <React.Fragment>
                    <TopCategory>
                        <div className='top_category_section'>
                            <div className='wrapper'>
                                <H2>Popular Category</H2>
                                <ul>
                                    <li>
                                        <div className='top_box'>
                                            <img src={top} alt="top" />
                                            <div className='top_content'>
                                                <h4>Accessories</h4>
                                                <button>Shop Now</button>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div className='top_box'>
                                            <img src={top} alt="top" />
                                            <div className='top_content'>
                                                <h4>Accessories</h4>
                                                <button>Shop Now</button>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div className='top_box'>
                                            <img src={top} alt="top" />
                                            <div className='top_content'>
                                                <h4>Accessories</h4>
                                                <button>Shop Now</button>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div className='top_box'>
                                            <img src={top} alt="top" />
                                            <div className='top_content'>
                                                <h4>Accessories</h4>
                                                <button>Shop Now</button>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </TopCategory>
                </React.Fragment>
                <React.Fragment>
                    <FeatureProduct>
                        <div className='feature_product'>
                            <div className='wrapper'>
                                <H2>Featured Product</H2>
                                <ul>
                                    <li>
                                        <div className='feature_box'>
                                            <div className='feature_img'>
                                                <img src={pro} alt="product" />
                                            </div>
                                            <h4>COMFY CHAIR</h4>
                                            <div className='price'>
                                                <span className='sp'>{styles?.currency}85</span>
                                                <span className='mrp'>{styles?.currency}100</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div className='feature_box'>
                                            <div className='feature_img'>
                                                <img src={pro} alt="product" />
                                            </div>
                                            <h4>COMFY CHAIR</h4>
                                            <div className='price'>
                                                <span className='sp'>{styles?.currency}85</span>
                                                <span className='mrp'>{styles?.currency}100</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div className='feature_box'>
                                            <div className='feature_img'>
                                                <img src={pro} alt="product" />
                                            </div>
                                            <h4>COMFY CHAIR</h4>
                                            <div className='price'>
                                                <span className='sp'>{styles?.currency}85</span>
                                                <span className='mrp'>{styles?.currency}100</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div className='feature_box'>
                                            <div className='feature_img'>
                                                <img src={pro} alt="product" />
                                            </div>
                                            <h4>COMFY CHAIR</h4>
                                            <div className='price'>
                                                <span className='sp'>{styles?.currency}85</span>
                                                <span className='mrp'>{styles?.currency}100</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div className='feature_box'>
                                            <div className='feature_img'>
                                                <img src={pro} alt="product" />
                                            </div>
                                            <h4>COMFY CHAIR</h4>
                                            <div className='price'>
                                                <span className='sp'>{styles?.currency}85</span>
                                                <span className='mrp'>{styles?.currency}100</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div className='feature_box'>
                                            <div className='feature_img'>
                                                <img src={pro} alt="product" />
                                            </div>
                                            <h4>COMFY CHAIR</h4>
                                            <div className='price'>
                                                <span className='sp'>{styles?.currency}85</span>
                                                <span className='mrp'>{styles?.currency}100</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div className='feature_box'>
                                            <div className='feature_img'>
                                                <img src={pro} alt="product" />
                                            </div>
                                            <h4>COMFY CHAIR</h4>
                                            <div className='price'>
                                                <span className='sp'>{styles?.currency}85</span>
                                                <span className='mrp'>{styles?.currency}100</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div className='feature_box'>
                                            <div className='feature_img'>
                                                <img src={pro} alt="product" />
                                            </div>
                                            <h4>COMFY CHAIR</h4>
                                            <div className='price'>
                                                <span className='sp'>{styles?.currency}85</span>
                                                <span className='mrp'>{styles?.currency}100</span>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </FeatureProduct>
                </React.Fragment>
              
                <React.Fragment>
                    <Hc1Section>
                        <div className='hc1_section'>
                            <div className='wrapper'>
                                <H2>BEST SELLING</H2>
                                <ul>
                                    <li>
                                        <div className='hc1_box'>
                                            <div className='left'>
                                                <img src={b1} alt="Product" />
                                            </div>
                                            <div className='right'>
                                                <h4>New Products</h4>
                                                <h5>Get 30% Off</h5>
                                                <Link to="/">
                                                    <Button>Shop Now</Button>
                                                </Link>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div className='hc1_box'>
                                            <div className='left'>
                                                <img src={b1} alt="Product" />
                                            </div>
                                            <div className='right'>
                                                <h4>Best Selling</h4>
                                                <h5>Collection of stands</h5>
                                                <Link to="/">
                                                    <Button>Shop Now</Button>
                                                </Link>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </Hc1Section>
                </React.Fragment>

                <React.Fragment>
                    <Hc2Section>
                        <div className='hc2_section'>
                            <div className='wrapper'>
                                <H2>ACCESSORIES</H2>
                                <ul>
                                    <li>
                                        <div className='hc2_box'>
                                            <img src={three} alt="Hc2 Section" />
                                            <div className='hc2_content'>
                                                <h4>INTERIOR LAMP</h4>
                                                <button>Shop Now</button>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div className='hc2_box'>
                                            <img src={three} alt="Hc2 Section" />
                                            <div className='hc2_content'>
                                                <h4>INTERIOR LAMP</h4>
                                                <button>Shop Now</button>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div className='hc2_box'>
                                            <img src={three} alt="Hc2 Section" />
                                            <div className='hc2_content'>
                                                <h4>INTERIOR LAMP</h4>
                                                <button>Shop Now</button>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </Hc2Section>
                </React.Fragment>
                <React.Fragment>
                    <Hc3Section>
                        <div className='h3_section'>
                            <div className='wrapper'>
                                <H2>FEATURES ELEMENTS</H2>
                                <div className='hc3_align'>
                                    <div className='hc3_1'>
                                        <ul>
                                            <li>
                                                <div className='hc3_box'>
                                                    <img src={five} alt="" />
                                                    <div className='hc3_content'>
                                                        <h4>WOOD LAMP</h4>
                                                        <button>Shop Now</button>
                                                    </div>
                                                </div>


                                            </li>
                                            <li>
                                                <div className='hc3_box'>
                                                    <img src={five} alt="" />
                                                    <div className='hc3_content'>
                                                        <h4>WOOD LAMP</h4>
                                                        <button>Shop Now</button>
                                                    </div>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                    <div className='hc3_2'>
                                        <ul>
                                            <li>
                                                <div className='hc3_box'>
                                                    <img src={five} alt="" />
                                                    <div className='hc3_content'>
                                                        <h4>WOOD LAMP</h4>
                                                        <button>Shop Now</button>
                                                    </div>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                    <div className='hc3_3'>
                                        <ul>
                                            <li>
                                                <div className='hc3_box'>
                                                    <img src={five} alt="" />
                                                    <div className='hc3_content'>
                                                        <h4>WOOD LAMP</h4>
                                                        <button>Shop Now</button>
                                                    </div>
                                                </div>
                                            </li>
                                            <li>
                                                <div className='hc3_box'>
                                                    <img src={five} alt="" />
                                                    <div className='hc3_content'>
                                                        <h4>WOOD LAMP</h4>
                                                        <button>Shop Now</button>
                                                    </div>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </Hc3Section>
                </React.Fragment>
                <GiftFooter />
            </Body>
        </React.Fragment>
    )
}

export default Furniture;


const Body = styled.div`
    display: grid;
    margin: 40px 0;
    width:100%;
    gap: 80px;

`

const H2 = styled.h2`
   font-size:30px;
   margin : 0 0 35px;
   text-transform: uppercase;
   font-family: ${styles?.r_regular} !important;
   letter-spacing: 0.7px;

`

const HeaderSection = styled.section`
 display: inline-block;
    width: 100%;
    position: relative;
.header_section {
    display: inline-block;
    width: 100%;
    position: relative;
}
.header_section .header_align {
    display: flex;
    align-items: center;
    justify-content: space-between;
    width: 100%;
    padding: 15px 0;
}
.header_section .header_align .header_left {
    width: fit-content;
    display: inline-block;
}

.header_section .header_align .header_left img {
    height: 55px;
}
.header_section .header_align .header_center {
    width: fit-content;
    display: inline-block;
}
.header_section .header_align .header_center {
    width: fit-content;
    display: inline-block;
}
.header_section .header_align .header_right .shop_cart {
    display: inline-block;
    position: relative;
}
.header_section .header_align .header_right .shop_cart ul {
    list-style: none;
    display: flex;
    align-items: center;
    gap: 15px;
    padding: 0;
    margin: 0;
}
.header_section .header_align .header_right .shop_cart ul li {
    position: relative;
    width: fit-content;
    display: flex;
    a {
        display: flex;
    }
}
.header_section .header_align .header_right .shop_cart ul li img {
    height: 25px;
}
.header_section .header_align .header_right .shop_cart ul li:last-child {
    margin: 0 0 0 0px;
    button {
        display: flex;
        align-items: center;
        justify-content: center;
        border: 0;
        height: auto;

        span {
            font-size: 26px;
        }
    }
}




















`

const BannerSection = styled.section`
    width: 100%;
    display: inline-block;
    position: relative;
    margin: 0 0 40px;
    img {
        width: 100%;
    }

`


const TopCategory = styled.section`
    width: 100%;
    display: inline-block;
    position: relative;

    .top_category_section {
        display: inline-block;
        width: 100%;
        position: relative;
    }
    .top_category_section ul {
        list-style: none;
        padding: 0;
        margin: 0;
        display: grid;
        grid-template-columns: repeat(4,1fr);
        gap: 25px;
    }
    .top_category_section ul li {
        width: 100%;
        display: inline-block;
        position: relative;
    }
    .top_category_section ul li .top_box {
        display: inline-block;
        position: relative;
        width: 100%;
    }
    .top_category_section ul li .top_box .top_content {
        width: 100%;
        padding: 20px 15px 15px 20%;
        bottom: 0;
        right: 0;
        position: absolute;
        text-align: right;
    }

    .top_category_section ul li .top_box .top_content h4 {
        font-size: 16px;
        font-family: ${styles?.r_regular} !important;
        text-transform: uppercase;
        color: ${styles?.color};
        font-weight: 600;
        letter-spacing: 1px;
        margin: 0 0 5px;
    }
    .top_category_section ul li .top_box .top_content button {
        padding: 0 !important;
    background: transparent;
    border: 0;
    padding: 0;
    font-size: 13px;
    font-style: italic;
    text-decoration: underline;
font-weight: 600;
font-family: ${styles?.r_regular} !important;
letter-spacing: 0.7px;
    }





`;


const FeatureProduct = styled.section`
    width: 100%;
    display: inline-block;
    position: relative;

    .feature_product {
        display: inline-block;
        width: 100%;
        position: relative;
    }
    .feature_product ul {
        list-style: none;
        width: 100%;
        display: grid;
        grid-template-columns: repeat(4,1fr);
        gap: 40px 25px;
        padding: 0;
        margin: 0;
    }
    .feature_product ul li {
        width: 100%;
        display: inline-block;
    }
    .feature_product ul li .feature_box {
        width: 100%;
        display: inline-block;
    }
    .feature_product ul li .feature_box .feature_img {
        width: 100%;
        display: inline-block;
        margin: 0 0 25px;
    }
    .feature_product ul li .feature_box .feature_img img {
        width: 100%;
    }
    .feature_product ul li .feature_box h4 {
        font-size: 20px;
    font-family: r_regular !important;
    text-transform: uppercase;
    color: #000;
    font-weight: 500;
    -webkit-letter-spacing: 1px;
    -moz-letter-spacing: 1px;
    -ms-letter-spacing: 1px;
    letter-spacing: 1px;
    margin: 0 0 7px;
    text-align: center;
    }
    .feature_product ul li .feature_box .price {
        display: flex;
        flex-wrap: wrap;
        width: fit-content;
        margin: auto;
        gap: 4px;
    }
    .feature_product ul li .feature_box .price span.sp {
        font-size: 18px;
        font-family: r_regular !important;
        color: #000;
    font-weight: 600;
    }
    .feature_product ul li .feature_box .price span.mrp {

    }


`

const Hc1Section = styled.section`
    * {
        font-family: ${styles?.r_regular};
    }
    width:100%;
    display: inline-block;
    position: relative;
    .hc1_section {
        display: inline-block;
        width: 100%;
        position: relative;
    }

    .hc1_section ul {
        display: grid;
        padding: 0;
        grid-template-columns: repeat(2,1fr);
        gap: 45px;
    }
    .hc1_section ul li {
        background: #dbf0e2;
    padding: 35px 30px;
    width: 100%;
    border-radius: 0px;
    display: grid;
    align-items: center;
    }
    .hc1_section ul li .hc1_box {
        display: flex;
        align-items: center;
        justify-content: space-between;
        flex-wrap: wrap;
    }
    .hc1_section ul li .hc1_box .left {
        width: 47%;
        display: inline-block;
    }
    .hc1_section ul li .hc1_box .right {
        width: 47%;
        display: flex;
        gap: 15px;
        text-align: center;
        flex-direction: column;
    }
    .hc1_section ul li .hc1_box .right h4 {
        font-size: 30px;
        text-transform: uppercase;
        margin: 0 !important;
        font-family: ${styles?.r_bold} !important;
    }
    .hc1_section ul li .hc1_box .right h5 {
        margin: 0 !important;
        font-size: 18px;
        font-family: ${styles?.r_regular};
    }
    .hc1_section ul li .hc1_box .right button {
        padding: 0 !important;
    background: transparent;
    border: 0;
    padding: 0;
    margin: auto;
    font-size: 13px;
    font-style: italic;
    -webkit-text-decoration: underline;
    text-decoration: underline;
    font-weight: 600;
    font-family: r_regular !important;
    -webkit-letter-spacing: 0.7px;
    -moz-letter-spacing: 0.7px;
    -ms-letter-spacing: 0.7px;
    letter-spacing: 0.7px;
    display: flex;
    }

    @media screen and (max-width:768px) {
        .hc1_section ul {
            grid-template-columns: repeat(1,1fr);
        }
    }

    @media screen and (max-width:480px) {
        .hc1_section ul li .hc1_box {
            flex-direction: column;
            gap: 40px;
        }
        .hc1_section ul li .hc1_box .right {
            width: 100%;
        }
        .hc1_section ul li .hc1_box .left {
            width: 100%;
            img {
                margin: auto;
                padding: 0 50px;
            }
        }





    }


`

const Hc2Section = styled.section`
    display: inline-block;
    width: 100%;
    position: relative;

    .hc2_section {
        display: inline-block;
        width: 100%;
        position: relative;
    }
    .hc2_section ul {
        list-style: none;
        padding: 0;
        margin: 0;
        display: grid;
        grid-template-columns: repeat(3,1fr);
        gap: 40px 25px;
    }
    .hc2_section ul li {
        width: 100%;
        display: inline-block;
        position: relative;
    }
    .hc2_section ul li .hc2_box {
        display: inline-block;
        width: 100%;
        position: relative;

    }
    .hc2_section ul li .hc2_box img {
        width: 100%;
    }
    .hc2_section ul li .hc2_box .hc2_content {
        display: flex;
        flex-direction: column;
        gap: 5px;
        position: absolute;
        bottom: 0;
        left: 0;
        width: 100%;
        padding: 20px;
        text-align: left;
    }
    .hc2_section ul li .hc2_box .hc2_content h4 {
        font-size: 23px;
    font-family: r_regular !important;
    text-transform: uppercase;
    color: #000;
    font-weight: 600;
    -webkit-letter-spacing: 1px;
    -moz-letter-spacing: 1px;
    -ms-letter-spacing: 1px;
    letter-spacing: 1px;
    margin: 0 0 5px;
    width: 100%;
    }
    .hc2_section ul li .hc2_box .hc2_content button {
        padding: 0 !important;
    background: transparent;
    border: 0;
    padding: 0;
    margin: 0;
    font-size: 13px;
    font-style: italic;
    -webkit-text-decoration: underline;
    text-decoration: underline;
    font-weight: 600;
    font-family: r_regular !important;
    -webkit-letter-spacing: 0.7px;
    -moz-letter-spacing: 0.7px;
    -ms-letter-spacing: 0.7px;
    letter-spacing: 0.7px;
    display: flex;
    }



`

const Hc3Section = styled.section`
   display:inline-block;
   width:100%;
   position: relative;

   .h3_section {
    display: inline-block;
    width: 100%;
    position: relative;
   }
   .h3_section .hc3_align {
    display: flex;
    align-items: stretch;
    width: 100%;
    gap: 25px;
   }
   .h3_section .hc3_align ul {
    list-style: none;
    padding: 0;
    margin: 0;
   }
   .h3_section .hc3_align .hc3_1, .h3_section .hc3_align .hc3_3 {
    flex:1;
   }
   .h3_section .hc3_align .hc3_2 {
    flex: 2;
   }
   .h3_section .hc3_align .hc3_1 ul, .h3_section .hc3_align .hc3_3 ul {
    display: grid;
    grid-template-columns: repeat(1,1fr);
    gap: 25px;
   }
   .h3_section .hc3_align .hc3_2 ul, .h3_section .hc3_align .hc3_2 ul li, .h3_section .hc3_align .hc3_2 ul li .hc3_box,.h3_section .hc3_align .hc3_2 ul li .hc3_box img  {
    height: 100%;
   }
   .h3_section .hc3_align .hc3_2 ul li .hc3_box img {
    object-fit: cover;
   }
   .h3_section ul li {
    position: relative;
   }
   .h3_section ul li .hc3_box .hc3_content {
        display: flex;
        flex-direction: column;
        gap: 5px;
        position: absolute;
        bottom: 0;
        left: 0;
        width: 100%;
        padding: 20px;
        text-align: left;
    }
    .h3_section ul li .hc3_box .hc3_content h4 {
        font-size: 23px;
    font-family: r_regular !important;
    text-transform: uppercase;
    color: #000;
    font-weight: 600;
    -webkit-letter-spacing: 1px;
    -moz-letter-spacing: 1px;
    -ms-letter-spacing: 1px;
    letter-spacing: 1px;
    margin: 0 0 5px;
    width: 100%;
    }
    .h3_section ul li .hc3_box .hc3_content button {
        padding: 0 !important;
    background: transparent;
    border: 0;
    padding: 0;
    margin: 0;
    font-size: 13px;
    font-style: italic;
    -webkit-text-decoration: underline;
    text-decoration: underline;
    font-weight: 600;
    font-family: r_regular !important;
    -webkit-letter-spacing: 0.7px;
    -moz-letter-spacing: 0.7px;
    -ms-letter-spacing: 0.7px;
    letter-spacing: 0.7px;
    display: flex;
    }













`