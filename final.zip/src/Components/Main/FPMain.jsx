import React, { useState, useEffect } from 'react'
import API from '../../Api/ApiService';
import FP1 from '../FeatureProduct/FP1'
import FP2 from '../FeatureProduct/FP2'
import FP3 from '../FeatureProduct/FP3'
import FP4 from '../FeatureProduct/FP4'
import FP5 from '../FeatureProduct/FP5'
import FP6 from '../FeatureProduct/FP6'
import PremiumFP1 from '../FeatureProduct/PremiumFP1'
import PremiumFP2 from '../FeatureProduct/PremiumFP2'






import {
  Skeleton,
} from "antd";
import AgriFeatureProduct from '../FeatureProduct/AgriFeatureProduct';
import GiftFeatureProduct from '../FeatureProduct/GiftFeatureProduct';
import FFP from '../FeatureProduct/FFP';
import DryFeatureProduct from '../FeatureProduct/DryFeatureProduct';

const FPMain = () => {
  const [theme, setTheme] = useState("")
  const [loading, setLoading] = useState(false);
  const api = new API();

  useEffect(() => {
    setLoading(true)
    api.themes().then((res) => {
      setLoading(false)
      setTheme(res.data.featuredproducttype)
    }).catch((err) => { setLoading(false) })
  }, [])




  return (
    <React.Fragment>
      {
        loading === true ?
          <Skeleton />
          :
          <>
            {theme === "FE1" ? <FFP /> : ""}
            {theme === "FE2" ? <DryFeatureProduct /> : ""}
            {theme === "FE3" ? <FP3 /> : ""}
            {theme === "FE4" ? <FP4 /> : ""}
            {theme === "FE5" ? <AgriFeatureProduct /> : ""}
            {theme === "FE6" ? <GiftFeatureProduct /> : ""}
            {theme === "PRE-FE1" ? <PremiumFP1 /> : ""}
            {theme === "PRE-FE2" ? <PremiumFP2 /> : ""}
          </>
      }
    </React.Fragment>
  )
}

export default FPMain