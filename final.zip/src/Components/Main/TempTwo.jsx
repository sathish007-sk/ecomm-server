import React from 'react'
import styled from 'styled-components';
import {Link} from "react-router-dom"
import { styles } from '../../Api/Data';
import hcall from '../../Assets/Images/Temp/icon/call.png'
import hmail from '../../Assets/Images/Temp/icon/email.png'
import horder from '../../Assets/Images/Temp/icon/order.png'
import hcart from '../../Assets/Images/Temp/icon/cart.png'
import henquire from '../../Assets/Images/Temp/icon/enquire.png'
import huser from '../../Assets/Images/Temp/icon/profile.png'
import haddress from '../../Assets/Images/Temp/icon/location.png'
import logo from '../../Assets/Images/Temp/logo.png'
import banner from '../../Assets/Images/Temp/banner.png'
import facebook from '../../Assets/Images/Temp/s1.png'
import instagram from '../../Assets/Images/Temp/s2.png'
import top from '../../Assets/Images/Temp/cat.webp'
import bg from '../../Assets/Images/Temp/bg.jpg'
import pro from '../../Assets/Images/Temp/product.webp'
import bimg from '../../Assets/Images/Temp/best.webp'
import b1 from "../../Assets/Images/Temp/gift.png"
import b2 from "../../Assets/Images/Temp/gift.png"
import address from "../../Assets/Images/Agri/location.png"
import call from "../../Assets/Images/Agri/call.png"
import mail from "../../Assets/Images/Agri/mail.png"
import MobileMenu from '../MenuBar/MobileMenu';
import { ShoppingCartOutlined } from '@ant-design/icons';
import { Input,Badge,Menu,Divider,Button } from 'antd';
const { Search } = Input;
const TempTwo = () => {
    const onSearch = (value) => console.log(value);
    return (
        <React.Fragment>
            {/* <React.Fragment>
                <HeaderSection>
                    <div className='head_section'>
                        <div className='head_top'>
                            <div className='wrapper'>
                                <div className='head_top_align'>
                                    <ul>
                                        <li>
                                            <a href="" title=''>
                                                <span className='icon'><img src={hcall} alt="Call" /></span>
                                                <span className='text'>6374445033</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="" title=''>
                                                <span className='icon'><img src={hmail} alt="Mail" style={{height:"12px"}} /></span>
                                                <span className='text'>contact@ecdigi.com</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="" title=''>
                                                <span className='icon'><img src={haddress} alt="Location" /></span>
                                                <span className='text'>Flat No.3, 3rd Floor, Srivari Kikani Centre</span>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div className='head_center'>
                            <div className='wrapper'>
                                <div className='head_center_align'>
                                    <div className='head_center_left'>
                                        <img src={logo} alt="Logo" />
                                    </div>
                                    <div className='head_center_center'>
                                        <Search
                                            placeholder="Search Product"
                                            onSearch={onSearch}
                                            style={{
                                                width: 300,
                                            }}
                                        />
                                    </div>
                                    <div className='head_center_right'>
                                        <ul>
                                            <li>
                                                <span className='icon'><img src={henquire} alt="Enquire Form" /></span>
                                                <span className='text'>Enquire Form</span>
                                            </li>
                                            <li>
                                                <span className='icon'><img src={huser} alt="My Account" /></span>
                                                <span className='text'>Sign Up / Login</span>
                                            </li>
                                            <li>
                                                <span className='icon'><Badge count={5} showZero size='small'><img src={hcart} alt="Cart" /></Badge></span>
                                                <span className='text'>My Cart</span>
                                            </li>
                                            <li>
                                                <span className='icon'><img src={horder} alt="My Order" /></span>
                                                <span className='text'>My Order</span>
                                            </li>
                                            <li className='mobile_menu'>
                                                <span><MobileMenu /></span>
                                                <span>Menu</span>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className='head_bottom'>
                            <div className='wrapper'>
                                <div className='head_bottom_align'>
                                <Menu mode="horizontal">
                                        <Menu.Item key="home">
                                            <Link to="/">Home</Link>
                                        </Menu.Item>
                                        <Menu.Item key="about">
                                            <Link to="/">About Us</Link>
                                        </Menu.Item>
                                        <Menu.Item key="Categories">
                                            <Link to="/">Categories</Link>
                                        </Menu.Item>
                                        <Menu.Item key="Policy">
                                            <Link to="/">Policy</Link>
                                        </Menu.Item>
                                        <Menu.Item key="Enquiry">
                                            <Link to="/">Enquiry From</Link>
                                        </Menu.Item>
                                        <Menu.Item key="Policy">
                                            <Link to="/">My Address</Link>
                                        </Menu.Item>
                                        <Menu.Item key="Policy">
                                            <Link to="/">My Profile</Link>
                                        </Menu.Item>
                                        <SubMenu key="product" title="Product">
                                        {category?.map((e, i) => {
                                        return (
                                        <Menu.Item key={`menuPdttemp1_${i}`}>
                                        <Link to={`/${e.category_name.toLowerCase().replace(/ /g, '-')
                                        .replace(/[^\w-]+/g, '')}`}>
                                        {e.category_name}
                                        </Link>
                                        </Menu.Item>
                                        );
                                        })}
                                        </SubMenu>
                                        <Menu.Item key="contact">
                                            <Link to="/">Contact Us</Link>
                                        </Menu.Item>

                                    </Menu>
                                    <div className='social_media'>
                                        <ul>
                                            <li>
                                                <img src={facebook} alt="Facebook" />
                                            </li>
                                            <li>
                                                <img src={instagram} alt="Instagram" />
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </HeaderSection>
            </React.Fragment> */}
            {/* <React.Fragment>
                <BannerSection>
                    <img src={banner} alt="banner" />                        
                </BannerSection>
            </React.Fragment> */}
            <Body>
            {/* <React.Fragment>
               <TopCategory>
                    <div className='top_category'>
                         <div className='wrapper'>               
                        <HeadDivider>
                            <Divider><h1>Popular Category</h1></Divider>
                        </HeadDivider>
                        <ul>
                            <li>
                                <div className='top_box'>
                                    <span>
                                        <img src={top} alt="Category" />
                                    </span>
                                    <h4>Birth Day</h4>
                                </div>
                            </li>
                            <li>
                                <div className='top_box'>
                                    <span>
                                        <img src={top} alt="Category" />
                                    </span>
                                    <h4>Birth Day</h4>
                                </div>
                            </li>
                            <li>
                                <div className='top_box'>
                                    <span>
                                        <img src={top} alt="Category" />
                                    </span>
                                    <h4>Birth Day</h4>
                                </div>
                            </li>
                            <li>
                                <div className='top_box'>
                                    <span>
                                        <img src={top} alt="Category" />
                                    </span>
                                    <h4>Birth Day</h4>
                                </div>
                            </li>
                            <li>
                                <div className='top_box'>
                                    <span>
                                        <img src={top} alt="Category" />
                                    </span>
                                    <h4>Birth Day</h4>
                                </div>
                            </li>
                            <li>
                                <div className='top_box'>
                                    <span>
                                        <img src={top} alt="Category" />
                                    </span>
                                    <h4>Birth Day</h4>
                                </div>
                            </li>
                        </ul> 
                        </div>              
                    </div>                    
                </TopCategory>                             
            </React.Fragment> */}
            {/* <React.Fragment>
                <FPSection>
                    <div className='fp_section'>
                        <div className='wrapper'>
                        <HeadDivider>
                            <Divider><h2>Featured Products</h2></Divider>
                        </HeadDivider>
                        <ul>
                            <li>
                                <div className='fp_box'>
                                    <div className='fp_img'>
                                        <img src={pro} alt="Products" />
                                    </div>
                                    <div className='fp_content'>
                                        <h4>Personalised 3D Crystal Birthday Gift for Husband</h4>
                                        <div className='fp_content_align'>
                                        <div className='fp_price'>
                                            <span className='sp'>Rs.99</span>
                                            <span className='mrp'>Rs.300</span>
                                        </div>
                                        <Button type='primary' size='small'><ShoppingCartOutlined /> Buy Now</Button>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div className='fp_box'>
                                    <div className='fp_img'>
                                        <img src={pro} alt="Products" />
                                    </div>
                                    <div className='fp_content'>
                                        <h4>Personalised 3D Crystal Birthday Gift for Husband</h4>
                                        <div className='fp_content_align'>
                                        <div className='fp_price'>
                                            <span className='sp'>Rs.99</span>
                                            <span className='mrp'>Rs.300</span>
                                        </div>
                                        <Button type='primary' size='small'><ShoppingCartOutlined /> Buy Now</Button>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div className='fp_box'>
                                    <div className='fp_img'>
                                        <img src={pro} alt="Products" />
                                    </div>
                                    <div className='fp_content'>
                                        <h4>Personalised 3D Crystal Birthday Gift for Husband</h4>
                                        <div className='fp_content_align'>
                                        <div className='fp_price'>
                                            <span className='sp'>Rs.99</span>
                                            <span className='mrp'>Rs.300</span>
                                        </div>
                                        <Button type='primary' size='small'><ShoppingCartOutlined /> Buy Now</Button>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div className='fp_box'>
                                    <div className='fp_img'>
                                        <img src={pro} alt="Products" />
                                    </div>
                                    <div className='fp_content'>
                                        <h4>Personalised 3D Crystal Birthday Gift for Husband</h4>
                                        <div className='fp_content_align'>
                                        <div className='fp_price'>
                                            <span className='sp'>Rs.99</span>
                                            <span className='mrp'>Rs.300</span>
                                        </div>
                                        <Button type='primary' size='small'><ShoppingCartOutlined /> Buy Now</Button>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div className='fp_box'>
                                    <div className='fp_img'>
                                        <img src={pro} alt="Products" />
                                    </div>
                                    <div className='fp_content'>
                                        <h4>Personalised 3D Crystal Birthday Gift for Husband</h4>
                                        <div className='fp_content_align'>
                                        <div className='fp_price'>
                                            <span className='sp'>Rs.99</span>
                                            <span className='mrp'>Rs.300</span>
                                        </div>
                                        <Button type='primary' size='small'><ShoppingCartOutlined /> Buy Now</Button>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div className='fp_box'>
                                    <div className='fp_img'>
                                        <img src={pro} alt="Products" />
                                    </div>
                                    <div className='fp_content'>
                                        <h4>Personalised 3D Crystal Birthday Gift for Husband</h4>
                                        <div className='fp_content_align'>
                                        <div className='fp_price'>
                                            <span className='sp'>Rs.99</span>
                                            <span className='mrp'>Rs.300</span>
                                        </div>
                                        <Button type='primary' size='small'><ShoppingCartOutlined /> Buy Now</Button>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div className='fp_box'>
                                    <div className='fp_img'>
                                        <img src={pro} alt="Products" />
                                    </div>
                                    <div className='fp_content'>
                                        <h4>Personalised 3D Crystal Birthday Gift for Husband</h4>
                                        <div className='fp_content_align'>
                                        <div className='fp_price'>
                                            <span className='sp'>Rs.99</span>
                                            <span className='mrp'>Rs.300</span>
                                        </div>
                                        <Button type='primary' size='small'><ShoppingCartOutlined /> Buy Now</Button>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div className='fp_box'>
                                    <div className='fp_img'>
                                        <img src={pro} alt="Products" />
                                    </div>
                                    <div className='fp_content'>
                                        <h4>Personalised 3D Crystal Birthday Gift for Husband</h4>
                                        <div className='fp_content_align'>
                                        <div className='fp_price'>
                                            <span className='sp'>Rs.99</span>
                                            <span className='mrp'>Rs.300</span>
                                        </div>
                                        <Button type='primary' size='small'><ShoppingCartOutlined /> Buy Now</Button>
                                        </div>
                                    </div>
                                </div>
                            </li>

                        </ul>
                        </div>
                    </div>                    
                </FPSection>
            </React.Fragment> */}
            <React.Fragment>
                <BestSales>
                    <div className='best_sales_section'>
                        <div className='wrapper'>
                        <HeadDivider>
                            <Divider><h2>Bestsellers</h2></Divider>
                        </HeadDivider>
                        <ul>
                            <li>
                                <div className='b_img'>
                                    <img src={bimg} alt="Bestsellers" />
                                </div>
                                <h4>Birthday Gifts</h4>
                            </li>
                            <li>
                                <div className='b_img'>
                                    <img src={bimg} alt="Bestsellers" />
                                </div>
                                <h4>Birthday Gifts</h4>
                            </li>
                            <li>
                                <div className='b_img'>
                                    <img src={bimg} alt="Bestsellers" />
                                </div>
                                <h4>Birthday Gifts</h4>
                            </li>
                            <li>
                                <div className='b_img'>
                                    <img src={bimg} alt="Bestsellers" />
                                </div>
                                <h4>Birthday Gifts</h4>
                            </li>
                            <li>
                                <div className='b_img'>
                                    <img src={bimg} alt="Bestsellers" />
                                </div>
                                <h4>Birthday Gifts</h4>
                            </li>
                            <li>
                                <div className='b_img'>
                                    <img src={bimg} alt="Bestsellers" />
                                </div>
                                <h4>Birthday Gifts</h4>
                            </li>
                            <li>
                                <div className='b_img'>
                                    <img src={bimg} alt="Bestsellers" />
                                </div>
                                <h4>Birthday Gifts</h4>
                            </li>
                            <li>
                                <div className='b_img'>
                                    <img src={bimg} alt="Bestsellers" />
                                </div>
                                <h4>Birthday Gifts</h4>
                            </li>
                            <li>
                                <div className='b_img'>
                                    <img src={bimg} alt="Bestsellers" />
                                </div>
                                <h4>Birthday Gifts</h4>
                            </li>
                            <li>
                                <div className='b_img'>
                                    <img src={bimg} alt="Bestsellers" />
                                </div>
                                <h4>Birthday Gifts</h4>
                            </li>
                        </ul>
                        </div>
                    </div>
                </BestSales>
            </React.Fragment>
            <React.Fragment>
                <FPSection>
                    <div className='fp_section'>
                        <div className='wrapper'>
                        <HeadDivider>
                            <Divider><h2>Trending Now</h2></Divider>
                        </HeadDivider>
                        <ul>
                            <li>
                                <div className='fp_box'>
                                    <div className='fp_img'>
                                        <img src={pro} alt="Products" />
                                    </div>
                                    <div className='fp_content'>
                                        <h4>Personalised 3D Crystal Birthday Gift for Husband</h4>
                                        <div className='fp_content_align'>
                                        <div className='fp_price'>
                                            <span className='sp'>Rs.99</span>
                                            <span className='mrp'>Rs.300</span>
                                        </div>
                                        <Button type='primary' size='small'><ShoppingCartOutlined /> Buy Now</Button>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div className='fp_box'>
                                    <div className='fp_img'>
                                        <img src={pro} alt="Products" />
                                    </div>
                                    <div className='fp_content'>
                                        <h4>Personalised 3D Crystal Birthday Gift for Husband</h4>
                                        <div className='fp_content_align'>
                                        <div className='fp_price'>
                                            <span className='sp'>Rs.99</span>
                                            <span className='mrp'>Rs.300</span>
                                        </div>
                                        <Button type='primary' size='small'><ShoppingCartOutlined /> Buy Now</Button>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div className='fp_box'>
                                    <div className='fp_img'>
                                        <img src={pro} alt="Products" />
                                    </div>
                                    <div className='fp_content'>
                                        <h4>Personalised 3D Crystal Birthday Gift for Husband</h4>
                                        <div className='fp_content_align'>
                                        <div className='fp_price'>
                                            <span className='sp'>Rs.99</span>
                                            <span className='mrp'>Rs.300</span>
                                        </div>
                                        <Button type='primary' size='small'><ShoppingCartOutlined /> Buy Now</Button>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div className='fp_box'>
                                    <div className='fp_img'>
                                        <img src={pro} alt="Products" />
                                    </div>
                                    <div className='fp_content'>
                                        <h4>Personalised 3D Crystal Birthday Gift for Husband</h4>
                                        <div className='fp_content_align'>
                                        <div className='fp_price'>
                                            <span className='sp'>Rs.99</span>
                                            <span className='mrp'>Rs.300</span>
                                        </div>
                                        <Button type='primary' size='small'><ShoppingCartOutlined /> Buy Now</Button>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            
                        </ul>
                        </div>
                    </div>                    
                </FPSection>
            </React.Fragment>
            <React.Fragment>
                    <Hc1Section>
                        <div className='hc1_section'>
                            <div className='wrapper'>
                                <ul>
                                    <li>
                                        <div className='hc1_box'>
                                            <div className='left'>
                                                <img src={b1} alt="Product" />
                                            </div>
                                            <div className='right'>
                                                <h4>New Products</h4>
                                                <h5>Get 30% Off</h5>
                                                <Link to="/">
                                                    <Button>Shop Now</Button>
                                                </Link>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div className='hc1_box'>
                                            <div className='left'>
                                                <img src={b2} alt="Product" />
                                            </div>
                                            <div className='right'>
                                                <h4>Best Selling</h4>
                                                <h5>Collection of stands</h5>
                                                <Link to="/">
                                                    <Button>Shop Now</Button>
                                                </Link>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </Hc1Section>
            </React.Fragment>
            </Body>
            <React.Fragment>
                <FooterSection>
                    <div className='footer_Section'>
                        <div className='wrapper'>
                            <div className='footer_align'>
                                <div className='footer_1'>
                                    <h4>Contact Us</h4>
                                    <ul>
                                        <li className='address'>No.2, DR. Krishnaswamy Mudaliyar Road, R.S. Puram, Coimbatore -415415</li>
                                        <li className='phone'>Office : +91 6374 445 033</li>
                                        <li className='email'>contact@ecdigi.com</li>
                                    </ul>
                                </div>
                                <div className='footer_2'>
                                    <h4>Quick links</h4>
                                    <ul>
                                        <li><a href="javascript:void(0)" title='Privacy Policy'>Privacy Policy</a></li>
                                        <li><a href="javascript:void(0)" title='Terms and Conditions'>Terms and Conditions</a></li>
                                        <li><a href="javascript:void(0)" title='Refund Policy'>Refund Policy</a></li>
                                        <li><a href="javascript:void(0)" title='Delivery Policy'>Delivery Policy</a></li>
                                    </ul>
                                </div>
                                <div className='footer_3'>
                                    <h4>Useful Links</h4>
                                    <ul>
                                        <li><a href="javascript:void(0)" title='Return Policy'>Return Policy</a></li>
                                        <li><a href="javascript:void(0)" title='Cancellation Policy'>Cancellation Policy</a></li>
                                    </ul>
                                </div>
                                <div className='footer_4'>
                                    <img src={logo} alt="Logo" />
                                    <ul>
                                        <li>
                                            <img src={facebook} alt="facebook" />
                                        </li>
                                        <li>
                                            <img src={instagram} alt="instagram" />
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div className='copy_text'>
                            <div className='wrapper'>
                                <div className='copy_align'>
                                    <div className='copy_left'>
                                        <p>All Rights Reserved. ecDigi</p>
                                    </div>
                                    <div className='copy_right'>
                                        <p>© 2022 Designed by ecDigi Technologies.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </FooterSection>
            </React.Fragment>
        </React.Fragment>
    )
}

export default TempTwo;

const HeadDivider = styled.div`
display: inline-block;
margin: 0 0 55px;
width: 100%;
    h1, h2 {
        margin: 0 !important;
        font-size: 30px !important;
        font-weight: 600;
        font-family: ${styles?.medium} !important;
    }
    .ant-divider-horizontal.ant-divider-with-text {
        border-top-color: ${styles?.color} !important;
        margin: 0;
    }

@media screen and (max-width:1200px) {
    margin: 0 0 40px;
}
@media screen and (max-width:480px) {
    h1, h2 {
        font-size: 27px !important;
    }

}

`
const Body = styled.div`
display: grid;
grid-template-columns: repeat(1,1fr);
gap: 120px;
margin: 60px 0;
width: 100%;

@media screen and (max-width:1200px) {
    gap: 80px;
    margin: 40px 0;
}


`
// const HeaderSection = styled.section`
//     * {
//         font-family: ${styles?.regular};
//     }
//     display: inline-block;
//     width:100%;
//     position: relative;

//     .head_section {
//         display: flex;
//         flex-direction: column;
//         position: relative;
//         width:100%;
//     }
//     .head_section .head_top {
//         display: inline-block;
//         position: relative;
//         width: 100%;
//         padding: 5px 0;
//         background: #eaeaea;
//     }
//     .head_section .head_top .head_top_align {
//         display: inline-block;
//         text-align: end;
//         position: relative;
//         width: 100%;
//     }
//     .head_section .head_top .head_top_align ul {
//         display: flex;
//         flex-wrap: wrap;
//         align-items: center;
//         gap: 30px;
//         padding: 0;
//         margin: 0 0 0 auto;
//         width: fit-content;
//     }
//     .head_section .head_top .head_top_align ul li a {
//         display: flex;
//         align-items: center;
//         gap: 12px;
//         color: ${styles?.color};
//         font-size: 13px;
//     }
//     .head_section .head_top .head_top_align ul li a span.icon img {
//         height: 16px;
//     }
//     .head_section .head_center {
//         background: #fff;
//         display: inline-block;
//         width: 100%;
//         padding: 20px 0;
//     }
//     .head_section .head_center .head_center_align {
//         display: flex;
//         align-items: center;
//         justify-content: space-between;
//         flex-wrap: wrap;
//         width: 100%;
//         position: relative;
//     }
//     .head_section .head_center .head_center_align .head_center_left {
//         display: inline-block;
//         width: fit-content;
//     }
//     .head_section .head_center .head_center_align .head_center_left img {
//         height: 55px;
//     }
//     .head_section .head_center .head_center_align .head_center_center {
//         width: fit-content;
//         display: inline-block;
//         border: 1px solid #8b8b91;
//     border-radius: 5px;
//     width: 300px;
//         input {
//             padding: 7px 15px;
//             border: 0;
//         }
//         button {
//             padding: 10px 0px;
//     height: auto;
//     border: 0;
//     background: transparent !important;
//     color: #000;
//         }
//         .ant-input-group-addon {
//             background: transparent;
//         }
//     }
//     .head_section .head_center .head_center_align .head_center_right {
//         width: fit-content;
//         display: inline-block;
        

//     }
//     .head_section .head_center .head_center_align .head_center_right ul {
//         display: flex;
//         align-items: center;
//         gap: 24px;
//         flex-wrap: wrap;
//         position: relative;
//         width:fit-content;
//         margin: 0;
//         padding: 0;
//     }
//     .head_section .head_center .head_center_align .head_center_right ul li {
//         display: flex;
//         align-items: center;
//         justify-content: center;
//         gap: 7px;
//         flex-direction: column;
//     }
//     .head_section .head_center .head_center_align .head_center_right ul li span.icon {
//         width: 100%;
//     display: flex;
//     text-align: center;
//     align-items: center;
//     justify-content: center;
//         img {
//             margin: auto;
//             height: 24px;
//         }
//     }
//     .head_section .head_center .head_center_align .head_center_right ul li span.text {
//         text-align: center;
//         font-size: 12px;
//         color: ${styles?.color};
//         font-weight: 500;
//     }

//     .head_bottom {
//         width: 100%;
//         display: inline-block;
//         position: relative;
//         background: #eaeaea;
//         padding: 3px 0;
//     }
//     .head_bottom .head_bottom_align {
//     display: flex;
//     align-items: center;
//     justify-content: space-between;
//     width: 100%;
//     ul {
//         width: 70%;
//     }
//     .social_media {
//         width:fit-content;
//         display: inline-block;
//     }
//     .social_media ul {
//         padding: 0;
//         margin: 0;
//         display: flex;
//         align-items: center;
//         gap: 13px;
//         width: fit-content;
//     }
//     .social_media ul img {
//         height: 26px;
//     }
// }
// .mobile_menu {
//     display: none !important;
// }

// @media screen and (max-width:1200px) {
//     .head_bottom {
//         display: none;
//     }
//     .head_section .head_center .head_center_align .head_center_left img {
//     height: 50px;
// }
// .mobile_menu {
//     display: flex !important;

//     button {
//         border: 0 !important;
//     padding: 0 !important;
//     height: 21px !important;
//     display: flex;
// }

// }

// }

// @media screen and (max-width:992px) {
    
//     .head_section .head_center .head_center_align .head_center_center {
//         width: 240px;
//         .ant-input-group-wrapper {
//             width: 240px !important;
//         }
//     }

//     .head_section .head_center .head_center_align .head_center_right ul {
//         gap: 14px;
//     }
//     .head_section .head_center .head_center_align .head_center_right ul li span:nth-child(2) {
//         display: none;
//     }
//     .head_section .head_center .head_center_align .head_center_right ul li:nth-child(1), .head_section .head_center .head_center_align .head_center_right ul li:nth-child(4) {
//         display: none;
//     }
//     .mobile_menu button {
//         border: 1px solid #d9d9d9 !important;
//     padding: 3px 5px !important;
//     height: auto !important;
//     margin: 0 0 0 10px;
//     }

// }


// @media screen and (max-width:768px) {
    
//     .head_section .head_top {
//         display: none;
//     }
//     .head_section .head_center {
//         padding: 12px 0;
//     }
//     .head_section .head_center .head_center_align .head_center_center input {
//     padding: 5px 15px;
//     }
//     .head_section .head_center .head_center_align .head_center_center button {
//     padding: 8px 0px;
//     }
//     .head_section .head_center .head_center_align .head_center_left img {
//     height: 45px;
// }


// }



// @media screen and (max-width:580px) {
    
//     .head_section .head_center .head_center_align {
//         position: relative;
//         padding: 0 0 50px;
//     }

//     .head_section .head_center .head_center_align .head_center_center {
//     width: 100%;
//     position: absolute;
//     bottom: 0;
//     left: 0;
// }
// .head_section .head_center .head_center_align .head_center_center .ant-input-group-wrapper {
//     width: 100% !important;
// }
// .head_section .head_center .head_center_align .head_center_left img {
//     height: 40px;
// }






// }






// `
const BannerSection = styled.section`
    display: inline-block;
    width: 100%;
    position: relative;
    margin: 0 0 60px;

    @media screen and (max-width:1200px) {
        margin: 0 0 40px;
    }



`
// const TopCategory = styled.section`
//     display: inline-block;
//     width: 100%;
//     position: relative;
    
//     ul {
//         width: 100%;
//         display: grid;
//         grid-template-columns: repeat(6,1fr);
//         gap: 40px 30px;
//         padding: 0;
//         margin: 0;
//     }
//     ul li {
//         width: 100%;
//         display: inline-block;
//     }
//     ul li span {
//         display: flex;
//         width: 100%;
//         position: relative;
//         align-items: center;
//         justify-content: center;
//         img {
//             width: 100%;
//             border-radius: 10px;
//             cursor: pointer;
//         }
//     }
//     ul li h4 {
//         text-align: center;
//         margin: 15px 0 0 0;
//         font-size: 16px;
//         color: ${styles?.color};
//         font-weight: 600;
//     }
    
//     @media screen and (max-width:992px) {
//         ul {
//         grid-template-columns: repeat(3,1fr);
//         gap: 30px 20px
//     }
//     }

//     @media screen and (max-width:768px) {
//         ul {
//         grid-template-columns: repeat(2,1fr);
//         gap: 30px 15px
//         }
//     }







// `
// const FPSection = styled.section`
//     display: inline-block;
//     position: relative;
//     width: 100%;
//     background: url(${bg});
//     background-repeat: repeat;
//     padding: 80px 0;

//     ul {
//         list-style: none;
//         padding: 0;
//         margin: 0;
//         display: grid;
//         grid-template-columns: repeat(4,1fr);
//         gap: 50px 25px;
//     }
//     ul li {
//         width: 100%;
//         display: inline-block;
//         position: relative;
//         box-shadow: 0 0 30px rgb(0 0 0 / 10%);
//     border-radius: 6px;
//     overflow: hidden;
//     }
//     ul li .fp_box, ul li .fp_box .fp_img {
//         width: 100%;
//         display: flex;
//     flex-direction: column;
//     }
//     ul li .fp_box .fp_img img {
//         width: 100%;
//         display: flex;
//         align-items: center;
//     }
//     ul li .fp_box .fp_content {
//         width: 100%;
//         display: inline-block;
//         padding: 15px 20px 20px 20px;
//         background: #fff;
//     }
//     ul li .fp_box .fp_content h4 {
//         text-align: left;
//         font-size: 15px;
//         font-family: ${styles?.regular}!important;
//         line-height: 1.7;
//         color: ${styles?.color};
//         margin: 0 !important;
//     }
//     ul li .fp_box .fp_content .fp_price {
//         display: flex;
//         align-items: center;
//         gap: 6px;
//     }
//     ul li .fp_box .fp_content .fp_price span.sp {
//         font-size: 18px;
//         font-family: ${styles?.bold};
//     }
//     ul li .fp_box .fp_content .fp_price span.mrp {
//         font-size: 12px;
//     }
//     ul li .fp_box .fp_content button {
//         display: flex;
//         align-items: center;
//         padding: 4px 7px;
//         height: auto;
//         font-size: 12px;
//     } 
//     .fp_content_align {
//         display: flex;
//         align-items: center;
//         gap: 20px;
//         justify-content: space-between;
//         flex-wrap: wrap;
//         margin: 25px 0 0 0;
//     }


//     @media screen and (max-width:1200px) {
//         padding: 50px 0;
//     }


//     @media screen and (max-width:992px) {
//         ul {
//     grid-template-columns: repeat(3,1fr);
//     gap: 30px 20px;
// }
//     }


//     @media screen and (max-width:768px) {
//          ul {
//     grid-template-columns: repeat(2,1fr);
//     gap: 30px 15px;
// }
//     }

//     @media screen and (max-width:480px) {
       
//         ul li .fp_box .fp_content {
//             padding: 15px 15px 20px 15px;
//         }
//         ul li .fp_box .fp_content h4 {
//             font-size: 14px;
//             line-height: 1.5;
//         }
//         .fp_content_align {
//             margin: 14px 0 0 0;
//             gap: 9px;
//         }


//     }







// `
const BestSales = styled.section`
   display: inline-block;
   width: 100%;
   position: relative;

   ul {
        width: 100%;
        display: grid;
        grid-template-columns: repeat(5,1fr);
        gap: 40px 25px;
        padding: 0;
        margin: 0;
    }
    ul li {
        width: 100%;
        display: inline-block;
    }
    ul li .b_img {
        display: flex;
        width: 100%;
        position: relative;
        align-items: center;
        justify-content: center;
        img {
            width: 100%;
            border-radius: 10px;
            cursor: pointer;
        }
    }
    ul li h4 {
        text-align: center;
        margin: 15px 0 0 0;
        font-size: 16px;
        color: ${styles?.color};
        font-weight: 600;
    }

    @media screen and (max-width:992px) {
        ul {
            grid-template-columns: repeat(3,1fr);
            gap: 30px 20px;
        }
    }

    @media screen and (max-width:768px) {
         ul {
    grid-template-columns: repeat(2,1fr);
    gap: 30px 15px;
}
    }




`
const Hc1Section = styled.section`
    * {
        font-family: ${styles?.r_regular};
    }
    width:100%;
    display: inline-block;
    position: relative;
    .hc1_section {
        display: inline-block;
        width: 100%;
        position: relative;
    }

    .hc1_section ul {
        display: grid;
        padding: 0;
        grid-template-columns: repeat(2,1fr);
        gap: 45px;
    }
    .hc1_section ul li {
        background: #eaeaea;
    padding: 35px 30px;
    width: 100%;
    border-radius: 14px;
    display: grid;
    align-items: center;
    }
    .hc1_section ul li .hc1_box {
        display: flex;
        align-items: center;
        justify-content: space-between;
        flex-wrap: wrap;
    }
    .hc1_section ul li .hc1_box .left {
        width: 47%;
        display: inline-block;
    }
    .hc1_section ul li .hc1_box .right {
        width: 47%;
        display: flex;
        gap: 15px;
        text-align: center;
        flex-direction: column;
    }
    .hc1_section ul li .hc1_box .right h4 {
        font-size: 30px;
        text-transform: uppercase;
        margin: 0 !important;
        font-family: ${styles?.r_bold} !important;
    }
    .hc1_section ul li .hc1_box .right h5 {
        margin: 0 !important;
        font-size: 18px;
        font-family: ${styles?.r_regular};
    }
    .hc1_section ul li .hc1_box .right button {
        background: #222;
    border: 1px solid #222;
    border-radius: 35px;
    color: #fff;
    padding: 5px 16px;
    height: auto;
    font-size: 15px;
    }

    @media screen and (max-width:768px) {
        .hc1_section ul {
            grid-template-columns: repeat(1,1fr);
        }
    }

    @media screen and (max-width:480px) {
        .hc1_section ul li .hc1_box {
            flex-direction: column;
            gap: 40px;
        }
        .hc1_section ul li .hc1_box .right {
            width: 100%;
        }
        .hc1_section ul li .hc1_box .left {
            width: 100%;
            img {
                margin: auto;
                padding: 0 50px;
            }
        }





    }


`
const FooterSection = styled.section`
    width: 100%;
    display: inline-block;
    position: relative;
    background: #eaeaea;
    margin: 60px 0 0 0;
    
    .footer_Section {
        width: 100%;
        display: inline-block;
        position: relative;
        padding: 60px 0 0 0;
    }
    .footer_Section .footer_align {
        display: flex;
        align-items: flex-start;
        width: 100%;
        justify-content: space-between;
        gap: 20px;
        ul {
            padding: 0;
        }
        h4 {
            color: ${styles?.color} !important;
            font-family: ${styles?.bold} !important;
            font-size: 27px;
            margin: 0 0 30px !important;
           
        }
    }
    .footer_1 {
        width: 28%;
        display: inline-block;
        ul {
            list-style: none;
        }
        ul li {
            color: ${styles?.color};
            margin: 0 0 20px;
            padding: 0 0 0 40px;
            font-size: 15px;
            position: relative;
            line-height: 1.9;
        }
        ul li:last-child {
                margin: 0;
            }
        ul li::before {
            content: "";
            position: absolute;
            background: url(${address});
            background-repeat: no-repeat !important;
            height: 21px;
            filter: brightness(0) !important;
    width: 21px;
    background-size: contain !important;
    left: 0;
    top: 6px;
    background-position: center left !important;
}
    ul li.address::before {
        background: url(${address});
    }
    ul li.phone::before {
        background: url(${call});
    }
    ul li.email::before {
        background: url(${mail});
    }

    }
    .footer_2 {
      width: fit-content;
      display: inline-block;
      ul li {
        line-height: 1.9;
        margin: 0 0 8px;
        font-size: 15px;
        color: ${styles?.color} !important;
        a {
            color: ${styles?.color} !important;
        }
      }
    }
    .footer_3 {
        width: fit-content;
      display: inline-block;
      ul li {
        line-height: 1.9;
        margin: 0 0 8px;
        font-size: 15px;
        color: ${styles?.color} !important;
        a {
            color: ${styles?.color} !important;
        }
      }
    }
    .footer_4 {
        width: fit-content;
      display: inline-block;

      img {
        margin: auto;
        height: 60px;
      }

      ul {
        list-style: none;
        width: fit-content;
        margin: 30px auto auto;
        display: flex;
        align-items: center;
        gap: 15px;
        img {
            height: 35px;
        }
      }
    }

    .copy_text {
        width: 100%;
        display: inline-block;
        padding: 15px 0;
        border-top: 1px solid #888;
        margin: 50px 0 0 0;
        p {
            line-height: 1.5;
            color: ${styles?.color};
            margin: 0;
        }
    }
    .copy_text .copy_align {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 20px;
    }


    @media screen and (max-width:956px) {
        .footer_Section .footer_align {
            display: grid;
            grid-template-columns: repeat(2,1fr);
            gap: 45px 30px;
        }
        .footer_1, .footer_2, .footer_3, .footer_4 {
            display: inline-block;
            width: 100%;
        }
    }


    @media screen and (max-width:768px) {
        margin: 75px 0 0 0;
    }


    @media screen and (max-width:480px) {
        .footer_Section .footer_align {
    display: flex;
   flex-direction: column-reverse;
}

.copy_text .copy_align {
    flex-wrap: wrap;
    flex-direction: column;
    justify-content: center;
    gap: 10px;
}





    }





`;