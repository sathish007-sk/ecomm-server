import React, { useState, useEffect } from 'react'
import styled from 'styled-components';
import growleft from "../../Assets/Images/Agri/grow.jpg"
import growright from "../../Assets/Images/Agri/grow_bg_2.jpg"
import growbg from "../../Assets/Images/Agri/grow_bg.png"
import growbg1 from "../../Assets/Images/Agri/bg2.png"
import s1 from "../../Assets/Images/Agri/s1.jpg"
import s2 from "../../Assets/Images/Agri/s2.jpg"
import s3 from "../../Assets/Images/Agri/s3.jpg"
import s4 from "../../Assets/Images/Agri/s4.jpg"
import bestservice from "../../Assets/Images/Agri/best_service.jpg"
import { Link } from 'react-router-dom'
import { Button } from "antd";
import { styles } from '../../Api/Data';
import API from '../../Api/ApiService';
import DefaultImg from "../../Assets/Images/default.png";

const AgriTemplate = () => {
    const [data, setData] = useState([]);
    const api = new API();

    useEffect(() => {
        aboutContent()
    }, [])

    const aboutContent = () => {
        let page = "about";
        api.dynamicPage(page).then((res) => {
            let data = {
                banner: res.data?.banner ? api.rootUrl + res.data.banner : "",
                content: res.data?.content,
            };
            setData(data);
        }).catch((err) => { })
    }

    

    return (
        <React.Fragment>
            <React.Fragment>
                <GrowSection>
                    <div className='grow_section'>
                        <div className='wrapper'>
                            <div className='grow_align'>
                                <div className='grow_left'>
                                    <img src={data.banner} alt="Grow" />
                                </div>
                                <div className='grow_right'>
                                    <div className='grow_right_top'>
                                        <h2 className='grow_head'>HOW TO GROW</h2>
                                        <p>{data.content && (
                                            <div dangerouslySetInnerHTML={{ __html: data.content.substr(0, 300) + "..." }}></div>
                                        )}</p>
                                    </div>
                                    <div className='grow_right_bottom'>
                                        <h2 className='about_head'>About us</h2>
                                        <p>{data.content && (
                                            <div dangerouslySetInnerHTML={{ __html: data.content.substr(300, 600) + "..." }}></div>
                                        )}</p>
                                        <Link to="/about">
                                            <Button>Read More</Button>
                                        </Link>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </GrowSection>
            </React.Fragment>
            <React.Fragment>
                <BestSection>
                    <div className='best_service_section'>
                        <div className='wrapper'>
                            <div className='best_service_align'>
                                <div className='best_service_left'>
                                    <img src={bestservice} alt="Best Service" />
                                </div>
                                <div className='best_service_right'>
                                    <h2>Best Service</h2>
                                    <ul>
                                        <li>
                                            <div className='left'>
                                                <img src={s1} alt="Best Service" />
                                            </div>
                                            <div className='right'>
                                                <h4>24X7 SUPPORT</h4>
                                                <p>It is a long established fact that a reader will be distracted.</p>
                                            </div>
                                        </li>
                                        <li>
                                            <div className='left'>
                                                <img src={s2} alt="Best Service" />
                                            </div>
                                            <div className='right'>
                                                <h4>FREE SHIPPING</h4>
                                                <p>It is a long established fact that a reader will be distracted.</p>
                                            </div>
                                        </li>
                                        <li>
                                            <div className='left'>
                                                <img src={s3} alt="Best Service" />
                                            </div>
                                            <div className='right'>
                                                <h4>BIG SAVING</h4>
                                                <p>It is a long established fact that a reader will be distracted.</p>
                                            </div>
                                        </li>
                                        <li>
                                            <div className='left'>
                                                <img src={s4} alt="Best Service" />
                                            </div>
                                            <div className='right'>
                                                <h4>BEST OFFERS</h4>
                                                <p>It is a long established fact that a reader will be distracted.</p>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </BestSection>
            </React.Fragment>
        </React.Fragment>
    )
}

export default AgriTemplate;

const GrowSection = styled.section`
   * {
        font-family: ${styles?.r_regular};
    }
    width:100%;
    display: inline-block;
    position: relative;
    &::before {
        content: "";
        position: absolute;
        background: url(${growbg});
        height: 155px;
    width: 155px;
    top: -62px;
    right: 0px;
    z-index: 1;
    background-size: contain;
    background-repeat: no-repeat;
    background-position: top right;
}
    .grow_section {
        background: #f3f3f3;
        width: 100%;
        display: inline-block;
        position: relative;
        &::before {
            content: "";
            position: absolute;
            background: url(${growbg1});
            z-index: 6;
    background-repeat: no-repeat;
    bottom: 0;
    right: 0;
    width: 75%;
    height: 57%;
    background-size: cover;
}
        &::after {
            content: "";
            position: absolute;
            background: url(${growright});
            z-index: 5;
    background-repeat: no-repeat;
    bottom: 0;
    right: 0;
    width: 75%;
    height: 57%;
    background-size: cover;
}
    }
    .grow_section .grow_align {
        display: flex;
        align-items: flex-start;
        flex-wrap: wrap;
        justify-content: space-between;
        position: relative;
        &::before {
            content: "";
            position: absolute;
        }
       
    }
    .grow_section .grow_align .grow_left {
        display: inline-block;
        width: 35%;
        position: relative;
        z-index: 30;
        &::before {
            content: "";
            position: absolute;
            top:10px;
            left:0;
            bottom: 0;
            right:10px;
            border: 1px solid #4abb6d;
            z-index: 1;
            border-radius: 3px;
        }
        img {
            width:100%;
            padding: 0 0 10px 15px;
            z-index: 10;
            border-radius: 3px;
            position: relative;
            border-radius: 3px;
    position: relative;
    height: 650px;
    object-fit: cover;

    @media screen and (max-width:768px) {
        height: 350px;
    }


        }
    }
    .grow_section .grow_align .grow_right {
        display: inline-block;
        width: 60%;
        padding: 50px 0;
        z-index: 30;
    }
    .grow_section .grow_align .grow_right p {
        line-height: 1.9;
        text-align: justify;
        font-family: ${styles?.r_regular} !important;
        color: ${styles?.color};
        font-size: 16px;
    }

    .grow_right_top {
        width:100%;
        display: inline-block;
        margin: 0 0 80px;
    }
    .grow_right_top h2 {
        -webkit-text-stroke: 2px #4abb6d; /* width and color */
        color: transparent !important;
        font-size: 55px;
        text-transform: uppercase;
        font-weight: 500;
        font-family: ${styles?.r_bold} !important;
        margin: 0 0 25px !important;
    }
    .grow_right_bottom h2 {
        color: #fff !important;
        text-transform: uppercase !important;
        font-family: ${styles?.r_bold} !important;
        font-size: 37px;
        margin: 0 0 25px !important;
    }
    .grow_right_bottom p {
        color: ${styles?.white} !important;
        font-size: 16px;
    }

    .grow_right_bottom button {
        background: #4abb6d;
    border: 1px solid #4abb6d;
    border-radius: 35px;
    color: #fff;
    padding: 8px 20px;
    height: auto;
    font-size: 15px;

    }


@media screen and (max-width:768px) {
    &::before, .grow_section::before, .grow_section::after {
        content: inherit;
    }
    .grow_right_bottom h2, .grow_section .grow_align .grow_right p {
        color: ${styles?.color} !important;
    }
    .grow_section .grow_align {
        flex-direction: column-reverse;
        gap: 50px;
        padding: 50px 0;
    }

    .grow_section .grow_align .grow_right {
        padding: 0 0 0px;
        width: 100%;
    }
    .grow_right_top {
        margin: 0 0 30px;
    }

    .grow_right_top h2 {
        font-size: 30px;
        text-align: center;
    }
    .grow_right_bottom h2 {
        font-size: 30px;
        text-align: center;
    }
    .grow_right_bottom button {
    padding: 6px 20px;
    margin: 35px auto auto;
    display: block;
}
.grow_section .grow_align .grow_left {
    width: 100%;
}





}



















`

const BestSection = styled.section`
    width: 100%;
    display: inline-block;
    position: relative;
    
    .best_service_section {
        width: 100%;
        display: inline-block;
        position: relative;
    }
    .best_service_section .best_service_align {
        display: flex;
        align-items: flex-start;
        justify-content: space-between;
        width: 100%;
        position: relative;
    }
    .best_service_section .best_service_align .best_service_left {
        width: 35%;
        display: inline-block;
    }
    .best_service_section .best_service_align .best_service_right {
        width: 63%;
        display: inline-block;
    }
    .best_service_section .best_service_align .best_service_right ul {
        display: grid;
        grid-template-columns: repeat(2,1fr);
        gap: 60px 50px;
        padding: 0;
    }
    .best_service_section .best_service_align .best_service_right ul li {
        display: flex;
        align-items: center;
        justify-content: space-between;
    }
    .best_service_section .best_service_align .best_service_right ul li .left {
        width: 32%;
        display: inline-block;
    }
    .best_service_section .best_service_align .best_service_right ul li .right {
        width: 64%;
        display: inline-block;
    }
    .best_service_section .best_service_align .best_service_right h2 {
    margin: 0 0 45px !important;
    font-family: "r_regular" !important;
    font-weight: 600;
   font-size: 37px;
    text-transform: uppercase;
    text-align: left;
    position: relative;
}
.best_service_section .best_service_align .best_service_right h4 {
    font-family: ${styles?.regular} !important;
    color: ${styles?.color} !important;
    font-size: 22px !important;
}
.best_service_section .best_service_align .best_service_right p {
    font-family: ${styles?.regular} !important;
    color: ${styles?.color} !important;
    font-size: 15px;
}


@media screen and (max-width:768px) {
    .best_service_section .best_service_align {
        flex-direction: column-reverse;
    }
    .best_service_section .best_service_align .best_service_right {
        width: 100%;
    }
    .best_service_section .best_service_align .best_service_right h2 {
        font-size: 30px;
        text-align: center;
    }
    .best_service_section .best_service_align .best_service_right ul {
        gap: 45px 25px;
    }
    .best_service_section .best_service_align .best_service_right ul li {
        flex-direction: column;
        gap: 25px;
    }
    .best_service_section .best_service_align .best_service_right ul li .left {
        width: 100%;
        img {
            margin: auto;
        }
    }
    .best_service_section .best_service_align .best_service_right ul li .right {
        width: 100%;
        text-align: center;
    }
    .best_service_section .best_service_align .best_service_left {
        width: 100%;
        margin: 45px 0 0 0;
        img {
            margin: auto;
        }
    }


@media screen and (max-width:480px) {
    .best_service_section .best_service_align .best_service_right ul li .left img {
        height: 85px;
    }
    .best_service_section .best_service_align .best_service_right h4 {
        font-size: 18px;
    }
    .best_service_section .best_service_align .best_service_right ul {
        grid-template-columns: repeat(1,1fr);
    }

}


}






`