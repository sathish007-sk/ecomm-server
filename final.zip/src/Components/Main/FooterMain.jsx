import React, { useState, useEffect } from 'react'
import API from '../../Api/ApiService';
import Footer1 from '../Footer/Footer1'
import Footer2 from '../Footer/Footer2'
import Footer3 from '../Footer/Footer3'
import Footer4 from '../Footer/Footer4'
import Footer5 from '../Footer/Footer5'
import Footer6 from '../Footer/Footer6'
import Premium1Footer1 from '../Footer/Premium1Footer1'
import Premium2Footer2 from '../Footer/Premium2Footer2'
import AgriFooter from '../Footer/AgriFooter';



import {
  Skeleton,
} from "antd";
import GiftFooter from '../Footer/GiftFooter';
import FFA from '../Footer/FFA';
import DryFooter from '../Footer/DryFooter';

const FooterMain = () => {

  const [theme, setTheme] = useState("")
  const [loading, setLoading] = useState(false);
  const api = new API();

  useEffect(() => {
    themeData();
  }, [])

  const themeData = () => {
    setLoading(true)
    api.themes().then((res) => {
      setTheme(res.data.footertype)
      setLoading(false)
    }).catch((err) => {
      setLoading(false)
    })
  }


  return (
    <React.Fragment>
      {
        loading === true ?
          <Skeleton />
          :
          <>
            {theme === "FA1" ? <FFA /> : ""}
            {theme === "FA2" ? <DryFooter /> : ""}
            {theme === "FA3" ? <Footer3 /> : ""}
            {theme === "FA4" ? <Footer4 /> : ""}
            {theme === "FA5" ? <AgriFooter /> : ""}
            {theme === "FA6" ? <GiftFooter /> : ""}
            {theme === "PRE-FA1" ? <Premium1Footer1 /> : ""}
            {theme === "PRE-FA2" ? <Premium2Footer2 /> : ""}
          </>
      }

    </React.Fragment>
  )
}

export default FooterMain;


