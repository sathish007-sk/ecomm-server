import React, { useEffect, useState } from 'react'
import API from '../../Api/ApiService'
import Banner from '../Banners/Banner'
import BA1 from '../Banners/BA1'
import BA2 from '../Banners/BA2'
import BA3 from '../Banners/BA3'
import BA4 from '../Banners/BA4'
import BA5 from '../Banners/BA5'
import BA6 from '../Banners/BA6'
import Premium1BA1 from '../Banners/Premium1BA1'
import Premium2BA2 from '../Banners/Premium2BA2'
import AgriBanner from '../Banners/AgriBanner'







import {
  Skeleton,
} from "antd";
import FBanner from '../Banners/FBanner'
import DryBanner from '../Banners/DryBanner'

const BannerMain = () => {
  const [theme, setTheme] = useState("")
  const [loading, setLoading] = useState(false);
  const api = new API();

  useEffect(() => {
    setLoading(true)
    api.themes().then((res) => {
      setLoading(false)
      setTheme(res.data.bannertype)
    }).catch((err) => { setLoading(false) })
  }, [])




  return (
    <React.Fragment>
      {
        loading === true ?
          <Skeleton />
          :
          <>
            {theme === "BA1" ? <FBanner /> : ""}
            {theme === "BA2" ? <DryBanner /> : ""}
            {theme === "BA3" ? <BA3 /> : ""}
            {theme === "BA4" ? <BA4 /> : ""}
            {theme === "BA5" ? <AgriBanner /> : ""}
            {theme === "BA6" ? <BA6 /> : ""}
            {theme === "PRE-BA1" ? <Premium1BA1 /> : ""}
            {theme === "PRE-BA2" ? <Premium2BA2 /> : ""}
          </>
      }
    </React.Fragment>
  )
}

export default BannerMain