import React from 'react'
import styled from 'styled-components';
import logo from '../../Assets/Images/Temp/logo.png'
import { Input, Badge, Menu, Dropdown, Button } from 'antd';
import { Link, useNavigate } from "react-router-dom";
import hcart from '../../Assets/Images/Temp/icon/cart.png'
import hsearch from '../../Assets/Images/Temp/icon/search.png'
import huser from '../../Assets/Images/Temp/icon/profile.png'
import MobileMenu from '../MenuBar/MobileMenu';
import banner from "../../Assets/Images/furniture/banner.jpg"
import pro from "../../Assets/Images/furniture/pro.png"
import top from "../../Assets/Images/furniture/b11.png"
import three from "../../Assets/Images/furniture/hc2.webp"
import b1 from "../../Assets/Images/furniture/hc1.jpg"
import five from "../../Assets/Images/furniture/5.png"
import fcall from "../../Assets/Images/furniture/f_phone.png"
import fmail from "../../Assets/Images/furniture/f_email.png"
import faddress from "../../Assets/Images/furniture/f_location.png"
import instgram from "../../Assets/Images/furniture/s2.png"
import facebook from "../../Assets/Images/furniture/s1.png"
import { styles } from '../../Api/Data';
const { Search } = Input;




const Furniture = () => {
    const onSearch = (value) => console.log(value);
    return (
        <React.Fragment>
            {/* <React.Fragment>
                <HeaderSection>
                    <div className='header_section'>
                        <div className='wrapper'>
                            <div className='header_top_align'>
                                <div className='header_top_left'>
                                    <ul>
                                        <li>
                                            <a href="javascript:void(0)">
                                                <img src={facebook} alt="" />
                                            </a>
                                        </li>
                                        <li>
                                            <a href="javascript:void(0)">
                                                <img src={instgram} alt="" />
                                            </a>
                                        </li>
                                    </ul>
                                    <Search
                                        placeholder="Search products..."
                                        onSearch={onSearch}
                                    />
                                </div>
                                <div className='header_top_center'>
                                    <img src={logo} alt="" />
                                </div>
                                <div className='header_top_right'>
                                    <div className='shop_cart'>
                                        <ul>
                                            <li>
                                                <img src={hsearch} alt="Search Bar" />
                                            </li>
                                            <li>
                                                <Link to="/">
                                                    <img src={huser} alt="User" />
                                                </Link>
                                            </li>
                                            <li>
                                                <Link to="/">
                                                    <Badge count={0} showZero size='small'>
                                                        <img src={hcart} alt="Cart" />
                                                    </Badge>
                                                </Link>
                                            </li>
                                            <li className='mob_view_only'>
                                                <MobileMenu />
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div className='header_bottom_align'>
                                <div className='header_bottom_center'>
                                    <Menu mode="horizontal">
                                        <Menu.Item key="home">
                                            <Link to="/">Home</Link>
                                        </Menu.Item>
                                        <Menu.Item key="about">
                                            <Link to="/about">About Us</Link>
                                        </Menu.Item>
                                        <Menu.Item key="Category">
                                            <Link to="/">Our Products</Link>
                                        </Menu.Item>
                                        <Menu.Item key="enquiry">
                                            <Link to="/">Enquiry</Link>
                                        </Menu.Item>
                                        <Menu.Item key="policy">
                                            <Link to="/">Our Policies</Link>
                                        </Menu.Item>
                                        <Menu.Item key="Contact">
                                            <Link to="/">Contact Us</Link>
                                        </Menu.Item>
                                    </Menu>
                                </div>
                            </div>
                        </div>
                    </div>
                </HeaderSection>
            </React.Fragment> */}
            <React.Fragment>
                <BannerSection>
                    <div className='banner_section'>
                        <div>
                            <img src={banner} alt="" />
                        </div>
                    </div>
                </BannerSection>
            </React.Fragment>
            <Body>
                {/* <React.Fragment>
                    <TopCategory>
                        <div className='top_category_section'>
                            <div className='wrapper'>
                                <H2>Popular Category</H2>
                                <ul>
                                    <li>
                                        <div className='top_box'>
                                            <div className='top_box_img'>
                                                <img src={top} alt="top" />
                                            </div>
                                            <div className='top_content'>
                                                <h4>Accessories</h4>

                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div className='top_box'>
                                            <div className='top_box_img'>
                                                <img src={top} alt="top" />
                                            </div>
                                            <div className='top_content'>
                                                <h4>Accessories</h4>

                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div className='top_box'>
                                            <div className='top_box_img'>
                                                <img src={top} alt="top" />
                                            </div>
                                            <div className='top_content'>
                                                <h4>Accessories</h4>

                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div className='top_box'>
                                            <div className='top_box_img'>
                                                <img src={top} alt="top" />
                                            </div>
                                            <div className='top_content'>
                                                <h4>Accessories</h4>

                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div className='top_box'>
                                            <div className='top_box_img'>
                                                <img src={top} alt="top" />
                                            </div>
                                            <div className='top_content'>
                                                <h4>Accessories</h4>

                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div className='top_box'>
                                            <div className='top_box_img'>
                                                <img src={top} alt="top" />
                                            </div>
                                            <div className='top_content'>
                                                <h4>Accessories</h4>

                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </TopCategory>
                </React.Fragment> */}
                {/* <React.Fragment>
                    <FeatureProduct>
                        <div className='feature_product'>
                            <div className='wrapper'>
                                <H2>Featured Product</H2>
                                <ul>
                                    <li>
                                        <div className='feature_box'>
                                            <div className='feature_img'>
                                                <img src={pro} alt="product" />
                                            </div>
                                            <h4>COMFY CHAIR</h4>
                                            <div className='price'>
                                                <span className='sp'>{styles?.currency}85</span>
                                                <span className='mrp'>{styles?.currency}100</span>
                                            </div>
                                            <button>Add to Cart</button>
                                        </div>
                                    </li>
                                    <li>
                                        <div className='feature_box'>
                                            <div className='feature_img'>
                                                <img src={pro} alt="product" />
                                            </div>
                                            <h4>COMFY CHAIR</h4>
                                            <div className='price'>
                                                <span className='sp'>{styles?.currency}85</span>
                                                <span className='mrp'>{styles?.currency}100</span>
                                            </div>
                                            <button>Add to Cart</button>
                                        </div>
                                    </li>
                                    <li>
                                        <div className='feature_box'>
                                            <div className='feature_img'>
                                                <img src={pro} alt="product" />
                                            </div>
                                            <h4>COMFY CHAIR</h4>
                                            <div className='price'>
                                                <span className='sp'>{styles?.currency}85</span>
                                                <span className='mrp'>{styles?.currency}100</span>
                                            </div>
                                            <button>Add to Cart</button>
                                        </div>
                                    </li>
                                    <li>
                                        <div className='feature_box'>
                                            <div className='feature_img'>
                                                <img src={pro} alt="product" />
                                            </div>
                                            <h4>COMFY CHAIR</h4>
                                            <div className='price'>
                                                <span className='sp'>{styles?.currency}85</span>
                                                <span className='mrp'>{styles?.currency}100</span>
                                            </div>
                                            <button>Add to Cart</button>
                                        </div>
                                    </li>
                                    <li>
                                        <div className='feature_box'>
                                            <div className='feature_img'>
                                                <img src={pro} alt="product" />
                                            </div>
                                            <h4>COMFY CHAIR</h4>
                                            <div className='price'>
                                                <span className='sp'>{styles?.currency}85</span>
                                                <span className='mrp'>{styles?.currency}100</span>
                                            </div>
                                            <button>Add to Cart</button>
                                        </div>
                                    </li>
                                    <li>
                                        <div className='feature_box'>
                                            <div className='feature_img'>
                                                <img src={pro} alt="product" />
                                            </div>
                                            <h4>COMFY CHAIR</h4>
                                            <div className='price'>
                                                <span className='sp'>{styles?.currency}85</span>
                                                <span className='mrp'>{styles?.currency}100</span>
                                            </div>
                                            <button>Add to Cart</button>
                                        </div>
                                    </li>
                                    <li>
                                        <div className='feature_box'>
                                            <div className='feature_img'>
                                                <img src={pro} alt="product" />
                                            </div>
                                            <h4>COMFY CHAIR</h4>
                                            <div className='price'>
                                                <span className='sp'>{styles?.currency}85</span>
                                                <span className='mrp'>{styles?.currency}100</span>
                                            </div>
                                            <button>Add to Cart</button>
                                        </div>
                                    </li>
                                    <li>
                                        <div className='feature_box'>
                                            <div className='feature_img'>
                                                <img src={pro} alt="product" />
                                            </div>
                                            <h4>COMFY CHAIR</h4>
                                            <div className='price'>
                                                <span className='sp'>{styles?.currency}85</span>
                                                <span className='mrp'>{styles?.currency}100</span>
                                            </div>
                                            <button>Add to Cart</button>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </FeatureProduct>
                </React.Fragment> */}

                {/* <React.Fragment>
                    <Hc1Section>
                        <div className='hc1_section'>
                            <div className='wrapper'>
                                <H2>BEST SELLING</H2>
                                <ul>
                                    <li>
                                        <div className='hc1_box'>
                                            <div className='left'>
                                                <img src={b1} alt="Product" />
                                                <Link to="/">
                                                    <Button>Shop Now</Button>
                                                </Link>
                                            </div>
                                            <div className='right'>
                                                <h4>New Products</h4>
                                                <h5>Get 30% Off</h5>

                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div className='hc1_box'>
                                            <div className='left'>
                                                <img src={b1} alt="Product" />
                                                <Link to="/">
                                                    <Button>Shop Now</Button>
                                                </Link>
                                            </div>
                                            <div className='right'>
                                                <h4>Best Selling</h4>
                                                <h5>Collection of stands</h5>

                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </Hc1Section>
                </React.Fragment> */}

                <React.Fragment>
                    <Hc2Section>
                        <div className='hc2_section'>
                            <div className='wrapper'>
                                <H2>ACCESSORIES</H2>
                                <div className='hc2_align'>
                                    <div className='hc2_left'>
                                        <ul>
                                            <li>
                                                <div className='hc2_box'>
                                                    <img src={three} alt="Hc2 Section" />
                                                    <div className='hc2_content'>
                                                        <h4>INTERIOR LAMP</h4>
                                                        <button>Shop Now</button>
                                                    </div>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                    <div className='hc2_right'>
                                        <ul>

                                            <li>
                                                <div className='hc2_box'>
                                                    <img src={three} alt="Hc2 Section" />
                                                    <div className='hc2_content'>
                                                        <h4>INTERIOR LAMP</h4>
                                                        <button>Shop Now</button>
                                                    </div>
                                                </div>
                                            </li>
                                            <li>
                                                <div className='hc2_box'>
                                                    <img src={three} alt="Hc2 Section" />
                                                    <div className='hc2_content'>
                                                        <h4>INTERIOR LAMP</h4>
                                                        <button>Shop Now</button>
                                                    </div>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </Hc2Section>
                </React.Fragment>
                <React.Fragment>
                    <Hc3Section>
                        <div className='h3_section'>
                            <div className='wrapper'>
                                <H2>FEATURES ELEMENTS</H2>
                                <div className='hc3_align'>
                                    <div className='hc3_1'>
                                        <ul>
                                            <li>
                                                <div className='hc3_box'>
                                                    <img src={five} alt="" />
                                                    <div className='hc3_content'>
                                                        <h4>WOOD LAMP</h4>
                                                        <button>Shop Now</button>
                                                    </div>
                                                </div>


                                            </li>
                                            <li>
                                                <div className='hc3_box'>
                                                    <img src={five} alt="" />
                                                    <div className='hc3_content'>
                                                        <h4>WOOD LAMP</h4>
                                                        <button>Shop Now</button>
                                                    </div>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                    <div className='hc3_2'>
                                        <ul>
                                            <li>
                                                <div className='hc3_box'>
                                                    <img src={five} alt="" />
                                                    <div className='hc3_content'>
                                                        <h4>WOOD LAMP</h4>
                                                        <button>Shop Now</button>
                                                    </div>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                    <div className='hc3_3'>
                                        <ul>
                                            <li>
                                                <div className='hc3_box'>
                                                    <img src={five} alt="" />
                                                    <div className='hc3_content'>
                                                        <h4>WOOD LAMP</h4>
                                                        <button>Shop Now</button>
                                                    </div>
                                                </div>
                                            </li>
                                            <li>
                                                <div className='hc3_box'>
                                                    <img src={five} alt="" />
                                                    <div className='hc3_content'>
                                                        <h4>WOOD LAMP</h4>
                                                        <button>Shop Now</button>
                                                    </div>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </Hc3Section>
                </React.Fragment>
                <React.Fragment>
                    <ParallaxSection>
                        <div className='parallax_section' style={{ background: `url(${three})` }}>
                            <h2>Vitra Chair Classic Design</h2>
                        </div>
                    </ParallaxSection>
                </React.Fragment>

            </Body>
            <React.Fragment>
                <FooterSection>
                    <div className='footer_section'>
                        <div className='wrapper'>
                            <H2>Get in Touch</H2>
                            <div className='contact_box_section'>
                                <ul className='c_box'>
                                    <li>
                                        <span>
                                            <img src={fcall} alt="Call" />
                                        </span>
                                        <p>+91 98765 43210</p>
                                    </li>
                                    <li>
                                        <span>
                                            <img src={fmail} alt="Mail" />
                                        </span>
                                        <p>contact@ecdigi.com</p>
                                    </li>
                                    <li>
                                        <span>
                                            <img src={faddress} alt="Address" />
                                        </span>
                                        <p>Flat No.3, 3rd Floor, Srivari Kikani Centre , R.S. Puram,R.S. Puram, Coimbatore-641002, TAMILNADU</p>
                                    </li>
                                </ul>
                                <div className='logo_row'>
                                    <img src={logo} alt="logo" />
                                </div>
                                <div className='social_media'>
                                    <ul>
                                        <li>
                                            <a href="javascript:void(0)">
                                                <img src={facebook} alt="" />
                                            </a>
                                        </li>
                                        <li>
                                            <a href="javascript:void(0)">
                                                <img src={instgram} alt="" />
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                                <div className='quicklinks_row'>
                                    <ul>
                                        <li>Privacy Policy</li>
                                        <li>Terms and Conditions</li>
                                        <li>Refund Policy</li>
                                        <li>Delivery Policy</li>
                                        <li>Return Policy</li>
                                        <li>Cancellation Policy</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div className='copy_text'>
                            <div className='wrapper'>
                                <div className='copy_align'>
                                    <div className='copy_left'>
                                        <p>All Rights Reserved. ecDigi Technologies</p>
                                    </div>
                                    <div className='copy_right'>
                                        <p>© 2022 Designed by <a href="https://ecdigi.com/" target="_blank" title='ecDigi Technologies'>ecDigi Technologies.</a></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </FooterSection>
            </React.Fragment>
        </React.Fragment>
    )
}

export default Furniture;


const Body = styled.div`
    display: grid;
    padding: 40px 0;
    width:100%;
    gap: 80px;
    background: ${styles?.themebg};
    float: left;
`

const H2 = styled.h2`
   font-size:30px;
   margin : 0 0 35px;
   text-transform: uppercase;
   font-family: ${styles?.r_regular} !important;
   letter-spacing: 0.7px;

   @media screen and (max-width:768px) {
    text-align: center;
   }

`

// const HeaderSection = styled.section`
//     display: inline-block;
//     width: 100%;
//     position: relative;
// .header_section {
//     display: inline-block;
//     width: 100%;
//     position: relative;
//     background: ${styles?.themebg};
//     padding: 20px 0 10px 0;
// }
// .header_top_align {
//     display: flex;
//     align-items: center;
//     justify-content: space-between;
//     width: 100%;
//     gap: 20px;
//     position: relative;
//     height: 55px;
// }
// .header_top_align .header_top_left {
//     display: inline-block;
//     position: relative;
//     width: fit-content;

//     ul {
//         display: flex;
//         align-items: center;
//         gap: 17px;
//         flex-wrap: wrap;
//         padding: 0;
//         margin: 0;
//     }
//     ul img {
//         height: 32px;
//     }

// }
// .header_top_align .header_top_center {
//     width:fit-content;
//     display: flex;
//     position: absolute;
//     top:50%;
//     left:50%;
//     transform: translate(-50%,-50%);
//     align-items: center;

//     img {
//         position: relative;
//         height: 55px;
//     }

// }
// .header_top_align .header_top_right {
//     width:fit-content;
//     display: inline-block;

//     ul {
//         display: flex;
//         margin: 0;
//         padding: 0;
//         align-items: center;
//         gap: 17px;
//         flex-wrap: wrap;
//     }
//     img {
//         height: 25px;
//     }
//     a {
//         display: flex;
//     }


// }
// .mob_view_only {
//     display: none;
// }

// .header_bottom_align {
//     display: flex;
//     flex-wrap: wrap;
//     align-items: center;
//     justify-content: center;
//     width: 100%;
//     margin: 20px 0 0 0;
// }

// .header_bottom_center {
//     width: 100%;
//     display: flex;
//     flex-wrap: wrap;
//     align-items: center;
//     justify-content: center;
//     ul {
//         width: 100%;
//     display: flex;
//     align-items: center;
//     justify-content: center;
//     }
// }



// @media screen and (max-width:1200px) {

//     .header_section {
//         padding: 15px 0;
//     }
//     .header_bottom_align {
//         display: none;
//     }
//     .mob_view_only {
//         display: block;

//         button {
//             display: flex;
//             align-items: center;
//             background:transparent;
//         }


//     }
// }


// @media screen and (max-width:580px) {
    
//     .header_top_align {
//         height: auto;
//     }
//     .header_top_align .header_top_left {
//         display: none;
//     }
//     .header_top_align .header_top_center {
//         position: relative;
//         top:0;
//         left:0;
//         transform: inherit;

//         img {
//             height: 40px;
//         }
        
//     }
//     .header_top_align .header_top_right img {
//     height: 20px;
// }
// .mob_view_only button {
//     border: 0;
//     padding: 0;
// }









// }











// `

const BannerSection = styled.section`
    width: 100%;
    float: left;
    display: inline-block;
    position: relative;
    padding: 0 0 40px;
    background: ${styles?.themebg};
    img {
        width: 100%;
    }

`


// const TopCategory = styled.section`
//     width: 100%;
//     display: inline-block;
//     position: relative;

//     .top_category_section {
//         display: inline-block;
//         width: 100%;
//         position: relative;
//     }
//     .top_category_section ul {
//         list-style: none;
//         padding: 0;
//         margin: 0;
//         display: grid;
//         grid-template-columns: repeat(6,1fr);
//         gap: 25px;
//     }
//     .top_category_section ul li {
//         width: 100%;
//         display: inline-block;
//         position: relative;
//     }
//     .top_category_section ul li .top_box {
//         display: inline-block;
//         position: relative;
//         width: 100%;
//     }
//     .top_category_section ul li .top_box .top_box_img {
//         height: 140px;
//     width: 140px;
//     padding: 35px;
//     background: #fff;
//     display: flex;
//     align-items: center;
//     justify-content: center;
//     margin: auto;
//     border-radius: 0 60px 60px 60px;
//     box-shadow: 0 0 15px rgb(0 0 0 / 5%);
//     /* border: 1px solid #bfbbbb; */
//     /* border-style: dashed; */
// }






//     .top_category_section ul li .top_box .top_content {
//         width: 100%;
//         padding: 20px 15px 0px 20px;
//         text-align: center;
        
//     }

//     .top_category_section ul li .top_box .top_content h4 {
//         font-size: 15px;
//         font-family: ${styles?.r_regular} !important;
//         text-transform: uppercase;
//         color: ${styles?.color};
//         font-weight: 600;
//         letter-spacing: 1px;
//         margin: 0 0 5px;
//     }
   

//     @media screen and (max-width:1200px) {
//         .top_category_section ul li .top_box .top_box_img {
//             height: 125px;
//             width: 125px;
//             padding: 33px;
//         }

// }

// @media screen and (max-width:992px) {
//     .top_category_section ul {
//         grid-template-columns: repeat(3,1fr);
//     }
// }

// @media screen and (max-width:580px) {
//     .top_category_section ul {
//     grid-template-columns: repeat(2,1fr);
//     gap: 30px 15px;
// }
// }







// `;


// const FeatureProduct = styled.section`
//     width: 100%;
//     display: inline-block;
//     position: relative;

//     .feature_product {
//         display: inline-block;
//         width: 100%;
//         position: relative;
//     }
//     .feature_product ul {
//         list-style: none;
//         width: 100%;
//         display: grid;
//         grid-template-columns: repeat(4,1fr);
//         gap: 40px 25px;
//         padding: 0;
//         margin: 0;
//     }
//     .feature_product ul li {
//         width: 100%;
//     display: inline-block;
//     background: #fff;
//     padding: 25px 20px;
//     border-radius: 15px;
//     box-shadow: 0 0 15px rgb(0 0 0 / 5%);
// }
//     .feature_product ul li .feature_box {
//         width: 100%;
//         display: inline-block;
//     }
//     .feature_product ul li .feature_box .feature_img {
//         width: 100%;
//         display: inline-block;
//         margin: 0 0 25px;
//     }
//     .feature_product ul li .feature_box .feature_img img {
//         width: 100%;
//     }
//     .feature_product ul li .feature_box h4 {
//         font-size: 20px;
//     font-family: r_regular !important;
//     text-transform: uppercase;
//     color: #000;
//     font-weight: 500;
//     -webkit-letter-spacing: 1px;
//     -moz-letter-spacing: 1px;
//     -ms-letter-spacing: 1px;
//     letter-spacing: 1px;
//     margin: 0 0 7px;
//     text-align: center;
//     }
//     .feature_product ul li .feature_box .price {
//         display: flex;
//         flex-wrap: wrap;
//         width: fit-content;
//         margin: auto;
//         gap: 4px;
//     }
//     .feature_product ul li .feature_box .price span.sp {
//         font-size: 18px;
//         font-family: r_regular !important;
//         color: #000;
//     font-weight: 600;
//     }
//     .feature_product ul li .feature_box .price span.mrp {

//     }
//     .feature_product ul li .feature_box button {
//         width: 100%;
//         margin: 15px 0 0 0;
//         border: 0;
//         border-radius: 8px;
//         padding: 7px 15px;
//         text-align: center;
//         background: linear-gradient(14.29deg, #efbc48 7.56%, #ffd064 87.33%);
//         color: #206942;
//         font-family: ${styles?.r_regular} !important;
//     }

//     @media screen and (max-width:992px) {
//         .feature_product ul {
//             grid-template-columns: repeat(3,1fr);
//         }
//     }

//     @media screen and (max-width:768px) {
//         .feature_product ul {
//             grid-template-columns: repeat(2,1fr);
//         }
//     }

//     @media screen and (max-width:580px) {
//         .feature_product ul li {
//     padding: 20px 15px;

//         }
//         .feature_product ul {
//     grid-template-columns: repeat(2,1fr);
//     gap: 30px 15px;
// }









//     }




// `

// const Hc1Section = styled.section`
//     * {
//         font-family: ${styles?.r_regular};
//     }
//     width:100%;
//     display: inline-block;
//     position: relative;
//     .hc1_section {
//         display: inline-block;
//         width: 100%;
//         position: relative;
//     }

//     .hc1_section ul {
//         display: grid;
//         padding: 0;
//         grid-template-columns: repeat(2,1fr);
//         gap: 45px;
//     }
//     .hc1_section ul li {
//         background: transparent;
//     padding: 0 45px 45px 45px;
//     width: 100%;
//     border-radius: 0px;
//     display: grid;
//     align-items: center;
//     position: relative;
//     }
//     .hc1_section ul li::before {
//         content: "";
//         position: absolute;
//         border: 1px solid #bfbbbb;
//         /* border-style: dashed; */
//     }
//     .hc1_section ul li .hc1_box {
//         display: flex;
//         align-items: flex-end;
//         justify-content: space-between;
//         flex-wrap: wrap;
//     }
//     .hc1_section ul li .hc1_box .left {
//         width: 47%;
//         display: inline-block;
//         position: relative;
//         z-index: 10;
//         img {
//             border-radius: 10px;
//         }
//         button {
//             width: fit-content;
//         margin: 30px auto 0 auto;
//         border: 0;
//         border-radius: 8px;
//         padding: 7px 15px;
//         display: flex;
//         text-align: center;
//         background: linear-gradient(14.29deg, #efbc48 7.56%, #ffd064 87.33%);
//         color: #206942;
//         font-family: ${styles?.r_regular} !important;
//         }
//     }
//     .hc1_section ul li .hc1_box .right {
//         width: 47%;
//         display: flex;
//         gap: 15px;
//         text-align: center;
//         flex-direction: column;
//         padding: 50px 0;
//     }
//     .hc1_section ul li .hc1_box .right::before {
//         content: "";
//     position: absolute;
//     border: 1px solid #c7c7c7;
//     /* border-style: dashed; */
//     height: 55%;
//     width: 100%;
//     right: 0;
//     bottom: 0;
//     z-index: 1;
//     border-radius: 10px;
// }
//     .hc1_section ul li .hc1_box .right h4 {
//         font-size: 30px;
//         text-transform: uppercase;
//         margin: 0 !important;
//         font-family: ${styles?.r_bold} !important;
//     }
//     .hc1_section ul li .hc1_box .right h5 {
//         margin: 0 !important;
//         font-size: 18px;
//         font-family: ${styles?.r_regular};
//     }
//     .hc1_section ul li .hc1_box .right button {
//         padding: 0 !important;
//     background: transparent;
//     border: 0;
//     padding: 0;
//     margin: auto;
//     font-size: 13px;
//     font-style: italic;
//     -webkit-text-decoration: underline;
//     text-decoration: underline;
//     font-weight: 600;
//     font-family: r_regular !important;
//     -webkit-letter-spacing: 0.7px;
//     -moz-letter-spacing: 0.7px;
//     -ms-letter-spacing: 0.7px;
//     letter-spacing: 0.7px;
//     display: flex;
//     }

//     @media screen and (max-width:1200px) {
//         .hc1_section ul li {
//             padding: 35px;
//         }
//         .hc1_section ul li .hc1_box .right::before {
//             height: 65%;
//         }
//     }


//     @media screen and (max-width:992px) {
//         .hc1_section ul {
//             grid-template-columns: repeat(1,1fr);
//         }
//         .hc1_section ul li {
//             padding: 25px;
//         }
//         .hc1_section ul li:nth-child(even) .hc1_box {
//             flex-direction: row-reverse;
//         }
//         .hc1_section ul li .hc1_box .right::before {
//     height: 100%;
// }
// .hc1_section ul li .hc1_box {
//     align-items: center;
// }
// .hc1_section ul li .hc1_box .left button {
//     display: none;
// }


//     }


//     @media screen and (max-width:768px) {
//         .hc1_section ul li {
//         border: 0;
//         background: #fff;
//         border-radius: 15px;
//     box-shadow: 0 0 15px rgb(0 0 0 / 5%);
//     }
//     .hc1_section ul li .hc1_box .right::before {
//         content: inherit;
//     }









//     }


//     @media screen and (max-width:480px) {
//          .hc1_section ul li .hc1_box .right h4 {
//     font-size: 25px;
//         }
//         .hc1_section ul li {
//             padding: 25px 15px;
//         }


//     }





// `

const Hc2Section = styled.section`
    display: inline-block;
    width: 100%;
    position: relative;

    .hc2_section {
        display: inline-block;
        width: 100%;
        position: relative;
    }

    .hc2_align {
        display: flex;
        align-items: stretch;
        width: 100%;
        gap: 30px;
    }
    .hc2_align .hc2_left {
        flex: 2;
        
    }
    .hc2_align .hc2_right {
        flex: 1;
        
    }

.hc2_section .hc2_align ul {
        list-style: none;
        padding: 0;
        margin: 0;
        display: grid;
        grid-template-columns: repeat(1,1fr);
        gap: 30px;
        height: 100%;
        width: 100%;
    }
    .hc2_section .hc2_align ul li {
        width: 100%;
        display: flex;
        position: relative;
        height: 100%;
        border-radius: 12px;
        overflow: hidden;
        box-shadow: 0 0 15px rgb(0 0 0 / 5%);
    }
    .hc2_section .hc2_align ul li::before {
        content: "";
    position: absolute;
    background: rgb(0 0 0 / 35%);
    height: 100%;
    width: 100%;
    top: 0;
    left: 0;
    z-index: 1;
    border-radius: 12px;
}
    .hc2_section .hc2_align ul li .hc2_box {
        display: inline-block;
        width: 100%;
        position: relative;
   
    }
    .hc2_section .hc2_align ul li .hc2_box img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }
    .hc2_section .hc2_align ul li .hc2_box .hc2_content {
        display: flex;
        flex-direction: column;
        gap: 8px;
        position: absolute;
        bottom: 0;
        left: 0;
        width: 100%;
        padding: 20px;
        text-align: left;
       
    z-index:10;
    }
    .hc2_section .hc2_align ul li .hc2_box .hc2_content h4 {
        font-size: 30px;
    font-family: ${styles?.r_bold} !important;
    text-transform: uppercase;
    color: #fff !important;
    font-weight: 600;
    -webkit-letter-spacing: 1px;
    -moz-letter-spacing: 1px;
    -ms-letter-spacing: 1px;
    letter-spacing: 1px;
    margin: 0 0 5px;
    width: 100%;
    }
    .hc2_section .hc2_align ul li .hc2_box .hc2_content button {
    width: fit-content;
    margin: 0px 0 0 0;
    border: 0;
    border-radius: 8px;
    padding: 6px 15px;
   display: flex;
    text-align: center;
    background: linear-gradient(14.29deg,#efbc48 7.56%,#ffd064 87.33%);
    color: #206942;
    font-family: r_regular !important;
}


@media screen and (max-width:768px) {
    .hc2_align {
        flex-direction: column;
    }
     .hc2_section .hc2_align ul li .hc2_box .hc2_content h4 {
    font-size: 26px;
    }
    .hc2_section .hc2_align ul li .hc2_box .hc2_content { 
        margin: auto;
    text-align: center;
    width: 100%;
    align-items: center;
    justify-content: center;
    }
    .hc2_section .hc2_align ul li .hc2_box .hc2_content { 
        margin: auto;
    }
 
}












`

const Hc3Section = styled.section`
   display:inline-block;
   width:100%;
   position: relative;

   .h3_section {
    display: inline-block;
    width: 100%;
    position: relative;
   }
   .h3_section .hc3_align {
    display: flex;
    align-items: stretch;
    width: 100%;
    gap: 25px;
   }
   .h3_section .hc3_align ul {
    list-style: none;
    padding: 0;
    margin: 0;
   }
   .h3_section .hc3_align .hc3_1, .h3_section .hc3_align .hc3_3 {
    flex:1;
   }
   .h3_section .hc3_align .hc3_2 {
    flex: 2;
   }
   .h3_section .hc3_align .hc3_1 ul, .h3_section .hc3_align .hc3_3 ul {
    display: grid;
    grid-template-columns: repeat(1,1fr);
    gap: 25px;
   }
   .h3_section .hc3_align .hc3_1 ul .hc3_box, .h3_section .hc3_align .hc3_3 ul li .hc3_box, .h3_section .hc3_align .hc3_2 ul .hc3_box {
    background: #fff;
    border-radius: 10px;
    overflow: hidden;
    box-shadow: 0 0 15px rgb(0 0 0 / 5%);
   }
   .h3_section .hc3_align .hc3_2 ul, .h3_section .hc3_align .hc3_2 ul li, .h3_section .hc3_align .hc3_2 ul li .hc3_box,.h3_section .hc3_align .hc3_2 ul li .hc3_box img  {
    height: 100%;
   }
   .h3_section .hc3_align .hc3_2 ul li .hc3_box img {
    object-fit: cover;
   }
   .h3_section .hc3_align img {
    padding: 0 0 40px;
   }
   .h3_section ul li {
    position: relative;
   }
   .h3_section ul li .hc3_box .hc3_content {
        display: flex;
        flex-direction: column;
        gap: 5px;
        position: absolute;
        bottom: 0;
        left: 0;
        width: 100%;
        padding: 20px;
        text-align: left;
    }
    .h3_section ul li .hc3_box .hc3_content h4 {
        font-size: 23px;
    font-family: r_regular !important;
    text-transform: uppercase;
    color: #000;
    font-weight: 600;
    -webkit-letter-spacing: 1px;
    -moz-letter-spacing: 1px;
    -ms-letter-spacing: 1px;
    letter-spacing: 1px;
    margin: 0 0 5px;
    width: 100%;
    }
    .h3_section ul li .hc3_box .hc3_content button {
        width: fit-content;
    margin: 0px 0 0 0;
    border: 0;
    border-radius: 8px;
    padding: 6px 15px;
   display: flex;
    text-align: center;
    background: linear-gradient(14.29deg,#efbc48 7.56%,#ffd064 87.33%);
    color: #206942;
    font-family: r_regular !important;
    }


    @media screen and (max-width:768px) {
        .h3_section .hc3_align {
            flex-direction: column;
        }

        .h3_section ul li .hc3_box .hc3_content {
            text-align: center;
        }

        .h3_section ul li .hc3_box .hc3_content button { 
            margin: auto;
        }












    }











`


const ParallaxSection = styled.section`
    width: 100%;
    display: inline-block;
    height: 85vh;
    overflow: hidden;
    position: relative;
    &::before {
        content: "";
    position: absolute;
    background: linear-gradient(to right, #fff 50%, transparent 50%);
    height: 100%;
    left: 0;
    top: 0;
    z-index: 10;
    width: 100%;
}
    .parallax_section {
        width:100%;
        display: flex;
        flex-direction: column;
        position: relative;
        height: 100%;
        position: absolute;
        top: 0;
    left: 0;
    background-repeat: no-repeat !important;
    background-attachment: fixed !important;
    background-position: right!important;
    background-size: 50% 100% !important;
}
    .parallax_section h2 {
        width: 50%;
        position: absolute;
        top: 50%;
        left: 0;
        transform: translate(0,-50%);
        padding: 50px 100px;
        z-index: 20;
        text-align: center;
        font-size: 55px;
    }


    @media screen and (max-width:1200px) {
        .parallax_section h2 {
            font-size: 45px;
            padding: 35px;
        }
        .parallax_section {
            background-size: cover !important;
        }
    }


    @media screen and (max-width:768px) {
    &::before {
    content: "";
    position: absolute;
    background: rgb(255 255 255 / 50%);
        }

        .parallax_section h2 {
    font-size: 35px;
    padding: 35px;
    width: 100%;
}



    }


   

`
const FooterSection = styled.section`
    display: inline-block;
    width: 100%;
    position: relative;
    padding: 40px 0 0 0;
    background: ${styles?.themebg};

    .footer_section {
        width: 100%;
        display: inline-block;
        position: relative;
    }
    .footer_section h2 {
        text-align: center;
    }

    .footer_section ul.c_box {
        list-style: none;
        padding: 0;
        margin: 0;
        display: grid;
        grid-template-columns: repeat(3,1fr);
        gap: 30px;
    }
    .footer_section ul.c_box li {
        background: #fff;
    padding: 25px 24px;
    border-radius: 10px;
    box-shadow: 0 0 12px rgb(0 0 0 / 5%);
    display: flex;
    align-items: center;
    flex-direction: column;
    gap: 20px;
    text-align: center;
    p {
        margin: 0;
    }
    }
    .footer_section ul.c_box li span {
   display: flex;
    align-items: center;
    justify-content: center;
    height: 65px;
    width: 65px;
    border-radius: 100%;
    border: 1px solid #000;
    padding: 17px;
}

.logo_row {
    width: 100%;
    display: inline-block;
    margin: 100px 0 0 0;

    img {
        height: 75px;
        margin: auto;
    }
}
.social_media {
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 20px 0 0 0;
}
.social_media ul {
    margin: 0;
    padding: 0;
    display: flex;
    gap: 18px;
    flex-wrap: wrap;
}
.social_media ul img {
    height: 35px;
}
.quicklinks_row {
    display: flex;
    align-items: center;
    justify-content: center;
    flex-wrap: wrap;
    margin: 25px 0 0 0;
}
.quicklinks_row ul {
    display: flex;
    align-items: center;
    gap: 20px 15px;
    margin: 0;
    padding: 0;
    justify-content: center;
    flex-wrap: wrap;
}
a {
    color: #000;
}

.copy_text {
        width: 100%;
        display: inline-block;
        padding: 10px 0;
        border-top: 1px solid #c7c7c7;
        margin: 50px 0 0 0;
        p {
            line-height: 1.5;
            color: ${styles?.color};
            margin: 0;
        }
    }
    .copy_text .copy_align {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 20px;
    }

    .copy_text .copy_align p {
        font-size: 14px;
    }


@media screen and (max-width: 768px) {
    .footer_section ul.c_box {
        grid-template-columns: repeat(1,1fr);
    }
    .copy_text .copy_align {
        flex-direction: column;
    gap: 10px;
    text-align: center;
    }
}



`