import React,{useState,useEffect} from 'react'
import API from '../../Api/ApiService';
import About1 from "../../Components/Pages/About/About1"
import About2 from "../../Components/Pages/About/About2"
import About3 from "../../Components/Pages/About/About3"
import About4 from "../../Components/Pages/About/About4"
import {
    Skeleton,
  } from "antd";


const AboutMain = () => {
    const [theme, setTheme] = useState("")
    const [loading, setLoading] = useState(false);
    const api = new API();
  
    useEffect(() => {
      setLoading(true)
      api.themes().then((res) => {
        setLoading(false)
        setTheme(res.data.aboutustype)
      }).catch((err) => { setLoading(false) })
    }, [])
   
  return (
    <React.Fragment>
        {
        loading === true ?
          <Skeleton />
          :
          <>
            {theme === "AB1" ? <About1 page="about" /> : ""}
            {theme === "AB2" ? <About2 page="about" /> : ""}
            {theme === "AB3" ? <About3 page="about" /> : ""}
            {theme === "AB4" ? <About4 page="about" /> : ""}
          </>
      }
    </React.Fragment>
  )
}

export default AboutMain