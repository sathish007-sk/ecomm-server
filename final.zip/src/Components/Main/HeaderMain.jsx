import React, { useState, useEffect } from 'react'
import API from '../../Api/ApiService';
import Header from '../Header/Header'
import Header1 from "../Header/Header1"
import Header2 from '../Header/Header2';
import Header3 from '../Header/Header3';
import Header4 from '../Header/Header4';
import Header5 from '../Header/Header5';
import Header6 from '../Header/Header6';
import Premium1HE1 from '../Header/Premium1HE1';
import Premium2HE2 from '../Header/Premium2HE2';
import AgriHeader from '../Header/AgriHeader';
import DryHeader from '../Header/DryHeader';




import {
  Skeleton,
} from "antd";
import GiftHeader from '../Header/GiftHeader';
import FHeader from '../Header/FHeader';

const HeaderMain = () => {
  const [theme, setTheme] = useState("")
  const [loading, setLoading] = useState(false);
  const api = new API();

  useEffect(() => {
    setLoading(true)
    api.themes().then((res) => {
      setTheme(res.data.headertype)
      setLoading(false)
    }).catch((err) => { setLoading(false) })
  }, [])


  return (
    <React.Fragment>
      {
        loading === true ?
          <Skeleton />
          :
          <>
            {theme === "HE1" ? <FHeader /> : ""}
            {theme === "HE2" ? <DryHeader /> : ""}
            {theme === "HE3" ? <Header3 /> : ""}
            {theme === "HE4" ? <Header4 /> : ""}
            {theme === "HE5" ? <AgriHeader /> : ""}
            {theme === "HE6" ? <GiftHeader /> : ""}
            {theme === "PRE-HE1" ? <Premium1HE1 /> : ""}
            {theme === "PRE-HE2" ? <Premium2HE2 /> : ""}
          </>
      }

    </React.Fragment>
  )
}

export default HeaderMain