import React from 'react'
import styled from 'styled-components'
import { styles } from '../../Api/Data'

const EShop = () => {
  return (
    <React.Fragment>
      {/*Header*/}
      <React.Fragment>
        <HeaderSection>
          <div className='header_section'>
            <div className='header_top'>
              <div className='wrapper'>
                <div className='header_top_align'>
                  <p>100% Secure delivery without contacting the courier</p>
                </div>
              </div>
            </div>
          </div>
        </HeaderSection>
      </React.Fragment>






    </React.Fragment>
  )
}

export default EShop;

const Body = styled.div`
  background: rgb(28 95 168 / 3%);
  display: grid;
  grid-template-columns: repeat(1,1fr);
  gap: 65px 0;
`




const HeaderSection = styled.section`
  display: flex;
  width: 100%;
  position: relative;
  
  .header_section {
    display: inline-block;
    width: 100%;
    position: relative;
  }
  .header_top {
    width: 100%;
    display: inline-block;
    position: relative;
    background: ${styles?.themeblue};
    padding: 5px 0;
  }
  .header_top_align {
    width: 100%;
    display: inline-block;
  } 
  p {
    text-align: center;
    margin: 0;
    line-height: 1.5;
    color: #fff;
    font-size: 15px;
    font-family: ${styles?.a_light};
    letter-spacing: 0.4px;
  }









`