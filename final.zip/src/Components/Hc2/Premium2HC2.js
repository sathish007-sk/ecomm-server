import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import API from "../../Api/ApiService";
import Default from '../../Assets/Images/default.png'
import styled, { ThemeProvider } from "styled-components";

export default function Premium2HC2(props) {
  const api = new API();
  const [data, setData] = useState([]);

  useEffect(() => {
    if (props.data) setData(props.data);
  }, [props]);

  const size = {
    desktop: "1920px",
    laptop: "1440px",
    minilaptop: "1200px",
    tabletl: "992px",
    tablet: "768px",
    mobilel: "580px",
    mobilep: "480px",
    mobiles: "380px",
  };

  const device = {
    desktop: `@media screen and (max-width: ${size.desktop})`,
    laptop: `@media screen and (max-width: ${size.laptop})`,
    minilaptop: `@media screen and (max-width: ${size.minilaptop})`,
    tabletl: `@media screen and (max-width: ${size.tabletl})`,
    tablet: `@media screen and (max-width: ${size.tablet})`,
    mobilel: `@media screen and (max-width: ${size.mobilel})`,
    mobilep: `@media screen and (max-width: ${size.mobilep})`,
    mobiles: `@media screen and (max-width: ${size.mobiles})`,
  };

  const theme = {
    id: 1,
    background: "#fff",
    color: "#dfad54",
    background: "#0d0d0d",
    border: "#dfad54",
    gray: "#8d8d8d",
    bg70: "rgb(255 255 255 / 70%)",
    bglight: "#f5f5f5",
    titlesize: [
      {
        screen: "desktop",
        value: 30,
      },
      {
        screen: "tablet",
        value: 20,
      },
      {
        screen: "mobile",
        value: 20,
      },
    ],
    colcount: [
      {
        screen: "desktop",
        value: 3,
      },
      {
        screen: "tablet",
        value: 2,
      },
      {
        screen: "mobile",
        value: 1,
      },
    ],
    gap: [
      {
        screen: "desktop",
        value: 25,
      },
      {
        screen: "tablet",
        value: 20,
      },
      {
        screen: "mobile",
        value: 15,
      },
    ],
  };

  const Section = styled.section`
    width: 100%;
    display: inline-block;
    position: relative;
    h2 {
      color: ${(props) =>
        props.theme.id && props.theme.color
          ? props.theme.color
          : "#000"} !important;
      text-align: center;
      margin: 0 0 45px;
      position: relative;
      padding: 0 0 18px;
      &:before {
        content: "";
        height: 4px;
        width: 75px;
        position: absolute;
        bottom: 0;
        left: 50%;
        transform: translate(-50%, 0px);
        border-radius: 3px;
        background: ${(props) =>
          props.theme.id && props.theme.color ? props.theme.color : "#000"};
      }
    }
  `;
  const Wrapperfull = styled.div`
    max-width: 100%;
    padding: 0 20px;
  `;
  const Permium2HC2Align = styled.div`
    display: grid;
    ${device.desktop} {
      grid-template-columns: repeat(
        ${(props) =>
          props.theme.id && props.theme.colcount[0].screen == "desktop"
            ? props.theme.colcount[0].value
            : 3},
        1fr
      );
      gap: ${(props) =>
        props.theme.id && props.theme.gap.desktop
          ? props.theme.gap.desktop
          : 25}px;
    }
    ${device.tabletl} {
      grid-template-columns: repeat(
        ${(props) =>
          props.theme.id && props.theme.colcount[1].screen == "tablet"
            ? props.theme.colcount[1].value
            : 2},
        1fr
      );
      gap: ${(props) =>
        props.theme.id && props.theme.gap.tablet
          ? props.theme.gap.tablet
          : 15}px;
    }
    ${device.tablet} {
      grid-template-columns: repeat(
        ${(props) =>
          props.theme.id && props.theme.colcount[2].screen == "mobile"
            ? props.theme.colcount[2].value
            : 1},
        1fr
      );
      gap: ${(props) =>
        props.theme.id && props.theme.gap.mobile
          ? props.theme.gap.mobile
          : 15}px;
    }
  `;
  const Premium1HC2Box = styled.div`
    min-height: 420px;
    position: relative;
    width: 100%;
    display: flex;
    align-items: flex-end;
    justify-content: center;
    flex-direction: column;
    gap: 45px 0;
    border: 0px solid
      ${(props) =>
        props.theme.id && props.theme.border ? props.theme.border : "#000"};
  `;

  const Permium2HC2Img = styled.div`
    display: inline-block;
    width: 100%;
    position: relative;
    border: 1px solid
      ${(props) =>
        props.theme.id && props.theme.color ? props.theme.color : "#000"};
    border-radius: 200px 10px 200px 200px;
    overflow: hidden;
    &:hover img {
      transform: scale(1.2);
      transition: all 0.5s ease-in-out;
    }
  `;

  const Permium2HC2Bg = styled.img`
    position: relative;
    width: 100%;
    transition: all 0.5s ease-in-out;
    max-height: 420px;
    object-fit: contain;

    ${device.mobilel} {
      max-height: 350px;
    }
  `;
  const Permium2HC2Content = styled.div`
    width: 100%;
    z-index: 10;
    padding: 0px 25px;
    display: flex;
    align-items: flex-start;
    flex-direction: column;
    gap: 18px;
    text-align: center;
  `;
  const Premium1HC2Title = styled.h4`
    margin: 0 !important;
    color: ${(props) =>
      props.theme.id && props.theme.color
        ? props.theme.color
        : "000"} !important;
    font-weight: 600;
    margin: 0;
    width: 100%;
    text-align: center;

    ${device.desktop} {
      font-size: ${(props) =>
        props.theme.id && props.theme.titlesize[0].screen == "desktop"
          ? props.theme.titlesize[0].value
          : 27}px !important;
    }
    ${device.tabletl} {
      font-size: ${(props) =>
        props.theme.id && props.theme.titlesize[1].screen == "tablet"
          ? props.theme.titlesize[1].value
          : 20}px !important;
    }
    ${device.mobilel} {
      font-size: ${(props) =>
        props.theme.id && props.theme.titlesize[2].screen == "mobile"
          ? props.theme.titlesize[2].value
          : 20}px !important;
    }
  `;
  const Permium2HC2Description = styled.div`
    p {
      margin: 0 !important;
      color: ${(props) =>
        props.theme.id && props.theme.gray ? props.theme.gray : "#888"};
    }
  `;
  const Premium1HC2Button = styled.button`
    position: relative;
    display: inline-block;
    padding: 0 0 0px 0px;
    width: fit-content;
    border: 1px solid
      ${(props) =>
        props.theme.id && props.theme.color ? props.theme.color : "#000"};
    background: transparent;
    outline: none;
    margin: auto;
    background: transparent;
    border-radius: 24px 5px 24px 24px;
    color: ${(props) =>
      props.theme.id && props.theme.background
        ? props.theme.background
        : "#000"};
    a {
      padding: 9px 20px;
      border: 0;

      border-radius: 3px;
      color: ${(props) =>
        props.theme.id && props.theme.color ? props.theme.color : "#000"};
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      font-size: 13px !important;
      display: inline-block;
      position: relative;
      z-index: 11;
    }
  `;
  const Permium2HC2SubTitle = styled.h5`
    position: absolute;
    top: 15px;
    right: 15px;
    margin: 0 !important;
    background: ${(props) =>
      props.theme.id && props.theme.color ? props.theme.color : "#000"};
    border-radius: 3px;
    color: ${(props) =>
      props.theme.id && props.theme.background
        ? props.theme.background
        : "#000"};
    font-size: 13px;
    padding: 5px 11px;
    text-transform: uppercase;
    font-style: italic;
  `;

  return (
    <ThemeProvider theme={theme}>
      <Section className="Premium2_HC2" id={theme.id}>
        <Wrapperfull>
          {data.title && <h2 className="Head_Text_Temp1">{data.title}</h2>}
          <Permium2HC2Align>
            {data?.content?.map((e, i) => {
              return (
                <Premium1HC2Box key={`premiumhc2_1_${i}`}>
                  <Permium2HC2Img>
                    <Permium2HC2Bg
                      src={`${e.image ? api.rootUrl + e.image : Default}`} alt={e.sub_title}
                    ></Permium2HC2Bg>
                  </Permium2HC2Img>
                  <Permium2HC2Content>
                    <Permium2HC2SubTitle>{e.sub_title}</Permium2HC2SubTitle>
                    <Premium1HC2Title>{e.title}</Premium1HC2Title>
                    <Permium2HC2Description>
                      {e.description && (
                        <p
                          dangerouslySetInnerHTML={{ __html: e.description }}
                        ></p>
                      )}
                    </Permium2HC2Description>
                    <Premium1HC2Button>
                      {e.link_text && <Link to={e.link.toLowerCase().replace(/ /g, '-')
                      .replace(/[^\w-]+/g, '')}>{e.link_text}</Link>}
                    </Premium1HC2Button>
                  </Permium2HC2Content>
                </Premium1HC2Box>
              );
            })}
          </Permium2HC2Align>
        </Wrapperfull>
      </Section>
    </ThemeProvider>
  );
}
