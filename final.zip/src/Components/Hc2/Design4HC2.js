import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import API from "../../Api/ApiService";
import Default from '../../Assets/Images/default.png'
import styled from "styled-components";
import { styles } from "../../Api/Data";
const user = JSON.parse(localStorage.getItem("persist:root"))?.company;
const colorCustom = user && JSON.parse(user).setColor;

export default function DesignFourHC2(props) {
  const api = new API();
  const [data, setData] = useState([]);

  useEffect(() => {
    if (props.data) setData(props.data);
  }, [props]);

  return (
    <React.Fragment>
      <Hc2>
      <section className="Template4_HC_2">
        <div className="Wrapper_Full">
          {data.title && <H2>{data.title}</H2>}
          <div className="Template4_HC_2_Align">
            {data?.content?.map((e, i) => {
              return (
                <div className="Template4_HC_2_Items" key={`hc2_1_${i}`}>
                  <div className="Template4_HC_2_Box">
                    <div
                  className="Template4_HC_2_Zoom">
                    <img src={e.image ? api.rootUrl + e.image : Default} alt={e.sub_title} />
                  </div>
                    <div className="Template4_HC_2_Content">
                      <i>{e.sub_title}</i>
                      <h4 className="Template4_HC_Title">{e.title}</h4>
                      {e.description && (
                        <p
                          dangerouslySetInnerHTML={{ __html: e.description }}
                        ></p>
                      )}
                      {e.link_text && (
                        <div className="Template4_HC_Action">
                          <Link to={e.link.toLowerCase().replace(/ /g, '-')
                      .replace(/[^\w-]+/g, '')}>
                            <button className="Template4_HC_Button">
                              {e.link_text}
                            </button>
                          </Link>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>
      </Hc2>
    </React.Fragment>
  );
}

const H2 = styled.h1`
  font-size: ${styles?.h2};
  font-family: ${styles?.font} !important;
  color: ${colorCustom?.color ? colorCustom?.color : styles?.color} !important;
  line-height: 1.4;
  margin: 0 0 25px;

  @media screen and (max-width: 768px) {
    text-align: center;
  }
`;

const Hc2 = styled.div`
  
.Template4_HC_2 {
  display: inline-block;
  width: 100%;
  position: relative;
}

.Template4_HC_2 .Template4_HC_2_Align {
  display: grid;
  grid-template-columns: repeat(3,1fr);
  gap: 20px;
}
.Template4_HC_2 .Template4_HC_2_Align .Template4_HC_2_Items {
  display: inline-block;
  width: 100%;
  position: relative;
  padding: 0px;
  background: ${styles?.white} !important;
}
.Template4_HC_2 .Template4_HC_2_Align .Template4_HC_2_Items .Template4_HC_2_Box {
  display: flex;
  flex-wrap: wrap;
  min-height: 400px;
  padding: 40px 30px;
  position: relative;
  align-items: center;
  justify-content: center;
  background: ${styles?.white} !important;
}
.Template4_HC_2 .Template4_HC_2_Align .Template4_HC_2_Items .Template4_HC_2_Box::before {
  content: '';
  position: absolute;
  background: ${styles?.bg60} !important;
  top:0;
  left:0;
  bottom: 0;
  right:0;
  height: 100%;
  width: 100%;
  z-index: 7;
}
.Template4_HC_2 .Template4_HC_2_Align .Template4_HC_2_Items .Template4_HC_2_Box .Template4_HC_2_Zoom {
  display: flex;
  position: absolute;
  top: 0%;
  left: 0;
  right: 0;
  bottom: 0;
  height: 100%;
  width: 100%;
  z-index: 5;
  background-position: center center;
  background-size: cover;
  align-items: center;
  justify-content: center;
  overflow: hidden;
}
.Template4_HC_2 .Template4_HC_2_Align .Template4_HC_2_Items .Template4_HC_2_Box .Template4_HC_2_Content {
  position: relative;
  z-index: 10;
  width: 100%;
  color: ${styles?.white} !important;
}

.Template4_HC_2 .Template4_HC_2_Align .Template4_HC_2_Items:nth-child(1) .Template4_HC_2_Box .Template4_HC_2_Content {
  text-align: end;
  padding: 0 0 0 50px;
}
.Template4_HC_2 .Template4_HC_2_Align .Template4_HC_2_Items:nth-child(2) .Template4_HC_2_Box .Template4_HC_2_Content {
  text-align: center;
  padding: 0 25px;
}
.Template4_HC_2 .Template4_HC_2_Align .Template4_HC_2_Items:nth-child(3) .Template4_HC_2_Box .Template4_HC_2_Content {
  text-align: left;
  padding: 0 50px 0 0;
}
.Template4_HC_2 .Template4_HC_2_Align .Template4_HC_2_Items .Template4_HC_2_Box .Template4_HC_2_Content i {
  font-size: 15px;
  letter-spacing: 0.5;
}
.Template4_HC_2 .Template4_HC_2_Align .Template4_HC_2_Items .Template4_HC_2_Box .Template4_HC_2_Content h4.Template4_HC_Title {
  font-size: 35px;
  font-weight: 700;
  color: ${styles?.white} !important;
}
.Template4_HC_2 .Template4_HC_2_Align .Template4_HC_2_Items .Template4_HC_2_Box .Template4_HC_2_Content p {
  line-height: 27px;
    font-size: 15px;
}

.Template4_HC_2 .Template4_HC_2_Align .Template4_HC_2_Items .Template4_HC_2_Box .Template4_HC_2_Content .Template4_HC_Action button.Template4_HC_Button {
  padding: 0 0 4px;
  background: transparent;
  border: 0;
  text-transform: uppercase;
  font-weight: 700;
  letter-spacing: 2px;
  border-bottom: 2px solid ${styles?.white} !important;
  color: ${styles?.white} !important;
  margin: 0 0 0 0;
}



@media screen and (max-width:992px) {
  .Template4_HC_2 .Template4_HC_2_Align {
  grid-template-columns: repeat(1,1fr);
}
.Template4_HC_2 .Template4_HC_2_Align .Template4_HC_2_Items:nth-child(1) .Template4_HC_2_Box .Template4_HC_2_Content,.Template4_HC_2 .Template4_HC_2_Align .Template4_HC_2_Items:nth-child(3) .Template4_HC_2_Box .Template4_HC_2_Content {
  padding: 0%;
  text-align: center;
}

}


@media screen and (max-width:480px) {
  .Template4_HC_2 .Template4_HC_2_Align .Template4_HC_2_Items .Template4_HC_2_Box .Template4_HC_2_Content h4.Template4_HC_Title {
  font-size: 30px;
}

}










`;