import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import { Button } from "react-bootstrap";
import API from "../../Api/ApiService";
import Default from "../../Assets/Images/default.png";
import styled from "styled-components";
import { styles } from "../../Api/Data";
const user = JSON.parse(localStorage.getItem("persist:root"))?.company;
const colorCustom = user && JSON.parse(user).setColor;

export default function Design2HC2(props) {
  const api = new API();
  const [data, setData] = useState([]);

  useEffect(() => {
    if (props.data) setData(props.data);
  }, [props]);

  return (
    <React.Fragment>
      <Hc2>
        <section className="Temp2_HC2">
          <div className="Wrapper">
            {data.title && <H2>{data.title}</H2>}
            <div className="Temp2_HC2_Align">
              {data?.content?.map((e, i) => {
                return (
                  <div className="Temp2_HC2_Box">
                    <div className="Temp2_HC2_Box_Grid">
                      <div className="Temp2_HC2_Head">
                        <p>{e.title}</p>
                      </div>
                      <img
                        src={e.image ? api.rootUrl + e.image : Default}
                        alt={e.title}
                      />
                      <Link
                        to={e.link
                          .toLowerCase()
                          .replace(/ /g, "-")
                          .replace(/[^\w-]+/g, "")}
                      >
                        <Button> {e.link_text}</Button>
                      </Link>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </section>
      </Hc2>
    </React.Fragment>
  );
}

const H2 = styled.h2`
  font-size: ${styles?.h2};
  font-family: ${styles?.font} !important;
  color: ${colorCustom?.color ? colorCustom?.color : styles?.color} !important;
  line-height: 1.4;
  margin: 0 0 25px;
  text-align: center;

  @media screen and (max-width: 768px) {
    text-align: center;
  }
`;


const Hc2 = styled.div`


.Temp2_HC2 {
  width: 100%;
  display: inline-block;
  position: relative;
}
.Temp2_HC2 .Temp2_HC2_Align {
  display: grid;
  grid-template-columns: repeat(3,1fr);
  gap: 40px 30px;
  width: 100%;
  position: relative;
}
.Temp2_HC2 .Temp2_HC2_Align .Temp2_HC2_Box {
  display: inline-block;
  width: 100%;
  position: relative;
  padding: 25px;
  border: 1px solid ${styles?.light};
}
.Temp2_HC2 .Temp2_HC2_Align .Temp2_HC2_Box .Temp2_HC2_Box_Grid {
  display: flex;
  flex-direction: column;
  gap: 20px;
  width: 100%;
}
.Temp2_HC2 .Temp2_HC2_Align .Temp2_HC2_Box .Temp2_HC2_Box_Grid .Temp2_HC2_Head {
  width: 100%;
  display: inline-block;
  position: relative;
}
.Temp2_HC2 .Temp2_HC2_Align .Temp2_HC2_Box .Temp2_HC2_Box_Grid .Temp2_HC2_Head p {
  text-align: center;
  font-size: ${styles?.h5};
  font-family: ${styles?.medium};
  color: ${styles?.color};
}
.Temp2_HC2 .Temp2_HC2_Align .Temp2_HC2_Box .Temp2_HC2_Box_Grid img {
  height: 230px;
  width: 100%;
  object-fit: contain;
}
.Temp2_HC2 .Temp2_HC2_Align .Temp2_HC2_Box .Temp2_HC2_Box_Grid button {
  position: absolute;
  left: 50%;
  transform: translate(-50%,0);
  bottom: -10px;
  background: ${styles?.color};
  border: 1px solid ${styles?.color};
  opacity: 0;
  transition: all 0.4s ease-in-out;
}
.Temp2_HC2 .Temp2_HC2_Align .Temp2_HC2_Box:hover .Temp2_HC2_Box_Grid button {
  bottom: 20px;
  opacity: 1;
  transition: all 0.4s ease-in-out;
}


@media screen and (max-width:768px) {


.Temp2_HC2 .Temp2_HC2_Align {
  grid-template-columns: repeat(1,1fr);
}
  
}




`;