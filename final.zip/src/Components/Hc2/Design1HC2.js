import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import styled from "styled-components";
import API from "../../Api/ApiService";
import { styles } from "../../Api/Data";
import Default from '../../Assets/Images/default.png'
const user = JSON.parse(localStorage.getItem("persist:root"))?.company;
const colorCustom = user && JSON.parse(user).setColor;
export default function Design1HC2(props) {
  const api = new API();
  const [data, setData] = useState([]);

  useEffect(() => {
    if (props.data) setData(props.data);
  }, [props]);

  return (
    <React.Fragment>
      <Hc2>

      
    <section className="Temp1_HC2">
      <div className="Wrapper_Full">
        {data.title && <H2>{data.title}</H2>}
        <div className="Temp1_HC2_Align">
          {data?.content?.map((e, i) => {
            return (
              <div key={`hc2_1_${i}`} className="Temp1_HC2_Box">
                <div
                  className="Temp1_HC2_Box_Bg">
                    <img src={e.image ? api.rootUrl + e.image : Default} alt={e.sub_title} />
                  </div>
                <div className="Temp1_HC2_Box_Content">
                  {/* <p>{e.sub_title}</p> */}
                  <h3>{e.title ? e.title:<br></br>}</h3>
                  {e.link_text && (
                    <div className="Temp1_HC2_Box_Btn">
                      <Link to={e.link.toLowerCase().replace(/ /g, '-')
                      .replace(/[^\w-]+/g, '')}>
                        <button>
                          <span>{e.link_text}</span>
                        </button>
                      </Link>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
    </Hc2>
    </React.Fragment>
  );
}
const H2 = styled.h2`
  font-size: ${styles?.h2};
  font-family: ${styles?.font} !important;
  color: ${colorCustom?.color ? colorCustom?.color : styles?.color} !important;
  line-height: 1.4;
  margin: 0 0 25px;

  @media screen and (max-width: 768px) {
    text-align: center;
  }
`;

const Hc2 = styled.div`

.Temp1_HC2 {
  width: 100%;
  display: inline-block;
  position: relative;
}

.Temp1_HC2 .Temp1_HC2_Align {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 40px 25px;
  position: relative;
  width: 100%;
}
.Temp1_HC2 .Temp1_HC2_Align .Temp1_HC2_Box {
  min-height: 350px;
  display: flex;
  width: 100%;
  position: relative;
  padding: 30px;
  align-items: center;
  justify-content: center;
  overflow: hidden;
}
.Temp1_HC2 .Temp1_HC2_Align .Temp1_HC2_Box::before {
  content: "";
  position: absolute;
  top: 0;
  left: 0;
  height: 100%;
  width: 100%;
  z-index: 7;
  background: ${styles.bg60};
}
.Temp1_HC2 .Temp1_HC2_Align .Temp1_HC2_Box .Temp1_HC2_Box_Bg {
  width: 100%;
  position: absolute;
  height: 100%;
  width: 100%;
  top: 0;
  left: 0;
  z-index: 5;
  background-repeat: no-repeat !important;
  background-position: center center;
  background-size: cover;
  transition: all 0.7s ease-in-out;
  display: flex;
  align-items: center;
  justify-content: center;
}
.Temp1_HC2 .Temp1_HC2_Align .Temp1_HC2_Box:hover .Temp1_HC2_Box_Bg {
  transition: all 0.7s ease-in-out;
  transform: scale(1.2);
}
.Temp1_HC2 .Temp1_HC2_Align .Temp1_HC2_Box .Temp1_HC2_Box_Content {
  position: relative;
  z-index: 10;
  width: 100%;
  display: flex;
  flex-direction: column;
  gap: 15px;
}
.Temp1_HC2 .Temp1_HC2_Align .Temp1_HC2_Box .Temp1_HC2_Box_Content p {
  font-size: 14px;
  color: ${styles?.white};
  margin: 0;
}
.Temp1_HC2 .Temp1_HC2_Align .Temp1_HC2_Box .Temp1_HC2_Box_Content h3 {
  font-size: ${styles?.h2};
  color: ${styles?.white} !important;
  font-family: ${styles?.bold} !important;
  margin: 0;
}
.Temp1_HC2
  .Temp1_HC2_Align
  .Temp1_HC2_Box
  .Temp1_HC2_Box_Content
  .Temp1_HC2_Box_Btn {
  display: inline-block;
  width: 100%;
}
.Temp1_HC2
  .Temp1_HC2_Align
  .Temp1_HC2_Box
  .Temp1_HC2_Box_Content
  .Temp1_HC2_Box_Btn
  button {
  padding: 6px 16px;
  outline: none;
  position: relative;
  border: 1px solid #fff;
  color: #fff;
  background: transparent;
  cursor: pointer;
  font-family: ${styles?.regular};
  font-size: 16px;
  margin: 0px 0 0 0;
}


@media screen and (max-width:768px) {
  .Temp1_HC2 .Temp1_HC2_Align, .Temp1_HC3 .Temp1_HC3_Bottom_Align_Box {
        grid-template-columns: repeat(1,1fr);
        text-align: center;
    }
}




`