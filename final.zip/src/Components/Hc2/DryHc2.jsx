import React, { useEffect, useState } from 'react'
import hc2 from "../../Assets/Images/dry/hc2.png"
import hmain from "../../Assets/Images/dry/hmain.png"
import styled from 'styled-components';
import { styles } from '../../Api/Data';
import { Link } from "react-router-dom";
import API from "../../Api/ApiService";
import Default from '../../Assets/Images/default.png'



const DryHc2 = (props) => {

  const api = new API();
  const [data, setData] = useState([]);

  useEffect(() => {
    if (props.data) setData(props.data);
  }, [props]);
  return (
    <React.Fragment>
      <Hc2Section>
        <div className='hc2_section'>
          <div className='wrapper'>
            {data.title && <H2>{data.title}</H2>}
            <ul>
              {
                data?.content?.slice(0, 3).map((e) => {
                  return (
                    <li key={e._id}>
                      <div className='hc2_box'>
                        <div className='hc2_top'>
                          <img src={e.image ? api.rootUrl + e.image : Default} alt="hc2" />
                        </div>
                        <div className='hc2_bottom'>
                          <h4>{e.title}</h4>
                          <h5> {e.description && (
                          <p
                            dangerouslySetInnerHTML={{ __html: e.description }}
                          ></p>
                        )}</h5>
                        <Link to={e.link.toLowerCase().replace(/ /g, '-')
                      .replace(/[^\w-]+/g, '')}>
                          <button>Shop Now</button>
                          </Link>
                        </div>
                      </div>
                    </li>
                  )
                })
              }
            </ul>
          </div>
        </div>
      </Hc2Section>
    </React.Fragment>
  )
}

export default DryHc2


const H2 = styled.h2`
   font-size:32px;
   margin : 0 0 50px;
   font-family: ${styles?.q_bold} !important;
   text-align: center;
   padding: 55px 0 0 0;
   &::before {
    content: "";
    position: absolute;
    background: url(${hmain});
    background-repeat: no-repeat;
    height: 46px;
    width: 46px;
    background-size: contain;
    top: 0;
    left: 50%;
    transform: translate(-50%, 0px);
   }

   @media screen and (max-width:768px) {
    text-align: center;
   }

`

const Hc2Section = styled.section`

width: 100%;
display: inline-block;
position: relative;

.hc2_section {
    display: inline-block;
    position: relative;
    width: 100%;
}
ul {
    padding: 0;
    margin: 0;
    display: grid;
    grid-template-columns: repeat(3,1fr);
    gap: 40px 30px;
}

ul li {
    width: 100%;
    display: inline-block;
    position: relative;
}

ul li .hc2_box {
    width: 100%;
    position: relative;
    text-align: center;
}
ul li .hc2_box .hc2_top {
    display: inline-block;
    position: relative;
    padding: 0 20px;
}
ul li .hc2_box .hc2_top img {
  width: 320px;
    border-radius: 100%;
    position: relative;
    z-index: 10;
    height: 320px;
    object-fit: cover;
}
.hc2_bottom {
    width: 100%;
    display: flex;
    flex-direction: column;
    gap: 15px;
    padding: 60px 24px 30px 24px;
    border: 1px solid #ebebeb;
    border-radius: 5px;
    margin: -50px 0 0 0;
    position: relative;
}
.hc2_bottom h4 {
    font-size: 22px;
    margin: 0 !important;
    font-family: ${styles?.q_bold};
}
.hc2_bottom h5 {
    font-size: 15px;
    font-family: ${styles?.q_regular} !important;
    color: ${styles?.gray} !important;
    line-height: 1.6;
}
.hc2_bottom button {
width: fit-content;
    background: ${styles?.themegreen};
    color: #fff;
    padding: 5px 20px;
    border-radius: 15px 1px 15px 1px;
    margin: 0;
    border: 0;
    position: absolute;
    bottom: -15px;
    left: 50%;
    transform: translate(-50%, 0px);
}


@media screen and (max-width:768px) {
    ul {
        grid-template-columns: repeat(1,1fr);
        gap: 65px;
    }
}

@media screen and (max-width:480px) {
    .hc2_bottom h4 {
        font-size: 18px;
    }
    ul li .hc2_box .hc2_top img {
      height: 240px;
      width: 240px;
    }
}






`