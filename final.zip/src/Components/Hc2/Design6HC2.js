import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Row, Col } from "react-bootstrap";
import API from "../../Api/ApiService";
import Default from "../../Assets/Images/default.png";
import styled from "styled-components";
import { styles } from "../../Api/Data";
const user = JSON.parse(localStorage.getItem("persist:root"))?.company;
const colorCustom = user && JSON.parse(user).setColor;
export default function Design6HC2(props) {
  const api = new API();
  const [data, setData] = useState([]);

  useEffect(() => {
    if (props.data) setData(props.data);
  }, [props]);

  return (
    <React.Fragment>
      <Hc2>
        <section className="Temp6_HC2">
          <div className="Wrapper_Full">
            {data.title && <h2 className="Head_Text_Temp6">{data.title}</h2>}
            <div className="Temp6_HC2_Align">
              <Row>
                {data?.content?.map((e, i) => {
                  return (
                    <Col
                      lg="4"
                      md="12"
                      sm="12"
                      className="Temp6_HC2_Align_Col"
                      key={`hc2_1_${i}`}
                    >
                      <div className="Temp6_HC2_Box">
                        <div className="Temp6_HC2_Image">
                          <div className="Temp6_HC2_Box_Bg">
                            <img
                              src={e.image ? api.rootUrl + e.image : Default}
                              alt={e.sub_title}
                            />
                          </div>
                        </div>
                        <div className="Temp6_HC2_Box_Content">
                          <p>{e.sub_title ? e.sub_title : <br></br>}</p>
                          <h3>{e.title ? e.title : <br></br>}</h3>
                          {e.description ? (
                            <p
                              dangerouslySetInnerHTML={{
                                __html: e.description,
                              }}
                            ></p>
                          ) : (
                            <br></br>
                          )}
                          {e.link_text && (
                            <div className="Temp6_HC2_Box_Btn">
                              <Link
                                to={e.link
                                  .toLowerCase()
                                  .replace(/ /g, "-")
                                  .replace(/[^\w-]+/g, "")}
                              >
                                <button>
                                  <span>{e.link_text}</span>
                                </button>
                              </Link>
                            </div>
                          )}
                        </div>
                      </div>
                    </Col>
                  );
                })}
              </Row>
            </div>
          </div>
        </section>
      </Hc2>
    </React.Fragment>
  );
}


const Hc2 = styled.div`
.Temp6_HC2 {
  width: 100%;
  display: inline-block;
  position: relative;
}
h2.Head_Text_Temp6 {
  font-size: 24px;
  font-family: ${styles?.bold} !important;
  color: ${styles?.colorapi} !important;
  line-height: 1.4;
  margin: 0 0 25px;
  text-transform: uppercase;
}

.Temp6_HC2_Align {
  display: flex;
  justify-content: center;
  column-gap: 25px;
}
.Temp6_HC2_Align .row{
  width:100%;
}

.Temp6_HC2 .Temp6_HC2_Align .Temp6_HC2_Box {
  border: 1px solid ${styles?.light};
  border-radius: 5px;
}

.Temp6_HC2_Box_Bg {
  position: relative;
  width: 100%;
  display: inline-block;
}

.Temp6_HC2 .Temp6_HC2_Align .Temp6_HC2_Box .Temp6_HC2_Box_Bg {
  width: 100%;
  position: relative;
  height: 250px;
  width: 100%;
  top: 0;
  left: 0;
  z-index: 5;
  background-repeat: no-repeat !important;
  background-position: center center;
  background-size: cover;
  transition: all 0.7s ease-in-out;
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
}
.Temp6_HC2 .Temp6_HC2_Align .Temp6_HC2_Box .Temp6_HC2_Box_Content {
  padding: 25px;
  text-align: center;
}
.Temp6_HC2 .Temp6_HC2_Align .Temp6_HC2_Box .Temp6_HC2_Box_Content p {
  font-size: 14px;
  color: ${styles?.color};
  margin: 0;
}
.Temp6_HC2 .Temp6_HC2_Align .Temp6_HC2_Box .Temp6_HC2_Box_Content h3 {
  font-size: 24px;
  color:${styles?.color} !important;
  font-family: ${styles?.bold} !important;
  margin: 0;
}
.Temp6_HC2 .Temp6_HC2_Align .Temp6_HC2_Box .Temp6_HC2_Box_Content p {
  font-size: 14px;
  color: ${styles?.color};
  margin: 0;
}

.Temp6_HC2 .Temp6_HC2_Align .Temp6_HC2_Box_Content .Temp6_HC2_Box_Btn button {
  padding: 7px 18px;
  outline: none;
  position: relative;
  border: 1px solid ${styles?.color};
  color: ${styles?.color};
  background: transparent;
  cursor: pointer;
  font-family: ${styles?.regular};
  font-size: 16px;
  margin: 10px 0 0 0;
}


@media screen and (max-width: 768px) {
 .Temp6_HC2 .Temp6_HC2_Align .Temp6_HC2_Box {
   padding: 25px;
 }
}

@media screen and (max-width: 380px) {
  .Temp6_HC2_Align {
    grid-template-columns: repeat(1, 1fr);
  }
}






`;