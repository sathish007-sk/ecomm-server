import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import DefaultImg from "../../Assets/Images/default.png";
import styled, { ThemeProvider } from "styled-components";
import API from "../../Api/ApiService";
import Default from '../../Assets/Images/default.png'

export default function Premium1HC2(props) {
  const api = new API();
  const [data, setData] = useState([]);

  useEffect(() => {
    if (props.data) setData(props.data);
  }, [props]);

  const size = {
    desktop: "1920px",
    laptop: "1440px",
    minilaptop: "1200px",
    tabletl: "992px",
    tablet: "768px",
    mobilel: "580px",
    mobilep: "480px",
    mobiles: "380px",
  };

  const device = {
    desktop: `@media screen and (max-width: ${size.desktop})`,
    laptop: `@media screen and (max-width: ${size.laptop})`,
    minilaptop: `@media screen and (max-width: ${size.minilaptop})`,
    tabletl: `@media screen and (max-width: ${size.tabletl})`,
    tablet: `@media screen and (max-width: ${size.tablet})`,
    mobilel: `@media screen and (max-width: ${size.mobilel})`,
    mobilep: `@media screen and (max-width: ${size.mobilep})`,
    mobiles: `@media screen and (max-width: ${size.mobiles})`,
  };

  const theme = {
    id: 2,
    color: "#000",
    background: "#000",
    border: "#ee8f0a",
    bg70: "rgb(255 255 255 / 70%)",
    bglight: "#f5f5f5",
    titlesize: [
      {
        screen: "desktop",
        value: 20,
      },
      {
        screen: "tablet",
        value: 20,
      },
      {
        screen: "mobile",
        value: 20,
      },
    ],
    colcount: [
      {
        screen: "desktop",
        value: 3,
      },
      {
        screen: "tablet",
        value: 2,
      },
      {
        screen: "mobile",
        value: 1,
      },
    ],
    gap: [
      {
        screen: "desktop",
        value: 20,
      },
      {
        screen: "tablet",
        value: 20,
      },
      {
        screen: "mobile",
        value: 15,
      },
    ],
  };

  console.log(theme.id, theme.color);

  const Section = styled.section`
    width: 100%;
    display: inline-block;
    position: relative;
    h2.Head_Text_Temp1 {
      color: ${(props) =>
        props.theme.id && props.theme.tcolor
          ? props.theme.tcolor
          : "#000"} !important;
      font-size: ${(props) =>
        props.theme.id && props.theme.hfontsize
          ? props.theme.hfontsize
          : 35}px !important;
      font-family: ${(props) =>
        props.theme.id && props.theme.hfont
          ? props.theme.hfont
          : ""} !important;
    }
  `;
  const Wrapperfull = styled.div`
    max-width: 100%;
    padding: 0 20px;
  `;
  const Permium1HC2Align = styled.div`
    display: grid;
    ${device.desktop} {
      grid-template-columns: repeat(
        ${(props) =>
          props.theme.colcount[0].screen == "desktop"
            ? props.theme.colcount[0].value
            : 3},
        1fr
      );
      gap: ${(props) =>
        props.theme.gap[0].screen == "desktop"
          ? props.theme.gap[0].value
          : 25}px;
    }
    ${device.tabletl} {
      grid-template-columns: repeat(
        ${(props) =>
          props.theme.colcount[1].screen == "tablet"
            ? props.theme.colcount[1].value
            : 2},
        1fr
      );
      gap: ${(props) =>
        props.theme.gap[0].screen == "tablet"
          ? props.theme.gap[0].value
          : 15}px;
    }
    ${device.tablet} {
      grid-template-columns: repeat(
        ${(props) =>
          props.theme.colcount[2].screen == "mobile"
            ? props.theme.colcount[2].value
            : 1},
        1fr
      );
      gap: ${(props) =>
        props.theme.gap[0].screen == "mobile"
          ? props.theme.gap[0].value
          : 15}px;
    }
  `;
  const Premium1HC2Box = styled.div`
    min-height: 420px;
    position: relative;
    width: 100%;
    display: flex;
    align-items: flex-end;
    justify-content: center;
    box-shadow: 0 0 12px rgb(0 0 0 / 16%);
    border: 1px solid
      ${(props) =>
        props.theme.id && props.theme.border ? props.theme.border : "#000"};
  `;
  const Permium1HC2Bg = styled.div`
    position: absolute;
    height: 100%;
    width: 100%;
    top: 0;
    left: 0;
    background-position: center center !important;
    background-size: contain !important;
    background-color: #f5f5f5 !important;
    z-index: 5;
    background-repeat: no-repeat !important;
    display: flex;
    align-items: center;
    justify-content: center;
    overflow: hidden;
  `;
  const Permium1HC2Content = styled.div`
    width: 100%;
    z-index: 10;
    padding: 20px 25px;
    background: ${(props) =>
      props.theme.id && props.theme.bg70
        ? props.theme.bg70
        : "rgb(255 255 255 / 70%)"};
    display: flex;
    align-items: flex-start;
    flex-direction: column;
    gap: 10px;
  `;
  const Premium1HC2Title = styled.h4`
    margin: 0 !important;
    color: ${(props) =>
      props.theme.id && props.theme.color
        ? props.theme.color
        : "000"} !important;
    font-weight: 600;
    margin: 0;

    ${device.desktop} {
      font-size: ${(props) =>
        props.theme.titlesize[0].screen == "desktop"
          ? props.theme.titlesize[0].value
          : 27}px !important;
    }
    ${device.tabletl} {
      font-size: ${(props) =>
        props.theme.titlesize[1].screen == "tablet"
          ? props.theme.titlesize[1].value
          : 20}px !important;
    }
    ${device.mobilel} {
      font-size: ${(props) =>
        props.theme.titlesize[2].screen == "mobile"
          ? props.theme.titlesize[2].value
          : 20}px !important;
    }
  `;
  const Permium1HC2Description = styled.div`
    p {
      margin: 0 !important;
      color: ${(props) =>
        props.theme.id && props.theme.gray ? props.theme.gray : "#888"};
    }
  `;
  const Premium1HC2Button = styled.button`
    position: relative;
    display: inline-block;
    padding: 0 0 6px 6px;
    width: fit-content;
    border: 0;
    background: transparent;
    outline: none;
    &:before {
      content: "";
      position: absolute;
      left: 0;
      bottom: 0;
      top: 6px;
      right: 6px;
      border: 1px solid
        ${(props) =>
          props.theme.id && props.theme.background
            ? props.theme.background
            : "#000"};
      border-radius: 3px;
    }
    &:hover {
      padding: 0 0 6px 6px;
    }
    a {
      padding: 9px 20px;
      border: 0;
      background: ${(props) =>
        props.theme.id && props.theme.background
          ? props.theme.background
          : "#000"};
      border-radius: 3px;
      color: #fff;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      font-size: 13px !important;
      display: inline-block;
      position: relative;
      z-index: 11;
    }
  `;
  const Permium1HC2SubTitle = styled.h5`
    position: absolute;
    top: 15px;
    right: 15px;
    margin: 0 !important;
    background: ${(props) =>
      props.theme.id && props.theme.background
        ? props.theme.background
        : "#000"};
    border-radius: 3px;
    color: #fff;
    font-size: 13px;
    padding: 5px 11px;
    text-transform: uppercase;
    font-style: italic;
  `;

  return (
    <ThemeProvider theme={theme}>
      <Section className="Premium1_HC2" id={theme.id}>
        <Wrapperfull>
          {data.title && <h2 className="Head_Text_Temp1">{data.title}</h2>}
          <Permium1HC2Align>
            {data?.content?.map((e, i) => {
              return (
                <Premium1HC2Box key={`premiumhc2_1_${i}`}>
                  {/* <Permium1HC2Bg
                    style={{
                      background: `url("${
                        e.image ? e.image : DefaultImg
                      }")no-repeat`,
                    }}
                  ></Permium1HC2Bg> */}
                  <Permium1HC2Bg>
                  <img src={e.image ? api.rootUrl + e.image : Default } alt={e.sub_title} />
                  </Permium1HC2Bg>
                  <Permium1HC2Content>
                    {e.sub_title ? (
                      <Permium1HC2SubTitle>{e.sub_title}</Permium1HC2SubTitle>
                    ) : (
                      ""
                    )}
                    <Premium1HC2Title>{e.title}</Premium1HC2Title>
                    <Permium1HC2Description>
                      {e.description && (
                        <p
                          dangerouslySetInnerHTML={{ __html: e.description }}
                        ></p>
                      )}
                    </Permium1HC2Description>
                    <Premium1HC2Button>
                      {e.link_text && <Link to={e.link.toLowerCase().replace(/ /g, '-')
                      .replace(/[^\w-]+/g, '')}>{e.link_text}</Link>}
                    </Premium1HC2Button>
                  </Permium1HC2Content>
                </Premium1HC2Box>
              );
            })}
          </Permium1HC2Align>
        </Wrapperfull>
      </Section>
    </ThemeProvider>
  );
}
