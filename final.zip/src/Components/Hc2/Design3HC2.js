import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import styled from "styled-components";
import API from "../../Api/ApiService";
import Default from "../../Assets/Images/default.png";
import { styles } from "../../Api/Data";
const user = JSON.parse(localStorage.getItem("persist:root"))?.company;
const colorCustom = user && JSON.parse(user).setColor;
export default function Design3Hc2(props) {
  const api = new API();
  const [data, setData] = useState([]);

  useEffect(() => {
    if (props.data) setData(props.data);
  }, [props]);

  return (
    <React.Fragment>
      <Hc2>
        <section className="Temp3_HC2">
          {data.title && <H2>{data.title}</H2>}
          <div className="wrapper">
            <div className="Temp3_HC2_Align">
              {data?.content?.map((e, i) => {
                return (
                  <div className="Temp3_HC2_Box" key={`hc2_1_${i}`}>
                    <div className="Temp3_HC2_Box_Align">
                      <div className="Temp3_HC2_Box_Zoom">
                        <img
                          src={e.image ? api.rootUrl + e.image : Default}
                          alt={e.sub_title}
                        />
                      </div>
                      <div className="Temp3_HC2_Box_Content">
                        <i>{e.sub_title}</i>
                        <h4>{e.title}</h4>

                        {e.description && (
                          <p
                            dangerouslySetInnerHTML={{ __html: e.description }}
                          ></p>
                        )}

                        {e.link_text && (
                          <div className="Temp3_HC2_Box_Btn">
                            <Link
                              to={e.link
                                .toLowerCase()
                                .replace(/ /g, "-")
                                .replace(/[^\w-]+/g, "")}
                            >
                              <button>
                                <span>{e.link_text}</span>
                              </button>
                            </Link>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </section>
      </Hc2>
    </React.Fragment>
  );
}
const H2 = styled.h2`
  font-size: ${styles?.h2};
  font-family: ${styles?.font} !important;
  color: ${colorCustom?.color ? colorCustom?.color : styles?.color} !important;
  line-height: 1.4;
  margin: 0 0 25px;
  text-align: center;

  @media screen and (max-width: 768px) {
    text-align: center;
  }
`;
const Hc2 = styled.div`
  .Temp3_HC2 {
    display: inline-block;
    width: 100%;
    position: relative;
  }

  .Temp3_HC2 .Temp3_HC2_Align {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    width: 100%;
    justify-content: center;
    position: relative;
    gap: 20px;
  }
  .Temp3_HC2 .Temp3_HC2_Align .Temp3_HC2_Box {
    width: 100%;
    display: flex;
    transition: all 0.4s ease-in-out;
  }
  .Temp3_HC2 .Temp3_HC2_Align .Temp3_HC2_Box:hover {
    transform: translateY(-10px);
    transition: all 0.4s ease-in-out;
  }
  .Temp3_HC2 .Temp3_HC2_Align .Temp3_HC2_Box .Temp3_HC2_Box_Align {
    width: 100%;
    display: inline-block;
    min-height: 450px;
    overflow: hidden;
    position: relative;
  }
  .Temp3_HC2
    .Temp3_HC2_Align
    .Temp3_HC2_Box
    .Temp3_HC2_Box_Align
    .Temp3_HC2_Box_Zoom {
    position: absolute;
    height: 100%;
    width: 100%;
    top: 0%;
    left: 0;
    z-index: 5;
    animation: h_zoom 30s ease-in-out infinite;
    transition: all 0.5s ease-in-out;
    background-repeat: no-repeat;
    background-position: center center;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .Temp3_HC2
    .Temp3_HC2_Align
    .Temp3_HC2_Box
    .Temp3_HC2_Box_Align
    .Temp3_HC2_Box_Content {
    position: relative;
    z-index: 15;
  }
  .Temp3_HC2 .Temp3_HC2_Align .Temp3_HC2_Box .Temp3_HC2_Box_Align::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: linear-gradient(to bottom,transparent,rgb(0 0 0 / 80%));
    z-index: 10;
  }
  .Temp3_HC2
    .Temp3_HC2_Align
    .Temp3_HC2_Box
    .Temp3_HC2_Box_Align
    .Temp3_HC2_Box_Content {
    position: absolute;
    z-index: 15;
    bottom: 0px;
    left: 0px;
    color: ${styles?.white} !important;
    padding: 20px;
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
  }
  .Temp3_HC2
    .Temp3_HC2_Align
    .Temp3_HC2_Box
    .Temp3_HC2_Box_Align
    .Temp3_HC2_Box_Content
    h4 {
    font-size: ${styles?.h4} !important;
    line-height: 1.5;
    color: ${styles?.white} !important;
    text-transform: uppercase;
    margin: 0 0 0px;
  }
  .Temp3_HC2
    .Temp3_HC2_Align
    .Temp3_HC2_Box
    .Temp3_HC2_Box_Align
    .Temp3_HC2_Box_Content
    p {
    margin: 0;
    width: 100%;
    display: inline-block;
  }

  .Temp3_HC2
    .Temp3_HC2_Align
    .Temp3_HC2_Box
    .Temp3_HC2_Box_Align
    .Temp3_HC2_Box_Content
    i {
    font-size: 14px;
    line-height: 1.5;
    color: ${styles?.white} !important;
    width: 100%;
    display: inline-block;
  }

  .Temp3_HC2
    .Temp3_HC2_Align
    .Temp3_HC2_Box
    .Temp3_HC2_Box_Align
    .Temp3_HC2_Box_Content
    .Temp3_HC2_Box_Btn
    button {
    padding: 7px 20px;
    border: 0;
    color: ${styles?.color} !important;
    font-weight: 600;
    letter-spacing: 0.5px;
    background: ${styles?.white} !important;
    border-radius: 30px;
    margin: 0px 0 0 0;
    font-size: 14px;
    width: 100%;
    display: inline-block;
  }

  @media screen and (max-width:768px) {
    .Temp3_HC2 .Temp3_HC2_Align {
      grid-template-columns: repeat(1,1fr);
    }
    .Temp3_HC2 .Temp3_HC2_Align .Temp3_HC2_Box .Temp3_HC2_Box_Align .Temp3_HC2_Box_Content {
  top:50%;
  bottom: auto;
  left: 0;
  transform: translate(0,-50%);
  text-align: center;
}
.Temp3_HC2 .Temp3_HC2_Align .Temp3_HC2_Box .Temp3_HC2_Box_Align .Temp3_HC2_Box_Content {
  width: 100%;
}
.Temp3_HC2 .Temp3_HC2_Align .Temp3_HC2_Box .Temp3_HC2_Box_Align .Temp3_HC2_Box_Content h4 {
  width: 100%;
}
.Temp3_HC2 .Temp3_HC2_Align .Temp3_HC2_Box .Temp3_HC2_Box_Align .Temp3_HC2_Box_Content .Temp3_HC2_Box_Btn button {
  display: flex;
  margin: auto;
  width: fit-content;
}
.Temp3_HC2 .Temp3_HC2_Align .Temp3_HC2_Box .Temp3_HC2_Box_Align .Temp3_HC2_Box_Content .Temp3_HC2_Box_Btn, .Temp3_HC2 .Temp3_HC2_Align .Temp3_HC2_Box .Temp3_HC2_Box_Align .Temp3_HC2_Box_Content .Temp3_HC2_Box_Btn a {
  width: 100%;
}
.Temp3_HC2 .Temp3_HC2_Align .Temp3_HC2_Box .Temp3_HC2_Box_Align::before {
  background: ${styles?.bg60};
}

.Temp3_HC2 .Temp3_HC2_Align .Temp3_HC2_Box:hover {
  transform: translateY(0px);
  transition: all 0.4s ease-in-out;
}
  }























`;
