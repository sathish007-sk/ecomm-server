import React, { useState, useEffect } from 'react'
import { Link, useNavigate } from "react-router-dom";
import { Menu, Space, Button, Drawer } from "antd";
import {
    UnorderedListOutlined,
    CloseOutlined,
    FileDoneOutlined, HomeOutlined, ShoppingOutlined, MailOutlined, FileProtectOutlined, PhoneOutlined, ShopOutlined, UserOutlined, ShoppingCartOutlined, WalletOutlined, LoginOutlined, LogoutOutlined, BankOutlined
} from "@ant-design/icons";
import { useSelector, useDispatch } from "react-redux"
import API from '../../Api/ApiService';
const MobileMenu = () => {
    const loginTrue = useSelector((state) => state.user.currentUser?.token);
    const [visible, setVisible] = useState(false);
    const [category, setCategory] = useState([]);
    const onSearch = (value) => console.log(value);
    const history = useNavigate();
    const dispatch = useDispatch();
    const api = new API();
    useEffect(() => {
        api.allCategory().then((res) => {
            if (res.status === 200) {
                setCategory(res.data.filter(e =>
                    e.parent == null
                ))
            }
        }).catch((err) => { })
    }, []);




    const catItems = category?.map((item) =>
        getItem(<Link to={item?.category_name.toLowerCase().replace(/ /g, '-')
            .replace(/[^\w-]+/g, '')}>{item?.category_name}</Link>, item?._id)
    )

    const logout = () => {
        api.logout(dispatch);
        history('/')
    };
    const onClose = () => {
        setVisible(false);
    };
    const showDrawer = () => {
        setVisible(true);
    };
    function getItem(label, key, icon, children, type) {
        return {
            key,
            icon,
            children,
            label,
            type,
        };
    }
    const items = [
        getItem((
            <Link to="/">Home</Link>
        ), "1", <HomeOutlined />),
        getItem((<Link to="/about">About Us</Link>
        ), '2', <FileDoneOutlined />),
        getItem('Product Category', 'sub1', <ShoppingOutlined />, catItems),

        getItem('Policies', 'sub2', <FileProtectOutlined />, [
            getItem((
                <Link to="/privacy-policy">Privacy Policy</Link>
            ), 'p1'),
            getItem((
                <Link to="/delivery-policy">Delivery Policy</Link>
            ), 'p2'),
            getItem((
                <Link to="/terms">Terms and Condition</Link>
            ), 'p3'),
            getItem((
                <Link to="/refund-policy">Refund Policy</Link>
            ), 'p4'),
            getItem((
                <Link to="/return-policy">Return Policy</Link>
            ), 'p5'),
            getItem((
                <Link to="/cancellation-policy">Cancellation Policy</Link>
            ), 'p6'),

        ]),
        getItem((
            <Link to="/enquiry">Enquire Form</Link>
        ), '3', <MailOutlined />),
        getItem((
            <Link to="/contact">Contact Us</Link>
        ), '4', <PhoneOutlined />),
        getItem((
            <Link to="/my-profile">My Profile</Link>
        ), '5', <UserOutlined />),
        getItem((
            <Link to="/my-address">My Address</Link>
        ), '6', <ShopOutlined />),
        getItem((
            <Link to="/cart">Cart</Link>
        ), '7', <ShoppingCartOutlined />),
        getItem((
            <Link to="/checkout">Checkout</Link>
        ), '8', <BankOutlined />),
        getItem((
            <Link to="/my-order">My Order</Link>
        ), '9', <WalletOutlined />),
        getItem((!loginTrue && loginTrue !== "" ? <Link to="/login">Login</Link> : <div onClick={logout}>Logout</div>), '10', (!loginTrue && loginTrue !== "" ? <LoginOutlined /> : <LogoutOutlined />)),
    ];

    const rootSubmenuKeys = ['sub1', 'sub2'];

    const [openKeys, setOpenKeys] = useState([]);
    const onOpenChange = (keys) => {
        const latestOpenKey = keys.find((key) => openKeys.indexOf(key) === -1);
        if (rootSubmenuKeys.indexOf(latestOpenKey) === -1) {
            setOpenKeys(keys);
        } else {
            setOpenKeys(latestOpenKey ? [latestOpenKey] : []);
        }
    };

    return (
        <React.Fragment>
            <Button className="barsMenu" type="outline" onClick={showDrawer}>
                <UnorderedListOutlined />
            </Button>
            <Drawer
                placement="right"
                closable={false}
                onClose={onClose}
                open={visible}
                className="agri_temp_menu"
                width={270}
                title="Menu"
                extra={
                    <Space>
                        <Button onClick={onClose} className="menu_btn"
                            style={{
                                display: "flex",
                                alignItems: "center",
                                padding: "0 9px"
                            }}
                        ><CloseOutlined /></Button>
                    </Space>
                }
            >
                <Menu
                    mode="inline"
                    openKeys={openKeys}
                    onOpenChange={onOpenChange}
                    style={{
                        width: "100%",
                    }}
                    items={items}
                    onClick={onClose}
                />




            </Drawer>
        </React.Fragment>
    )
}

export default MobileMenu