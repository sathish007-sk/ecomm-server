import React, {useEffect} from "react";
import styled from "styled-components";
import { Link } from "react-router-dom";
import { connect, useSelector, useDispatch } from "react-redux";
import {
  AlignRightOutlined,
  ShoppingCartOutlined,
  ShoppingOutlined,
  LogoutOutlined,
  CaretDownOutlined,
  ProfileOutlined,
  UserOutlined,
} from "@ant-design/icons";
import { useNavigate } from "react-router-dom";
import { header, styles } from "../../Api/Data";
import {getCartList} from '../../Store/cartTypes'
import { Button, Input, Drawer, Dropdown,Menu } from "antd";
import API from "../../Api/ApiService";
const { Search } = Input;





const Header = (props) => {
  const api = new API();
  const company = useSelector((state) => {
    return state.company?.value;
  });
  const cartList = useSelector((state) => state.cart.products);
  const onSearch = (value) => console.log(value);
  const [open, setOpen] = React.useState(false);
  const loginTrue = useSelector((state) => state.user.currentUser?.token);
  const dispatch = useDispatch();
  const navigate = useNavigate();
  useEffect(() => {
    props.getCartList();
    if (!loginTrue && loginTrue != "") {
    } else {
     
    }
  }, [loginTrue])


  

  const showDrawer = () => {
    setOpen(true);
  };
  const onClose = () => {
    setOpen(false);
  }

  const logOut = () => {
    api.logout(dispatch);
    navigate('/')
    // window.location.reload(true)
  }
  const menu = (
    <Menu>
      <Menu.Item key="1_cart">
        <Link to="/cart">
          <ShoppingCartOutlined /> Cart
        </Link>
      </Menu.Item>
      <Menu.Item key="1_profile">
        <Link to="/my-profile">
          <ProfileOutlined /> Profile
        </Link>
      </Menu.Item>
      <Menu.Item key="1_order">
        <Link to="/my-order">
          <ShoppingOutlined /> My Order
        </Link>
      </Menu.Item>
      
    </Menu>
  );
 
  return (
    <HeaderSection>
      <Wrapper>
         <HeaderAlign>
          <HeaderLeft>
            <Search placeholder="Search Product" onSearch={onSearch} />
          </HeaderLeft>
          <HeaderCenter>
            <Link to="/">
              <H2>
                <Img src={company?.logo} />
              </H2>
            </Link>
          </HeaderCenter>
          <HeaderRight>
          {!loginTrue && loginTrue != "" ?
            <>
            <Link to="/register">
              <Text>Register</Text>
            </Link>
            <Link to="/login">
              <Text>Login</Text>
            </Link> </> :
           <>
            
            <Dropdown overlay={menu}>
                <BtnText>
                  
                  <UserOutlined /> My Account<CaretDownOutlined />
                </BtnText>
              </Dropdown>
               <Text onClick={logOut}>
               <LogoutOutlined /> Sign out
             </Text>
             </>
            }
           
            <Link to="/cart">
              <Button>
                <ShoppingCartOutlined />
                Cart ({loginTrue!="" && !loginTrue ? 0 : cartList.length})
              </Button>
            </Link>
            <MenuBarSection>
              <ButtonMenu type="primary" onClick={showDrawer}>
                <AlignRightOutlined />
              </ButtonMenu>
              <Drawer
                title="ecDigi"
                placement="right"
                onClose={onClose}
                open={open}
              >
                <Link to="/">
                  <p>Home</p>
                </Link>

                <p>About Us</p>
                <Link to="/shop">
                  <p>Shop</p>
                </Link>
                <Link to="/product">
                  <p>Product</p>
                </Link>
                <p>Category</p>
                <p>Brands</p>
              </Drawer>
            </MenuBarSection>
          </HeaderRight>
        </HeaderAlign>
      </Wrapper>
    </HeaderSection>
  );
};

const mapStateToProps = (state) => ({
  products:state.cart.products,
});

export default connect(mapStateToProps,{getCartList}) (Header);

const HeaderSection = styled.header`
  display: inline-block;
  width: 100%;
  position: relative;
  border-bottom: 1px solid ${styles.light};
  box-sizing: border-box;
`;
const Wrapper = styled.div`
  max-width: 1200px;
  margin: auto;
  padding: 0 10px;
`;

const HeaderAlign = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 12px 0;
  position: relative;
  height: 85px;
`;
const Text = styled.div`
  color: ${header.gray};
  cursor: pointer;
`;
const HeaderLeft = styled.div`
  display: inline-block;
  width: fit-content;
`;
const HeaderCenter = styled.div`
  display: inline-block;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
`;

const Img = styled.img`
  max-width: 100%;
  height: 50px;
`;

const HeaderRight = styled.div`
  display: flex;
  align-items: center;
  gap: 18px;
  flex-wrap: wrap;
  button {
    background: ${header.background};
    color: #fff;
    padding: 5px 12px;
    height: auto;
  }
`;
const MenuBarSection = styled.div`
width:fit-content;
position: relative;
`;
const ButtonMenu = styled.div`
cursor: pointer;
width: fit-content;
position: relative;
font-size: 27px;
font-weight: 700;
`;
const H2 = styled.h2`
font-size: 30px;
text-transform: uppercase;
font-weight: 700;
margin: 0;
`;

const BtnText = styled.div`
display: flex;
align-items: center;
gap: 8px;
border: 1px solid ${styles.light};
padding: 6px 15px;
cursor: pointer;
`;