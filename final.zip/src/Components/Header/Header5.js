import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Badge, Menu, Button, Dropdown, Drawer, message } from "antd";
import { AiOutlineMenu } from "react-icons/ai";
import Login from "../../Ecommerce/Login";
import SearchBoxComponent from "../../Ecommerce/SearchBox";
import {
  SearchOutlined,
  ShoppingCartOutlined,
  ShoppingOutlined,
  LogoutOutlined,
  DownOutlined,
  ProfileOutlined,
  LoginOutlined,
} from "@ant-design/icons";
import API from "../../Api/ApiService";
import { connect, useSelector, useDispatch } from "react-redux";
import { getCartList } from "../../Store/cartTypes";
import styled from "styled-components";
import { styles } from "../../Api/Data";
const user = JSON.parse(localStorage.getItem("persist:root"))?.company;
const colorCustom = user && JSON.parse(user).setColor;

const { SubMenu } = Menu;
function Header5(props) {
  const dispatch = useDispatch();
  const history = useNavigate();
  const loginTrue = useSelector((state) => state.user.currentUser?.token);
  const cartList = useSelector((state) => state.cart.products);
  const [search, setSearch] = useState(true);
  const [category, setCategory] = useState([]);
  const [productcategory, setProductcategory] = useState([]);
  const [visible, setVisible] = useState(false);
  const api = new API();
  const company = useSelector((state) => {
    return state.company?.value;
  });

  useEffect(() => {
    props.getCartList();
    api
      .allCategory()
      .then((res) => {
        if (res.status === 200) {
          setCategory(res.data.filter((e) => e.parent == null));
        }
      })
      .catch((err) => {});
  }, []);

  const toogleSearch = () => {
    setSearch(!search);
  };

  const showDrawer = () => {
    setVisible(true);
  };

  const onClose = () => {
    setVisible(false);
  };

  const logout = (values) => {
    api.logout(dispatch);
    history("/");
  };
  const menu = (
    <Menu onClick={onClose}>
      <Menu.Item key="1_cart">
        <Link to="/cart">
          <ShoppingCartOutlined /> Cart
        </Link>
      </Menu.Item>
      <Menu.Item key="1_profile">
        <Link to="/my-profile">
          <ProfileOutlined /> Profile
        </Link>
      </Menu.Item>
      <Menu.Item key="1_order">
        <Link to="/my-order">
          <ShoppingOutlined /> My Order
        </Link>
      </Menu.Item>
      <Menu.Item key="1_signout">
        <a onClick={logout}>
          <LogoutOutlined /> Sign out
        </a>
      </Menu.Item>
    </Menu>
  );

  return (
    <React.Fragment>
      <HeaderSection>
        <header className="Temp5_Header">
          <nav className="Temp5_Navbar">
            <div className="Temp5_Header_Align">
              <div className="Temp5_Header_DesktopMenu">
                <span className="menu">
                  <Menu mode="horizontal">
                    <Menu.Item key="home">
                      <Link to="/">Home</Link>
                    </Menu.Item>
                    <Menu.Item key="about">
                      <Link to="/about">About Us</Link>
                    </Menu.Item>

                    <SubMenu key="product" title="Product">
                      {category?.map((e, i) => {
                        return (
                          <Menu.Item key={`menuPdtTemp5_${i}`}>
                            <Link
                              to={`/${e.category_name
                                .toLowerCase()
                                .replace(/ /g, "-")
                                .replace(/[^\w-]+/g, "")}`}
                            >
                              {e.category_name}
                            </Link>
                          </Menu.Item>
                        );
                      })}
                    </SubMenu>
                    <Menu.Item key="contact">
                      <Link to="/contact">Contact Us</Link>
                    </Menu.Item>
                    <Menu.Item key="enquiry">
                      <Link to="/enquiry">Enquiry</Link>
                    </Menu.Item>
                  </Menu>
                </span>
              </div>
              <div className="Temp5_Header_Logo">
                <Link to="/">
                  <img className="logo" src={company.logo} />
                </Link>
              </div>
              <div className="Temp5_Header_ShopCart">
                {search && <SearchBoxComponent style={{ minWidth: "300px" }} />}

                {/* <Button type="text" onClick={toogleSearch}>
                            <SearchOutlined />
                        </Button> */}

                {!loginTrue && loginTrue !== "" && (
                  <Link to="/cart">
                    <Badge count={cartList.length}>
                      <Button type="text">
                        <ShoppingCartOutlined />
                      </Button>
                    </Badge>
                  </Link>
                )}

                {!loginTrue && loginTrue !== "" ? (
                  <Link to="/login">
                    <Button type="text">
                      <LoginOutlined />
                      Login
                    </Button>
                  </Link>
                ) : (
                  <Dropdown overlay={menu}>
                    <Button
                      type="text"
                      className="ant-dropdown-link"
                      onClick={(e) => e.preventDefault()}
                    >
                      My Account
                      <DownOutlined />
                    </Button>
                  </Dropdown>
                )}
              </div>

              <div className="Temp5_Header_MobileMenu">
                <Button
                  className="barsMenu"
                  type="outline"
                  onClick={showDrawer}
                >
                  <AiOutlineMenu />
                </Button>

                <Drawer
                  placement="right"
                  closable={false}
                  onClose={onClose}
                  open={visible}
                  className="temp-1"
                >
                  <span className="menu">
                    <Menu mode="inline" onClick={onClose}>
                      <Menu.Item key="home">
                        <Link to="/">Home</Link>
                      </Menu.Item>
                      <Menu.Item key="about">
                        <Link to="/about">About Us</Link>
                      </Menu.Item>

                      <SubMenu key="product" title="Product">
                        {category?.map((e, i) => {
                          return (
                            <Menu.Item key={`menuPdtTemp5_${i}`}>
                              <Link
                                to={`/${e.category_name
                                  .toLowerCase()
                                  .replace(/ /g, "-")
                                  .replace(/[^\w-]+/g, "")}`}
                              >
                                {e.category_name}
                              </Link>
                            </Menu.Item>
                          );
                        })}
                      </SubMenu>
                      <Menu.Item key="contact">
                        <Link to="/contact">Contact Us</Link>
                      </Menu.Item>
                      <Menu.Item key="enquiry">
                        <Link to="/enquiry">Enquiry</Link>
                      </Menu.Item>
                    </Menu>
                  </span>

                  <div className="mobile-hide-search">
                    {<SearchBoxComponent />}
                    {/* <Button type="text" onClick={toogleSearch}>
                  <SearchOutlined />
                </Button> */}
                  </div>

                  {!loginTrue && loginTrue !== "" && (
                    <Link to="/cart" onClick={onClose}>
                      <Badge count={cartList.length}>
                        <Button type="text">
                          <ShoppingCartOutlined />
                        </Button>
                      </Badge>
                    </Link>
                  )}

                  {!loginTrue && loginTrue !== "" ? (
                    <Link to="/login">
                      <Button type="text">
                        <LoginOutlined />
                        Login
                      </Button>
                    </Link>
                  ) : (
                    <Dropdown overlay={menu}>
                      <Button
                        type="text"
                        className="ant-dropdown-link"
                        onClick={(e) => e.preventDefault()}
                      >
                        My Account
                        <DownOutlined />
                      </Button>
                    </Dropdown>
                  )}
                </Drawer>
              </div>
            </div>
          </nav>
        </header>
      </HeaderSection>
    </React.Fragment>
  );
}
const mapStateToProps = (state) => ({
  products: state.cart.products,
});
export default connect(mapStateToProps, { getCartList })(Header5);



const HeaderSection = styled.div`
header.Temp5_Header {
  position: sticky;
  top: 0px;
  left: 0px;
  z-index: 1000;
  background: ${styles?.white};
  width: 100%;
  // padding: 10px;
}

.Temp5_Header_Align {
  display: flex;
  align-items: center;
  border-radius: 6px;
  height: 63px;
  box-shadow: 0px 3px 60px 0px #959595;
  padding: 0 20px;
  justify-content: space-between;
}

.Temp5_Header_Logo {
  display: inline-block;
  width: fit-content;
}

.Temp5_Header_MobileMenu {
  width: fit-content;
}

.Temp5_Header_MobileMenu {
  display: none;
}

.Temp5_Header_ShopCart {
  display: flex;
  align-items: center;
}

.Temp5_Header_ShopCart
  .ant-btn.ant-btn-text.ant-dropdown-trigger.ant-dropdown-link {
  display: flex;
  align-items: center;
}


@media screen and (max-width: 1024px) {
  .Temp5_Header_DesktopMenu {
    display: none;
  }

  .Temp5_Header_MobileMenu {
    display: block;
    width: fit-content;
    text-align: end;
  }
  .Temp5_Header_MobileMenu button {
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .mobile-hide-search{
    display: none;
  }
}

@media screen and (max-width:992px) {
  .Temp5_Header_MobileMenu {
    display: block;
    width: fit-content;
    text-align: end;
  }

  .Temp5_Header_ShopCart {
    display: flex;
  }

  .Temp5_Header_DesktopMenu {
    display: none;
  }
  .mobile-hide-search{
    display: none;
  }
}

@media screen and (max-width:768px) {
  .Temp5_Header_Logo .logo {
    height: 37px;
  }
}


@media screen and (max-width:600px) {
  .Temp5_Header_ShopCart {
    display: none;
  }
}

@media screen and (max-width:480px) {
  .Temp5_Header_ShopCart {
    display: none;
  }
  .mobile-hide-search{
    display: block;
  }
}


`;