import React, { useState, useEffect } from 'react'
import styled from 'styled-components';
import logo from "../../Assets/Images/logo.png"
import instgram from "../../Assets/Images/furniture/s2.png"
import facebook from "../../Assets/Images/furniture/s1.png"
import support from "../../Assets/Images/dry/support.png"
import cart from "../../Assets/Images/dry/cart.png"
import user from "../../Assets/Images/dry/user.png"
import shop from "../../Assets/Images/dry/shop.png"
import { getCartList } from "../../Store/cartTypes";
import delivery from "../../Assets/Images/dry/delivery.png"
import checkout from "../../Assets/Images/dry/payment.png"
import profile from "../../Assets/Images/dry/myaccount.png"
import order from "../../Assets/Images/dry/wallet.png"
import { Input, Badge, Menu, Dropdown } from 'antd';
import { Link, useNavigate } from "react-router-dom"
import { styles } from '../../Api/Data';
import { FilterOutlined } from '@ant-design/icons';
import MobileMenu from '../MenuBar/MobileMenu';
import email from "../../Assets/Images/dry/email.png"
import call from "../../Assets/Images/dry/call.png"
import hmain from "../../Assets/Images/dry/hmain.png"
import { connect, useSelector, useDispatch } from "react-redux"
import API from '../../Api/ApiService';
import SearchBoxComponent from '../../Ecommerce/SearchBox';
import { ShoppingCartOutlined, BankOutlined, UserOutlined, ShopOutlined, WalletOutlined, LogoutOutlined } from '@ant-design/icons';
const { Search } = Input;
const { SubMenu } = Menu;


const DryHeader = (props) => {
  const onSearch = (value) => console.log(value);
  const company = useSelector((state) => state.company?.value);
  const socialMediaLink = useSelector(
    (state) => state.company?.socialMediaLinks
  );
  const loginTrue = useSelector((state) => state.user.currentUser?.token);
  const dispatch = useDispatch();
  const [category, setCategory] = useState([]);
  const cartList = useSelector((state) => state.cart.products);
  const api = new API();
  const history = useNavigate();
  const [visible, setVisible] = useState(false);
  const logout = () => {
    api.logout(dispatch);
    history('/')
  };
  const onClose = () => {
    setVisible(false);
  };
   
  useEffect(() => {
    props.getCartList();
    api.allCategory().then((res) => {
        console.log(res)
       if (res.status === 200) {
            setCategory(res.data.filter(e =>
                e.parent == null
            ))
        }
    }).catch((err) => { })
}, []);

 

  const menu = (
    <Menu onClick={onClose} className="profile_drop">

      <Menu.Item key="3">
        <Link to="/my-profile">
          <UserOutlined />My Profile
        </Link>
      </Menu.Item>
      <Menu.Item key="4">
        <Link to="/my-profile">
          <ShopOutlined /> My Address
        </Link>
      </Menu.Item>
      <Menu.Item key="1">
        <Link to="/cart">
          <ShoppingCartOutlined /> Cart
        </Link>
      </Menu.Item>
      <Menu.Item key="2">
        <Link to="/cart">
          <BankOutlined /> Checkout
        </Link>
      </Menu.Item>
      <Menu.Item key="5">
        <Link to="/my-order">
          <WalletOutlined /> My Order
        </Link>
      </Menu.Item>
      <Menu.Item key="6">
        <a onClick={logout}>
          <LogoutOutlined /> Sign out
        </a>
      </Menu.Item>
    </Menu>
  );



  return (
    <React.Fragment>
      <HeaderSection>
        <div className='header_section'>
          <div className='header_text'>
            <div className='wrapper'>
              <div className='header_text_align'>
                <div className='header_text_left'>
                  <p>
                    <span>
                      <img src={delivery} alt="delivery" />
                    </span>
                    <span>100% Secure delivery without contacting the courier</span>
                  </p>
                </div>
                <div className='header_text_right'>
                  <ul>
                    <li>
                      <a href={"mailto:" + company.email} title='Mail Us'>
                        <span>

                          <img src={email} alt="email" />

                        </span>
                        <span>Mail Us</span>
                      </a>
                    </li>
                    <li>
                      <Link to="/my-profile" title='My Profile'>
                        <span>
                          <img src={profile} alt="profile" />
                        </span>
                        <span>My Profile</span>
                      </Link>
                    </li>
                    <li>
                      <Link to="/my-order" title="My Order">
                        <span>
                          <img src={order} alt="order" />
                        </span>
                        <span>My Order</span>
                      </Link>
                    </li>
                    <li>
                      <Link to="/checkout" title='Checkout'>
                        <span>
                          <img src={checkout} alt="checkout" />
                        </span>
                        <span>Checkout</span>
                      </Link>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <div className='header_top'>
            <div className='wrapper'>
              <div className='header_top_align'>
                <div className='header_top_left'>
                  <Link to="/">
                    <img src={company?.logo ? company?.logo : logo} alt={company?.name} />
                  </Link>
                </div>
                <div className='header_top_center'>
                  {<SearchBoxComponent />}
                </div>
                <div className='header_top_right'>
                  <div className='header_top_right_support'>
                    <a href={"tel:+91" + company.mobile_no} title='Call Now'>
                      <span>
                        <img src={support} alt="Support" />
                      </span>
                      <span>
                        <i>Online Support</i>
                        <p>+91 {company.mobile_no}</p>
                      </span>
                    </a>
                  </div>
                  <div className='shop_btn'>
                    <ul>
                      <li>

                        {
                          !loginTrue && loginTrue !== "" ? <Link to="/login"><img src={user} alt="Login" title='Login' /></Link>
                            :
                            <Dropdown overlay={menu} placement="bottomRight">
                              <div
                                onClick={(e) => e.preventDefault()}
                              >
                                <img src={user} alt="Login" title='My Account' />

                              </div>
                            </Dropdown>
                        }
                      </li>
                      <li>
                        <Link to="/cart">
                          <Badge count={loginTrue != "" && !loginTrue ? 0 : cartList.length === 0 ? 0 : cartList.length} size="small" showZero>
                            <img src={shop} alt="cart" title='View Cart' />
                          </Badge>
                        </Link>
                      </li>
                      <li className='dry_fruites_mob_menu'>
                        <MobileMenu />
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className='header_bottom'>
            <div className='wrapper'>
              <div className='header_bottom_align'>
                <div className='header_bottom_left'>
                  <Menu mode="horizontal">
                    <SubMenu key="Categories" title="All Categories" icon={<FilterOutlined />} className="submenu_btn">
                      {category?.map((e, i) => {
                        return (
                          <Menu.Item key={`menuPdttemp1_${i}`}>
                            <Link to={`/${e.category_name.toLowerCase().replace(/ /g, '-')
                              .replace(/[^\w-]+/g, '')}`}>
                              {e.category_name}
                            </Link>
                          </Menu.Item>
                        );
                      })}
                    </SubMenu>
                    <Menu.Item key="home">
                      <Link to="/">Home</Link>
                    </Menu.Item>
                    <Menu.Item key="about">
                      <Link to="/about">About Us</Link>
                    </Menu.Item>
                    <Menu.Item key="enquiry">
                      <Link to="/enquiry">Enquiry Form</Link>
                    </Menu.Item>
                    <SubMenu key="Policy" title="Our Policy">
                      <Menu.Item key="1p">
                        <Link to="/privacy-policy">Privacy Policy</Link>
                      </Menu.Item>
                      <Menu.Item key="2p">
                        <Link to="/delivery-policy">Delivery Policy</Link>
                      </Menu.Item>
                      <Menu.Item key="3p">
                        <Link to="/terms">Terms and Condition</Link>
                      </Menu.Item>
                      <Menu.Item key="4p">
                        <Link to="/refund-policy">Refund Policy</Link>
                      </Menu.Item>
                      <Menu.Item key="5p">
                        <Link to="/return-policy">Return Policy</Link>
                      </Menu.Item>
                      <Menu.Item key="6p">
                        <Link to="/cancellation-policy">Cancellation Policy</Link>
                      </Menu.Item>
                    </SubMenu>
                    <Menu.Item key="myaddress">
                      <Link to="/my-address">My Address</Link>
                    </Menu.Item>
                    <Menu.Item key="Contact">
                      <Link to="/contact">Contact Us</Link>
                    </Menu.Item>
                  </Menu>
                </div>
                <div className='header_bottom_right'>
                  <ul>
                    {
                      socialMediaLink?.map((item) => {
                        return (
                          <li key={item?._id}>
                            <a href={item?.link} title={item?.label} target="_blank">
                              <img src={api.rootUrl + item.icon} alt={item?.label} /></a>
                          </li>
                        )
                      })
                    }
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </HeaderSection>
    </React.Fragment>
  )
}
const mapStateToProps = (state) => ({
  products: state.cart.products,
});
export default connect(mapStateToProps, { getCartList })(DryHeader);

const H2 = styled.h2`
   font-size:32px;
   margin : 0 0 50px;
   font-family: ${styles?.q_bold} !important;
   text-align: center;
   padding: 55px 0 0 0;
   &::before {
    content: "";
    position: absolute;
    background: url(${hmain});
    background-repeat: no-repeat;
    height: 46px;
    width: 46px;
    background-size: contain;
    top: 0;
    left: 50%;
    transform: translate(-50%, 0px);
   }

   @media screen and (max-width:768px) {
    text-align: center;
   }

`

const HeaderSection = styled.section`
    * {
        font-family: ${styles?.q_regular};
    }
    a {
      color: #fff;
    }
  width  :100% ;
  display: inline-block;
  position: relative;

  .header_section, .header_top {
    width: 100%;
    display: inline-block;
    position: relative;
  }
  .header_text {
    width: 100%;
    display: inline-block;
    background: ${styles?.themegreen};
  }
  .header_text_align {
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
  }
  .header_text_align .header_text_left {
    width: fit-content;
    display: inline-block;
    
  }
  .header_text_align .header_text_left p {
    display: flex;
    align-items: center;
    gap: 10px;
    font-size: 13px;
  }
  .header_text_align .header_text_left img {
    height: 14px;
    filter: brightness(0) invert(1);
  }
  .header_text_align .header_text_right {
    width: fit-content;
    display: inline-block;
  }
  .header_text_align .header_text_right ul {
    display: flex;
    align-items: center;
    margin: 0;
    padding: 0;
    gap: 18px;
    line-height: 32px !important;
  }
  .header_text_align .header_text_right ul li {
    width: fit-content;
    display: flex;
    align-items: center;
    gap: 5px;
    padding: 1px 18px 1px 0;
    border-right: 1px solid rgb(255 255 255 / 40%);

    a {
      display: flex;
    align-items: center;
    gap: 5px;
    }

    &:last-child {
        border: 0;
        padding: 0;
    }
  }
  .header_text_align .header_text_right ul li span:nth-child(1) {
    width: fit-content;
    display: inline-block;
    
  }
  .header_text_align .header_text_right ul li span:nth-child(2) {
    width: fit-content;
    display: inline-block;
}
.header_text_align .header_text_right ul li span:nth-child(1) img {
    height: 13px;
    filter: brightness(0) invert(1);
}
.header_text_align .header_text_right ul li span:nth-child(2) {
    color: ${styles?.white};
    font-size: 13px;
    letter-spacing: 0.2px;
}













  .header_text p {
    text-align: center;
    margin: 0;
    line-height: 1.5;
    padding: 6px 0;
    color: ${styles?.white};
  }
  .header_top { 
    border-bottom: 1px solid #f2f2f2;
  }
  .header_top_align {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    justify-content: space-between;
    gap: 15px;
    width: 100%;
    position: relative;
    padding: 15px 0;
  }
  .header_top_left {
    width: fit-content;
    display: inline-block;
  }
  .header_top_left img {
    height: 55px;
  }
  .header_top_center {
    width: 360px;
    border: 1px solid #ebebeb;
    display: inline-block;
    border-radius: 35px;
    padding: 0 5px 0 0;
}
    
    input, button, .ant-input-group-addon {
        border: 0;
        background: transparent;
    }
    input, .ant-input-group > .ant-input-affix-wrapper:not(:last-child) .ant-input {
        padding: 3px 4px;
    }
    input:focus, .ant-input-search .ant-input-group .ant-input-affix-wrapper:not(:last-child) {
        outline: none;
        box-shadow: inherit;
    }
    .ant-input-search .ant-input-group .ant-input-affix-wrapper:not(:last-child) {
      border: 0;
      background: transparent;
    }
  

.header_top_right {
    display: flex;
    align-items: center;
    gap: 50px;
    flex-wrap: wrap;
}
.header_top_right_support, .header_top_right_support a {
    display: flex;
    align-items: center;
    gap: 15px;
}
.header_top_right_support span:nth-child(1) {
    display: inline-block;
    position: relative;
    width: fit-content;
}
.header_top_right_support span:nth-child(1) img {
    height: 40px;
}
.header_top_right_support span:nth-child(2) {
    display: flex;
    position: relative;
    width: fit-content;
    flex-direction: column;
    gap: 8;
    i {
        color: ${styles?.gray};
        font-size: 13px;
    }
    p {
        margin: 0 !important;
        font-family: ${styles?.q_bold};
        font-size: 18px;
        color: ${styles?.color};
    }
}

.shop_btn {
    display: inline-block;
    width: fit-content;
    position: relative;
    a {
        display: flex;
    }
}
.shop_btn ul {
    margin: 0;
    padding: 0;
    display: flex;
    gap: 20px;
    align-items: center;
    flex-wrap: wrap;
}
.shop_btn ul li {
    display: flex;
}
.shop_btn ul img {
    height: 25px;
}
.header_bottom {
    width: 100%;
    display: inline-block;
}
.header_bottom_align {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 20px;
    padding: 12px 0;
}
.header_bottom_align .header_bottom_left {
    width: 75%;
    display: inline-block;
    .ant-menu-horizontal {
        line-height: 35px !important;
    }
}
.header_bottom_align .header_bottom_left ul {
    width: 100%;
    margin: 0;
    padding: 0;
}
.header_bottom_align .header_bottom_left ul li a {
    font-family: ${styles?.q_bold};
}
.header_bottom_align .header_bottom_right {
    width: fit-content;
    display: inline-block;
}
.header_bottom_align .header_bottom_right ul {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    gap: 15px;
    padding: 0;
    margin: 0;
}

.header_bottom_align .header_bottom_right ul img {
    height: 28px;
}


.submenu_btn {
    display: flex;
    align-items: center;
    background: ${styles?.themegreen};
    color:${styles?.white};
    border-radius: 5px;
    padding: 0 20px !important;

    .ant-menu-submenu-title {
        align-items: center;
    color: #fff !important;
    display: flex;
    }
}

.ant-menu-title-content {
  font-weight: 600;
}


.dry_fruites_mob_menu {
    display: none !important;
}


@media screen and (max-width:1200px) {
    .header_bottom {
        display: none;
    }
    .header_top_left img {
        height: 47px;
    }
    .header_top_center {
        width: 280px;
    }
    .dry_fruites_mob_menu {
    display: flex !important;
}
.dry_fruites_mob_menu button {
    display: flex;
    align-items: center;
    justify-content: center;
}





}



@media screen and (max-width:992px) {
    .header_top_right_support {
        display: none;
    }
    .header_text {
        display: none;
    }

}

@media screen and (max-width:768px) {
    .header_top_align {
        padding: 15px 0 70px 0;
        position: relative;
    }
    .header_top_center {
    width: 100%;
    position: absolute;
    bottom: 15px;
    left: 0;
}





}
















`