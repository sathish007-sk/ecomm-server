import React, { useState, useEffect } from 'react'
import styled from 'styled-components';
import { Link, useNavigate } from "react-router-dom";
import { styles } from '../../Api/Data';
import { getCartList } from "../../Store/cartTypes";
import { ShoppingCartOutlined, BankOutlined, UserOutlined, ShopOutlined, WalletOutlined, LogoutOutlined } from '@ant-design/icons';
import hcall from '../../Assets/Images/Temp/icon/call.png'
import hmail from '../../Assets/Images/Temp/icon/email.png'
import horder from '../../Assets/Images/Temp/icon/order.png'
import hcart from '../../Assets/Images/Temp/icon/cart.png'
import henquire from '../../Assets/Images/Temp/icon/enquire.png'
import huser from '../../Assets/Images/Temp/icon/profile.png'
import haddress from '../../Assets/Images/Temp/icon/location.png'
import logo from '../../Assets/Images/Temp/logo.png'
import facebook from '../../Assets/Images/Temp/s1.png'
import instagram from '../../Assets/Images/Temp/s2.png'
import MobileMenu from '../MenuBar/MobileMenu';
import API from '../../Api/ApiService';
import SearchBoxComponent from "../../Ecommerce/SearchBox";
import { Input, Badge, Menu, Dropdown } from 'antd';
import { connect, useSelector, useDispatch } from "react-redux"
const { Search } = Input;
const { SubMenu } = Menu;
const GiftHeader = (props) => {
    const loginTrue = useSelector((state) => state.user.currentUser?.token);
    const dispatch = useDispatch();
    const [category, setCategory] = useState([]);
    const cartList = useSelector((state) => state.cart.products);
    const [scroll, setScroll] = useState(false);
    const api = new API();
    const history = useNavigate();
    const [visible, setVisible] = useState(false);
    const logout = () => {
        api.logout(dispatch);
        history('/')
    };
    const company = useSelector((state) => {
        return state.company?.value;
    });
    const socialMediaLink = useSelector(
        (state) => state.company?.socialMediaLinks
    );
    const onClose = () => {
        setVisible(false);
    };
    useEffect(() => {
        window.addEventListener("scroll", () => {
          setScroll(window.scrollY > 1);
        });
      }, []);


    useEffect(() => {
        props.getCartList();
        api.allCategory().then((res) => {

            if (res.status === 200) {
                setCategory(res.data.filter(e =>
                    e.parent == null
                ))
            }
        }).catch((err) => { })
    }, []);

    const menu = (
        <Menu onClick={onClose} className="profile_drop">

            <Menu.Item key="3">
                <Link to="/my-profile">
                    <UserOutlined />My Profile
                </Link>
            </Menu.Item>
            <Menu.Item key="4">
                <Link to="/my-address">
                    <ShopOutlined /> My Address
                </Link>
            </Menu.Item>
            <Menu.Item key="1">
                <Link to="/cart">
                    <ShoppingCartOutlined /> Cart
                </Link>
            </Menu.Item>
            <Menu.Item key="2">
                <Link to="/checkout">
                    <BankOutlined /> Checkout
                </Link>
            </Menu.Item>
            <Menu.Item key="5">
                <Link to="/my-order">
                    <WalletOutlined /> My Order
                </Link>
            </Menu.Item>
            <Menu.Item key="6">
                <a onClick={logout}>
                    <LogoutOutlined /> Sign out
                </a>
            </Menu.Item>
        </Menu>
    );



   
    return (
        <React.Fragment>
            <HeaderSection1>
                <div className='head_section'>
                    <div className='head_top'>
                        <div className='wrapper'>
                            <div className='head_top_align'>
                                <ul>
                                    <li>
                                        <a href={"tel:+91" + company.mobile_no} title='Call Now'>
                                            <span className='icon'><img src={hcall} alt="Call" /></span>
                                            <span className='text'>{company?.mobile_no}</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href={"mailto:" + company.email} title='Mail to'>
                                            <span className='icon'><img src={hmail} alt="Mail" style={{ height: "12px" }} /></span>
                                            <span className='text'>{company?.email}</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a>
                                            <span className='icon'><img src={haddress} alt="Location" /></span>
                                            <span className='text'>{company?.address?.address_line1}</span>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div className='head_center' id={scroll ?  "scroll_head" : ""}>
                        <div className='wrapper'>
                            <div className='head_center_align'>
                                <div className='head_center_left'>
                                    <Link to="/">
                                        <img src={company?.logo ? company?.logo : logo} alt="Logo" />
                                    </Link>
                                </div>
                                <div className='head_center_center'>
                                    {<SearchBoxComponent />}
                                </div>
                                <div className='head_center_right'>
                                    <ul>
                                        <Link to="/enquiry">
                                            <li>
                                                <span className='icon'><img src={henquire} alt="Enquire Form" /></span>
                                                <span className='text'>Enquire Form</span>
                                            </li>
                                        </Link>
                                        {
                                            !loginTrue && loginTrue !== "" ? <Link to="/login">
                                                <li>
                                                    <span className='icon'><img src={huser} alt="My Account" /></span>
                                                    <span className='text'>Sign Up / Login</span>
                                                </li>

                                            </Link>
                                                :
                                                <Dropdown overlay={menu} placement="bottomRight">
                                                    <div
                                                        onClick={(e) => e.preventDefault()}
                                                    >
                                                        <li>
                                                            <span className='icon'><img src={huser} alt="My Account" /></span>
                                                            <span className='text'>Logout</span>
                                                        </li>

                                                    </div>
                                                </Dropdown>
                                        }
                                        <Link to="/cart">
                                            <li>
                                                <span className='icon'><Badge count={loginTrue != "" && !loginTrue ? 0 : cartList.length === 0 ? 0 : cartList.length} showZero size='small'><img src={hcart} alt="Cart" /></Badge></span>
                                                <span className='text'>My Cart</span>
                                            </li>
                                        </Link>
                                        <Link to="/my-order">
                                            <li>
                                                <span className='icon'><img src={horder} alt="My Order" /></span>
                                                <span className='text'>My Order</span>
                                            </li>
                                        </Link>
                                        <li className='mobile_menu'>
                                            <span><MobileMenu /></span>
                                            <span className='text'>Menu</span>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className='head_bottom'>
                        <div className='wrapper'>
                            <div className='head_bottom_align'>
                                <Menu mode="horizontal">
                                    <Menu.Item key="home">
                                        <Link to="/">Home</Link>
                                    </Menu.Item>
                                    <Menu.Item key="about">
                                        <Link to="/about">About Us</Link>
                                    </Menu.Item>
                                    <SubMenu key="Categories" title="Categories">
                                        {category?.map((e, i) => {
                                            return (
                                                <Menu.Item key={`menuPdttemp1_${i}`}>
                                                    <Link to={`/${e.category_name.toLowerCase().replace(/ /g, '-')
                                                        .replace(/[^\w-]+/g, '')}`}>
                                                        {e.category_name}
                                                    </Link>
                                                </Menu.Item>
                                            );
                                        })}
                                    </SubMenu>
                                    <SubMenu key="Policy" title="Policy">
                                        <Menu.Item key="1p">
                                            <Link to="/privacy-policy">Privacy Policy</Link>
                                        </Menu.Item>
                                        <Menu.Item key="2p">
                                            <Link to="/delivery-policy">Delivery Policy</Link>
                                        </Menu.Item>
                                        <Menu.Item key="3p">
                                            <Link to="/terms">Terms and Condition</Link>
                                        </Menu.Item>
                                        <Menu.Item key="4p">
                                            <Link to="/refund-policy">Refund Policy</Link>
                                        </Menu.Item>
                                        <Menu.Item key="5p">
                                            <Link to="/return-policy">Return Policy</Link>
                                        </Menu.Item>
                                        <Menu.Item key="6p">
                                            <Link to="/cancellation-policy">Cancellation Policy</Link>
                                        </Menu.Item>
                                    </SubMenu>
                                    {/* <Menu.Item key="Policy">
                                        <Link to="/">Policy</Link>
                                    </Menu.Item> */}
                                    <Menu.Item key="Enquiry">
                                        <Link to="/enquiry">Enquiry From</Link>
                                    </Menu.Item>
                                    <Menu.Item key="my-address">
                                        <Link to="/my-address">My Address</Link>
                                    </Menu.Item>
                                    <Menu.Item key="my-profile">
                                        <Link to="/my-profile">My Profile</Link>
                                    </Menu.Item>
                                    <Menu.Item key="contact">
                                        <Link to="/contact">Contact Us</Link>
                                    </Menu.Item>

                                </Menu>
                                <div className='social_media'>

                                    <ul>
                                        {
                                            socialMediaLink?.map((item) => {
                                                return (
                                                    <li key={item?._id}>
                                                        <a href={item?.link} title={item?.label} target="_blank">
                                                            <img src={api.rootUrl + item.icon} alt={item?.label} /></a>
                                                    </li>
                                                )
                                            })
                                        }
                                       
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </HeaderSection1>
        </React.Fragment>
    )
}
const mapStateToProps = (state) => ({
    products: state.cart.products,
});
export default connect(mapStateToProps, { getCartList })(GiftHeader);


const HeaderSection1 = styled.section`
    * {
        font-family: ${styles?.regular};
    }
    display: inline-block;
    width:100%;
    position: relative;
#scroll_head {
    position: fixed;
    top: 0;
    left: 0;
    box-shadow: 0 0 8px rgb(0 0 0 / 15%);
    transition: all 0.8s ease-in-out;
}
    .head_section {
        display: flex;
        flex-direction: column;
        position: relative;
        width:100%;
    }
    .head_section .head_top {
        display: inline-block;
        position: relative;
        width: 100%;
        padding: 5px 0;
        background: #eaeaea;
    }
    .head_section .head_top .head_top_align {
        display: inline-block;
        text-align: end;
        position: relative;
        width: 100%;
    }
    .head_section .head_top .head_top_align ul {
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        gap: 30px;
        padding: 0;
        margin: 0 0 0 auto;
        width: fit-content;
    }
    .head_section .head_top .head_top_align ul li a {
        display: flex;
        align-items: center;
        gap: 12px;
        color: ${styles?.color};
        font-size: 13px;
    }
    .head_section .head_top .head_top_align ul li a span.icon img {
        height: 16px;
    }
    .head_section .head_center {
        background: #fff;
        display: inline-block;
        width: 100%;
        padding: 20px 0;
        top: 0;
        z-index: 1000;

    }
    .head_section .head_center .head_center_align {
        display: flex;
        align-items: center;
        justify-content: space-between;
        flex-wrap: wrap;
        width: 100%;
        position: relative;
    }
    .head_section .head_center .head_center_align .head_center_left {
        display: inline-block;
        width: fit-content;
    }
    .head_section .head_center .head_center_align .head_center_left img {
        height: 55px;
    }
    .head_section .head_center .head_center_align .head_center_center {
        width: fit-content;
        display: inline-block;
        border: 1px solid #8b8b91;
    border-radius: 5px;
    width: 300px;
    .ant-input-affix-wrapper {
        border: 0;
    }
        input {
            padding: 2px 5px;
            border: 0;
        }
        button {
            padding: 4px 0px;
    height: auto;
    border: 0;
    background: transparent !important;
    color: #000;
        }
        .ant-input-group-addon {
            background: transparent;
        }
    }
    .head_section .head_center .head_center_align .head_center_right {
        width: fit-content;
        display: inline-block;
        

    }
    .head_section .head_center .head_center_align .head_center_right ul {
        display: flex;
        align-items: center;
        gap: 35px;
        flex-wrap: wrap;
        position: relative;
        width:fit-content;
        margin: 0;
        padding: 0;
    }
    .head_section .head_center .head_center_align .head_center_right ul li {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 7px;
        flex-direction: column;
    }
    .head_section .head_center .head_center_align .head_center_right ul li span.icon {
        width: 100%;
    display: flex;
    text-align: center;
    align-items: center;
    justify-content: center;
        img {
            margin: auto;
            height: 24px;
        }
    }
    .head_section .head_center .head_center_align .head_center_right ul li span.text {
        text-align: center;
        font-size: 12px;
        color: ${styles?.color};
        font-weight: 500;
    }

    .head_bottom {
        width: 100%;
        display: inline-block;
        position: relative;
        background: #eaeaea;
        padding: 3px 0;
    }
    .head_bottom .head_bottom_align {
    display: flex;
    align-items: center;
    justify-content: space-between;
    width: 100%;
    ul {
        width: 70%;
    }
    .social_media {
        width:fit-content;
        display: inline-block;
    }
    .social_media ul {
        padding: 0;
        margin: 0;
        display: flex;
        align-items: center;
        gap: 13px;
        width: fit-content;
    }
    .social_media ul img {
        height: 26px;
    }
}
.mobile_menu {
    display: none !important;
}

@media screen and (max-width:1200px) {
    .head_bottom {
        display: none;
    }
    .head_section .head_center .head_center_align .head_center_left img {
    height: 50px;
}
.mobile_menu {
    display: flex !important;

    button {
        border: 0 !important;
    padding: 0 !important;
    height: 21px !important;
    display: flex;
}

}

}

@media screen and (max-width:992px) {
    
    .head_section .head_center .head_center_align .head_center_center {
        width: 240px;
        .ant-input-group-wrapper {
            width: 240px !important;
        }
    }

    .head_section .head_center .head_center_align .head_center_right ul {
        gap: 14px;
    }
    .head_section .head_center .head_center_align .head_center_right ul li span.text {
        display: none;
    }
    .head_section .head_center .head_center_align .head_center_right ul a:nth-child(1), .head_section .head_center .head_center_align .head_center_right ul a:nth-child(4) {
        display: none;
    }
    .mobile_menu button {
        border: 1px solid #d9d9d9 !important;
    padding: 3px 5px !important;
    height: auto !important;
    margin: 0 0 0 10px;
    }

}


@media screen and (max-width:768px) {
    
    .head_section .head_top {
        display: none;
    }
    .head_section .head_center {
        padding: 12px 0;
    }
    .head_section .head_center .head_center_align .head_center_center input {
    padding: 2px 5px;
    }
    .head_section .head_center .head_center_align .head_center_center button {
    padding: 4px 0px;
    }
    .head_section .head_center .head_center_align .head_center_left img {
    height: 45px;
}


}



@media screen and (max-width:580px) {
    
    .head_section .head_center .head_center_align {
        position: relative;
        padding: 0 0 50px;
    }

    .head_section .head_center .head_center_align .head_center_center {
    width: 100%;
    position: absolute;
    bottom: 0;
    left: 0;
}
.head_section .head_center .head_center_align .head_center_center .ant-input-group-wrapper {
    width: 100% !important;
}
.head_section .head_center .head_center_align .head_center_left img {
    height: 40px;
}






}






`