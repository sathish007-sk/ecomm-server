import React, { useState, useEffect } from 'react'
import styled from 'styled-components';
import { ShoppingCartOutlined, BankOutlined, UserOutlined, ShopOutlined, WalletOutlined, LogoutOutlined } from '@ant-design/icons';
import { getCartList } from "../../Store/cartTypes";
import logo from '../../Assets/Images/Temp/logo.png'
import { Input, Badge, Menu, Dropdown, Button } from 'antd';
import { Link, useNavigate } from "react-router-dom";
import SearchBoxComponent from "../../Ecommerce/SearchBox";
import hcart from '../../Assets/Images/Temp/icon/cart.png'
import hsearch from '../../Assets/Images/Temp/icon/search.png'
import huser from '../../Assets/Images/Temp/icon/profile.png'
import MobileMenu from '../MenuBar/MobileMenu';
import instgram from "../../Assets/Images/furniture/s2.png"
import facebook from "../../Assets/Images/furniture/s1.png"
import { styles } from '../../Api/Data';
import { connect, useSelector, useDispatch } from "react-redux"
import API from '../../Api/ApiService';
const { SubMenu } = Menu;
const FHeader = (props) => {
    const loginTrue = useSelector((state) => state.user.currentUser?.token);
    const dispatch = useDispatch();
    const [category, setCategory] = useState([]);
    const cartList = useSelector((state) => state.cart.products);
    const api = new API();
    const history = useNavigate();
    const [search, setSearch] = useState(false);
    const [visible, setVisible] = useState(false);
    const [scroll, setScroll] = useState(false);
    const logout = () => {
        api.logout(dispatch);
        history('/')
    };
    const company = useSelector((state) => {
        return state.company?.value;
    });
    const socialMediaLink = useSelector(
        (state) => state.company?.socialMediaLinks
    );
    const onClose = () => {
        setVisible(false);
    };
    const toogleSearch = () => {
        setSearch(!search);
    };
    useEffect(() => {
        window.addEventListener("scroll", () => {
          setScroll(window.scrollY > 1);
        });
      }, []);
    useEffect(() => {
        props.getCartList();
        api.allCategory().then((res) => {

            if (res.status === 200) {
                setCategory(res.data.filter(e =>
                    e.parent == null
                ))
            }
        }).catch((err) => { })
    }, []);

    const menu = (
        <Menu onClick={onClose} className="profile_drop">

            <Menu.Item key="3">
                <Link to="/my-profile">
                    <UserOutlined />My Profile
                </Link>
            </Menu.Item>
            <Menu.Item key="4">
                <Link to="/my-address">
                    <ShopOutlined /> My Address
                </Link>
            </Menu.Item>
            <Menu.Item key="1">
                <Link to="/cart">
                    <ShoppingCartOutlined /> Cart
                </Link>
            </Menu.Item>
            <Menu.Item key="2">
                <Link to="/checkout">
                    <BankOutlined /> Checkout
                </Link>
            </Menu.Item>
            <Menu.Item key="5">
                <Link to="/my-order">
                    <WalletOutlined /> My Order
                </Link>
            </Menu.Item>
            <Menu.Item key="6">
                <a onClick={logout}>
                    <LogoutOutlined /> Sign out
                </a>
            </Menu.Item>
        </Menu>
    );




    return (
        <React.Fragment>
            <HeaderSection>
                <div className='header_section'>
                    <div id={scroll ?  "scroll_head" : ""}>
                    <div className='wrapper'>
                        <div className='header_top_align'>
                            <div className='header_top_left'>
                                <ul>
                                    {
                                        socialMediaLink?.map((item) => {
                                            return (
                                                <li key={item?._id}>
                                                    <a href={item?.link} title={item?.label} target="_blank">
                                                        <img src={api.rootUrl + item.icon} alt={item?.label} /></a>
                                                </li>
                                            )
                                        })
                                    }
                                </ul>
                                {/* <Search
                            placeholder="Search products..."
                            onSearch={onSearch}
                        /> */}
                            </div>
                            <div className='header_top_center'>
                                
                                <Link to="/">
                                    <img src={company?.logo ? company?.logo : logo} alt="Logo" />
                                </Link>
                            </div>
                            <div className='header_top_right'>
                                <div className='shop_cart'>
                                    <ul>
                                        <li className='search_comp'>
                                            <img src={hsearch} alt="Search Bar" onClick={toogleSearch} />
                                            {search && <SearchBoxComponent style={{ minWidth: "200px" }} />}
                                        </li>
                                        {
                                            !loginTrue && loginTrue !== "" ? <Link to="/login">
                                                <li>
                                                    <img src={huser} alt="My Account" />
                                                </li>

                                            </Link>
                                                :
                                                <Dropdown overlay={menu} placement="bottomRight">
                                                    <div
                                                        onClick={(e) => e.preventDefault()}
                                                    >
                                                        <li>
                                                            <img src={huser} alt="My Account" />
                                                        </li>

                                                    </div>
                                                </Dropdown>
                                        }
                                        <li>
                                            <Link to="/cart">
                                                <Badge count={loginTrue != "" && !loginTrue ? 0 : cartList.length === 0 ? 0 : cartList.length} showZero size='small'>
                                                    <img src={hcart} alt="Cart" />
                                                </Badge>
                                            </Link>
                                        </li>
                                        <li className='mob_view_only'>
                                            <MobileMenu />
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        </div>
                        </div>
                        <div className='wrapper'>
                        <div className='header_bottom_align'>
                            <div className='header_bottom_center'>
                            <Menu mode="horizontal">
                                    <Menu.Item key="home">
                                        <Link to="/">Home</Link>
                                    </Menu.Item>
                                    <Menu.Item key="about">
                                        <Link to="/about">About Us</Link>
                                    </Menu.Item>
                                    <SubMenu key="Categories" title="Categories">
                                        {category?.map((e, i) => {
                                            return (
                                                <Menu.Item key={`menuPdttemp1_${i}`}>
                                                    <Link to={`/${e.category_name.toLowerCase().replace(/ /g, '-')
                                                        .replace(/[^\w-]+/g, '')}`}>
                                                        {e.category_name}
                                                    </Link>
                                                </Menu.Item>
                                            );
                                        })}
                                    </SubMenu>
                                    <SubMenu key="Policy" title="Policy">
                                        <Menu.Item key="1p">
                                            <Link to="/privacy-policy">Privacy Policy</Link>
                                        </Menu.Item>
                                        <Menu.Item key="2p">
                                            <Link to="/delivery-policy">Delivery Policy</Link>
                                        </Menu.Item>
                                        <Menu.Item key="3p">
                                            <Link to="/terms">Terms and Condition</Link>
                                        </Menu.Item>
                                        <Menu.Item key="4p">
                                            <Link to="/refund-policy">Refund Policy</Link>
                                        </Menu.Item>
                                        <Menu.Item key="5p">
                                            <Link to="/return-policy">Return Policy</Link>
                                        </Menu.Item>
                                        <Menu.Item key="6p">
                                            <Link to="/cancellation-policy">Cancellation Policy</Link>
                                        </Menu.Item>
                                    </SubMenu>
                                   
                                    <Menu.Item key="Enquiry">
                                        <Link to="/enquiry">Enquiry From</Link>
                                    </Menu.Item>
                                    {/* <Menu.Item key="my-address">
                                        <Link to="/my-address">My Address</Link>
                                    </Menu.Item>
                                    <Menu.Item key="my-profile">
                                        <Link to="/my-profile">My Profile</Link>
                                    </Menu.Item> */}
                                    <Menu.Item key="contact">
                                        <Link to="/contact">Contact Us</Link>
                                    </Menu.Item>

                                </Menu>
                            </div>
                        </div>
                    </div>
                </div>
            </HeaderSection>
        </React.Fragment>
    )
}
const mapStateToProps = (state) => ({
    products: state.cart.products,
});
export default connect(mapStateToProps, { getCartList })(FHeader);


const H2 = styled.h2`
   font-size:30px;
   margin : 0 0 35px;
   text-transform: uppercase;
   font-family: ${styles?.r_regular} !important;
   letter-spacing: 0.7px;

   @media screen and (max-width:768px) {
    text-align: center;
   }

`

const HeaderSection = styled.section`

#scroll_head {
position: fixed;
    top: 0;
    left: 0;
    z-index: 1000;
    width: 100%;
    background: #fff;
    padding: 15px 0;
    box-shadow: 0 0 12px rgb(0 0 0 / 10%);
}

    display: inline-block;
    width: 100%;
    position: relative;
.header_section {
    display: inline-block;
    width: 100%;
    position: relative;
    background: ${styles?.themebg};
    padding: 20px 0 10px 0;
}
.header_top_align {
    display: flex;
    align-items: center;
    justify-content: space-between;
    width: 100%;
    gap: 20px;
    position: relative;
    height: 55px;
}
.header_top_align .header_top_left {
    display: inline-block;
    position: relative;
    width: fit-content;

    ul {
        display: flex;
        align-items: center;
        gap: 17px;
        flex-wrap: wrap;
        padding: 0;
        margin: 0;
    }
    ul img {
        height: 32px;
    }

}
.header_top_align .header_top_center {
    width:fit-content;
    display: flex;
    position: absolute;
    top:50%;
    left:50%;
    transform: translate(-50%,-50%);
    align-items: center;

    img {
        position: relative;
        height: 55px;
    }

}
.header_top_align .header_top_right {
    width:fit-content;
    display: inline-block;

    ul {
        display: flex;
        margin: 0;
        padding: 0;
        align-items: center;
        gap: 17px;
        flex-wrap: wrap;
    }
    img {
        height: 25px;
        cursor: pointer;
    }
    a {
        display: flex;
    }


}


.search_comp {
    display: inline-block;
    position: relative;
    z-index: 100;
}
.search_comp {
    form {
         position: absolute;
    top: 130%;
    right: 0;
    }

    @media screen and (max-width:480px) {
        form {
            right: -100px;
        }
    }
}






.mob_view_only {
    display: none;
}

.header_bottom_align {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    justify-content: center;
    width: 100%;
    margin: 20px 0 0 0;
}

.header_bottom_center {
    width: 100%;
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    justify-content: center;
    ul {
        width: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    }
}



@media screen and (max-width:1200px) {

    .header_section {
        padding: 15px 0;
    }
    .header_bottom_align {
        display: none;
    }
    .mob_view_only {
        display: block;

        button {
            display: flex;
            align-items: center;
            background:transparent;
        }


    }
}


@media screen and (max-width:580px) {
    
    .header_top_align {
        height: auto;
    }
    .header_top_align .header_top_left {
        display: none;
    }
    .header_top_align .header_top_center {
        position: relative;
        top:0;
        left:0;
        transform: inherit;

        img {
            height: 40px;
        }
        
    }
    .header_top_align .header_top_right img {
    height: 20px;
}
.mob_view_only button {
    border: 0;
    padding: 0;
}









}











`