import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { message, Badge, Menu, Button, Dropdown, Drawer } from "antd";
import { CgMenuRight } from "react-icons/cg";
import Login from "../../Ecommerce/Login";
import SearchBoxComponent from "../../Ecommerce/SearchBox";
import {
  SearchOutlined,
  ShoppingCartOutlined,
  ShoppingOutlined,
  LogoutOutlined,
  DownOutlined,
  ProfileOutlined,
} from "@ant-design/icons";
import API from "../../Api/ApiService";
import { LoginOutlined } from '@ant-design/icons';
import { connect, useSelector, useDispatch } from "react-redux";
import { getCartList } from "../../Store/cartTypes";
import DefaultImg from "../../Assets/Images/default.png";
import styled, { ThemeProvider } from "styled-components";

const { SubMenu } = Menu;



function Permium1HE1(props) {
  const dispatch = useDispatch();
  const history = useNavigate();
  const loginTrue = useSelector((state) => state.user.currentUser?.token);
  const cartList = useSelector((state) => state.cart.products);
  const [search, setSearch] = useState(false);
  const [category, setCategory] = useState([]);
  const [productcategory, setProductcategory] = useState([]);
  const [visible, setVisible] = useState(false);
  const api = new API();
  const company = useSelector((state) => {
    return state.company?.value;
  });

  useEffect(() => {
    props.getCartList();
    api.allCategory().then((res)=>{
      if(res.status===200) {
        setCategory(res.data.filter(e=>
          e.parent==null
          ))
      }
    }).catch((err)=>{})
  }, []);

  const toogleSearch = () => {
    setSearch(!search);
  };

  const showDrawer = () => {
    setVisible(true);
  };

  const onClose = () => {
    setVisible(false);
  };

  const logout = (values) => {
    api.logout(dispatch);
    history('/')
  };

  const menu = (
    <Menu onClick={onClose}>
      <Menu.Item key="1_cart">
        <Link to="/cart">
          <ShoppingCartOutlined /> Cart
        </Link>
      </Menu.Item>
      <Menu.Item key="1_profile">
        <Link to="/my-profile">
          <ProfileOutlined /> Profile
        </Link>
      </Menu.Item>
      <Menu.Item key="1_order">
        <Link to="/my-order">
          <ShoppingOutlined /> My Order
        </Link>
      </Menu.Item>
      <Menu.Item key="1_signout">
        <a onClick={logout}>
          <LogoutOutlined /> Sign out
        </a>
      </Menu.Item>
    </Menu>
  );

  const size = {
    desktop: "1920px",
    laptop: "1440px",
    minilaptop: "1200px",
    tabletl: "992px",
    tablet: "768px",
    mobilel: "580px",
    mobilep: "480px",
    mobiles: "380px",
  };
   const device = {
    desktop: `@media screen and (max-width: ${size.desktop})`,
    laptop: `@media screen and (max-width: ${size.laptop})`,
    minilaptop: `@media screen and (max-width: ${size.minilaptop})`,
    tabletl: `@media screen and (max-width: ${size.tabletl})`,
    tablet: `@media screen and (max-width: ${size.tablet})`,
    mobilel: `@media screen and (max-width: ${size.mobilel})`,
    mobilep: `@media screen and (max-width: ${size.mobilep})`,
    mobiles: `@media screen and (max-width: ${size.mobiles})`,
  };
  
  const theme = {
    id: 1,
    color: "#000",
    background: "#000",
    border: "#ee8f0a",
    gray: "#888",
    bg70: "rgb(255 255 255 / 70%)",
    bglight: "#f5f5f5",
    titlesize: [
      {
        screen: "desktop",
        value: 30,
      },
      {
        screen: "tablet",
        value: 20,
      },
      {
        screen: "mobile",
        value: 20,
      },
    ],
    colcount: [
      {
        screen: "desktop",
        value: 3,
      },
      {
        screen: "tablet",
        value: 2,
      },
      {
        screen: "mobile",
        value: 1,
      },
    ],
    gap: [
      {
        screen: "desktop",
        value: 25,
      },
      {
        screen: "tablet",
        value: 20,
      },
      {
        screen: "mobile",
        value: 15,
      },
    ],
  };
  
  const Header = styled.header`
  width: 100%;
  display: inline-block;
  position: sticky;
  top: 0;
  left: 0;
  z-index: 1000;
  background: #fff;
  box-shadow: 0 0 10px rgb(0 0 0 / 20%);
  .ant-input-search .ant-input-group .ant-input-affix-wrapper:not(:last-child) {
    padding: 0;
  }
  input[type="search"] {
    border: 0 !important;
  }
  `;
  const WrapperFull = styled.div`
    max-width: 100%;
    padding: 0 20px;
  `;
  const HeaderAlign = styled.div`
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    width: 100%;
    position: relative;
    gap: 10px;
    padding: 18px 0;
  
    ${device.tablet} {
      padding: 15px 0 80px 0;
    }
  `;
  const HeaderLeft = styled.div`
    display: inline-block;
    width: fit-content;
    position: relative;
  `;
  const Logo = styled.img`
    height: 45px;
  `;
  const HeaderCenter = styled.div`
    display: inline-block;
    width: 500px;
    border-radius: 4px;
    overflow: hidden;
    input[type="search"] {
      padding: 9px 12px;
      border: 1px solid #d9d9d9;
      border-radius: 2px;
      color: #000;
    }
    input[type="search"]::placeholder {
      color: #888;
    }
    button {
      width: 55px;
      padding: 10px;
      height: 42px;
      border: 1px solid #d9d9d9;
      border-radius: 5px;
      background: #888;
      color: #fff !important;
      font-size: 18px;
    }
  
    ${device.minilaptop} {
      width: 350px;
    }
  
    ${device.tablet} {
      position: absolute;
      bottom: 15px;
      left: 0;
      width: 100%;
    }
  `;
  const HeaderRight = styled.div`
    display: flex;
    gap: 10px;
    align-items: center;
    flex-wrap: wrap;
  `;
  const HeaderShop = styled.div`
    display: inline-block;
    width: fit-content;
    button {
      display: flex;
      align-items: center;
      margin: 0 !important;
    }
    ${device.minilaptop} {
      button.ant-btn.ant-btn-text.ant-dropdown-trigger.ant-dropdown-link {
        margin: 0 !important;
      }
    }
  `;
  const HeaderMenu = styled.div`
    display: flex;
    button {
      display: flex;
      border: 0;
      align-items: center;
      flex-wrap: wrap;
  
      svg {
        font-size: 30px !important;
      }
    }
  `;

  return (
    <ThemeProvider theme={theme}>
      <Header className="Premium1_HE1" id={theme.id}>
        <WrapperFull>
          <HeaderAlign>
            <HeaderLeft>
              <Link to="/">
                <Logo className="Per_Logo" src={company.logo} />
              </Link>
            </HeaderLeft>
            <HeaderCenter>
              {/* {search && <SearchBoxComponent />} */}
              <SearchBoxComponent />
            </HeaderCenter>
            <HeaderRight>
              <HeaderShop>
                {!loginTrue && loginTrue!=="" ? (
                  <Link to="/login"><Button type="text"><LoginOutlined />Login</Button></Link>
                ) : (
                  <Dropdown overlay={menu}>
                    <Button
                      type="text"
                      className="ant-dropdown-link"
                      onClick={(e) => e.preventDefault()}
                    >
                      My Account
                      <DownOutlined />
                    </Button>
                  </Dropdown>
                )}
              </HeaderShop>
              <HeaderMenu>
                <Button
                  className="barsMenu"
                  type="outline"
                  onClick={showDrawer}
                >
                  <CgMenuRight />
                </Button>
                <Drawer
                  placement="right"
                  closable={false}
                  onClose={onClose}
                  open={visible}
                  className="HE_4_Menu"
                >
                  <span className="menu">
                    <Menu mode="inline" onClick={onClose}>
                      <Menu.Item key="home">
                        <Link to="/">Home</Link>
                      </Menu.Item>
                      <Menu.Item key="about">
                        <Link to="/about">About Us</Link>
                      </Menu.Item>

                      <SubMenu key="product" title="Product">
                        {category?.map((e, i) => {
                          return (
                            <Menu.Item key={`menuPdttemp3mob_${i}`}>
                              <Link
                                to={`/${e.category_name.toLowerCase().replace(/ /g, '-')
                                .replace(/[^\w-]+/g, '')}`}
                              >
                                {e.category_name}
                              </Link>
                            </Menu.Item>
                          );
                        })}
                      </SubMenu>
                      <Menu.Item key="contact">
                        <Link to="/contact">Contact Us</Link>
                      </Menu.Item>
                      <Menu.Item key="enquiry">
                        <Link to="/enquiry">Enquiry</Link>
                      </Menu.Item>
                    </Menu>
                  </span>

                  {!loginTrue && loginTrue!=="" && (
                    <Link to="/cart" onClick={onClose}>
                      <Badge count={cartList.length}>
                        <Button type="text">
                          <ShoppingCartOutlined />
                        </Button>
                      </Badge>
                    </Link>
                  )}

                  {!loginTrue && loginTrue!=="" ? (
                   <Link to="/login"><Button type="text"><LoginOutlined />Login</Button></Link>
                  ) : (
                    <Dropdown overlay={menu}>
                      <Button
                        type="text"
                        className="ant-dropdown-link"
                        onClick={(e) => e.preventDefault()}
                      >
                       My Account
                        <DownOutlined />
                      </Button>
                    </Dropdown>
                  )}
                </Drawer>
              </HeaderMenu>
            </HeaderRight>
          </HeaderAlign>
        </WrapperFull>
      </Header>
    </ThemeProvider>
  );
}
const mapStateToProps = (state) => ({
  products: state.cart.products,
});
export default connect(mapStateToProps, { getCartList })(Permium1HE1);
