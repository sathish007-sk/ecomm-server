import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import {  Badge, Menu, Button, Dropdown, Drawer,Tabs, Space,
  Tooltip,
  Avatar, } from "antd";
import { AiOutlineMenu } from "react-icons/ai";
import SearchBoxComponent from "../../Ecommerce/SearchBox";
import { LoginOutlined } from '@ant-design/icons';
import MobileMenu from "../MenuBar/MobileMenu";

import {
  SearchOutlined,
  ShoppingCartOutlined,
  ShoppingOutlined,
  LogoutOutlined,
  DownOutlined,
  ProfileOutlined,
  UserOutlined,
  MailFilled,
  PhoneFilled,

} from "@ant-design/icons";
import API from "../../Api/ApiService";
import { connect, useSelector, useDispatch } from "react-redux";
import { getCartList } from "../../Store/cartTypes";
import styled from "styled-components";
import { styles } from "../../Api/Data";
const user = JSON.parse(localStorage.getItem("persist:root"))?.company;
const colorCustom = user && JSON.parse(user).setColor;

const { SubMenu } = Menu;
function Header1(props) {
  const dispatch = useDispatch();
  const history = useNavigate();
  const loginTrue = useSelector((state) => state.user.currentUser?.token);
  const user = useSelector((state) => state.login);
  const cartList = useSelector((state) => state.cart.products);
  const [search, setSearch] = useState(false);
  const [category, setCategory] = useState([]);
  const [productcategory, setProductcategory] = useState([]);
  const [visible, setVisible] = useState(false);
  const api = new API();
  const company = useSelector((state) => {
    return state.company?.value;
  });
  const socialMediaLink = useSelector(
    (state) => state.company?.socialMediaLinks
  );

  useEffect(() => {
    props.getCartList();
    api.allCategory().then((res)=>{
      if(res.status===200) {
        setCategory(res.data.filter(e=>
          e.parent==null
          ))
      }
    }).catch((err)=>{})
  }, []);

  const toogleSearch = () => {
    setSearch(!search);
  };

  const showDrawer = () => {
    setVisible(true);
  };

  const onClose = () => {
    setVisible(false);
  };

  const logout = () => {
    api.logout(dispatch);
    history('/')
  };

  const menu = (
    <Menu onClick={onClose}>
      <Menu.Item key="1_cart">
        <Link to="/cart">
          <ShoppingCartOutlined /> Cart
        </Link>
      </Menu.Item>
      <Menu.Item key="1_profile">
        <Link to="/my-profile">
          <ProfileOutlined /> Profile
        </Link>
      </Menu.Item>
      <Menu.Item key="1_order">
        <Link to="/my-order">
          <ShoppingOutlined /> My Order
        </Link>
      </Menu.Item>
      <Menu.Item key="1_signout">
        <a onClick={logout}>
          <LogoutOutlined /> Sign out
        </a>
      </Menu.Item>
    </Menu>
  );

  return (
    <React.Fragment>
      <HeadSection>

     
    <header className="Temp1_Header">
      <nav className="Temp1_Navbar">
        <div className="Temp1_Header_Align">
          <div className="Temp1_Header_Logo">
            <Link to="/">
              <img className="logo" src={company.logo} />
            </Link>
          </div>

          <div className="Temp1_Header_DesktopMenu">
            <span className="menu">
              <Menu mode="horizontal">
                <Menu.Item key="home">
                  <Link to="/">Home</Link>
                </Menu.Item>
                <Menu.Item key="about">
                  <Link to="/about">About Us</Link>
                </Menu.Item>

                <SubMenu key="product" title="Product">
                  {category?.map((e, i) => {
                    return (
                      <Menu.Item key={`menuPdttemp1_${i}`}>
                        <Link to={`/${e.category_name.toLowerCase().replace(/ /g, '-')
                      .replace(/[^\w-]+/g, '')}`}>
                          {e.category_name}
                        </Link>
                      </Menu.Item>
                    );
                  })}
                </SubMenu>
                <Menu.Item key="contact">
                  <Link to="/contact">Contact Us</Link>
                </Menu.Item>
                <Menu.Item key="enquiry">
                  <Link to="/enquiry">Enquiry</Link>
                </Menu.Item>
              </Menu>
            </span>
          </div>

          <div className="Temp1_Header_ShopCart">
            {search && <SearchBoxComponent style={{ minWidth: "300px" }} />}

            <Button type="text" onClick={toogleSearch}>
              <SearchOutlined />
            </Button>

            {!loginTrue && loginTrue!=="" && (
              <Link to="/cart">
                <Badge count={loginTrue!="" && !loginTrue ? 0 : cartList.length}>
                  <Button type="text">
                    <ShoppingCartOutlined />
                  </Button>
                </Badge>
              </Link>
            )}

            {!loginTrue && loginTrue!=="" ? (
              <Link to="/login"><Button><LoginOutlined />Login</Button></Link>
            ) : (
              <Dropdown overlay={menu}>
                <Button
                  type="text"
                  className="ant-dropdown-link"
                  onClick={(e) => e.preventDefault()}
                >
                  My Account
                  <DownOutlined />
                </Button>
              </Dropdown>
            )}
          </div>

          <div className="Temp1_Header_MobileMenu">
            <MobileMenu />
            {/* <Button className="barsMenu" type="outline" onClick={showDrawer}>
              <AiOutlineMenu />
            </Button>

            <Drawer
                      placement="right"
                      closable={false}
                      onClose={onClose}
                      open={visible}
                      className="HE_6_Menu"
                      width={300}
                    >
                      <Tabs defaultActiveKey="1">
                        <Tabs.TabPane
                          tab="Menu"
                          key="1"
                          className="menu-contact"
                        >
                          <span className="menu">
                            <Menu mode="inline" onClick={onClose}>
                              <Menu.Item key="home">
                                <Link to="/">Home</Link>
                              </Menu.Item>
                              <Menu.Item key="about">
                                <Link to="/about">About Us</Link>
                              </Menu.Item>
                              <Menu.Item key="contact">
                                <Link to="/contact">Contact Us</Link>
                              </Menu.Item>
                              <Menu.Item key="enquiry">
                                <Link to="/enquiry">Enquiry</Link>
                              </Menu.Item>
                            </Menu>
                          </span>
                          {search && <SearchBoxComponent />}
                          <Button type="text" onClick={toogleSearch}>
                            <SearchOutlined />
                          </Button>                          
                        </Tabs.TabPane>
                        <Tabs.TabPane tab="Browse Categories" key="2">
                          <Menu mode="inline" onClick={onClose}>
                            {category?.map((e, i) => {
                              return (
                                <Menu.Item key={`menuPdttemp4_${i}`}>
                                  <Link
                                    to={`/${e.category_name
                                      .toLowerCase().replace(/ /g, '-')
                      .replace(/[^\w-]+/g, '')}`}
                                  >
                                    {e.category_name}
                                  </Link>
                                </Menu.Item>
                              );
                            })}
                          </Menu>
                        </Tabs.TabPane>
                      </Tabs>
                      <div className="Menu_Contact_Info">
                            <h3>Contact Info</h3>
                            <p>
                              {company.address?.address_line1},{" "}
                              {company.address?.address_line2},
                              {company.address?.area},{" "}
                              {company.address?.district?.name}-
                              {company.address?.pincode},
                              <br />
                              {company.address?.state?.name}
                            </p>
                            <div className="Template6_Footer_MailUs">
                              {company.email && (
                                <p>
                                  <a href={"mailto:" + company.email}>
                                    <MailFilled style={{ color: "#434242" }} />{" "}
                                    {company.email}
                                  </a>
                                </p>
                              )}
                              {company.landline_no && (
                                <p>
                                  <a href={"tel:" + company.landline_no}>
                                    <PhoneFilled style={{ color: "#434242" }} />{" "}
                                    {company.landline_no}
                                  </a>
                                </p>
                              )}
                            </div>
                            <div className="Template6_Footer_Social_Media">
                              <Space>
                                {socialMediaLink.map((e, i) => (
                                  <Tooltip title={e.label} key={`smL${i}`}>
                                    <a href={e.link} target="_blank">
                                      <Avatar
                                        gap={10}
                                        src={api.rootUrl + e.icon}
                                      ></Avatar>
                                    </a>
                                  </Tooltip>
                                ))}
                              </Space>
                            </div>
                          </div>
                    </Drawer> */}
          </div>
        </div>
      </nav>
    </header>
    </HeadSection>
    </React.Fragment>
  );
}
const mapStateToProps = (state) => ({
  products: state.cart.products,
});
export default connect(mapStateToProps, { getCartList })(Header1);



const HeadSection = styled.div`
position: sticky;
    top: 0;
    left: 0;
    z-index: 1000;
    background: #ffff;
    box-shadow: 0 0 8px rgb(0 0 0 / 15%);
.Temp1_Header {
    display: inline-block;
    width: 100%;
    position: sticky;
    padding: 15px 0;
    top: 0;
    left: 0;
    background: #fff;
    z-index: 1000;
    box-shadow: 0 0 5px rgb(0 0 0 / 7%);
    .ant-menu-horizontal {
      border: 0 !important;
    }
}
.Temp1_Header .Temp1_Navbar {
  display: inline-block;
  width: 100%;
  position: relative;
}
.Temp1_Header .Temp1_Navbar .Temp1_Header_Align {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  justify-content: space-between;
  width: 100%;
  padding: 0 25px;

  @media screen and (max-width:480px){
    padding: 0 10px;
  }
}
.Temp1_Header .Temp1_Navbar .Temp1_Header_Align .Temp1_Header_Logo {
  width: fit-content;
  display: inline-block;
}
.Temp1_Header .Temp1_Navbar .Temp1_Header_Align .Temp1_Header_Logo img {
    height: 50px;
}
.Temp1_Header .Temp1_Navbar .Temp1_Header_Align .Temp1_Header_DesktopMenu {
  width: fit-content;
  display: inline-block;
  margin: auto auto auto 30px;
}
.Temp1_Header .Temp1_Navbar .Temp1_Header_Align .Temp1_Header_ShopCart {
  width: fit-content;
  display: inline-block;
}
.Temp1_Header .Temp1_Navbar .Temp1_Header_Align .Temp1_Header_MobileMenu {
  display: none;
}
.Temp1_Header .Temp1_Navbar .Temp1_Header_Align .Temp1_Header_Logo img {
  padding: 0;
}
.Temp1_Header
  .Temp1_Navbar
  .Temp1_Header_Align
  .Temp1_Header_DesktopMenu
  .ant-menu-title-content
  a,
.Temp1_Header
  .Temp1_Navbar
  .Temp1_Header_Align
  .Temp1_Header_DesktopMenu
  .ant-menu-title-content {
  color: ${styles?.gray};
  font-family: ${styles?.regular};
  font-size: ${styles?.p};
}
.Temp1_Header
  .Temp1_Navbar
  .Temp1_Header_Align
  .Temp1_Header_DesktopMenu
  .ant-menu-horizontal {
  width: 500px;
}
.Temp1_Header
  .Temp1_Navbar
  .Temp1_Header_Align
  .Temp1_Header_DesktopMenu
  .ant-menu-horizontal:not(.ant-menu-dark)
  > .ant-menu-item,
.Temp1_Header
  .Temp1_Navbar
  .Temp1_Header_Align
  .Temp1_Header_DesktopMenu
  .ant-menu-horizontal:not(.ant-menu-dark)
  > .ant-menu-submenu {
  padding: 0 15px;
}
.Temp1_Header
  .Temp1_Navbar
  .Temp1_Header_Align
  .Temp1_Header_ShopCart
  .ant-btn
  .anticon {
  color: ${styles?.gray};
  font-size: ${styles?.p};
}
.Temp1_Header .Temp1_Navbar .Temp1_Header_Align .Temp1_Header_ShopCart {
  display: flex;
}
.Temp1_Header
  .Temp1_Navbar
  .Temp1_Header_Align
  .Temp1_Header_ShopCart
  .ant-btn {
  padding: 0 12px;
  display: flex;
  align-items: center;
}
.Temp1_Header
  .Temp1_Navbar
  .Temp1_Header_Align
  .Temp1_Header_ShopCart
  .ant-dropdown-trigger
  > .anticon.anticon-down,
.ant-dropdown-link > .anticon.anticon-down,
.Temp1_Header
  .Temp1_Navbar
  .Temp1_Header_Align
  .Temp1_Header_ShopCart
  .ant-dropdown-button
  > .anticon.anticon-down {
  align-items: center;
  justify-content: center;
  display: flex;
}
.Temp1_Header
  .Temp1_Navbar
  .Temp1_Header_Align
  .Temp1_Header_ShopCart
  .ant-dropdown-menu-title-content
  > a {
  color: ${styles?.gray};
}

.Temp1_Header .ant-badge-count {
  margin-top: 0px !important;
    right: 8px !important;
    height: 15px !important;
    min-width: 15px !important;
    width: 15px !important;
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
    font-size: 10px !important;
    font-weight: 700 !important;
    line-height: 17px !important;

}

.Temp1_Header .Temp1_Navbar .Temp1_Header_Align .Temp1_Header_ShopCart .ant-badge button.ant-btn.ant-btn-text {
    margin: 0 10px 0 0;
  }



@media screen and (max-width: 1200px) {
  .Temp1_Header .Temp1_Navbar .Temp1_Header_Align .Temp1_Header_DesktopMenu {
    display: none;
  }
   .Temp1_Header .Temp1_Navbar .Temp1_Header_Align .Temp1_Header_ShopCart {
    width: fit-content;
    margin: auto 15px auto auto;
  } 
  .Temp1_Header .Temp1_Navbar .Temp1_Header_Align {
    justify-content: inherit;
  }
  .Temp1_Header .Temp1_Navbar .Temp1_Header_Align .Temp1_Header_ShopCart button.ant-btn.ant-btn-text {
    display: none;
    margin: 0 !important;
  }
  .Temp1_Header .Temp1_Navbar .Temp1_Header_Align .Temp1_Header_ShopCart .ant-badge button.ant-btn.ant-btn-text {
    display: none;
    margin: 0;
  }
  .Temp1_Header .Temp1_Navbar .Temp1_Header_Align .Temp1_Header_MobileMenu {
    display: block;
    margin: auto 0 auto 0;
  }
  .Temp1_Header .Temp1_Navbar .Temp1_Header_Align .Temp1_Header_MobileMenu button {
    display: flex;
    align-items: center;
    justify-content: center;
  }

  
.ant-drawer-body {
    padding: 20px 20px !important;
}
.ant-drawer-right > .ant-drawer-content-wrapper {
    width: 280px !important;
}
.ant-btn.ant-btn-text.ant-dropdown-trigger.ant-dropdown-link {
    display: flex !important;
    width: 100% !important;
    align-items: center !important;
    margin: 10px 0 0 0 !important;
    padding: 5px 0 !important;
}



}


@media screen and (max-width: 768px) {

     
.ant-tabs > .ant-tabs-nav .ant-tabs-nav-list, .ant-tabs > div > .ant-tabs-nav .ant-tabs-nav-list {
    position: relative;
    display: flex;
    transition: transform 0.3s;
    width: fit-content;
    text-align: center;
    margin: auto;
}
.ant-tabs > .ant-tabs-nav .ant-tabs-nav-list, .ant-tabs > div > .ant-tabs-nav .ant-tabs-nav-list {
    width: fit-content;
    text-align: center;
    margin: auto;
}



}


@media screen and (max-width: 480px) {

.Temp1_Header .Temp1_Navbar .Temp1_Header_Align .Temp1_Header_Logo img {
    height: 35px;
}




}




`;