import React from 'react'
import Template from './Template'



const SelectTemplate = () => {

  return (
    <React.Fragment>
      <Template />
    </React.Fragment>
  )
}

export default SelectTemplate;